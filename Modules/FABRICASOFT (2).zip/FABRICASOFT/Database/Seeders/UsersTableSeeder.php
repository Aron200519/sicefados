<?php
namespace Modules\FABRICASOFT\Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Modules\SICA\Entities\Person;
use Modules\SICA\Entities\Role;use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Crear o actualizar usuario para Deimar Guarnizo (Aprendiz FABRICASOFT)
        $person = Person::where('document_number', '12345678')->first(); // Cambia esto por el número de documento real
        
        if (!$person) {
            // Si no existe la persona, la creamos
            $person = Person::create([
                'first_name' => 'Deimar',
                'first_last_name' => 'Guarnizo',
                'second_last_name' => 'García',
                'document_type' => 'Cédula de ciudadanía',
                'document_number' => '12345678',
                'personal_email' => 'deimarguarnizo5@gmail.com',
                'telephone1' => '3001234567',
                'address' => 'Dirección del aprendiz',
                'date_of_birth' => '1990-01-01',
                'gender' => 'Masculino',
                'marital_status' => 'Soltero(a)',
                'eps_id' => 1,
                'population_group_id' => 1,
                'pension_entity_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        // Crear o actualizar el usuario
        $user = User::updateOrCreate(
            ['email' => 'deimarguarnizo5@gmail.com'],
            [
                'nickname' => 'deimarguarnizo',
                'person_id' => $person->id,
                'email' => 'deimarguarnizo5@gmail.com',
                'password' => Hash::make('Degu4469'),
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );

        // Asignar el rol de aprendiz de FABRICASOFT
        $role = Role::where('slug', 'fabricasoft.apprentice')->first();
        
        if ($role) {
            // Verificar si el usuario ya tiene el rol asignado
            if (!$user->roles()->where('slug', 'fabricasoft.apprentice')->exists()) {
                $user->roles()->attach($role->id);
                $this->command->info("✓ Rol 'fabricasoft.apprentice' asignado al usuario {$user->email}");
            } else {
                $this->command->info("✓ El usuario {$user->email} ya tiene el rol 'fabricasoft.apprentice'");
            }
        } else {
            $this->command->warn("⚠ Rol 'fabricasoft.apprentice' no encontrado. Ejecuta primero RolesTableSeeder.");
        }

        // Crear registro de aprendiz en la tabla apprentices
        $course = \Modules\SICA\Entities\Course::first(); // Obtener el primer curso disponible
        
        if ($course) {
            $apprentice = \Modules\SICA\Entities\Apprentice::updateOrCreate(
                ['person_id' => $person->id, 'course_id' => $course->id],
                [
                    'apprentice_status' => 'EN FORMACIÓN',
                    'created_at' => now(),
                    'updated_at' => now(),
                ]
            );
            
            $this->command->info("✓ Registro de aprendiz creado para {$person->first_name} {$person->first_last_name}");
        } else {
            $this->command->warn("⚠ No se encontraron cursos disponibles para crear el registro de aprendiz.");
        }

        $this->command->info("✓ Usuario aprendiz 'deimarguarnizo5@gmail.com' creado/actualizado exitosamente");
        $this->command->info("  - Email: deimarguarnizo5@gmail.com");
        $this->command->info("  - Contraseña: Degu4469");
        $this->command->info("  - Rol: fabricasoft.apprentice");
    }
}