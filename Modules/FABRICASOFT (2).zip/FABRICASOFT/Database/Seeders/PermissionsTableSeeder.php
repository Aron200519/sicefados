<?php

namespace Modules\FABRICASOFT\Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\SICA\Entities\App;
use Modules\SICA\Entities\Permission;
use Modules\SICA\Entities\Role;

class PermissionsTableSeeder extends Seeder {
    public function run()
    {
        // Obtener aplicación FABRICASOFT
        $app = App::where('name', 'FABRICASOFT')->first();

        if (!$app) {
            $this->command->error('La aplicación FABRICASOFT no existe. Crea la app primero.');
            return;
        }
            ['slug' => 'fabricasoft.admin.welcome'],
            [
                'name' => 'Acceso al Rol de Administrador',
                'description' => 'Acceso al Rol de Administrador',
                'description_english' => 'Access to the Administrator Role',
                'app_id' => $app->id,
            ]
        );

        $permissions_admin[] = $admin_permission->id;

        // Asignar permisos al rol administrador
        $rol_admin = Role::where('slug', 'fabricasoft.admin')->first();
        if ($rol_admin) {
            $rol_admin->permissions()->syncWithoutDetaching($permissions_admin);
        } else {
            $this->command->warn('Rol fabricasoft.admin no encontrado. Crea el rol antes de ejecutar el seeder.');
        }        /** ============================================
         *  PERMISOS PARA APRENDIZ
         *  ============================================ */
        $permissions_apprentice = [];

        // Crear permiso
        $apprentice_permission = Permission::updateOrCreate(
            ['slug' => 'fabricasoft.apprentice.aprendiz'],
            [
                'name' => 'Acceso al Rol de Aprendiz',
                'description' => 'Acceso al Rol de Aprendiz',
                'description_english' => 'Access to the Apprentice Role',
                'app_id' => $app->id,
            ]
        );

        $permissions_apprentice[] = $apprentice_permission->id;

        // Asignar permisos al rol aprendiz
        $rol_apprentice = Role::where('slug', 'fabricasoft.apprentice')->first();
        if ($rol_apprentice) {
            $rol_apprentice->permissions()->syncWithoutDetaching($permissions_apprentice);
        } else {
            $this->command->warn('Rol fabricasoft.apprentice no encontrado. Crea el rol antes de ejecutar el seeder.');
        };
        /** ============================================
         *  PERMISOS PARA USUARIO
         *  ============================================ */
        $permissions_users = [];
        // Crear permiso
        $users_permission = Permission::updateOrCreate(
            ['slug' => 'fabricasoft.users.usuario'],
            [
                'name' => 'Acceso al Rol de Usuario',
                'description' => 'Acceso al Rol de Usuario',
                'description_english' => 'Access to the User Role',
                'app_id' => $app->id,
            ]
        );
        $permissions_users[] = $users_permission->id;
        // Permiso para ajustes de usuario
        $ajustes_permission = Permission::updateOrCreate(
            ['slug' => 'fabricasoft.ajustes'],
            [
                'name' => 'Ajustes FABRICASOFT',
                'description' => 'Acceso a ajustes de usuario en FABRICASOFT',
                'description_english' => 'FABRICASOFT User Settings Access',
                'app_id' => $app->id,
            ]
        );
        $permissions_users[] = $ajustes_permission->id;
        // Permiso para actualizar ajustes de usuario
        $ajustes_update_permission = Permission::updateOrCreate(
            ['slug' => 'fabricasoft.ajustes.update'],
            [
                'name' => 'Actualizar Ajustes FABRICASOFT',
                'description' => 'Permite actualizar los ajustes de usuario en FABRICASOFT',
                'description_english' => 'FABRICASOFT User Settings Update',
                'app_id' => $app->id,
            ]
        );
        $permissions_users[] = $ajustes_update_permission->id;
        // Asignar permisos al rol usuario
        $rol_users = Role::where('slug', 'fabricasoft.users')->first();
        if ($rol_users) {
            $rol_users->permissions()->syncWithoutDetaching($permissions_users);
        } else {
            $this->command->warn('Rol fabricasoft.users no encontrado. Crea el rol antes de ejecutar el seeder.');
        }    }
}
