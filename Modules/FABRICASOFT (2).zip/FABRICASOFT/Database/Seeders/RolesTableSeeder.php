<?php

namespace Modules\FABRICASOFT\Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Modules\SICA\Entities\Role;
use Modules\SICA\Entities\App;

class RolesTableSeeder extends Seeder
{
    public function run()
    {
        $app = App::where('name', 'FABRICASOFT')->firstOrFail();

        $roleadmin = Role::updateOrCreate(['slug' => 'fabricasoft.admin'], [
            'name' => 'Administrador',
            'description' => 'Administrador del sistema de Fabricasoft',
            'description_english' => 'Fabricasoft system administrator',
            'full_access' => 'No',
            'app_id' => $app->id,
        ]);

        $roleapprentice = Role::updateOrCreate(['slug' => 'fabricasoft.apprentice'], [
            'name' => 'Aprendiz',
            'description' => 'Aprendiz del sistema de Fabricasoft',
            'description_english' => 'Fabricasoft system apprentice',
            'full_access' => 'No',
            'app_id' => $app->id,
        ]);

        $roleusers = Role::updateOrCreate(['slug' => 'fabricasoft.users'], [
            'name' => 'Usuario',
            'description' => 'Usuario del sistema de Fabricasoft',
            'description_english' => 'Fabricasoft system user',
            'full_access' => 'No',
            'app_id' => $app->id,
        ]);

    }
}
