<?php

namespace Modules\FABRICASOFT\Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Modules\SICA\Entities\Role;

class FinalVerificationSeeder extends Seeder
{
    public function run()
    {
        echo "=== VERIFICACIÓN FINAL DEL SISTEMA FABRICASOFT ===\n\n";

        // Verificar roles
        $roles = Role::where('slug', 'like', 'fabricasoft.%')->get();
        echo "✅ Roles de FABRICASOFT encontrados: " . $roles->count() . "\n";
        foreach ($roles as $role) {
            echo "   - " . $role->name . " (" . $role->slug . ")\n";
        }

        // Verificar usuarios con roles
        $users = User::with('roles')->get();
        $adminCount = 0;
        $devCount = 0;
        $clientCount = 0;
        $noRoleCount = 0;

        foreach ($users as $user) {
            $hasFabricasoftRole = false;
            
            foreach ($user->roles as $role) {
                if (str_contains($role->slug, 'fabricasoft.')) {
                    $hasFabricasoftRole = true;
                    
                    if ($role->slug == 'fabricasoft.admin') {
                        $adminCount++;
                    } elseif ($role->slug == 'fabricasoft.apprentice') {
                        $devCount++;
                    } elseif ($role->slug == 'fabricasoft.users') {
                        $clientCount++;
                    }
                }
            }
            
            if (!$hasFabricasoftRole) {
                $noRoleCount++;
            }
        }

        echo "\n📊 ESTADÍSTICAS DE USUARIOS:\n";
        echo "   - Administradores: " . $adminCount . "\n";
        echo "   - Desarrolladores: " . $devCount . "\n";
        echo "   - Clientes: " . $clientCount . "\n";
        echo "   - Sin rol: " . $noRoleCount . "\n";
        echo "   - Total usuarios: " . $users->count() . "\n";

        if ($noRoleCount == 0) {
            echo "\n✅ SISTEMA COMPLETAMENTE CONFIGURADO\n";
            echo "   Todos los usuarios tienen roles asignados correctamente.\n";
        } else {
            echo "\n⚠️ ATENCIÓN: Hay " . $noRoleCount . " usuarios sin roles asignados.\n";
        }

        echo "\n🎯 FUNCIONALIDADES DISPONIBLES:\n";
        echo "   ✅ Panel de Administración: /fabricasoft/admin/users\n";
        echo "   ✅ Panel de Desarrolladores: /fabricasoft/desarrolladores\n";
        echo "   ✅ Panel de Clientes: /fabricasoft/users/users\n";
        echo "   ✅ Gestión de Solicitudes: /fabricasoft/solicitudes\n";
        echo "   ✅ Nueva Solicitud: /fabricasoft/nuevasolicitud\n";

        echo "\n🔐 ACCESO POR ROLES:\n";
        echo "   - Administradores: Pueden gestionar usuarios y ver todas las solicitudes\n";
        echo "   - Desarrolladores: Pueden ver grupos y proyectos asignados\n";
        echo "   - Clientes: Pueden crear y gestionar sus propias solicitudes\n";

        echo "\n🚀 EL SISTEMA ESTÁ LISTO PARA USAR\n";
    }
} 