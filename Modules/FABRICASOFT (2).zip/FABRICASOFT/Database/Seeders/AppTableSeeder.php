<?php
namespace Modules\FABRICASOFT\Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\SICA\Entities\App;class AppTableSeeder extends Seeder
{
    public function run()
    {
        $app = App::updateOrCreate(['name' => 'FABRICASOFT'], [
            'name' => 'FABRICASOFT',
            'description' => 'Sistema de gestión de proyectos de software',
            'description_english' => 'Software project management system',
        ]);

        echo "App FABRICASOFT creada/actualizada con ID: " . $app->id . "\n";    }
}