<?php

namespace Modules\FABRICASOFT\Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Modules\SICA\Entities\Role;

class VerifyRolesSeeder extends Seeder
{
    public function run()
    {
        $users = User::with('roles')->get();
        $adminCount = 0;
        $devCount = 0;
        $clientCount = 0;
        $noRoleCount = 0;

        foreach ($users as $user) {
            $hasFabricasoftRole = false;
            
            foreach ($user->roles as $role) {
                if (str_contains($role->slug, 'fabricasoft.')) {
                    $hasFabricasoftRole = true;
                    
                    if ($role->slug == 'fabricasoft.admin') {
                        $adminCount++;
                    } elseif ($role->slug == 'fabricasoft.apprentice') {
                        $devCount++;
                    } elseif ($role->slug == 'fabricasoft.users') {
                        $clientCount++;
                    }
                }
            }
            
            if (!$hasFabricasoftRole) {
                $noRoleCount++;
                echo "Usuario sin rol: " . $user->nickname . " (" . $user->email . ")\n";
            }
        }

        echo "\n=== RESUMEN DE ROLES ===\n";
        echo "Administradores: " . $adminCount . "\n";
        echo "Desarrolladores: " . $devCount . "\n";
        echo "Clientes: " . $clientCount . "\n";
        echo "Sin rol: " . $noRoleCount . "\n";
        echo "Total usuarios: " . $users->count() . "\n";
        
        if ($noRoleCount == 0) {
            echo "\n✅ TODOS LOS USUARIOS TIENEN ROLES ASIGNADOS\n";
        } else {
            echo "\n⚠️ HAY USUARIOS SIN ROLES ASIGNADOS\n";
        }
    }
} 