<?php

namespace Modules\FABRICASOFT\Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Modules\SICA\Entities\Role;

class AssignClientRoleSeeder extends Seeder
{
    public function run()
    {
        // Obtener el rol de cliente
        $clientRole = Role::where('slug', 'fabricasoft.users')->first();
        
        if (!$clientRole) {
            echo "Error: No se encontró el rol de cliente (fabricasoft.users)\n";
            return;
        }

        // Obtener todos los usuarios
        $allUsers = User::all();
        $usersAssigned = 0;

        foreach ($allUsers as $user) {
            // Verificar si el usuario ya tiene algún rol de FABRICASOFT
            $hasFabricasoftRole = $user->roles()->where('slug', 'like', 'fabricasoft.%')->exists();
            
            if (!$hasFabricasoftRole) {
                // Asignar rol de cliente al usuario
                $user->roles()->attach($clientRole->id);
                echo "Rol de cliente asignado a: " . $user->nickname . " (" . $user->email . ")\n";
                $usersAssigned++;
            } else {
                echo "Usuario " . $user->nickname . " ya tiene rol asignado, saltando...\n";
            }
        }

        echo "\nProceso completado. Se asignó rol de cliente a " . $usersAssigned . " usuarios.\n";
    }
} 