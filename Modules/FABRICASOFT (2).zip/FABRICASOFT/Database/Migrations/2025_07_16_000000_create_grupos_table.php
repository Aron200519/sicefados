<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::create('grupos', function (Blueprint $table) {
            $table->id();
            $table->string('nombre');
            $table->unsignedBigInteger('lider_id');
            $table->unsignedBigInteger('proyecto_id');
            $table->timestamps();
            $table->foreign('lider_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('proyecto_id')->references('id')->on('new_request')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('grupos');
    }
}; 