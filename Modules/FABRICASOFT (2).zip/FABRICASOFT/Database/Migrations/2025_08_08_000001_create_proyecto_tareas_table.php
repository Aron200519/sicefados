<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('proyecto_tareas', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('proyecto_id');
            $table->unsignedBigInteger('asignado_por');
            $table->unsignedBigInteger('asignado_a')->nullable();
            $table->string('titulo');
            $table->text('descripcion');
            $table->enum('prioridad', ['baja', 'media', 'alta', 'urgente'])->default('media');
            $table->date('fecha_limite')->nullable();
            $table->integer('tiempo_estimado')->default(8); // en horas
            $table->integer('progreso')->default(0); // porcentaje 0-100
            $table->enum('estado', ['pendiente', 'en_progreso', 'revision', 'completada', 'cancelada'])->default('pendiente');
            $table->text('comentarios')->nullable();
            $table->timestamp('fecha_inicio')->nullable();
            $table->timestamp('fecha_completado')->nullable();
            $table->timestamps();

            // Foreign keys
            $table->foreign('proyecto_id')->references('id')->on('new_request')->onDelete('cascade');
            $table->foreign('asignado_por')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('asignado_a')->references('id')->on('users')->onDelete('set null');

            // Indexes
            $table->index(['proyecto_id', 'estado']);
            $table->index(['asignado_a', 'estado']);
            $table->index('prioridad');
            $table->index('fecha_limite');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('proyecto_tareas');
    }
};
