<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('requerimientos', function (Blueprint $table) {
            // Agregar campos para las barras deslizantes
            $table->integer('complejidad')->default(5)->after('criterios_aceptacion');
            $table->integer('tiempo_estimado')->default(16)->after('complejidad');
            $table->integer('urgencia')->default(3)->after('tiempo_estimado');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('requerimientos', function (Blueprint $table) {
            $table->dropColumn(['complejidad', 'tiempo_estimado', 'urgencia']);
        });
    }
};
