<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::dropIfExists('new_request');
        Schema::create('new_request', function (Blueprint $table) {
            $table->id();
            // Información del Solicitante
            $table->string('applicant_name');
            $table->string('applicant_role');
            $table->string('company_name');
            $table->string('department');
            $table->string('email');
            $table->string('phone');
            $table->string('country');
            $table->string('department_location');
            $table->string('municipality');
            // Identificación del Proyecto
            $table->string('project_name');
            $table->enum('project_code_exists', ['yes','no'])->nullable();
            $table->string('project_code')->nullable();
            $table->enum('document_version', ['first','update','no_doc'])->nullable();
            $table->string('version_number')->nullable();
            $table->enum('has_documents', ['yes','no','unsure'])->nullable();
            $table->json('documents')->nullable(); // rutas de archivos
            $table->enum('system_type', ['new','expand','replace','other'])->nullable();
            $table->string('system_type_other')->nullable();
            $table->enum('reference_system', ['yes','no','unsure'])->nullable();
            $table->string('reference_system_details')->nullable();
            // Objetivos del Sistema
            $table->text('system_purpose');
            $table->text('general_objective');
            $table->text('specific_objectives');
            $table->json('system_goals')->nullable();
            $table->string('system_goals_other')->nullable();
            // Funcionalidades
            $table->json('functionalities')->nullable();
            $table->string('functionalities_other')->nullable();
            // Usuarios y Accesos
            $table->string('user_type_1');
            $table->text('user_functions_1');
            $table->string('user_type_2');
            $table->text('user_functions_2');
            $table->string('user_type_other')->nullable();
            $table->text('user_functions_other')->nullable();
            $table->enum('user_restrictions', ['yes','no','unsure']);
            // Características Técnicas
            $table->json('platform')->nullable();
            $table->enum('offline', ['yes','no','unsure']);
            $table->json('devices')->nullable();
            $table->string('devices_other')->nullable();
            $table->enum('integration', ['yes','no','unsure']);
            $table->string('integration_details')->nullable();
            $table->enum('database', ['yes','no','unsure']);
            $table->enum('backups', ['yes','no','unsure']);
            // Seguridad y Rendimiento
            $table->enum('security_level', ['high','medium','basic','unsure']);
            $table->enum('availability', ['24_7','business_hours','other']);
            $table->string('availability_other')->nullable();
            $table->integer('initial_users');
            $table->integer('future_users');
            $table->enum('load_time', ['3_seconds','5_seconds','no_preference']);
            // Entregas por Fases
            $table->enum('phased_delivery', ['yes','no','unsure']);
            $table->text('phase_1')->nullable();
            $table->text('phase_2')->nullable();
            $table->text('phase_3')->nullable();
            $table->text('phase_other')->nullable();
            // Documentación
            $table->json('documentation')->nullable();
            $table->string('documentation_other')->nullable();
            $table->enum('documentation_support', ['yes','no','unsure']);
            // Capacitación
            $table->enum('training_needed', ['yes','no','unsure']);
            $table->text('training_details')->nullable();
            $table->json('training_type')->nullable();
            $table->string('training_type_other')->nullable();
            // Cronograma
            $table->date('start_date');
            $table->date('end_date');
            $table->enum('strict_deadlines', ['yes','no','unsure']);
            $table->text('deadlines_details')->nullable();
            // Presupuesto
            $table->enum('budget_defined', ['yes','no','unsure']);
            $table->string('budget_details')->nullable();
            $table->enum('budget_includes_support', ['yes','no','unsure']);
            // Proceso Actual
            $table->text('current_process');
            $table->enum('has_process_documents', ['yes','no','unsure']);
            $table->json('process_documents')->nullable(); // rutas de archivos
            $table->string('status')->default('pendiente');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('new_request');
    }
}; 