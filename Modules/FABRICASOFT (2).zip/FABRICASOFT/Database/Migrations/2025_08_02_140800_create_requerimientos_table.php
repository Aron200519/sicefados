<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('requerimientos', function (Blueprint $table) {
            $table->id();
            $table->string('titulo');
            $table->text('descripcion');
            $table->unsignedBigInteger('proyecto_id');
            $table->enum('tipo', ['funcional', 'no_funcional', 'tecnico', 'usuario']);
            $table->enum('prioridad', ['alta', 'media', 'baja']);
            $table->enum('estado', ['pendiente', 'en_analisis', 'aprobado', 'rechazado', 'implementado'])->default('pendiente');
            $table->text('criterios_aceptacion')->nullable();
            $table->unsignedBigInteger('creado_por');
            $table->unsignedBigInteger('asignado_a')->nullable();
            $table->date('fecha_limite')->nullable();
            $table->integer('tiempo_estimado_horas')->nullable();
            $table->text('comentarios')->nullable();
            $table->timestamps();

            // Foreign keys
            $table->foreign('proyecto_id')->references('id')->on('new_request')->onDelete('cascade');
            $table->foreign('creado_por')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('asignado_a')->references('id')->on('users')->onDelete('set null');

            // Indexes
            $table->index(['proyecto_id', 'estado']);
            $table->index(['creado_por', 'estado']);
            $table->index('tipo');
            $table->index('prioridad');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('requerimientos');
    }
};
