<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('proyecto_avances', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('proyecto_id');
            $table->unsignedBigInteger('usuario_id');
            $table->integer('porcentaje_avance'); // 0-100
            $table->text('descripcion');
            $table->timestamp('fecha_avance');
            $table->text('comentarios')->nullable();
            $table->json('archivos_adjuntos')->nullable();
            $table->timestamps();

            // Foreign keys
            $table->foreign('proyecto_id')->references('id')->on('new_request')->onDelete('cascade');
            $table->foreign('usuario_id')->references('id')->on('users')->onDelete('cascade');

            // Indexes
            $table->index(['proyecto_id', 'fecha_avance']);
            $table->index('usuario_id');
            $table->index('porcentaje_avance');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('proyecto_avances');
    }
};
