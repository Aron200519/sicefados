<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('respuestas_formularios', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('servicio_id');
            $table->unsignedBigInteger('pregunta_id');
            $table->text('respuesta');
            $table->timestamps();

            // Índices para mejorar el rendimiento
            $table->index('servicio_id');
            $table->index('pregunta_id');
            
            // Clave foránea para servicio_id (referencia a new_request)
            $table->foreign('servicio_id')->references('id')->on('new_request')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('respuestas_formularios');
    }
};
