<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up() {
        Schema::create('formulario_seguimiento', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('formulario_id');
            $table->unsignedBigInteger('servicio_id'); // ID de new_request
            $table->unsignedBigInteger('user_id'); // Usuario que llenó el formulario
            $table->unsignedBigInteger('assigned_user_id')->nullable(); // Desarrollador asignado
            $table->enum('estado', [
                'pendiente',
                'en_revision', 
                'en_desarrollo',
                'testing',
                'completado',
                'rechazado',
                'pausado'
            ])->default('pendiente');
            $table->text('comentarios')->nullable();
            $table->text('respuesta_admin')->nullable();
            $table->text('respuesta_desarrollador')->nullable();
            $table->timestamp('fecha_envio');
            $table->timestamp('fecha_revision')->nullable();
            $table->timestamp('fecha_desarrollo')->nullable();
            $table->timestamp('fecha_completado')->nullable();
            $table->integer('prioridad')->default(1); // 1=baja, 2=media, 3=alta, 4=urgente
            $table->boolean('notificado_admin')->default(false);
            $table->boolean('notificado_desarrollador')->default(false);
            $table->boolean('notificado_usuario')->default(false);
            $table->timestamps();

            // Índices para optimizar consultas
            $table->index(['formulario_id', 'estado']);
            $table->index(['user_id', 'estado']);
            $table->index(['assigned_user_id', 'estado']);
            $table->index('fecha_envio');
            $table->index('prioridad');

            // Claves foráneas
            $table->foreign('formulario_id')->references('id')->on('formularios')->onDelete('cascade');
            $table->foreign('servicio_id')->references('id')->on('new_request')->onDelete('cascade');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('assigned_user_id')->references('id')->on('users')->onDelete('set null');
        });
    }

    public function down() {
        Schema::dropIfExists('formulario_seguimiento');
    }
};

