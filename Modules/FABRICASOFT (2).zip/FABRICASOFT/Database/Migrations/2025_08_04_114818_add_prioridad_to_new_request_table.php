<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddPrioridadToNewRequestTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('new_request', function (Blueprint $table) {
            $table->enum('prioridad', ['alta', 'media', 'baja'])->default('media')->after('status');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('new_request', function (Blueprint $table) {
            $table->dropColumn('prioridad');
        });
    }
}
