# Seguridad FABRICASOFT

## Descripción
Este módulo implementa un sistema de seguridad robusto para el módulo FABRICASOFT que previene el acceso no autorizado a rutas protegidas y muestra mensajes de error apropiados.

## Características

### 1. Middlewares de Seguridad

#### FabricasoftAuthMiddleware
- **Ubicación**: `Modules/FABRICASOFT/Http/Middleware/FabricasoftAuthMiddleware.php`
- **Función**: Verifica que el usuario esté autenticado y tenga roles de FABRICASOFT
- **Aplicación**: Rutas que requieren autenticación básica

#### FabricasoftAdminMiddleware
- **Ubicación**: `Modules/FABRICASOFT/Http/Middleware/FabricasoftAdminMiddleware.php`
- **Función**: Verifica que el usuario esté autenticado y tenga rol de administrador
- **Aplicación**: Rutas administrativas

### 2. JavaScript de Seguridad

#### FabricasoftSecurity
- **Ubicación**: `Modules/FABRICASOFT/Resources/assets/js/security.js`
- **Función**: Maneja errores de autenticación en el frontend
- **Características**:
  - Intercepta peticiones AJAX y fetch
  - Muestra alertas de SweetAlert2
  - Redirige automáticamente al inicio
  - Maneja diferentes tipos de errores

### 3. Rutas Protegidas

#### Rutas Públicas (Sin autenticación)
- `/fabricasoft/index` - Página principal

#### Rutas con Autenticación Básica
- `/fabricasoft/apprentices/aprendiz` - Panel de aprendices
- `/fabricasoft/users/users` - Panel de usuarios
- `/fabricasoft/desarrolladores` - Panel de desarrolladores
- `/fabricasoft/solicitudes` - Gestión de solicitudes
- `/fabricasoft/nuevasolicitud` - Nueva solicitud

#### Rutas Administrativas
- `/fabricasoft/admin/*` - Todas las rutas administrativas
- Gestión de usuarios
- Gestión de formularios
- Pre-registros
- Notificaciones

## Implementación

### 1. Registro de Middlewares
Los middlewares se registran en `Modules/FABRICASOFT/Providers/FABRICASOFTServiceProvider.php`:

```php
protected function registerMiddleware()
{
    $router = $this->app['router'];
    
    $router->aliasMiddleware('fabricasoft.auth', \Modules\FABRICASOFT\Http\Middleware\FabricasoftAuthMiddleware::class);
    $router->aliasMiddleware('fabricasoft.admin', \Modules\FABRICASOFT\Http\Middleware\FabricasoftAdminMiddleware::class);
}
```

### 2. Aplicación en Rutas
Las rutas están organizadas en grupos según el nivel de seguridad requerido:

```php
// Rutas públicas
Route::get('/index', 'FABRICASOFTController@index');

// Rutas con autenticación básica
Route::middleware([FabricasoftAuthMiddleware::class])->group(function() {
    // Rutas protegidas
});

// Rutas administrativas
Route::middleware([FabricasoftAdminMiddleware::class])->group(function() {
    // Rutas de admin
});
```

### 3. Manejo de Errores

#### Respuestas JSON (AJAX)
```json
{
    "error": true,
    "message": "No tienes permisos para acceder a esta sección.",
    "script": "<script>Swal.fire({...})</script>"
}
```

#### Respuestas HTTP
- **403 Forbidden**: Para usuarios no autenticados o sin permisos
- **Redirect**: Redirección al inicio con mensaje de error

### 4. Frontend Integration

El JavaScript se carga automáticamente en todos los layouts del módulo:

```html
<script src="{{ asset('modules/fabricasoft/js/security.js') }}"></script>
```

## Uso

### Para Desarrolladores

1. **Agregar nueva ruta protegida**:
   ```php
   Route::middleware([FabricasoftAuthMiddleware::class])->group(function() {
       Route::get('/nueva-ruta', 'Controller@method');
   });
   ```

2. **Agregar ruta administrativa**:
   ```php
   Route::middleware([FabricasoftAdminMiddleware::class])->group(function() {
       Route::get('/admin/nueva-ruta', 'Controller@method');
   });
   ```

### Para Usuarios

- **Usuarios no registrados**: Serán redirigidos al inicio con mensaje de error
- **Usuarios sin roles**: Verán mensaje de permisos insuficientes
- **Usuarios con permisos**: Acceso normal a las funcionalidades

## Mensajes de Error

### Usuario No Autenticado
- **Título**: "Acceso Denegado"
- **Mensaje**: "No tienes permisos para acceder a esta sección. Debes estar registrado e iniciar sesión."
- **Acción**: Redirección automática al inicio

### Usuario Sin Permisos
- **Título**: "Permisos Insuficientes"
- **Mensaje**: "No tienes permisos para acceder a esta sección. Tu cuenta no tiene los roles necesarios."
- **Acción**: Redirección automática al inicio

### Usuario Sin Rol de Admin
- **Título**: "Permisos de Administrador Requeridos"
- **Mensaje**: "No tienes permisos de administrador para acceder a esta sección."
- **Acción**: Redirección automática al inicio

## Compilación de Assets

Para compilar los assets del módulo:

```bash
npm run dev
# o
npm run production
```

Los archivos se compilan a:
- `public/js/fabricasoft-security.js`
- `public/css/fabricasoft.css`

## Configuración

### Variables de Entorno
- `APP_ENV`: Controla si se cargan assets compilados o de desarrollo

### Rutas
- `route('home')`: URL de redirección por defecto

## Dependencias

### Backend
- Laravel Framework
- Middleware de autenticación
- Sistema de roles (SICA)

### Frontend
- SweetAlert2 (opcional, con fallback a alert nativo)
- jQuery (opcional, para interceptar AJAX)

## Seguridad

### Características de Seguridad
1. **Verificación de autenticación**: Todas las rutas protegidas verifican si el usuario está logueado
2. **Verificación de roles**: Se verifica que el usuario tenga los roles necesarios
3. **Protección CSRF**: Integrado con el sistema CSRF de Laravel
4. **Sanitización de datos**: Los datos se sanitizan antes de procesarse
5. **Logs de auditoría**: Todas las acciones se registran para auditoría

### Mejores Prácticas
1. Siempre usar los middlewares apropiados para cada ruta
2. No exponer información sensible en los mensajes de error
3. Mantener actualizados los roles y permisos
4. Revisar regularmente los logs de auditoría
5. Implementar rate limiting para prevenir ataques de fuerza bruta

## Troubleshooting

### Problemas Comunes

1. **Middleware no funciona**:
   - Verificar que esté registrado en el ServiceProvider
   - Limpiar caché: `php artisan cache:clear`

2. **JavaScript no se carga**:
   - Verificar que el archivo existe en la ruta correcta
   - Comprobar que los assets estén compilados

3. **Errores de permisos**:
   - Verificar que el usuario tenga los roles correctos
   - Revisar la configuración de roles en la base de datos

### Logs
Los errores se registran en:
- `storage/logs/laravel.log`
- Logs de auditoría del sistema

## Mantenimiento

### Actualizaciones
1. Revisar regularmente las rutas protegidas
2. Actualizar los middlewares según sea necesario
3. Mantener actualizado el JavaScript de seguridad
4. Revisar y actualizar la documentación

### Monitoreo
1. Revisar logs de acceso
2. Monitorear intentos de acceso no autorizado
3. Verificar que los middlewares funcionen correctamente
4. Probar regularmente las rutas protegidas 