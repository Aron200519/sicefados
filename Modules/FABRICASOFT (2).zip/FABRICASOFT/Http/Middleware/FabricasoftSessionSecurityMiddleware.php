<?php

namespace Modules\FABRICASOFT\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Log;
use App\Models\UserSession;
use App\Models\User;

class FabricasoftSessionSecurityMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        // Solo aplicar a usuarios autenticados
        if (!Auth::check()) {
            return $next($request);
        }

        $user = Auth::user();
        $currentSessionId = Session::getId();
        $userAgent = $request->header('User-Agent');
        $ipAddress = $request->ip();

        // Log para debug
        Log::info('FabricasoftSessionSecurityMiddleware - Usuario: ' . $user->id . ', Session: ' . $currentSessionId);

        // Limpiar sesiones expiradas
        UserSession::cleanExpiredSessions();

        // Buscar la sesión actual del usuario
        $currentUserSession = UserSession::where('user_id', $user->id)
            ->where('session_id', $currentSessionId)
            ->first();

        // Si no existe la sesión actual, verificar si hay otra sesión activa
        if (!$currentUserSession) {
            $activeSession = UserSession::where('user_id', $user->id)
                ->where('is_active', true)
                ->first();

            if ($activeSession) {
                Log::info('Sesión múltiple detectada - Usuario: ' . $user->id . ', Sesión activa: ' . $activeSession->session_id);
                // Hay otra sesión activa, invalidar la actual
                return $this->handleMultipleSessions($request, $activeSession);
            } else {
                // No hay sesiones activas, crear una nueva
                $this->createNewSession($user->id, $currentSessionId, $userAgent, $ipAddress);
                Log::info('Nueva sesión creada - Usuario: ' . $user->id . ', Session: ' . $currentSessionId);
            }
        } else {
            // La sesión existe, verificar si está activa
            if (!$currentUserSession->isActive()) {
                Log::info('Sesión expirada - Usuario: ' . $user->id . ', Session: ' . $currentSessionId);
                // La sesión expiró, crear una nueva
                $currentUserSession->deactivate();
                $this->createNewSession($user->id, $currentSessionId, $userAgent, $ipAddress);
            } else {
                // Actualizar la actividad de la sesión
                $currentUserSession->updateActivity();
            }
        }

        return $next($request);
    }

    /**
     * Manejar múltiples sesiones activas
     */
    private function handleMultipleSessions(Request $request, UserSession $activeSession)
    {
        // Invalidar la sesión actual
        Session::flush();
        Auth::logout();

        Log::info('Sesión cerrada por conflicto - Usuario: ' . $activeSession->user_id . ', Session: ' . $activeSession->session_id);

        if ($request->expectsJson() || $request->ajax()) {
            return response()->json([
                'error' => true,
                'message' => 'Tu sesión ha sido cerrada porque se detectó otra sesión activa en otro dispositivo.',
                'code' => 'SESSION_CONFLICT'
            ], 401);
        }

        // Redirigir con mensaje de error
        return redirect()->route('login')->with('error', 'Tu sesión ha sido cerrada porque se detectó otra sesión activa en otro dispositivo. Por favor, inicia sesión nuevamente.');
    }

    /**
     * Crear una nueva sesión de usuario
     */
    private function createNewSession(int $userId, string $sessionId, string $userAgent, string $ipAddress): void
    {
        // Desactivar todas las sesiones anteriores del usuario
        $deactivatedCount = UserSession::where('user_id', $userId)
            ->where('is_active', true)
            ->update(['is_active' => false]);

        if ($deactivatedCount > 0) {
            Log::info('Sesiones desactivadas: ' . $deactivatedCount . ' para usuario: ' . $userId);
        }

        // Crear la nueva sesión
        UserSession::create([
            'user_id' => $userId,
            'session_id' => $sessionId,
            'user_agent' => $userAgent,
            'ip_address' => $ipAddress,
            'last_activity' => now(),
            'is_active' => true
        ]);
    }
}
