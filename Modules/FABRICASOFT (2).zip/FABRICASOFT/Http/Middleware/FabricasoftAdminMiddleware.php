<?php

namespace Modules\FABRICASOFT\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class FabricasoftAdminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        // Verificar si el usuario está autenticado
        if (!Auth::check()) {
            if ($request->expectsJson()) {
                return response()->json([
                    'error' => 'No tienes permisos de administrador. Debes estar registrado e iniciar sesión.',
                    'redirect' => route('cefa.welcome')
                ], 403);
            }
            
            // Para peticiones AJAX, devolver JSON con script de error
            if ($request->ajax()) {
                return response()->json([
                    'error' => true,
                    'message' => 'No tienes permisos de administrador. Debes estar registrado e iniciar sesión.',
                    'script' => "
                        <script>
                            Swal.fire({
                                icon: 'error',
                                title: 'Acceso Denegado',
                                text: 'No tienes permisos de administrador. Debes estar registrado e iniciar sesión.',
                                confirmButtonText: 'Ir al Inicio',
                                allowOutsideClick: false
                            }).then((result) => {
                                window.location.href = '" . route('home') . "';
                            });
                        </script>
                    "
                ]);
            }
            
            // Para peticiones normales, redirigir con mensaje de error
            return redirect()->route('cefa.welcome')->with('error', 'No tienes permisos de administrador. Debes estar registrado e iniciar sesión.');
        }

        // Verificar si el usuario tiene rol de administrador de FABRICASOFT
        $user = Auth::user();
        $hasAdminRole = $user->hasRole('fabricasoft.admin');
        
        if (!$hasAdminRole) {
            if ($request->expectsJson()) {
                return response()->json([
                    'error' => 'No tienes permisos de administrador para acceder a esta sección.',
                    'redirect' => route('cefa.welcome')
                ], 403);
            }
            
            // Para peticiones AJAX, devolver JSON con script de error
            if ($request->ajax()) {
                return response()->json([
                    'error' => true,
                    'message' => 'No tienes permisos de administrador para acceder a esta sección.',
                    'script' => "
                        <script>
                            Swal.fire({
                                icon: 'warning',
                                title: 'Permisos de Administrador Requeridos',
                                text: 'No tienes permisos de administrador para acceder a esta sección.',
                                confirmButtonText: 'Ir al Inicio',
                                allowOutsideClick: false
                            }).then((result) => {
                                window.location.href = '" . route('home') . "';
                            });
                        </script>
                    "
                ]);
            }
            
            // Para peticiones normales, redirigir con mensaje de error
            return redirect()->route('cefa.welcome')->with('error', 'No tienes permisos de administrador para acceder a esta sección.');
        }

        return $next($request);
    }
} 