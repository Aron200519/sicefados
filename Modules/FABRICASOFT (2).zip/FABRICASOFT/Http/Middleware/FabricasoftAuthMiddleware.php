<?php

namespace Modules\FABRICASOFT\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

class FabricasoftAuthMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        // Verificar si el usuario está autenticado
        if (!Auth::check()) {
            if ($request->expectsJson()) {
                return response()->json([
                    'error' => 'No tienes permisos para acceder a esta sección. Debes estar registrado e iniciar sesión.',
                    'redirect' => route('cefa.welcome')
                ], 403);
            }
            
            // Para peticiones AJAX, devolver JSON con script de error
            if ($request->ajax()) {
                return response()->json([
                    'error' => true,
                    'message' => 'No tienes permisos para acceder a esta sección. Debes estar registrado e iniciar sesión.',
                    'script' => "
                        <script>
                            Swal.fire({
                                icon: 'error',
                                title: 'Acceso Denegado',
                                text: 'No tienes permisos para acceder a esta sección. Debes estar registrado e iniciar sesión.',
                                confirmButtonText: 'Ir al Inicio',
                                allowOutsideClick: false
                            }).then((result) => {
                                window.location.href = '" . route('home') . "';
                            });
                        </script>
                    "
                ]);
            }
            
            // Para peticiones normales, redirigir con mensaje de error
            return redirect()->route('cefa.welcome')->with('error', 'No tienes permisos para acceder a esta sección. Debes estar registrado e iniciar sesión.');
        }

        // Verificar si el usuario tiene roles de FABRICASOFT
        $user = Auth::user();
        $hasFabricasoftRole = $user->roles()->where('slug', 'like', 'fabricasoft.%')->exists();
        
        if (!$hasFabricasoftRole) {
            if ($request->expectsJson()) {
                return response()->json([
                    'error' => 'No tienes permisos para acceder a esta sección. Tu cuenta no tiene los roles necesarios.',
                    'redirect' => route('cefa.welcome')
                ], 403);
            }
            
            // Para peticiones AJAX, devolver JSON con script de error
            if ($request->ajax()) {
                return response()->json([
                    'error' => true,
                    'message' => 'No tienes permisos para acceder a esta sección. Tu cuenta no tiene los roles necesarios.',
                    'script' => "
                        <script>
                            Swal.fire({
                                icon: 'warning',
                                title: 'Permisos Insuficientes',
                                text: 'No tienes permisos para acceder a esta sección. Tu cuenta no tiene los roles necesarios.',
                                confirmButtonText: 'Ir al Inicio',
                                allowOutsideClick: false
                            }).then((result) => {
                                window.location.href = '" . route('home') . "';
                            });
                        </script>
                    "
                ]);
            }
            
            // Para peticiones normales, redirigir con mensaje de error
            return redirect()->route('cefa.welcome')->with('error', 'No tienes permisos para acceder a esta sección. Tu cuenta no tiene los roles necesarios.');
        }

        return $next($request);
    }
} 