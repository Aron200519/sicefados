<?php

namespace Modules\FABRICASOFT\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\PreregistrationRequest;
use App\Models\User;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Modules\FABRICASOFT\Emails\PreregistrationNotification;

class PreregistrationController extends Controller
{
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
          'full_name' => 'required|string|max:255',
          'document_type' => 'required|in:CC,CE,TI,PP,NIT',
          'document_number' => 'required|string|max:20',
          'company_name' => 'required|string|max:255',
          'email' => 'required|email|max:255',
          'password' => 'required|string|min:6',
          'country' => 'required|string|max:255',
          'municipality' => 'required|string|max:255',
          'position' => 'required|string|max:255',
          'department' => 'required|string|max:255',
          'phone' => 'required|string|max:255',
          'state' => 'required|string|max:255',
          'project_description' => 'required|string|max:100',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Por favor, complete todos los campos correctamente.',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $data = $request->all();
            $data['password'] = bcrypt($request->password);
            $preregistration = PreregistrationRequest::create($data);

            // Enviar notificación por correo al administrador
            $this->sendAdminNotification($preregistration);

            return response()->json([
                'success' => true,
                'message' => 'Solicitud enviada exitosamente'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al enviar la solicitud. Por favor, intente nuevamente.',
            ], 500);
        }
    }

    public function index()
    {
        $requests = PreregistrationRequest::orderBy('created_at', 'desc')->get();
        return view('fabricasoft::admin.preregistration.index', compact('requests'));
    }

    public function approve($id)
    {
        $request = PreregistrationRequest::findOrFail($id);
        
        try {
            DB::beginTransaction();
            
            // Crear persona en la tabla people si no existe
            $personId = $this->createOrGetPerson($request);
            
            // Verificar si ya existe un usuario con ese email
            $existingUser = User::where('email', $request->email)->first();
            
            if ($existingUser) {
                // Si existe, actualizar el usuario existente
                $user = $existingUser;
                $user->person_id = $personId;
                $user->password = $request->password; // Actualizar contraseña
                $user->save();
                
                Log::info('Usuario existente actualizado: ' . $user->email);
            } else {
                // Si no existe, crear nuevo usuario
                $fullName = trim($request->full_name);
                $nameParts = explode(' ', $fullName);
                $baseNickname = !empty($nameParts[0]) ? strtolower($nameParts[0]) : 'user';
                
                // Agregar timestamp para garantizar unicidad
                $nickname = $baseNickname . '_' . time();
                
                $user = new User();
                $user->nickname = $nickname;
                $user->email = $request->email;
                $user->person_id = $personId;
                $user->password = $request->password;
                $user->save();
                
                Log::info('Nuevo usuario creado: ' . $user->email);
            }
            
            // Asignar rol de cliente (si no lo tiene ya)
            $clientRole = \Modules\SICA\Entities\Role::where('slug', 'fabricasoft.users')->first();
            if ($clientRole && !$user->roles()->where('roles.id', $clientRole->id)->exists()) {
                $user->roles()->attach($clientRole->id);
                Log::info('Rol de cliente asignado al usuario: ' . $user->email);
            }
            
            // Actualizar estado del pre-registro
            $request->update([
                'status' => 'approved',
                'approved_at' => now()
            ]);
            
            DB::commit();
            
            // Enviar notificación por correo al solicitante
            $this->sendApprovalNotification($request);
            
            return redirect()->back()->with('success', 'Solicitud aprobada exitosamente. Usuario actualizado/creado con rol de cliente.');
            
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('Error al aprobar pre-registro: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Error al aprobar la solicitud: ' . $e->getMessage());
        }
    }

    public function reject(Request $request, $id)
    {
        $preregistration = PreregistrationRequest::findOrFail($id);
        $preregistration->update([
            'status' => 'rejected',
            'admin_notes' => $request->input('admin_notes'),
            'rejected_at' => now()
        ]);

        // Enviar notificación por correo al solicitante
        $this->sendRejectionNotification($preregistration);

        return redirect()->back()->with('success', 'Solicitud rechazada exitosamente');
    }

    private function sendAdminNotification($preregistration)
    {
        try {
            // Enviar correo al administrador (puedes cambiar el email por el del admin)
            Mail::to('admin@fabricasoft.com')->send(new PreregistrationNotification($preregistration, 'admin'));      
            Log::info('Notificación de nueva solicitud enviada al administrador',
                ['email' => $preregistration->email,
                'full_name' => $preregistration->full_name,
                'company' => $preregistration->company_name
            ]);
        } catch (\Exception $e) {
            Log::error('Error enviando notificación al administrador: ' . $e->getMessage());
        }
    }

    private function sendApprovalNotification($preregistration)
    {
        try {
            // Enviar correo de aprobación al solicitante
            Mail::to($preregistration->email)->send(new PreregistrationNotification($preregistration, 'approval'));      
            Log::info('Notificación de aprobación enviada al solicitante',
                ['email' => $preregistration->email,
                'full_name' => $preregistration->full_name
            ]);
        } catch (\Exception $e) {
            Log::error('Error enviando notificación de aprobación: ' . $e->getMessage());
        }
    }

    private function sendRejectionNotification($preregistration)
    {
        try {
            // Enviar correo de rechazo al solicitante
            Mail::to($preregistration->email)->send(new PreregistrationNotification($preregistration, 'rejection'));      
            Log::info('Notificación de rechazo enviada al solicitante',
                ['email' => $preregistration->email,
                'full_name' => $preregistration->full_name,
                'notes' => $preregistration->admin_notes
            ]);
        } catch (\Exception $e) {
            Log::error('Error enviando notificación de rechazo: ' . $e->getMessage());
        }
    }

    private function createOrGetPerson($preregistration)
    {
        // Verificar si ya existe una persona con ese email en cualquiera de las columnas de email
        $existingPerson = DB::table('people')
            ->where('personal_email', $preregistration->email)
            ->orWhere('misena_email', $preregistration->email)
            ->orWhere('sena_email', $preregistration->email)
            ->first();
        
        if ($existingPerson) {
            return $existingPerson->id;
        }
        
        // Crear nueva persona
        $population_group_id = DB::table('population_groups')->min('id') ?? 1;
        
        $personData = [
            'first_name' => explode(' ', $preregistration->full_name)[0],
            'first_last_name' => explode(' ', $preregistration->full_name)[1],
            'second_last_name' => explode(' ', $preregistration->full_name)[2] ?? 'Auto',
            'personal_email' => $preregistration->email,
            'telephone1' => $preregistration->phone,
            'document_type' => 'Cédula de ciudadanía',
            'document_number' => time(), // Usar timestamp como documento temporal
            'population_group_id' => $population_group_id,
            'eps_id' => 1,
            'pension_entity_id' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ];
        
        $personId = DB::table('people')->insertGetId($personData);
        return $personId;
    }
} 