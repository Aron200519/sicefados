<?php

namespace Modules\FABRICASOFT\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\FABRICASOFT\Entities\NewRequest;
use Illuminate\Support\Facades\Storage;

class NewRequestController extends Controller
{
    public function store(Request $request)
    {
        $data = $request->all();

        // Manejo de archivos adjuntos (documents, process_documents)
        if ($request->hasFile('documents')) {
            $files = [];
            foreach ($request->file('documents') as $file) {
                $files[] = $file->store('new_request/documents', 'public');
            }
            $data['documents'] = json_encode($files);
        }
        if ($request->hasFile('process_documents')) {
            $files = [];
            foreach ($request->file('process_documents') as $file) {
                $files[] = $file->store('new_request/process_documents', 'public');
            }
            $data['process_documents'] = json_encode($files);
        }

        // Manejo de campos múltiples (checkboxes)
        $checkboxFields = [
            'system_goals', 'functionalities', 'platform', 'devices', 'documentation', 'training_type'
        ];
        foreach ($checkboxFields as $field) {
            if ($request->has($field)) {
                $data[$field] = is_array($request->$field) ? json_encode($request->$field) : $request->$field;
            }
        }

        // Asegurar que el campo 'department' se guarde correctamente
        if (isset($data['department'])) {
            $data['department'] = $request->input('department');
        }

        $newRequest = NewRequest::create($data);

        if ($request->ajax() || $request->wantsJson()) {
            return response()->json(['success' => true, 'id' => $newRequest->id]);
        }
        return redirect()->back()->with('success', '¡Solicitud enviada correctamente!');
    }

    public function edit($id)
    {
        $solicitud = NewRequest::findOrFail($id);
        // Obtener las solicitudes del usuario autenticado (igual que en nuevasolicitud)
        $userEmail = auth()->user()->email;
        $userRequests = NewRequest::where('email', $userEmail)->get();
        return view('fabricasoft::layouts.masternuevasolicitud', compact('solicitud', 'userRequests'));
    }

    public function update(Request $request, $id)
    {
        $solicitud = NewRequest::findOrFail($id);
        $data = $request->all();
        // Manejo de archivos adjuntos (documents, process_documents)
        if ($request->hasFile('documents')) {
            $files = [];
            foreach ($request->file('documents') as $file) {
                $files[] = $file->store('new_request/documents', 'public');
            }
            $data['documents'] = json_encode($files);
        }
        if ($request->hasFile('process_documents')) {
            $files = [];
            foreach ($request->file('process_documents') as $file) {
                $files[] = $file->store('new_request/process_documents', 'public');
            }
            $data['process_documents'] = json_encode($files);
        }
        // Manejo de campos múltiples (checkboxes)
        $checkboxFields = [
            'system_goals', 'functionalities', 'platform', 'devices', 'documentation', 'training_type'
        ];
        foreach ($checkboxFields as $field) {
            if ($request->has($field)) {
                $data[$field] = is_array($request->$field) ? json_encode($request->$field) : $request->$field;
            }
        }
        $solicitud->update($data);
        return redirect()->route('fabricasoft.nuevasolicitud')->with('success', '¡Solicitud actualizada correctamente!');
    }

    public function destroy($id)
    {
        $solicitud = NewRequest::findOrFail($id);
        $solicitud->delete();
        return redirect()->route('fabricasoft.nuevasolicitud')->with('success', '¡Solicitud eliminada correctamente!');
    }
} 