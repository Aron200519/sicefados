<?php

namespace Modules\FABRICASOFT\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\User;
use App\Models\UserNotification;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Modules\FABRICASOFT\Entities\Formulario;
use Modules\FABRICASOFT\Entities\RespuestaFormulario;

class FABRICASOFTController extends Controller
{
    public function apprentices()
    {
        $user = Auth::user();
        $userId = $user->id;
        
        // Obtener estadísticas del usuario
        $stats = \Modules\FABRICASOFT\Entities\NewRequest::getProjectStatsByUser($userId);
        
        // Obtener proyectos activos del usuario (en desarrollo, aprobados, testing)
        $misProyectos = \Modules\FABRICASOFT\Entities\NewRequest::where('assigned_user_id', $userId)
            ->whereIn('status', ['en_desarrollo', 'aprobada', 'testing', 'revision'])
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();
        
        // Obtener tareas pendientes (proyectos pendientes)
        $tareasRecientes = \Modules\FABRICASOFT\Entities\NewRequest::where('assigned_user_id', $userId)
            ->where('status', 'pendiente')
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();
        
        return view('fabricasoft::aprendiz', compact('stats', 'misProyectos', 'tareasRecientes'));
    }

    public function aprendizDashboard()
    {
        $user = Auth::user();
        $userId = $user->id;
        
        // Obtener estadísticas del usuario
        $stats = \Modules\FABRICASOFT\Entities\NewRequest::getProjectStatsByUser($userId);
        
        // Obtener proyectos activos del usuario (en desarrollo, aprobados, testing)
        $misProyectos = \Modules\FABRICASOFT\Entities\NewRequest::where('assigned_user_id', $userId)
            ->whereIn('status', ['en_desarrollo', 'aprobada', 'testing', 'revision'])
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();
        
        // Calcular progresos para los proyectos activos usando lógica unificada
        $progresosProyectos = \Modules\FABRICASOFT\Entities\NewRequest::calcularProgresosParaProyectos($misProyectos);
        
        // Obtener tareas pendientes (proyectos pendientes)
        $tareasRecientes = \Modules\FABRICASOFT\Entities\NewRequest::where('assigned_user_id', $userId)
            ->where('status', 'pendiente')
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();
        
        // Obtener proyectos completados
        $proyectosCompletados = \Modules\FABRICASOFT\Entities\NewRequest::where('assigned_user_id', $userId)
            ->where('status', 'completado')
            ->orderBy('updated_at', 'desc')
            ->limit(3)
            ->get();
        
        // Calcular métricas adicionales
        $totalProyectos = \Modules\FABRICASOFT\Entities\NewRequest::where('assigned_user_id', $userId)->count();
        $proyectosActivos = \Modules\FABRICASOFT\Entities\NewRequest::where('assigned_user_id', $userId)
            ->whereIn('status', ['en_desarrollo', 'aprobada', 'testing', 'revision'])->count();
        $proyectosPendientes = \Modules\FABRICASOFT\Entities\NewRequest::where('assigned_user_id', $userId)
            ->where('status', 'pendiente')->count();
        
        // Obtener actividad reciente (últimos cambios en proyectos)
        $actividadReciente = \Modules\FABRICASOFT\Entities\NewRequest::where('assigned_user_id', $userId)
            ->whereNotNull('updated_at')
            ->orderBy('updated_at', 'desc')
            ->limit(5)
            ->get();
        
        return view('fabricasoft::aprendiz.dashboard', compact(
            'stats', 
            'misProyectos', 
            'tareasRecientes', 
            'proyectosCompletados',
            'totalProyectos',
            'proyectosActivos',
            'proyectosPendientes',
            'actividadReciente',
            'progresosProyectos'
        ));
    }

    public function aprendizProyectos()
    {
        $user = Auth::user();
        $userId = $user->id;
        
        // Obtener todos los proyectos del usuario (excluyendo rechazados)
        $proyectos = \Modules\FABRICASOFT\Entities\NewRequest::where('assigned_user_id', $userId)
            ->where('status', '!=', 'rechazado')
            ->orderBy('created_at', 'desc')
            ->get();
        
        // Calcular progresos usando lógica unificada
        $progresosProyectos = \Modules\FABRICASOFT\Entities\NewRequest::calcularProgresosParaProyectos($proyectos);
        
        // Calcular estadísticas por estado
        $estadisticas = [
            'total' => $proyectos->count(),
            'pendientes' => $proyectos->where('status', 'pendiente')->count(),
            'en_desarrollo' => $proyectos->where('status', 'en_desarrollo')->count(),
            'revision' => $proyectos->where('status', 'revision')->count(),
            'testing' => $proyectos->where('status', 'testing')->count(),
            'completados' => $proyectos->where('status', 'completado')->count(),
        ];
        
        return view('fabricasoft::aprendiz.proyectos', compact('proyectos', 'estadisticas', 'progresosProyectos'));
    }

    public function aprendizTareas()
    {
        $user = Auth::user();
        $userId = $user->id;
        
        // Obtener todos los proyectos asignados al aprendiz (excluyendo rechazados)
        $proyectos = \Modules\FABRICASOFT\Entities\NewRequest::where('assigned_user_id', $userId)
            ->where('status', '!=', 'rechazado')
            ->orderBy('created_at', 'desc')
            ->get();
        
        // Calcular progresos para cada proyecto
        $progresosProyectos = \Modules\FABRICASOFT\Entities\NewRequest::calcularProgresosParaProyectos($proyectos);
        
        // Calcular estadísticas generales
        $estadisticas = [
            'total' => $proyectos->count(),
            'pendientes' => $proyectos->where('status', 'pendiente')->count(),
            'en_desarrollo' => $proyectos->where('status', 'en_desarrollo')->count(),
            'revision' => $proyectos->where('status', 'revision')->count(),
            'testing' => $proyectos->where('status', 'testing')->count(),
            'completados' => $proyectos->where('status', 'completado')->count(),
        ];
        
        return view('fabricasoft::aprendiz.tareas', compact('proyectos', 'estadisticas', 'progresosProyectos'));
    }

    public function aprendizRequerimientos()
    {
        $user = Auth::user();
        $userId = $user->id;

        // Obtener proyectos asignados al aprendiz para el modal
        $proyectos = \Modules\FABRICASOFT\Entities\NewRequest::where('assigned_user_id', $userId)
            ->whereIn('status', ['en_desarrollo', 'pendiente', 'revision'])
            ->get();

        // Obtener requerimientos del aprendiz con información del proyecto
        $requerimientosConRespuestas = DB::table('requerimientos')
            ->leftJoin('new_request', 'requerimientos.proyecto_id', '=', 'new_request.id')
            ->leftJoin('respuestas_formulario', 'new_request.id', '=', 'respuestas_formulario.servicio_id')
            ->where('requerimientos.creado_por', $userId)
            ->select(
                'requerimientos.*',
                'new_request.project_name',
                'respuestas_formulario.pregunta',
                'respuestas_formulario.respuesta'
            )
            ->get();

        // Calcular estadísticas
        $estadisticas = [
            'total' => $requerimientosConRespuestas->count(),
            'conFormulario' => $requerimientosConRespuestas->whereNotNull('pregunta')->count(),
            'pendientes' => $requerimientosConRespuestas->where('estado', 'pendiente')->count(),
            'en_desarrollo' => $requerimientosConRespuestas->where('estado', 'en_analisis')->count(),
        ];

        return view('fabricasoft::aprendiz.requerimientos', compact('requerimientosConRespuestas', 'estadisticas', 'proyectos'));
    }

    public function aprendizReportes()
    {
        $user = Auth::user();
        $userId = $user->id;
        
        // Obtener todos los proyectos del usuario para reportes
        $proyectos = \Modules\FABRICASOFT\Entities\NewRequest::where('assigned_user_id', $userId)
            ->where('status', '!=', 'rechazado')
            ->orderBy('created_at', 'desc')
            ->get();
        
        // Calcular progresos usando lógica unificada
        $progresosProyectos = \Modules\FABRICASOFT\Entities\NewRequest::calcularProgresosParaProyectos($proyectos);
        
        // Calcular métricas detalladas
        $proyectosCompletados = $proyectos->where('status', 'completado')->count();
        $tareasCompletadas = $proyectos->whereIn('status', ['completado', 'aprobada'])->count();
        $horasTrabajadas = $proyectos->sum('estimated_hours') ?? 0;
        $eficiencia = $proyectos->count() > 0 ? round(($proyectosCompletados / $proyectos->count()) * 100, 1) : 0;
        
        // Calcular incrementos (simulado para este mes vs anterior)
        $incrementoProyectos = 15; // Simulado
        $incrementoTareas = 8; // Simulado
        $promedioHoras = $proyectos->count() > 0 ? round($horasTrabajadas / $proyectos->count(), 1) : 0;
        
        // Datos para gráficos usando lógica unificada
        $proyectosLabels = $proyectos->pluck('project_name')->toArray();
        $proyectosData = $proyectos->map(function($proyecto) use ($progresosProyectos) {
            return $progresosProyectos[$proyecto->id] ?? $proyecto->progreso_por_estado;
        })->toArray();
        
        // Distribución de tareas por estado
        $tareasDistribucion = [
            $proyectos->where('status', 'pendiente')->count(),
            $proyectos->where('status', 'en_desarrollo')->count(),
            $proyectos->where('status', 'revision')->count(),
            $proyectos->where('status', 'testing')->count(),
            $proyectos->where('status', 'completado')->count(),
        ];
        
        // Rendimiento por proyecto usando lógica unificada
        $rendimientoProyectos = $proyectos->map(function($proyecto) use ($progresosProyectos) {
            return (object) [
                'project_name' => $proyecto->project_name,
                'applicant_name' => $proyecto->applicant_name,
                'progreso' => $progresosProyectos[$proyecto->id] ?? $proyecto->progreso_por_estado,
                'tareas_completadas' => $proyecto->status === 'completado' ? 1 : 0,
                'total_tareas' => 1,
                'tiempo_estimado' => $proyecto->estimated_hours ?? 0,
                'tiempo_real' => $proyecto->estimated_hours ?? 0,
                'formulario_id' => $proyecto->formulario_id,
            ];
        });
        
        // Actividad reciente
        $actividadReciente = $proyectos->take(5)->map(function($proyecto) {
            return (object) [
                'descripcion' => "Proyecto '{$proyecto->project_name}' actualizado",
                'icono' => 'edit',
                'created_at' => $proyecto->updated_at ?? $proyecto->created_at
            ];
        });
        
        // Logros y metas
        $logros = [
            (object) ['titulo' => 'Primer Proyecto', 'descripcion' => 'Completar tu primer proyecto', 'completado' => $proyectosCompletados > 0, 'progreso' => null],
            (object) ['titulo' => 'Eficiencia 80%', 'descripcion' => 'Alcanzar 80% de eficiencia', 'completado' => $eficiencia >= 80, 'progreso' => $eficiencia],
            (object) ['titulo' => '5 Proyectos', 'descripcion' => 'Completar 5 proyectos', 'completado' => $proyectosCompletados >= 5, 'progreso' => $proyectosCompletados],
        ];
        
        return view('fabricasoft::aprendiz.reportes', compact(
            'proyectosCompletados',
            'tareasCompletadas', 
            'horasTrabajadas',
            'eficiencia',
            'incrementoProyectos',
            'incrementoTareas',
            'promedioHoras',
            'proyectosLabels',
            'proyectosData',
            'tareasDistribucion',
            'rendimientoProyectos',
            'actividadReciente',
            'logros',
            'progresosProyectos'
        ));
    }
    
    /**
     * Calcular el progreso de un proyecto basado en su estado
     */
    private function calcularProgresoProyecto($proyecto)
    {
        switch ($proyecto->status) {
            case 'pendiente': return 10;
            case 'en_desarrollo': return 40;
            case 'revision': return 70;
            case 'testing': return 85;
            case 'completado': return 100;
            default: return 0;
        }
    }

    /**
     * Calcular progreso avanzado basado en tareas y avances del desarrollador
     */
    private function calcularProgresoProyectoAvanzado($proyecto, $tareas, $avances)
    {
        // Progreso base por estado del proyecto
        $progresoBase = $this->calcularProgresoProyecto($proyecto);
        
        // Si no hay tareas, usar el progreso base
        if ($tareas->count() == 0) {
            return $progresoBase;
        }
        
        // Calcular progreso basado en tareas completadas
        $tareasCompletadas = $tareas->where('estado', 'completada')->count();
        $totalTareas = $tareas->count();
        $progresoTareas = $totalTareas > 0 ? ($tareasCompletadas / $totalTareas) * 100 : 0;
        
        // Calcular progreso basado en avances registrados
        $progresoAvances = 0;
        if ($avances->count() > 0) {
            $progresoAvances = $avances->sum('porcentaje_avance') / $avances->count();
        }
        
        // Combinar progresos: 40% estado base + 40% tareas + 20% avances
        $progresoFinal = ($progresoBase * 0.4) + ($progresoTareas * 0.4) + ($progresoAvances * 0.2);
        
        return min(100, max(0, $progresoFinal));
    }

    /**
     * Mostrar formulario para crear nuevo requerimiento
     */

    /**
     * Guardar nuevo requerimiento
     */
        public function aprendizRequerimientosGuardar(Request $request)
    {
        try {
            $request->validate([
                'titulo' => 'required|string|max:255',
                'descripcion' => 'required|string',
                'proyecto_id' => 'required|exists:new_request,id',
                'tipo' => 'required|in:funcional,no_funcional,tecnico,usuario',
                'prioridad' => 'required|in:alta,media,baja',
                'criterios_aceptacion' => 'nullable|string',
            ]);

            $user = Auth::user();

            // Verificar si ya existe un requerimiento con el mismo título en el mismo proyecto
            $existeRequerimiento = DB::table('requerimientos')
                ->where('titulo', $request->titulo)
                ->where('proyecto_id', $request->proyecto_id)
                ->where('creado_por', $user->id)
                ->exists();

            if ($existeRequerimiento) {
                return response()->json([
                    'success' => false,
                    'message' => 'Ya existe un requerimiento con este título en este proyecto.'
                ], 422);
            }

            // Crear el requerimiento
            $id = DB::table('requerimientos')->insertGetId([
                'titulo' => $request->titulo,
                'descripcion' => $request->descripcion,
                'proyecto_id' => $request->proyecto_id,
                'tipo' => $request->tipo,
                'prioridad' => $request->prioridad,
                'estado' => 'pendiente',
                'criterios_aceptacion' => $request->criterios_aceptacion,
                'creado_por' => $user->id,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            // Si es una petición AJAX, devolver JSON
            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Requerimiento creado exitosamente.',
                    'id' => $id
                ]);
            }

            return redirect()->route('fabricasoft.aprendiz.requerimientos')
                ->with('success', 'Requerimiento creado exitosamente.');

        } catch (\Exception $e) {
            // Si es una petición AJAX, devolver JSON con error
            if ($request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Error al crear el requerimiento: ' . $e->getMessage()
                ], 500);
            }

            return redirect()->back()
                ->with('error', 'Error al crear el requerimiento: ' . $e->getMessage())
                ->withInput();
        }
    }

    public function aprendizRequerimientosEliminar($id)
    {
        try {
            $user = Auth::user();
            
            // Verificar que el requerimiento existe
            $requerimiento = DB::table('requerimientos')
                ->where('id', $id)
                ->first();
            
            if (!$requerimiento) {
                return response()->json([
                    'success' => false,
                    'message' => 'Requerimiento no encontrado.'
                ], 404);
            }
            
            // Verificar si el usuario es admin o es el creador del requerimiento
            $isAdmin = DB::table('role_user')
                ->join('roles', 'role_user.role_id', '=', 'roles.id')
                ->where('role_user.user_id', $user->id)
                ->where('roles.slug', 'fabricasoft.admin')
                ->exists();
            
            $isCreator = ($requerimiento->creado_por == $user->id);
            
            if (!$isAdmin && !$isCreator) {
                return response()->json([
                    'success' => false,
                    'message' => 'No tienes permisos para eliminar este requerimiento.'
                ], 403);
            }
            
            // Eliminar el requerimiento
            DB::table('requerimientos')->where('id', $id)->delete();
            
            return response()->json([
                'success' => true,
                'message' => 'Requerimiento eliminado exitosamente.'
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al eliminar el requerimiento: ' . $e->getMessage()
            ], 500);
        }
    }

    public function aprendizProyectoDetalle($id)
    {
        $user = Auth::user();
        $userId = $user->id;
        
        // Obtener el proyecto específico del usuario
        $proyecto = \Modules\FABRICASOFT\Entities\NewRequest::where('id', $id)
            ->where('assigned_user_id', $userId)
            ->firstOrFail();
        
        // Obtener las respuestas del formulario si existen
        $respuestas = collect();
        if ($proyecto->formulario_id) {
            $respuestas = DB::table('respuestas_formulario')
                ->where('servicio_id', $id)
                ->get();
        }
        
        // Datos de ejemplo para las estadísticas (en un caso real vendrían de la base de datos)
        $progresoGeneral = 75;
        $tareasCompletadas = 3;
        $totalTareas = 5;
        $totalRequerimientos = 8;
        $tiempoEstimado = 40;
        $tiempoReal = 35;
        
        // Datos de ejemplo para las pestañas
        $requerimientos = [];
        $tareas = [];
        $documentos = [];
        $comentarios = [];
        
        return view('fabricasoft::aprendiz.proyecto-detalle', compact(
            'proyecto', 
            'respuestas',
            'progresoGeneral', 
            'tareasCompletadas', 
            'totalTareas', 
            'totalRequerimientos', 
            'tiempoEstimado', 
            'tiempoReal',
            'requerimientos',
            'tareas',
            'documentos',
            'comentarios'
        ));
    }

    public function aprendizProyectoEditar($id)
    {
        $user = Auth::user();
        $userId = $user->id;
        
        // Obtener el proyecto específico del usuario
        $proyecto = \Modules\FABRICASOFT\Entities\NewRequest::where('id', $id)
            ->where('assigned_user_id', $userId)
            ->firstOrFail();
        
        return view('fabricasoft::aprendiz.proyecto-editar', compact('proyecto'));
    }

    public function aprendizProyectoActualizar(Request $request, $id)
    {
        $user = Auth::user();
        $userId = $user->id;
        
        // Obtener el proyecto específico del usuario
        $proyecto = \Modules\FABRICASOFT\Entities\NewRequest::where('id', $id)
            ->where('assigned_user_id', $userId)
            ->firstOrFail();
        
        // Validar los datos
        $request->validate([
            'status' => 'required|in:' . \Modules\FABRICASOFT\Entities\NewRequest::getEstadosParaValidacion(),
            'prioridad' => 'required|in:alta,media,baja',
            'general_objective' => 'nullable|string|max:1000',
            'specific_objectives' => 'nullable|string|max:1000',
            'system_purpose' => 'nullable|string|max:1000',
            'system_type' => 'nullable|string|max:100',
            'platform' => 'nullable|string|max:100',
            'initial_users' => 'nullable|integer|min:1',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
            'apprentice_comments' => 'nullable|string|max:2000',
        ]);
        
        // Preparar los datos para actualizar, convirtiendo strings vacíos a null
        $updateData = [
            'status' => $request->status,
            'prioridad' => $request->prioridad,
            'general_objective' => $request->general_objective ?: null,
            'specific_objectives' => $request->specific_objectives ?: null,
            'system_purpose' => $request->system_purpose ?: null,
            'system_type' => $request->system_type ?: null,
            'platform' => $request->platform ?: null,
            'initial_users' => $request->initial_users ?: null,
            'start_date' => $request->start_date ?: null,
            'end_date' => $request->end_date ?: null,
            'apprentice_comments' => $request->apprentice_comments ?: null,
        ];
        
        try {
            // Actualizar el proyecto
            $proyecto->update($updateData);
            
            return redirect()->route('fabricasoft.aprendiz.proyectos')
                ->with('success', 'Proyecto actualizado correctamente.');
        } catch (\Exception $e) {
            Log::error('Error al actualizar proyecto: ' . $e->getMessage());
            Log::error('Datos a actualizar: ' . json_encode($updateData));
            
            return redirect()->back()
                ->with('error', 'Error al actualizar el proyecto: ' . $e->getMessage())
                ->withInput();
        }
    }

    public function users()
    {
        if (!Auth::check()) {
            return redirect()->route('login');
        }

        $userEmail = Auth::user()->email;
        $userRequests = DB::table('new_request')
            ->where('email', $userEmail)
            ->orderBy('created_at', 'desc')
            ->get();

        return view('fabricasoft::users', compact('userRequests'));
    }

    public function createUser()
    {
        $people = DB::table('people')->get();
        $roles = \Modules\SICA\Entities\Role::where('slug', 'like', 'fabricasoft.%')->get();
        return view('fabricasoft::admin.users.create', compact('people', 'roles'));
    }

    public function editUser($id)
    {
        $user = \App\Models\User::with('roles')->findOrFail($id);
        $people = DB::table('people')->get();
        $roles = \Modules\SICA\Entities\Role::where('slug', 'like', 'fabricasoft.%')->get();
        return view('fabricasoft::admin.users.edit', compact('user', 'people', 'roles'));
    }

    public function desarrolladores()
    {
        // Obtener TODOS los usuarios con rol de aprendiz (desarrolladores) sin filtrar por asignación
        $desarrolladores = \App\Models\User::whereHas('roles', function($query) {
            $query->where('slug', 'fabricasoft.apprentice');
        })->get();
        
        // Agregar información sobre si cada desarrollador es líder o miembro de algún grupo
        foreach ($desarrolladores as $dev) {
            $dev->es_lider = DB::table('grupos')->where('lider_id', $dev->id)->exists();
            $dev->es_miembro = DB::table('grupo_miembros')->where('user_id', $dev->id)->exists();
        }
        
        // Obtener TODOS los proyectos sin filtrar por status ni asignación
        $proyectosAprobados = DB::table('new_request')
            ->select('id', 'project_name', 'applicant_name', 'company_name', 'document_type', 'document_number', 'status', 'formulario_id')
            ->get();
        
        // Obtener grupos creados con información del líder y proyecto
        $grupos = DB::table('grupos')
            ->join('users', 'grupos.lider_id', '=', 'users.id')
            ->join('new_request', 'grupos.proyecto_id', '=', 'new_request.id')
            ->select('grupos.*', 'users.nickname as lider_nombre', 'users.email as lider_email', 'new_request.project_name', 'new_request.applicant_name', 'new_request.document_type', 'new_request.document_number', 'new_request.formulario_id')
            ->get();
        
        return view('fabricasoft::desarrolladores', compact('desarrolladores', 'proyectosAprobados', 'grupos'));
    }

    public function verGrupo($id)
    {
        // Obtener información completa del grupo
        $grupo = DB::table('grupos')
            ->join('users', 'grupos.lider_id', '=', 'users.id')
            ->join('new_request', 'grupos.proyecto_id', '=', 'new_request.id')
            ->leftJoin('formularios', 'new_request.formulario_id', '=', 'formularios.id')
            ->select(
                'grupos.*',
                'users.nickname as lider_nombre',
                'users.email as lider_email',
                'new_request.*',
                'formularios.nombre as formulario_nombre',
                'formularios.preguntas as formulario_preguntas'
            )
            ->where('grupos.id', $id)
            ->first();

        if (!$grupo) {
            return redirect()->back()->with('error', 'Grupo no encontrado.');
        }

        // Obtener las respuestas del formulario si existe
        $respuestas = null;
        if ($grupo->formulario_id) {
            $respuestas = DB::table('respuestas_formulario')
                ->where('servicio_id', $grupo->proyecto_id)
                ->get();
        }

        return view('fabricasoft::admin.ver_grupo', compact('grupo', 'respuestas'));
    }

    public function verGrupoJson($id)
    {
        // Obtener información completa del grupo
        $grupo = DB::table('grupos')
            ->join('users', 'grupos.lider_id', '=', 'users.id')
            ->join('new_request', 'grupos.proyecto_id', '=', 'new_request.id')
            ->leftJoin('formularios', 'new_request.formulario_id', '=', 'formularios.id')
            ->select(
                'grupos.*',
                'users.nickname as lider_nombre',
                'users.email as lider_email',
                'new_request.*',
                'formularios.nombre as formulario_nombre',
                'formularios.preguntas as formulario_preguntas'
            )
            ->where('grupos.id', $id)
            ->first();

        if (!$grupo) {
            return response()->json(['error' => 'Grupo no encontrado.'], 404);
        }

        // Obtener las respuestas del formulario si existe
        $respuestas = null;
        if ($grupo->formulario_id) {
            $respuestas = DB::table('respuestas_formulario')
                ->where('servicio_id', $grupo->proyecto_id)
                ->get();
        }

        return response()->json([
            'grupo' => $grupo,
            'respuestas' => $respuestas
        ]);
    }


    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        return view('fabricasoft::create');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('fabricasoft::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        return view('fabricasoft::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
    }

    public function storeUser(Request $request)
    {
        $request->validate([
            'nickname' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:6',
            'person_id' => 'required|numeric',
            'role_id' => 'required|exists:roles,id',
        ]);
        $personExists = DB::table('people')->where('id', $request->person_id)->exists();
        if (!$personExists) {
            // Obtener el primer id válido de population_groups
            $population_group_id = DB::table('population_groups')->min('id') ?? 1;
            $columns = DB::select('SHOW COLUMNS FROM people');
            $data = [];
            foreach ($columns as $col) {
                $name = $col->Field;
                if ($name === 'id') {
                    $data[$name] = $request->person_id;
                } else if ($name === 'created_at' || $name === 'updated_at') {
                    $data[$name] = now();
                } else if ($name === 'population_group_id') {
                    $data[$name] = $population_group_id;
                } else if ($name === 'eps_id' || $name === 'pension_entity_id') {
                    $data[$name] = 1;
                } else if (str_contains($col->Type, 'int')) {
                    $data[$name] = 0;
                } else if (str_contains($col->Type, 'date')) {
                    $data[$name] = '2000-01-01';
                } else if (str_contains($col->Type, 'varchar') && preg_match('/varchar\((\d+)\)/', $col->Type, $m) && (int)$m[1] <= 3) {
                    $data[$name] = 'NR';
                } else if (str_contains($col->Type, 'varchar') || str_contains($col->Type, 'text')) {
                    $data[$name] = 'No registra';
                } else {
                    $data[$name] = null;
                }
            }
            // Algunos campos clave con valores útiles
            $data['document_type'] = 'Cédula de ciudadanía';
            $data['document_number'] = $request->person_id;
            $data['first_name'] = 'Generado';
            $data['first_last_name'] = 'Auto';
            $data['second_last_name'] = 'Auto';
            DB::table('people')->insert($data);
        }
        $user = new User();
        $user->nickname = $request->nickname;
        $user->email = $request->email;
        $user->person_id = $request->person_id;
        $user->password = Hash::make($request->password);
        $user->save();
        
        // Asignar rol al usuario
        $user->roles()->attach($request->role_id);
        
        return redirect()->route('fabricasoft.admin.users.index')->with('success', 'Usuario creado correctamente');
    }

    public function updateUser(Request $request, $id)
    {
        $user = User::findOrFail($id);
        $request->validate([
            'nickname' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $user->id,
            'password' => 'nullable|string|min:6',
            'role_id' => 'required|exists:roles,id',
        ]);
        $personExists = DB::table('people')->where('id', $user->person_id)->exists();
        if (!$personExists) {
            return redirect()->back()->with('error', 'El Person ID no existe en la tabla people.')->withInput();
        }
        $user->nickname = $request->nickname;
        $user->email = $request->email;
        if ($request->filled('password')) {
            $user->password = Hash::make($request->password);
        }
        $user->save();
        
        // Actualizar rol del usuario
        $user->roles()->sync([$request->role_id]);
        
        return redirect()->route('fabricasoft.admin.users.index')->with('success', 'Usuario actualizado correctamente');
    }

    public function destroyUser($id)
    {
        $user = User::findOrFail($id);
        $user->delete();
        return redirect()->route('fabricasoft.admin.users.index')->with('success', 'Usuario eliminado correctamente');
    }

    public function solicitudes(Request $request)
    {
        // Verificar si el usuario tiene rol de administrador
        $user = Auth::user();
        $isAdmin = DB::table('role_user')
            ->join('roles', 'role_user.role_id', '=', 'roles.id')
            ->where('role_user.user_id', $user->id)
            ->where('roles.slug', 'fabricasoft.admin')
            ->exists();
        
        if ($isAdmin) {
            // Si es admin, mostrar vista de admin con filtro SOLO por email
            $query = DB::table('new_request');

            // Log para debugging
            \Log::info('Filtro aplicado:', [
                'email' => $request->input('email')
            ]);

            // Filtro SOLO por email específico
            if ($request->has('email') && $request->input('email')) {
                $query->where('email', 'like', '%' . $request->input('email') . '%');
                \Log::info('Filtro por email aplicado: ' . $request->input('email'));
            }

            // Obtener todas las solicitudes ordenadas por fecha de creación (más recientes primero)
            $allRequests = $query->orderBy('created_at', 'desc')->get();
            
            \Log::info('Total de solicitudes encontradas: ' . $allRequests->count());

            return view('fabricasoft::admin.solicitudes', compact('allRequests'));
        } else {
            // Si es usuario normal, mostrar vista de usuario con filtrado mejorado
            $userEmail = Auth::user()->email;
            $query = DB::table('new_request')->where('email', $userEmail);
            
            // Filtros adicionales para usuarios
            if ($request->has('status') && $request->input('status')) {
                $query->where('status', $request->input('status'));
            }
            
            if ($request->has('project_name') && $request->input('project_name')) {
                $query->where('project_name', 'like', '%' . $request->input('project_name') . '%');
            }
            
            $userRequests = $query->orderBy('created_at', 'desc')->get();

            return view('fabricasoft::nuevasolicitud', compact('userRequests'));
        }
    }

    public function solicitudesSoporte()
    {
        // Obtener todos los formularios personalizados
        $formularios = \Modules\FABRICASOFT\Entities\Formulario::orderBy('created_at', 'desc')->get();
        
        return view('fabricasoft::admin.solicitudes_soporte', compact('formularios'));
    }

    /**
     * Método específico para filtrar solicitudes por email
     */
    public function filtrarSolicitudesPorEmail(Request $request)
    {
        $email = $request->input('email');
        
        if (!$email) {
            return response()->json(['error' => 'Email requerido'], 400);
        }
        
        $solicitudes = DB::table('new_request')
            ->where('email', 'like', '%' . $email . '%')
            ->orderBy('created_at', 'desc')
            ->get();
            
        return response()->json([
            'success' => true,
            'solicitudes' => $solicitudes,
            'total' => $solicitudes->count()
        ]);
    }

    public function nuevasolicitud(Request $request)
    {
        if (!Auth::check()) {
            return redirect()->route('login');
        }

        $userEmail = Auth::user()->email; // Obtener el email del usuario autenticado
        $query = DB::table('new_request')->where('email', $userEmail);
        
        // Aplicar filtros si están presentes
        if ($request->has('status') && $request->input('status')) {
            $query->where('status', $request->input('status'));
        }
        
        if ($request->has('project_name') && $request->input('project_name')) {
            $query->where('project_name', 'like', '%' . $request->input('project_name') . '%');
        }
        
        $userRequests = $query->orderBy('created_at', 'desc')->get();

        return view('fabricasoft::nuevasolicitud', compact('userRequests'));
    }

    public function getPendingRequests()
    {
        // Obtener solicitudes pendientes
        $pendingRequests = DB::table('new_request')
            ->where('status', 'pendiente')
            ->orderBy('created_at', 'desc')
            ->get();

        // Obtener solicitudes aprobadas
        $approvedRequests = DB::table('new_request')
            ->where('status', 'aprobada')
            ->orderBy('created_at', 'desc')
            ->get();

        // Obtener solicitudes rechazadas
        $rejectedRequests = DB::table('new_request')
            ->where('status', 'rechazada')
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json([
            'pending' => $pendingRequests,
            'approved' => $approvedRequests,
            'rejected' => $rejectedRequests
        ]);
    }

    public function storeNewRequest(Request $request)
    {
        // Validación de los datos del formulario
        $validatedData = $request->validate([
            // 1. Información del Solicitante
            'applicant_name' => 'required|string|max:255',
            'document_type' => 'required|in:CC,CE,TI,PP,NIT',
            'document_number' => 'required|string|max:30',
            'applicant_role' => 'required|string|max:255',
            'company_name' => 'required|string|max:255',
            'department' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone' => 'required|string|max:20',
            'country' => 'required|string|max:255',
            'department_location' => 'required|string|max:255',
            'municipality' => 'required|string|max:255',
            // 2. Identificación del Proyecto
            'project_name' => 'required|string|max:255',
            'project_code_exists' => 'required|in:yes,no',
            'project_code' => 'nullable|string|max:255',
            'document_version' => 'required|in:first,update,no_doc',
            'version_number' => 'nullable|string|max:255',
            'has_documents' => 'required|in:yes,no,unsure',
            'documents' => 'nullable|array',
            'documents.*' => 'file|mimes:pdf,doc,docx,xls,xlsx,jpg,png|max:10240',
            'system_type' => 'required|in:new,expand,replace,other',
            'system_type_other' => 'nullable|string|max:255',
            'reference_system' => 'required|in:yes,no,unsure',
            'reference_system_details' => 'nullable|string|max:255',
            // 3. Objetivos del Sistema
            'system_purpose' => 'required|string',
            'general_objective' => 'required|string',
            'specific_objectives' => 'required|string',
            'system_goals' => 'nullable|array',
            'system_goals_other' => 'nullable|string|max:255',
            // 4. Funcionalidades del Sistema
            'functionalities' => 'nullable|array',
            'functionalities_other' => 'nullable|string|max:255',
            // 5. Usuarios y Accesos
            'user_type_1' => 'required|string|max:255',
            'user_functions_1' => 'required|string',
            'user_type_2' => 'required|string|max:255',
            'user_functions_2' => 'required|string',
            'user_type_other' => 'nullable|string|max:255',
            'user_functions_other' => 'nullable|string',
            'user_restrictions' => 'required|in:yes,no,unsure',
            // 6. Características Técnicas
            'platform' => 'nullable|array',
            'offline' => 'required|in:yes,no,unsure',
            'devices' => 'nullable|array',
            'devices_other' => 'nullable|string|max:255',
            'integration' => 'required|in:yes,no,unsure',
            'integration_details' => 'nullable|string|max:255',
            'database' => 'required|in:yes,no,unsure',
            'backups' => 'required|in:yes,no,unsure',
            // 7. Seguridad y Rendimiento
            'security_level' => 'required|in:high,medium,basic,unsure',
            'availability' => 'required|in:24_7,business_hours,other',
            'availability_other' => 'nullable|string|max:255',
            'initial_users' => 'required|integer|min:1',
            'future_users' => 'required|integer|min:1',
            'load_time' => 'required|in:3_seconds,5_seconds,no_preference',
            // 8. Entregas por Fases
            'phased_delivery' => 'required|in:yes,no,unsure',
            'phase_1' => 'nullable|string',
            'phase_2' => 'nullable|string',
            'phase_3' => 'nullable|string',
            'phase_other' => 'nullable|string',
            // 9. Documentación
            'documentation' => 'nullable|array',
            'documentation_other' => 'nullable|string|max:255',
            'documentation_support' => 'required|in:yes,no,unsure',
            // 10. Capacitación
            'training_needed' => 'required|in:yes,no,unsure',
            'training_details' => 'nullable|string',
            'training_type' => 'nullable|array',
            'training_type_other' => 'nullable|string|max:255',
            // 11. Cronograma
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'strict_deadlines' => 'required|in:yes,no,unsure',
            'deadlines_details' => 'nullable|string',
            // 12. Presupuesto
            'budget_defined' => 'required|in:yes,no,unsure',
            'budget_details' => 'nullable|string|max:255',
            'budget_includes_support' => 'required|in:yes,no,unsure',
            // 13. Proceso Actual
            'current_process' => 'required|string',
            'has_process_documents' => 'required|in:yes,no,unsure',
            'process_documents' => 'nullable|array',
            'process_documents.*' => 'file|mimes:pdf,doc,docx,xls,xlsx,jpg,png|max:10240',
        ]);

        // Forzar arrays para campos múltiples
        $validatedData['system_goals'] = (array)($validatedData['system_goals'] ?? []);
        $validatedData['functionalities'] = (array)($validatedData['functionalities'] ?? []);
        $validatedData['platform'] = (array)($validatedData['platform'] ?? []);
        $validatedData['devices'] = (array)($validatedData['devices'] ?? []);
        $validatedData['documentation'] = (array)($validatedData['documentation'] ?? []);
        $validatedData['training_type'] = (array)($validatedData['training_type'] ?? []);

        // Manejo de archivos adjuntos
        $documents = [];
        if ($request->hasFile('documents')) {
            foreach ($request->file('documents') as $file) {
                $filename = time() . '_' . $file->getClientOriginalName();
                $file->storeAs('public/documents', $filename);
                $documents[] = $filename;
            }
        }
        $validatedData['documents'] = json_encode($documents);

        // Manejo de documentos del proceso actual
        $processDocuments = [];
        if ($request->hasFile('process_documents')) {
            foreach ($request->file('process_documents') as $file) {
                $filename = time() . '_' . $file->getClientOriginalName();
                $file->storeAs('public/process_documents', $filename);
                $processDocuments[] = $filename;
            }
        }
        $validatedData['process_documents'] = json_encode($processDocuments);

        // Convertir arrays a JSON para almacenamiento
        $validatedData['system_goals'] = json_encode($validatedData['system_goals']);
        $validatedData['functionalities'] = json_encode($validatedData['functionalities']);
        $validatedData['platform'] = json_encode($validatedData['platform']);
        $validatedData['devices'] = json_encode($validatedData['devices']);
        $validatedData['documentation'] = json_encode($validatedData['documentation']);
        $validatedData['training_type'] = json_encode($validatedData['training_type']);

        // Establecer estado inicial
        $validatedData['status'] = 'pendiente';

        // Guardar en la base de datos
        DB::table('new_request')->insert($validatedData);

        // Obtener el ID de la solicitud insertada
        $requestId = DB::getPdo()->lastInsertId();

        // Notificar a todos los administradores sobre la nueva solicitud
        $adminUsers = User::whereHas('roles', function($query) {
            $query->where('slug', 'superadmin');
        })->get();

        foreach ($adminUsers as $admin) {
            UserNotification::create([
                'user_id' => $admin->id,
                'title' => 'Nueva Solicitud de Proyecto',
                'message' => "Se ha recibido una nueva solicitud para el proyecto: {$validatedData['project_name']} del cliente: {$validatedData['applicant_name']}",
                'type' => 'info',
                'module' => 'FABRICASOFT',
                'data' => [
                    'request_id' => $requestId,
                    'project_name' => $validatedData['project_name'],
                    'applicant_name' => $validatedData['applicant_name'],
                    'email' => $validatedData['email']
                ]
            ]);
        }

        // Notificar al cliente que su solicitud fue recibida
        $clientUser = User::where('email', $validatedData['email'])->first();
        if ($clientUser) {
            UserNotification::create([
                'user_id' => $clientUser->id,
                'title' => 'Solicitud Recibida',
                'message' => "Su solicitud para el proyecto '{$validatedData['project_name']}' ha sido recibida y está siendo revisada por nuestro equipo.",
                'type' => 'success',
                'module' => 'FABRICASOFT',
                'data' => [
                    'request_id' => $requestId,
                    'project_name' => $validatedData['project_name']
                ]
            ]);
        }

        return redirect()->route('fabricasoft.solicitudes')->with('success', 'Solicitud enviada correctamente. Será revisada por el equipo de desarrollo.');
    }

    public function updateStatus(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:' . \Modules\FABRICASOFT\Entities\NewRequest::getEstadosParaValidacion()
        ]);

        try {
            // Obtener información del proyecto antes de actualizar
            $project = DB::table('new_request')->where('id', $id)->first();
            
            if (!$project) {
                return response()->json(['success' => false, 'message' => 'Proyecto no encontrado'], 404);
            }

            // Verificar que solo se puedan cambiar estados de solicitudes pendientes
            if ($project->status !== 'pendiente' && in_array($request->status, ['aprobada', 'rechazado'])) {
                return response()->json(['success' => false, 'message' => 'Solo se pueden aprobar o rechazar solicitudes pendientes'], 400);
            }

            DB::table('new_request')
                ->where('id', $id)
                ->update([
                    'status' => $request->status,
                    'updated_at' => now()
                ]);

            // Notificar al cliente sobre el cambio de estado
            $clientUser = User::where('email', $project->email)->first();
            if ($clientUser) {
                $statusMessages = [
                    'pendiente' => 'está pendiente de revisión',
                    'aprobada' => 'ha sido aprobada y pasará a desarrollo',
                    'rechazado' => 'ha sido rechazada',
                    'en_desarrollo' => 'ha sido aprobado y está en desarrollo',
                    'testing' => 'está en fase de pruebas',
                    'revision' => 'está en revisión',
                    'completado' => 'ha sido completado',
                    'cancelado' => 'ha sido cancelado'
                ];

                $message = $statusMessages[$request->status] ?? "ha cambiado a estado: {$request->status}";

                UserNotification::create([
                    'user_id' => $clientUser->id,
                    'title' => 'Actualización de Solicitud',
                    'message' => "Su solicitud '{$project->project_name}' {$message}.",
                    'type' => $request->status === 'aprobada' ? 'success' : ($request->status === 'rechazado' ? 'error' : 'info'),
                    'module' => 'FABRICASOFT',
                    'data' => [
                        'request_id' => $id,
                        'project_name' => $project->project_name,
                        'old_status' => $project->status,
                        'new_status' => $request->status
                    ]
                ]);
            }

            // Si se asigna a un desarrollador, notificar al desarrollador
            if ($request->status === 'en_desarrollo' && $request->assigned_user_id) {
                $developer = User::find($request->assigned_user_id);
                if ($developer) {
                    UserNotification::create([
                        'user_id' => $developer->id,
                        'title' => 'Nuevo Proyecto Asignado',
                        'message' => "Se le ha asignado el proyecto '{$project->project_name}' para desarrollo.",
                        'type' => 'info',
                        'module' => 'FABRICASOFT',
                        'data' => [
                            'request_id' => $id,
                            'project_name' => $project->project_name,
                            'client_name' => $project->applicant_name
                        ]
                    ]);
                }
            }

            return response()->json(['success' => true, 'message' => 'Estado actualizado correctamente']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Error al actualizar el estado: ' . $e->getMessage()], 500);
        }
    }

    public function getRequestDetails($id)
    {
        try {
            // Verificar que el ID sea válido
            if (!$id || !is_numeric($id)) {
                return redirect()->back()->with('error', 'ID de solicitud inválido');
            }

            $request = DB::table('new_request')->where('id', $id)->first();
            
            if (!$request) {
                return redirect()->back()->with('error', 'Solicitud no encontrada');
            }

            // Obtener tareas del proyecto
            $tareas = DB::table('proyecto_tareas')
                ->where('proyecto_id', $id)
                ->orderBy('created_at', 'desc')
                ->get();

            // Obtener requerimientos del proyecto
            $requerimientos = DB::table('proyecto_requerimientos')
                ->where('proyecto_id', $id)
                ->orderBy('created_at', 'desc')
                ->get();

            return view('fabricasoft::admin.request_details', compact('request', 'tareas', 'requerimientos'));
        } catch (\Exception $e) {
            Log::error('Error en getRequestDetails: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Error interno del servidor: ' . $e->getMessage());
        }
    }

    public function getRequestDetailsJson($id)
    {
        try {
            // Verificar que el ID sea válido
            if (!$id || !is_numeric($id)) {
                return response()->json(['error' => 'ID de solicitud inválido'], 400);
            }

            $request = DB::table('new_request')->where('id', $id)->first();
            
            if (!$request) {
                return response()->json(['error' => 'Solicitud no encontrada'], 404);
            }

            return response()->json([
                'success' => true,
                'data' => $request
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Error interno del servidor: ' . $e->getMessage()], 500);
        }
    }

    public function listarFormularios()
    {
        // Aquí deberías obtener los formularios de la base de datos. Por ahora, dummy:
        $formularios = collect([]); // Cambia esto por el modelo real cuando esté listo
        return view('fabricasoft::admin.formularios_listado', compact('formularios'));
    }

    public function storeFormularioPersonalizado(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'preguntas' => 'required|array|min:1',
        ]);
        $formulario = Formulario::create([
            'nombre' => $request->nombre,
            'preguntas' => $request->preguntas,
        ]);
        return redirect()->route('fabricasoft.admin.solicitudes_soporte')
            ->with('success', 'Formulario guardado correctamente.');
    }

    public function verFormulario($id)
    {
        $formulario = \Modules\FABRICASOFT\Entities\Formulario::findOrFail($id);
        return view('fabricasoft::admin.formularios_ver', compact('formulario'));
    }

    public function verFormularioJson($id)
    {
        try {
            $formulario = \Modules\FABRICASOFT\Entities\Formulario::findOrFail($id);
            return response()->json([
                'id' => $formulario->id,
                'nombre' => $formulario->nombre,
                'preguntas' => $formulario->preguntas,
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'error' => 'Formulario no encontrado',
                'message' => 'El formulario con ID ' . $id . ' no existe.'
            ], 404);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Error interno del servidor',
                'message' => 'Ocurrió un error al cargar el formulario.'
            ], 500);
        }
    }

    public function editarFormulario($id)
    {
        $formulario = \Modules\FABRICASOFT\Entities\Formulario::findOrFail($id);
        return view('fabricasoft::admin.formularios_editar', compact('formulario'));
    }

    public function updateFormulario(Request $request, $id)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'preguntas' => 'required|array|min:1',
        ]);
        $formulario = \Modules\FABRICASOFT\Entities\Formulario::findOrFail($id);
        $formulario->update([
            'nombre' => $request->nombre,
            'preguntas' => $request->preguntas,
        ]);
        return redirect()->route('fabricasoft.admin.solicitudes_soporte')
            ->with('success', 'Formulario actualizado correctamente.');
    }

    public function eliminarFormulario($id)
    {
        try {
            // Buscar el formulario
            $formulario = \Modules\FABRICASOFT\Entities\Formulario::findOrFail($id);
            
            // Verificar si hay servicios asociados a este formulario
            $serviciosAsociados = DB::table('new_request')
                ->where('formulario_id', $id)
                ->count();
            
            if ($serviciosAsociados > 0) {
                return redirect()->back()->with('error', 'No se puede eliminar el formulario porque tiene servicios asociados.');
            }
            
            // Eliminar el formulario
            $formulario->delete();
            
            return redirect()->back()->with('success', 'Formulario eliminado correctamente.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Error al eliminar el formulario: ' . $e->getMessage());
        }
    }

    public function asociarFormularioServicio(Request $request)
    {
        $servicioId = $request->input('servicio_id');
        $formularioId = $request->input('formulario_id');
        
        $servicio = \Modules\FABRICASOFT\Entities\NewRequest::find($servicioId);
        if ($servicio) {
            $servicio->formulario_id = $formularioId;
            $servicio->save();
            
            return redirect()->back()->with('success', 'Formulario asociado correctamente al servicio.');
        }
        
        return redirect()->back()->with('error', 'Error al asociar el formulario.');
    }

    public function asignarAprendiz(Request $request)
    {
        $request->validate([
            'servicio_id' => 'required|exists:new_request,id',
            'aprendiz_id' => 'required|exists:users,id'
        ]);

        $servicio = \Modules\FABRICASOFT\Entities\NewRequest::find($request->servicio_id);
        $aprendiz = \App\Models\User::find($request->aprendiz_id);

        if ($servicio && $aprendiz) {
            $servicio->assigned_user_id = $request->aprendiz_id;
            // Cambiar el estado a 'en_desarrollo' cuando se asigna a un aprendiz
            if ($servicio->status === 'pendiente') {
                $servicio->status = 'en_desarrollo';
            }
            $servicio->save();

            return redirect()->back()->with('success', "Proyecto '{$servicio->project_name}' asignado correctamente al aprendiz '{$aprendiz->nickname}' y estado cambiado a 'En Desarrollo'.");
        }

        return redirect()->back()->with('error', 'Error al asignar el proyecto al aprendiz.');
    }

    public function guardarRespuestasFormulario(Request $request)
    {
        $request->validate([
            'formulario_id' => 'required|exists:formularios,id',
            'respuestas' => 'required|array',
        ]);
        $user = auth()->user();
        
        // Verificar si es una edición (existe servicio_id) o una nueva solicitud
        $servicioId = $request->input('servicio_id');
        $isEditing = !empty($servicioId);
        
        if ($isEditing) {
            // Verificar que el usuario sea el propietario del servicio
            $servicio = DB::table('new_request')
                ->where('id', $servicioId)
                ->where('email', $user->email)
                ->first();

            if (!$servicio) {
                return redirect()->back()->with('error', 'No tiene permisos para editar este formulario.');
            }
            
            // Eliminar respuestas existentes
            RespuestaFormulario::where('servicio_id', $servicioId)->delete();
            
            // Actualizar respuestas
            foreach ($request->respuestas as $preguntaId => $respuesta) {
                RespuestaFormulario::create([
                    'servicio_id' => $servicioId,
                    'pregunta_id' => $preguntaId,
                    'respuesta' => $respuesta,
                ]);
            }
            
            return redirect()->route('fabricasoft.nuevasolicitud')
                ->with('success', '¡Formulario actualizado correctamente!');
        } else {
            // Crear nueva solicitud
            $userProfile = DB::table('new_request')
                ->where('email', $user->email)
                ->orderBy('created_at', 'desc')
                ->first();
            
            // Crear nueva solicitud de servicio (new_request)
            $servicioId = DB::table('new_request')->insertGetId([
                'applicant_name' => $userProfile->applicant_name ?? $user->name ?? $user->nickname ?? $user->email,
                'applicant_role' => $userProfile->applicant_role ?? 'Cliente',
                'company_name' => $userProfile->company_name ?? '-',
                'department' => $userProfile->department ?? '-',
                'email' => $user->email,
                'phone' => $userProfile->phone ?? '-',
                'country' => $userProfile->country ?? '-',
                'department_location' => $userProfile->department ?? '-',
                'municipality' => $userProfile->municipality ?? '-',
                'project_name' => 'Solicitud vía formulario',
                'project_code_exists' => 'no',
                'project_code' => null,
                'document_version' => 'no_doc',
                'version_number' => null,
                'has_documents' => 'no',
                'documents' => json_encode([]),
                'system_type' => 'other',
                'system_type_other' => null,
                'reference_system' => 'no',
                'reference_system_details' => null,
                'system_purpose' => '-',
                'general_objective' => '-',
                'specific_objectives' => '-',
                'system_goals' => json_encode([]),
                'system_goals_other' => null,
                'functionalities' => json_encode([]),
                'functionalities_other' => null,
                'user_type_1' => '-',
                'user_functions_1' => '-',
                'user_type_2' => '-',
                'user_functions_2' => '-',
                'user_type_other' => null,
                'user_functions_other' => null,
                'user_restrictions' => 'no',
                'platform' => json_encode([]),
                'offline' => 'no',
                'devices' => json_encode([]),
                'devices_other' => null,
                'integration' => 'no',
                'integration_details' => null,
                'database' => 'no',
                'backups' => 'no',
                'security_level' => 'basic',
                'availability' => 'business_hours',
                'availability_other' => null,
                'initial_users' => 1,
                'future_users' => 1,
                'load_time' => 'no_preference',
                'phased_delivery' => 'no',
                'phase_1' => null,
                'phase_2' => null,
                'phase_3' => null,
                'phase_other' => null,
                'documentation' => json_encode([]),
                'documentation_other' => null,
                'documentation_support' => 'no',
                'training_needed' => 'no',
                'training_details' => null,
                'training_type' => json_encode([]),
                'training_type_other' => null,
                'start_date' => now()->addDays(30),
                'end_date' => now()->addDays(60),
                'strict_deadlines' => 'no',
                'deadlines_details' => null,
                'budget_defined' => 'no',
                'budget_details' => null,
                'budget_includes_support' => 'no',
                'current_process' => '-',
                'has_process_documents' => 'no',
                'process_documents' => json_encode([]),
                'status' => 'pendiente',
                'formulario_id' => $request->formulario_id,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            // Guardar las respuestas del formulario usando el modelo
            foreach ($request->respuestas as $preguntaId => $respuesta) {
                RespuestaFormulario::create([
                    'servicio_id' => $servicioId,
                    'pregunta_id' => $preguntaId,
                    'respuesta' => $respuesta,
                ]);
            }

            // Crear seguimiento automático del formulario
            \Modules\FABRICASOFT\Entities\FormularioSeguimiento::create([
                'formulario_id' => $request->formulario_id,
                'servicio_id' => $servicioId,
                'user_id' => $user->id,
                'estado' => 'pendiente',
                'fecha_envio' => now(),
                'prioridad' => 2, // Media
            ]);

            return redirect()->route('fabricasoft.nuevasolicitud')
                ->with('success', '¡Formulario enviado correctamente! Tu solicitud ha sido registrada con el ID: ' . $servicioId);
        }
    }

    public function notifications()
    {
        try {
            $user = auth()->user();
            
            // SOLO obtener solicitudes pendientes de proyectos (formularios)
            $pendingRequests = DB::table('new_request')
                ->where('status', 'pendiente')
                ->orderBy('created_at', 'desc')
                ->limit(10)
                ->get(['id', 'project_name', 'applicant_name', 'email', 'status', 'created_at']);

            // Convertir solicitudes pendientes en notificaciones
            $notifications = [];
            
            if ($pendingRequests->count() > 0) {
                foreach ($pendingRequests as $request) {
                    $notifications[] = [
                        'id' => $request->id,
                        'type' => 'request',
                        'title' => 'Nueva Solicitud de Proyecto',
                        'message' => "Proyecto: {$request->project_name} - Cliente: {$request->applicant_name}",
                        'notification_type' => 'warning',
                        'module' => 'FABRICASOFT',
                        'read_at' => null,
                        'created_at' => $request->created_at,
                        'project_name' => $request->project_name,
                        'applicant_name' => $request->applicant_name,
                        'email' => $request->email,
                        'status' => $request->status
                    ];
                }
            }
            // Si no hay solicitudes pendientes, el array $notifications permanece vacío

            return response()->json($notifications);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Error al cargar notificaciones'], 500);
        }
    }

    public function editarFormularioLlenado($servicio_id)
    {
        $user = auth()->user();
        
        // Verificar que el usuario sea el propietario del servicio
        $servicio = DB::table('new_request')
            ->where('id', $servicio_id)
            ->where('email', $user->email)
            ->first();

        if (!$servicio) {
            return redirect()->back()->with('error', 'No tiene permisos para editar este formulario.');
        }

        // Obtener el formulario asociado
        $formulario = Formulario::find($servicio->formulario_id);
        if (!$formulario) {
            return redirect()->back()->with('error', 'Formulario no encontrado.');
        }

        // Obtener las respuestas actuales usando el modelo
        $respuestas = RespuestaFormulario::where('servicio_id', $servicio_id)
            ->pluck('respuesta', 'pregunta_id')
            ->toArray();

        return view('fabricasoft::usuario.editar_formulario', compact('formulario', 'respuestas', 'servicio_id'));
    }

    public function actualizarFormularioLlenado(Request $request, $servicio_id)
    {
        $user = auth()->user();
        
        // Verificar que el usuario sea el propietario del servicio
        $servicio = DB::table('new_request')
            ->where('id', $servicio_id)
            ->where('email', $user->email)
            ->first();

        if (!$servicio) {
            return redirect()->back()->with('error', 'No tiene permisos para editar este formulario.');
        }

        $request->validate([
            'respuestas' => 'required|array',
        ]);

        // Actualizar las respuestas usando el modelo
        foreach ($request->respuestas as $preguntaId => $respuesta) {
            RespuestaFormulario::where('servicio_id', $servicio_id)
                ->where('pregunta_id', $preguntaId)
                ->update([
                    'respuesta' => $respuesta,
                ]);
        }

        return redirect()->back()->with('success', 'Formulario actualizado correctamente.');
    }

    public function eliminarFormularioLlenado(Request $request, $servicio_id)
    {
        $user = auth()->user();
        
        // Verificar que el usuario sea el propietario del servicio
        $servicio = DB::table('new_request')
            ->where('id', $servicio_id)
            ->where('email', $user->email)
            ->first();

        if (!$servicio) {
            return redirect()->back()->with('error', 'No tiene permisos para eliminar este formulario.');
        }

        // Eliminar las respuestas usando el modelo
        RespuestaFormulario::where('servicio_id', $servicio_id)->delete();

        // Eliminar el servicio
        DB::table('new_request')
            ->where('id', $servicio_id)
            ->delete();

        return redirect()->back()->with('success', 'Formulario eliminado correctamente.');
    }

    public function proyectos()
    {
        $proyectos = \Modules\FABRICASOFT\Entities\NewRequest::with('assignedUser')
            ->orderBy('created_at', 'desc')
            ->get();
        
        return view('fabricasoft::admin.proyectos', compact('proyectos'));
    }

    /**
     * Dashboard del cliente con seguimiento de avance
     */
    public function clienteDashboard()
    {
        $user = Auth::user();
        
        // Obtener proyectos del cliente
        $userRequests = \Modules\FABRICASOFT\Entities\NewRequest::where('email', $user->email)
            ->with('assignedUser')
            ->orderBy('created_at', 'desc')
            ->get();
        
        // Usar la lógica unificada de progreso
        $progresos = \Modules\FABRICASOFT\Entities\NewRequest::calcularProgresosParaProyectos($userRequests);
        
        // Calcular progreso promedio
        $progresoPromedio = 0;
        if ($userRequests->count() > 0) {
            $progresoPromedio = array_sum($progresos) / $userRequests->count();
        }
        
        // Obtener datos adicionales para las vistas
        $tareasPorProyecto = [];
        $requerimientosPorProyecto = [];
        $avancesPorProyecto = [];
        
        foreach ($userRequests as $proyecto) {
            // Obtener tareas del proyecto
            $tareas = DB::table('proyecto_tareas')
                ->where('proyecto_id', $proyecto->id)
                ->orderBy('created_at', 'desc')
                ->get();
            $tareasPorProyecto[$proyecto->id] = $tareas;
            
            // Obtener requerimientos del proyecto
            $requerimientos = DB::table('proyecto_requerimientos')
                ->where('proyecto_id', $proyecto->id)
                ->orderBy('created_at', 'desc')
                ->get();
            $requerimientosPorProyecto[$proyecto->id] = $requerimientos;
            
            // Obtener avances del proyecto
            $avances = DB::table('proyecto_avances')
                ->where('proyecto_id', $proyecto->id)
                ->orderBy('created_at', 'desc')
                ->get();
            $avancesPorProyecto[$proyecto->id] = $avances;
        }
        
        return view('fabricasoft::cliente.dashboard', compact(
            'userRequests', 
            'progresos', 
            'progresoPromedio',
            'tareasPorProyecto',
            'requerimientosPorProyecto',
            'avancesPorProyecto'
        ));
    }

    /**
     * Obtener detalles de un proyecto específico para el cliente
     */
    public function getDetalleProyectoCliente($id)
    {
        try {
            $user = Auth::user();
            
            // Verificar que el proyecto pertenece al cliente
            $proyecto = \Modules\FABRICASOFT\Entities\NewRequest::where('id', $id)
                ->where('email', $user->email)
                ->with('assignedUser')
                ->first();
            
            if (!$proyecto) {
                return response()->json([
                    'success' => false,
                    'message' => 'Proyecto no encontrado o no tienes permisos para verlo'
                ], 404);
            }
            
            // Obtener tareas del proyecto
            $tareas = DB::table('proyecto_tareas')
                ->where('proyecto_id', $id)
                ->orderBy('created_at', 'desc')
                ->get();
            
            // Obtener requerimientos del proyecto
            $requerimientos = DB::table('proyecto_requerimientos')
                ->where('proyecto_id', $id)
                ->orderBy('created_at', 'desc')
                ->get();
            
            // Obtener avances del proyecto
            $avances = DB::table('proyecto_avances')
                ->where('proyecto_id', $id)
                ->orderBy('created_at', 'desc')
                ->get();
            
            // Calcular progreso del proyecto
            $progreso = $this->calcularProgresoProyectoAvanzado($proyecto, $tareas, $avances);
            
            return response()->json([
                'success' => true,
                'proyecto' => $proyecto,
                'tareas' => $tareas,
                'requerimientos' => $requerimientos,
                'avances' => $avances,
                'progreso' => $progreso
            ]);
            
        } catch (\Exception $e) {
            Log::error('Error en getDetalleProyectoCliente: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Error interno del servidor'
            ], 500);
        }
    }

    /**
     * Vista de avance de proyectos para admin
     */
    public function avanceProyectos()
    {
        // Obtener todos los proyectos con sus desarrolladores asignados
        $proyectos = \Modules\FABRICASOFT\Entities\NewRequest::with('assignedUser')
            ->orderBy('created_at', 'desc')
            ->get();
        
        // Obtener desarrolladores
        $desarrolladores = \App\Models\User::whereHas('roles', function($query) {
            $query->where('name', 'aprendiz');
        })->get();
        
        // Calcular métricas
        $totalProyectos = $proyectos->count();
        $proyectosEnDesarrollo = $proyectos->whereIn('status', ['en_desarrollo', 'revision', 'testing'])->count();
        $proyectosCompletados = $proyectos->where('status', 'completado')->count();
        
        // Calcular progreso promedio usando lógica unificada
        $progresoPromedio = 0;
        $progresos = \Modules\FABRICASOFT\Entities\NewRequest::calcularProgresosParaProyectos($proyectos);
        
        foreach ($progresos as $progreso) {
            $progresoPromedio += $progreso;
        }
        
        if ($totalProyectos > 0) {
            $progresoPromedio = $progresoPromedio / $totalProyectos;
        }
        
        // Calcular datos mensuales para el gráfico
        $datosMensuales = [];
        for ($mes = 1; $mes <= 12; $mes++) {
            $datosMensuales[$mes] = \Modules\FABRICASOFT\Entities\NewRequest::where('status', 'completado')
                ->whereMonth('updated_at', $mes)
                ->count();
        }
        
        // Calcular datos de proyectos por desarrollador
        $datosDesarrolladores = [];
        foreach ($desarrolladores as $desarrollador) {
            $proyectosCount = $proyectos->where('assigned_user_id', $desarrollador->id)->count();
            if ($proyectosCount > 0) {
                $datosDesarrolladores[] = [
                    'nombre' => $desarrollador->name,
                    'proyectos' => $proyectosCount,
                    'color' => '#' . substr(md5($desarrollador->name), 0, 6) // Color único basado en el nombre
                ];
            }
        }
        
        // Agregar proyectos sin asignar
        $proyectosSinAsignar = $proyectos->whereNull('assigned_user_id')->count();
        if ($proyectosSinAsignar > 0) {
            $datosDesarrolladores[] = [
                'nombre' => 'Sin Asignar',
                'proyectos' => $proyectosSinAsignar,
                'color' => '#6B7280'
            ];
        }
        
        // Obtener información de grupos y equipos
        $grupos = DB::table('grupos')->get();
        $equipos = DB::table('grupo_miembros')->get();
        
        // Obtener estadísticas de equipos
        $statsEquipos = [
            'total_grupos' => $grupos->count(),
            'grupos_activos' => $grupos->where('created_at', '>=', now()->subDays(30))->count(),
            'miembros_totales' => $equipos->count()
        ];
        
        return view('fabricasoft::admin.avance-proyectos', compact(
            'proyectos', 
            'desarrolladores', 
            'totalProyectos', 
            'proyectosEnDesarrollo', 
            'proyectosCompletados', 
            'progresoPromedio',
            'progresos',
            'grupos',
            'equipos',
            'statsEquipos',
            'datosMensuales',
            'datosDesarrolladores'
        ));
    }

    /**
     * Vista de seguimiento para admin
     */
    public function seguimiento()
    {
        // Obtener todos los proyectos con sus desarrolladores asignados
        $proyectos = \Modules\FABRICASOFT\Entities\NewRequest::with('assignedUser')
            ->orderBy('created_at', 'desc')
            ->get();
        
        // Obtener desarrolladores
        $desarrolladores = \App\Models\User::whereHas('roles', function($query) {
            $query->where('name', 'aprendiz');
        })->get();
        
        // Calcular métricas de seguimiento
        $totalProyectos = $proyectos->count();
        $proyectosPendientes = $proyectos->where('status', 'pendiente')->count();
        $proyectosEnDesarrollo = $proyectos->whereIn('status', ['en_desarrollo', 'revision', 'testing'])->count();
        $proyectosCompletados = $proyectos->where('status', 'completado')->count();
        $proyectosAprobados = $proyectos->where('status', 'aprobada')->count();
        
        // Calcular progreso promedio usando lógica unificada
        $progresoPromedio = 0;
        $progresos = \Modules\FABRICASOFT\Entities\NewRequest::calcularProgresosParaProyectos($proyectos);
        
        foreach ($progresos as $progreso) {
            $progresoPromedio += $progreso;
        }
        
        if ($totalProyectos > 0) {
            $progresoPromedio = $progresoPromedio / $totalProyectos;
        }
        
        // Obtener proyectos por estado para seguimiento
        $proyectosPorEstado = [
            'pendiente' => $proyectos->where('status', 'pendiente'),
            'en_desarrollo' => $proyectos->where('status', 'en_desarrollo'),
            'revision' => $proyectos->where('status', 'revision'),
            'testing' => $proyectos->where('status', 'testing'),
            'aprobada' => $proyectos->where('status', 'aprobada'),
            'completado' => $proyectos->where('status', 'completado')
        ];
        
        // Obtener información de grupos y equipos
        $grupos = DB::table('grupos')->get();
        $equipos = DB::table('grupo_miembros')->get();
        
        // Obtener estadísticas de equipos
        $statsEquipos = [
            'total_grupos' => $grupos->count(),
            'grupos_activos' => $grupos->where('created_at', '>=', now()->subDays(30))->count(),
            'miembros_totales' => $equipos->count()
        ];
        
        return view('fabricasoft::admin.seguimiento', compact(
            'proyectos', 
            'desarrolladores', 
            'totalProyectos', 
            'proyectosPendientes',
            'proyectosEnDesarrollo', 
            'proyectosCompletados',
            'proyectosAprobados',
            'progresoPromedio',
            'progresos',
            'proyectosPorEstado',
            'grupos',
            'equipos',
            'statsEquipos'
        ));
    }

    /**
     * Obtener detalles de avance de un proyecto específico
     */
    public function getDetalleAvance($id)
    {
        $proyecto = \Modules\FABRICASOFT\Entities\NewRequest::with('assignedUser')->find($id);
        
        if (!$proyecto) {
            return response()->json(['error' => 'Proyecto no encontrado'], 404);
        }
        
        $progreso = $proyecto->calcularProgresoCompleto();
        
        // Calcular tiempo transcurrido y restante
        $tiempoTranscurrido = 0;
        $tiempoRestante = 0;
        
        if ($proyecto->start_date && $proyecto->end_date) {
            $inicio = \Carbon\Carbon::parse($proyecto->start_date);
            $fin = \Carbon\Carbon::parse($proyecto->end_date);
            $hoy = \Carbon\Carbon::now();
            
            $tiempoTranscurrido = $inicio->diffInDays($hoy);
            $tiempoRestante = $hoy->diffInDays($fin);
        }
        
        return response()->json([
            'proyecto' => $proyecto,
            'progreso' => $progreso,
            'tiempoTranscurrido' => $tiempoTranscurrido,
            'tiempoRestante' => $tiempoRestante
        ]);
    }

    /**
     * Actualizar progreso de un proyecto
     */
    public function actualizarProgreso(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:' . \Modules\FABRICASOFT\Entities\NewRequest::getEstadosParaValidacion(),
            'progreso_manual' => 'nullable|integer|min:0|max:100',
            'comentarios' => 'nullable|string|max:1000'
        ]);
        
        $proyecto = \Modules\FABRICASOFT\Entities\NewRequest::find($id);
        
        if (!$proyecto) {
            return response()->json(['error' => 'Proyecto no encontrado'], 404);
        }
        
        $proyecto->status = $request->status;
        
        // Si se proporciona progreso manual, guardarlo en un campo adicional
        if ($request->has('progreso_manual')) {
            $proyecto->progreso_manual = $request->progreso_manual;
        }
        
        // Guardar comentarios si se proporcionan
        if ($request->has('comentarios')) {
            $proyecto->apprentice_comments = $request->comentarios;
        }
        
        $proyecto->save();
        
        return response()->json([
            'success' => true,
            'message' => 'Progreso actualizado correctamente',
            'progreso' => $this->calcularProgresoProyecto($proyecto)
        ]);
    }

    /**
     * Generar reporte de avance
     */
    public function generarReporteAvance($id)
    {
        $proyecto = \Modules\FABRICASOFT\Entities\NewRequest::with('assignedUser')->find($id);
        
        if (!$proyecto) {
            return response()->json(['error' => 'Proyecto no encontrado'], 404);
        }
        
        $progreso = $this->calcularProgresoProyecto($proyecto);
        
        // Aquí se podría generar un PDF o Excel con el reporte
        // Por ahora retornamos los datos en JSON
        
        return response()->json([
            'proyecto' => $proyecto,
            'progreso' => $progreso,
            'fecha_generacion' => now()->format('d/m/Y H:i:s'),
            'reporte_url' => null // URL del reporte generado
        ]);
    }

    /**
     * Crear nueva tarea para el avance de proyectos
     */
    public function crearTareaAvance(Request $request)
    {
        $request->validate([
            'titulo' => 'required|string|max:255',
            'descripcion' => 'required|string',
            'estado' => 'required|in:pendiente,en_progreso,revision,completada',
            'fase' => 'required|in:analisis,diseno,implementacion,pruebas,despliegue'
        ]);

        try {
            // Por ahora, guardamos en localStorage del frontend
            // En el futuro, se podría guardar en la base de datos
            return response()->json([
                'success' => true,
                'message' => 'Tarea creada correctamente',
                'data' => [
                    'id' => $request->fase . '-' . time(),
                    'titulo' => $request->titulo,
                    'descripcion' => $request->descripcion,
                    'estado' => $request->estado,
                    'completada' => $request->estado === 'completada'
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al crear la tarea: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Actualizar tarea del avance de proyectos
     */
    public function actualizarTareaAvance(Request $request, $id)
    {
        $request->validate([
            'titulo' => 'required|string|max:255',
            'descripcion' => 'required|string',
            'estado' => 'required|in:pendiente,en_progreso,revision,completada'
        ]);

        try {
            // Por ahora, actualizamos en localStorage del frontend
            // En el futuro, se podría actualizar en la base de datos
            return response()->json([
                'success' => true,
                'message' => 'Tarea actualizada correctamente',
                'data' => [
                    'id' => $id,
                    'titulo' => $request->titulo,
                    'descripcion' => $request->descripcion,
                    'estado' => $request->estado,
                    'completada' => $request->estado === 'completada'
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al actualizar la tarea: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Eliminar tarea del avance de proyectos
     */
    public function eliminarTareaAvance($id)
    {
        try {
            // Por ahora, eliminamos en localStorage del frontend
            // En el futuro, se podría eliminar de la base de datos
            return response()->json([
                'success' => true,
                'message' => 'Tarea eliminada correctamente'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al eliminar la tarea: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obtener usuarios con roles para gestión
     */
    public function getGestionRoles()
    {
        // Obtener usuarios con rol de aprendiz/desarrollador
        $users = \App\Models\User::with('roles')
            ->whereHas('roles', function($query) {
                $query->where('slug', 'fabricasoft.apprentice');
            })
            ->get();
        
        return response()->json([
            'success' => true,
            'users' => $users->map(function($user) {
                return [
                    'id' => $user->id,
                    'nickname' => $user->nickname,
                    'email' => $user->email,
                    'roles' => $user->roles->pluck('name')
                ];
            })
        ]);
    }

    /**
     * Obtener equipo de un proyecto
     */
    public function getEquipoProyecto($id)
    {
        $proyecto = \Modules\FABRICASOFT\Entities\NewRequest::with('assignedUser')->find($id);
        
        if (!$proyecto) {
            return response()->json(['error' => 'Proyecto no encontrado'], 404);
        }
        
        $equipo = [
            'principal' => null,
            'miembros' => []
        ];
        
        // Desarrollador principal
        if ($proyecto->assignedUser) {
            $equipo['principal'] = [
                'id' => $proyecto->assignedUser->id,
                'nickname' => $proyecto->assignedUser->nickname,
                'email' => $proyecto->assignedUser->email
            ];
        }
        
        // Miembros del equipo
        if ($proyecto->equipo_desarrollo) {
            $miembrosData = json_decode($proyecto->equipo_desarrollo, true);
            if ($miembrosData) {
                foreach ($miembrosData as $miembro) {
                    $usuario = \App\Models\User::find($miembro['user_id']);
                    if ($usuario) {
                        $equipo['miembros'][] = [
                            'user_id' => $usuario->id,
                            'nickname' => $usuario->nickname,
                            'email' => $usuario->email,
                            'rol' => $miembro['rol']
                        ];
                    }
                }
            }
        }
        
        return response()->json([
            'success' => true,
            'equipo' => $equipo
        ]);
    }

    /**
     * Asignar equipo de desarrollo a un proyecto
     */
    public function asignarDesarrollador(Request $request)
    {
        $request->validate([
            'proyecto_id' => 'required|exists:new_request,id',
            'desarrollador_id' => 'required|exists:users,id',
            'equipo_ids' => 'nullable|array',
            'equipo_ids.*' => 'exists:users,id',
            'equipo_roles' => 'nullable|array',
            'equipo_roles.*' => 'in:desarrollador,disenador,tester,analista'
        ]);

        $proyecto = \Modules\FABRICASOFT\Entities\NewRequest::find($request->proyecto_id);
        
        // Asignar desarrollador principal
        $proyecto->assigned_user_id = $request->desarrollador_id;
        
        // Guardar información del equipo en campos adicionales
        $equipoData = [];
        if ($request->has('equipo_ids') && $request->has('equipo_roles')) {
            for ($i = 0; $i < count($request->equipo_ids); $i++) {
                if (!empty($request->equipo_ids[$i]) && !empty($request->equipo_roles[$i])) {
                    $equipoData[] = [
                        'user_id' => $request->equipo_ids[$i],
                        'rol' => $request->equipo_roles[$i]
                    ];
                }
            }
        }
        
        // Guardar equipo como JSON en un campo adicional
        $proyecto->equipo_desarrollo = json_encode($equipoData);
        $proyecto->save();

        // Preparar mensaje de respuesta
        $mensaje = 'Desarrollador principal asignado correctamente';
        if (!empty($equipoData)) {
            $mensaje .= ' con ' . count($equipoData) . ' miembro(s) adicional(es) del equipo';
        }

        return response()->json([
            'success' => true,
            'message' => $mensaje,
            'equipo_count' => count($equipoData)
        ]);
    }

    /**
     * Actualizar progreso general (para el modal de proyectos)
     */
    public function actualizarProgresoGeneral(Request $request)
    {
        $request->validate([
            'proyecto_id' => 'required|exists:new_request,id',
            'nuevo_status' => 'required|in:' . \Modules\FABRICASOFT\Entities\NewRequest::getEstadosParaValidacion(),
            'comentarios' => 'nullable|string|max:1000'
        ]);

        $proyecto = \Modules\FABRICASOFT\Entities\NewRequest::find($request->proyecto_id);
        $proyecto->status = $request->nuevo_status;
        
        if ($request->has('comentarios')) {
            $proyecto->apprentice_comments = $request->comentarios;
        }
        
        $proyecto->save();

        return response()->json([
            'success' => true,
            'message' => 'Progreso actualizado correctamente'
        ]);
    }
    
    /**
     * Registrar cambios en el historial del proyecto
     */
    private function registrarCambioProyecto($proyecto, $status, $comentarios = null)
    {
        // Aquí podrías implementar un sistema de historial de cambios
        // Por ahora, solo registramos en el log
        Log::info('Cambio de estado en proyecto', [
            'proyecto_id' => $proyecto->id,
            'proyecto_nombre' => $proyecto->project_name,
            'estado_anterior' => $proyecto->getOriginal('status'),
            'estado_nuevo' => $status,
            'comentarios' => $comentarios,
            'usuario' => Auth::user()->nickname ?? Auth::user()->email,
            'fecha' => now()
        ]);
    }
    
    /**
     * Obtener historial de cambios de un proyecto
     */
    public function getHistorialProyecto($id)
    {
        $proyecto = \Modules\FABRICASOFT\Entities\NewRequest::find($id);
        
        if (!$proyecto) {
            return response()->json(['error' => 'Proyecto no encontrado'], 404);
        }
        
        // Aquí podrías implementar la lógica para obtener el historial real
        // Por ahora, devolvemos información básica
        $historial = [
            [
                'fecha' => $proyecto->created_at,
                'accion' => 'Proyecto creado',
                'usuario' => 'Sistema',
                'detalles' => 'Proyecto registrado en el sistema'
            ],
            [
                'fecha' => $proyecto->updated_at,
                'accion' => 'Última actualización',
                'usuario' => 'Sistema',
                'detalles' => 'Estado actual: ' . ucfirst(str_replace('_', ' ', $proyecto->status))
            ]
        ];
        
        return response()->json([
            'success' => true,
            'historial' => $historial
        ]);
    }
    
    /**
     * Mostrar página principal de notificaciones
     */
    public function notificationsIndex()
    {
        $user = Auth::user();
        
        // Obtener notificaciones del usuario
        $notifications = collect();
        
        // Aquí puedes implementar la lógica para obtener notificaciones reales
        // Por ahora, creamos algunas notificaciones de ejemplo
        if ($user) {
            // Notificaciones de ejemplo (reemplazar con lógica real)
            $notifications = collect([
                [
                    'id' => 1,
                    'title' => 'Bienvenido al sistema',
                    'message' => 'Has sido registrado exitosamente en FABRICASOFT',
                    'type' => 'notification',
                    'read_at' => null,
                    'created_at' => now()->subDays(1)
                ]
            ]);
        }
        
        return view('fabricasoft::notifications.index', compact('notifications'));
    }
    
    /**
     * Marcar notificación como leída
     */
    public function markNotificationAsRead($id)
    {
        $user = Auth::user();
        
        if (!$user) {
            return response()->json(['error' => 'Usuario no autenticado'], 401);
        }
        
        // Aquí implementarías la lógica para marcar la notificación como leída
        // Por ahora, solo devolvemos éxito
        
        return response()->json([
            'success' => true,
            'message' => 'Notificación marcada como leída'
        ]);
    }

    /**
     * Obtener tareas de un proyecto específico
     */
    public function getProyectoTareas($id)
    {
        $user = Auth::user();
        $proyecto = \Modules\FABRICASOFT\Entities\NewRequest::where('id', $id)
            ->where('assigned_user_id', $user->id)
            ->first();
        
        if (!$proyecto) {
            return response()->json(['error' => 'Proyecto no encontrado o no tienes permisos'], 404);
        }
        
        // Tareas completas basadas en avance-proyectos.blade.php
        $tareas = [
            'analisis' => [
                ['id' => 'analisis-1', 'titulo' => 'Historias de usuario con criterios de aceptación (.xlsx)', 'descripcion' => 'Documento que describe las funcionalidades desde la perspectiva del usuario final, incluyendo criterios específicos para validar que cada historia esté completa.', 'completada' => true, 'estado' => 'completada'],
                ['id' => 'analisis-2', 'titulo' => 'Historial de usuario (.xlsx)', 'descripcion' => 'Registro detallado de todas las interacciones y cambios realizados por los usuarios en el sistema.', 'completada' => true, 'estado' => 'completada'],
                ['id' => 'analisis-3', 'titulo' => 'Matriz de trazabilidad de requisitos (.xlsx)', 'descripcion' => 'Tabla que relaciona cada requisito con su origen, implementación y pruebas, asegurando que ningún requisito se pierda durante el desarrollo.', 'completada' => true, 'estado' => 'completada'],
                ['id' => 'analisis-4', 'titulo' => 'SRS completo y con diagramas iniciales (.docx)', 'descripcion' => 'Especificación de Requisitos del Software que describe detalladamente qué debe hacer el sistema, incluyendo diagramas UML iniciales.', 'completada' => true, 'estado' => 'completada'],
                ['id' => 'analisis-5', 'titulo' => 'Crear diagrama de contexto (nivel 0 de DFD)', 'descripcion' => 'Diagrama de Flujo de Datos que muestra el sistema como un proceso central y su interacción con entidades externas.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'analisis-6', 'titulo' => 'Crear diagrama de casos de uso (UML)', 'descripcion' => 'Diagrama UML que identifica todos los actores del sistema y las funcionalidades principales que pueden realizar.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'analisis-7', 'titulo' => 'Especificaciones de casos de uso', 'descripcion' => 'Documento detallado que describe los flujos principales y alternativos para cada caso de uso identificado.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'analisis-8', 'titulo' => 'Documento de análisis completo', 'descripcion' => 'Resumen ejecutivo de todo el análisis realizado, incluyendo conclusiones y recomendaciones para las siguientes fases.', 'completada' => false, 'estado' => 'pendiente']
            ],
            'diseno' => [
                ['id' => 'diseno-1', 'titulo' => 'Documento de diseño técnico', 'descripcion' => 'Especificación detallada de la arquitectura del sistema, patrones de diseño utilizados y estructura modular.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'diseno-2', 'titulo' => 'Crear diagrama de clases (UML)', 'descripcion' => 'Diagrama UML que muestra las entidades del sistema, sus atributos, métodos y las relaciones entre ellas.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'diseno-3', 'titulo' => 'Crear diagrama de secuencia (UML)', 'descripcion' => 'Diagrama UML que representa el flujo de mensajes entre objetos en un escenario específico del sistema.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'diseno-4', 'titulo' => 'Crear diagrama de actividades (UML)', 'descripcion' => 'Diagrama UML que describe los flujos de procesos internos y la lógica de negocio del sistema.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'diseno-5', 'titulo' => 'Crear diagrama de flujo de procesos', 'descripcion' => 'Flowchart que representa visualmente los procesos clave del sistema y su flujo de trabajo.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'diseno-6', 'titulo' => 'Modelo entidad-relación (ERD)', 'descripcion' => 'Diagrama que muestra las tablas de la base de datos, sus relaciones y cardinalidades.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'diseno-7', 'titulo' => 'Diccionario de datos', 'descripcion' => 'Definición detallada de cada campo de la base de datos, incluyendo tipos, restricciones y descripciones.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'diseno-8', 'titulo' => 'Wireframes o mockups', 'descripcion' => 'Bocetos visuales de las interfaces del sistema, mostrando la disposición de elementos y navegación.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'diseno-9', 'titulo' => 'Prototipo funcional', 'descripcion' => 'Prototipo interactivo creado en Figma, Adobe XD o herramienta similar para validar el diseño con usuarios.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'diseno-10', 'titulo' => 'Presentación de diseño para cliente (.pptx)', 'descripcion' => 'Presentación que explica el diseño del sistema al cliente para su aprobación antes de la implementación.', 'completada' => true, 'estado' => 'completada']
            ],
            'implementacion' => [
                ['id' => 'implementacion-1', 'titulo' => 'Manual de instalación y configuración', 'descripcion' => 'Documento paso a paso para instalar y configurar el entorno de desarrollo y producción.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'implementacion-2', 'titulo' => 'Documentación de API', 'descripcion' => 'Documentación completa de la API usando Swagger, Postman o Redoc, incluyendo endpoints, parámetros y respuestas.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'implementacion-3', 'titulo' => 'Estándares de codificación', 'descripcion' => 'Documento que define las convenciones de nomenclatura, estructura de carpetas y mejores prácticas de código.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'implementacion-4', 'titulo' => 'Bitácora de desarrollo', 'descripcion' => 'Registro diario de avances, decisiones técnicas y problemas encontrados durante la implementación.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'implementacion-5', 'titulo' => 'Logo y elementos visuales (.docx)', 'descripcion' => 'Documento que contiene el logo del proyecto y todos los elementos visuales utilizados en la interfaz.', 'completada' => true, 'estado' => 'completada'],
                ['id' => 'implementacion-6', 'titulo' => 'Repositorio Git con commits organizados', 'descripcion' => 'Repositorio de código fuente con commits organizados por funcionalidad y documentación del historial de cambios.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'implementacion-7', 'titulo' => 'Documentación de código', 'descripcion' => 'Comentarios en el código y documentación técnica de las funciones y clases principales.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'implementacion-8', 'titulo' => 'Manual de desarrollador', 'descripcion' => 'Guía para desarrolladores que incluye configuración del entorno, flujo de trabajo y estándares del proyecto.', 'completada' => false, 'estado' => 'pendiente']
            ],
            'pruebas' => [
                ['id' => 'pruebas-1', 'titulo' => 'Plan de pruebas (.docx)', 'descripcion' => 'Documento que define la estrategia de pruebas, tipos de pruebas a realizar y cronograma de ejecución.', 'completada' => true, 'estado' => 'completada'],
                ['id' => 'pruebas-2', 'titulo' => 'Casos de prueba (.xlsx)', 'descripcion' => 'Matriz de casos de prueba que cubre todos los escenarios y funcionalidades del sistema.', 'completada' => true, 'estado' => 'completada'],
                ['id' => 'pruebas-3', 'titulo' => 'Resultados de pruebas (.docx)', 'descripcion' => 'Reporte de los resultados obtenidos de la ejecución de todos los casos de prueba.', 'completada' => true, 'estado' => 'completada'],
                ['id' => 'pruebas-4', 'titulo' => 'Plan de pruebas manuales (.docx)', 'descripcion' => 'Plan específico para pruebas manuales que no pueden ser automatizadas.', 'completada' => true, 'estado' => 'completada'],
                ['id' => 'pruebas-5', 'titulo' => 'Registro de errores/bugs', 'descripcion' => 'Documento en Excel o herramienta de gestión que registra todos los errores encontrados durante las pruebas.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'pruebas-6', 'titulo' => 'Pruebas de integración y validación', 'descripcion' => 'Documentación de las pruebas que validan la integración entre módulos y la funcionalidad completa del sistema.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'pruebas-7', 'titulo' => 'Informe final de pruebas', 'descripcion' => 'Reporte final con el estatus de aprobación y recomendaciones para el despliegue.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'pruebas-8', 'titulo' => 'Reporte de calidad', 'descripcion' => 'Evaluación de la calidad del software basada en los resultados de las pruebas y métricas de calidad.', 'completada' => false, 'estado' => 'pendiente']
            ],
            'despliegue' => [
                ['id' => 'despliegue-1', 'titulo' => 'Manual de usuario', 'descripcion' => 'Guía completa para usuarios finales con capturas de pantalla paso a paso de todas las funcionalidades.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'despliegue-2', 'titulo' => 'Manual técnico', 'descripcion' => 'Documentación técnica para administradores y personal de sistemas sobre la instalación y mantenimiento.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'despliegue-3', 'titulo' => 'Registro de despliegue', 'descripcion' => 'Documento que registra fecha, hora y todos los cambios realizados durante el despliegue en producción.', 'completada' => false, 'estado' => 'pendiente'],
                ['id' => 'despliegue-4', 'titulo' => 'Plan de capacitación', 'descripcion' => 'Plan detallado para capacitar a usuarios y administradores en el uso del sistema desplegado.', 'completada' => false, 'estado' => 'pendiente']
            ]
        ];
        
        return response()->json([
            'success' => true,
            'proyecto' => $proyecto,
            'tareas' => $tareas
        ]);
    }

    /**
     * Guardar nueva tarea de proyecto
     */
    public function guardarTareaProyecto(Request $request, $id)
    {
        $user = Auth::user();
        $proyecto = \Modules\FABRICASOFT\Entities\NewRequest::where('id', $id)
            ->where('assigned_user_id', $user->id)
            ->first();
        
        if (!$proyecto) {
            return response()->json(['error' => 'Proyecto no encontrado o no tienes permisos'], 404);
        }
        
        $request->validate([
            'titulo' => 'required|string|max:255',
            'descripcion' => 'required|string',
            'estado' => 'required|in:pendiente,en_progreso,completada',
            'fase' => 'required|in:analisis,diseno,implementacion,pruebas,despliegue'
        ]);
        
        // Aquí implementarías la lógica para guardar en la base de datos
        // Por ahora, simulamos el guardado
        
        $nuevaTarea = [
            'id' => $request->fase . '-' . time(),
            'titulo' => $request->titulo,
            'descripcion' => $request->descripcion,
            'estado' => $request->estado,
            'completada' => $request->estado === 'completada',
            'proyecto_id' => $id,
            'fase' => $request->fase,
            'creado_por' => $user->id,
            'created_at' => now()
        ];
        
        return response()->json([
            'success' => true,
            'message' => 'Tarea creada exitosamente',
            'tarea' => $nuevaTarea
        ]);
    }

    /**
     * Actualizar tarea de proyecto
     */
    public function actualizarTareaProyecto(Request $request, $id, $tareaId)
    {
        $user = Auth::user();
        $proyecto = \Modules\FABRICASOFT\Entities\NewRequest::where('id', $id)
            ->where('assigned_user_id', $user->id)
            ->first();
        
        if (!$proyecto) {
            return response()->json(['error' => 'Proyecto no encontrado o no tienes permisos'], 404);
        }
        
        $request->validate([
            'titulo' => 'required|string|max:255',
            'descripcion' => 'required|string',
            'estado' => 'required|in:pendiente,en_progreso,completada'
        ]);
        
        // Aquí implementarías la lógica para actualizar en la base de datos
        // Por ahora, simulamos la actualización
        
        $tareaActualizada = [
            'id' => $tareaId,
            'titulo' => $request->titulo,
            'descripcion' => $request->descripcion,
            'estado' => $request->estado,
            'completada' => $request->estado === 'completada',
            'updated_at' => now()
        ];
        
        return response()->json([
            'success' => true,
            'message' => 'Tarea actualizada exitosamente',
            'tarea' => $tareaActualizada
        ]);
    }

    /**
     * Eliminar tarea de proyecto
     */
    public function eliminarTareaProyecto($id, $tareaId)
    {
        $user = Auth::user();
        $proyecto = \Modules\FABRICASOFT\Entities\NewRequest::where('id', $id)
            ->where('assigned_user_id', $user->id)
            ->first();
        
        if (!$proyecto) {
            return response()->json(['error' => 'Proyecto no encontrado o no tienes permisos'], 404);
        }
        
        // Aquí implementarías la lógica para eliminar de la base de datos
        // Por ahora, simulamos la eliminación
        
        return response()->json([
            'success' => true,
            'message' => 'Tarea eliminada exitosamente'
        ]);
    }

    public function obtenerRespuestasFormulario($servicio_id)
    {
        $user = auth()->user();
        
        // Verificar que el usuario sea el propietario del servicio
        $servicio = DB::table('new_request')
            ->where('id', $servicio_id)
            ->where('email', $user->email)
            ->first();

        if (!$servicio) {
            return response()->json(['error' => 'No tiene permisos para acceder a este formulario.'], 403);
        }

        // Obtener el formulario asociado
        $formulario = Formulario::find($servicio->formulario_id);
        if (!$formulario) {
            return response()->json(['error' => 'Formulario no encontrado.'], 404);
        }

        // Obtener las respuestas existentes
        $respuestas = RespuestaFormulario::where('servicio_id', $servicio_id)->get();
        
        // Convertir respuestas a un formato más fácil de usar
        $respuestasFormateadas = [];
        foreach ($respuestas as $respuesta) {
            $respuestasFormateadas[$respuesta->pregunta_id] = $respuesta->respuesta;
        }

        return response()->json([
            'success' => true,
            'formulario' => $formulario,
            'respuestas' => $respuestasFormateadas,
            'servicio_id' => $servicio_id
        ]);
    }

    /**
     * Vista de seguimiento para el cliente
     */
    public function clienteSeguimiento()
    {
        $user = Auth::user();
        
        // Obtener proyectos del cliente
        $userRequests = \Modules\FABRICASOFT\Entities\NewRequest::where('email', $user->email)
            ->with('assignedUser')
            ->orderBy('created_at', 'desc')
            ->get();
        
        // Usar la lógica unificada de progreso
        $progresos = \Modules\FABRICASOFT\Entities\NewRequest::calcularProgresosParaProyectos($userRequests);
        
        // Calcular progreso promedio
        $progresoPromedio = 0;
        if ($userRequests->count() > 0) {
            $progresoPromedio = array_sum($progresos) / $userRequests->count();
        }
        
        // Obtener nombres de formularios
        $formularios = \Modules\FABRICASOFT\Entities\Formulario::pluck('nombre', 'id')->toArray();
        
        // Obtener datos adicionales para las vistas
        $tareasPorProyecto = [];
        $requerimientosPorProyecto = [];
        $avancesPorProyecto = [];
        
        foreach ($userRequests as $proyecto) {
            // Obtener tareas del proyecto
            $tareas = DB::table('proyecto_tareas')
                ->where('proyecto_id', $proyecto->id)
                ->orderBy('created_at', 'desc')
                ->get();
            $tareasPorProyecto[$proyecto->id] = $tareas;
            
            // Obtener requerimientos del proyecto
            $requerimientos = DB::table('proyecto_requerimientos')
                ->where('proyecto_id', $proyecto->id)
                ->orderBy('created_at', 'desc')
                ->get();
            $requerimientosPorProyecto[$proyecto->id] = $requerimientos;
            
            // Obtener avances del proyecto
            $avances = DB::table('proyecto_avances')
                ->where('proyecto_id', $proyecto->id)
                ->orderBy('created_at', 'desc')
                ->get();
            $avancesPorProyecto[$proyecto->id] = $avances;
        }
        
        return view('fabricasoft::cliente.seguimiento', compact(
            'userRequests', 
            'progresos', 
            'progresoPromedio',
            'formularios',
            'tareasPorProyecto',
            'requerimientosPorProyecto',
            'avancesPorProyecto'
        ));
    }

    /**
     * Vista de soporte técnico para el cliente
     */
    public function clienteSoporte()
    {
        $user = Auth::user();
        
        // Obtener proyectos del cliente para mostrar en el soporte
        $userRequests = \Modules\FABRICASOFT\Entities\NewRequest::where('email', $user->email)
            ->with('assignedUser')
            ->orderBy('created_at', 'desc')
            ->get();
        
        // Obtener información de contacto del equipo de soporte
        $soporteInfo = [
            'email' => 'soporte@fabricasoft.com',
            'telefono' => '+57 300 123 4567',
            'horario' => 'Lunes a Viernes: 8:00 AM - 6:00 PM',
            'equipo' => [
                [
                    'nombre' => 'Equipo de Desarrollo',
                    'descripcion' => 'Especialistas en desarrollo de software personalizado',
                    'email' => 'desarrollo@fabricasoft.com'
                ],
                [
                    'nombre' => 'Equipo de Soporte',
                    'descripcion' => 'Asistencia técnica y resolución de problemas',
                    'email' => 'soporte@fabricasoft.com'
                ],
                [
                    'nombre' => 'Coordinación de Proyectos',
                    'descripcion' => 'Seguimiento y coordinación de proyectos',
                    'email' => 'coordinacion@fabricasoft.com'
                ]
            ]
        ];
        
        return view('fabricasoft::cliente.soporte', compact(
            'userRequests',
            'soporteInfo'
        ));
    }

}
