<?php

namespace Modules\FABRICASOFT\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use Modules\FABRICASOFT\Entities\NewRequest;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;

class AjustesController extends Controller
{
    // Mostrar el formulario de ajustes
    public function show()
    {
        $user = Auth::user();
        $person = $user->person ?? null;
        
        // Si tienes datos de empresa en NewRequest, puedes obtener el último o el más relevante
        $solicitud = NewRequest::where('email', $user->email)->latest()->first();
        
        // Obtener información adicional según el rol
        $proyectosAsignados = null;
        $gruposLiderados = null;
        
        // Verificar si es desarrollador (tiene proyectos asignados)
        $proyectosAsignados = NewRequest::where('assigned_user_id', $user->id)->get();
        $gruposLiderados = DB::table('grupos')->where('lider_id', $user->id)->get();
        
        // Verificar si es cliente (tiene solicitudes de proyecto)
        $proyectosCliente = NewRequest::where('email', $user->email)->get();
        
        // Verificar el rol según la ruta actual
        $isAdmin = request()->route()->getName() === 'fabricasoft.admin.ajustes';
        $isDesarrollador = request()->route()->getName() === 'fabricasoft.aprendiz.ajustes';
        $isCliente = !$isAdmin && !$isDesarrollador;
        
        // Filtrar información según el rol
        if ($isAdmin || $isDesarrollador) {
            // Para Admin y Desarrollador, usar datos de people/users en lugar de new_request
            $proyectosCliente = collect(); // Vacío para admin/desarrollador
            
            // Crear objeto con datos desde people/users para Admin/Desarrollador
            $solicitudFiltrada = new \stdClass();
            
            // Obtener datos desde la tabla people si existe
            if ($person) {
                $solicitudFiltrada->applicant_name = trim($person->first_name . ' ' . $person->first_last_name);
                $solicitudFiltrada->phone = $person->telephone1 ?? '';
                
                // Mapear document_type de people al formato del formulario
                $documentTypeMapping = [
                    'Cédula de ciudadanía' => 'CC',
                    'Cédula de extranjería' => 'CE', 
                    'Tarjeta de identidad' => 'TI',
                    'Pasaporte' => 'PP',
                    'Documento nacional de identidad' => 'NIT'
                ];
                $solicitudFiltrada->document_type = $documentTypeMapping[$person->document_type] ?? '';
                $solicitudFiltrada->document_number = $person->document_number ?? '';
                $solicitudFiltrada->country = '';
                $solicitudFiltrada->department_location = '';
                $solicitudFiltrada->municipality = '';
            } else {
                // Si no hay person, usar valores vacíos
                $solicitudFiltrada->applicant_name = '';
                $solicitudFiltrada->phone = '';
                $solicitudFiltrada->document_type = '';
                $solicitudFiltrada->document_number = '';
                $solicitudFiltrada->country = '';
                $solicitudFiltrada->department_location = '';
                $solicitudFiltrada->municipality = '';
            }
            
            // Campos de empresa siempre vacíos para Admin/Desarrollador
            $solicitudFiltrada->company_name = '';
            $solicitudFiltrada->department = '';
            $solicitudFiltrada->applicant_role = '';
            
            $solicitud = $solicitudFiltrada;
        }
        
        return view('fabricasoft::ajustes', compact('user', 'person', 'solicitud', 'isAdmin', 'isDesarrollador', 'isCliente', 'proyectosAsignados', 'gruposLiderados', 'proyectosCliente'));
    }

    // Actualizar la información del cliente
    public function update(Request $request)
    {
        $user = Auth::user();
        $person = $user->person;
        $solicitud = NewRequest::where('email', $user->email)->latest()->first();

        // Determinar el rol para validación
        $currentRoute = request()->route()->getName();
        $isAdminUpdate = $currentRoute === 'fabricasoft.admin.ajustes.update';
        $isDesarrolladorUpdate = $currentRoute === 'fabricasoft.aprendiz.ajustes.update';
        
        // Reglas básicas para todos los roles
        $rules = [
            'nickname' => 'nullable|string|max:255',
            'email' => 'required|email|max:255',
            'phone' => 'nullable|string|max:30',
            'applicant_name' => 'nullable|string|max:255',
            'document_type' => 'nullable|in:CC,CE,TI,PP,NIT',
            'document_number' => 'nullable|numeric|digits_between:6,15',
        ];
        
        // Solo agregar campos de ubicación para clientes
        if (!$isAdminUpdate && !$isDesarrolladorUpdate) {
            $rules['country'] = 'nullable|string|max:100';
            $rules['department_location'] = 'nullable|string|max:100';
            $rules['municipality'] = 'nullable|string|max:100';
        }
        
        // Solo agregar campos de empresa para clientes
        if (!$isAdminUpdate && !$isDesarrolladorUpdate) {
            $rules['company_name'] = 'nullable|string|max:255';
            $rules['department'] = 'nullable|string|max:100';
            $rules['applicant_role'] = 'nullable|string|max:100';
        }
        
        // Validar datos
        $validatedData = $request->validate($rules);
        
        // Convertir valores null a cadenas vacías, excepto para campos ENUM
        $data = collect($validatedData)->map(function($value, $key) {
            // Para document_type (ENUM), mantener null si está vacío
            if ($key === 'document_type') {
                return $value ?: null;
            }
            // Para otros campos, convertir null a cadena vacía
            return $value ?? '';
        })->toArray();

        // Actualizar datos en User (información básica)
        User::where('id', $user->id)->update([
            'nickname' => $data['nickname'] ?? $user->nickname,
            'email' => $data['email'] ?? $user->email
        ]);
        
        // Crear o actualizar información del perfil en la tabla people si existe la relación
        if ($user->person) {
            $person = $user->person;
            // Actualizar campos disponibles en people
            if (isset($data['phone']) && $data['phone']) {
                $person->telephone1 = $data['phone'];
            }
            if (isset($data['applicant_name']) && $data['applicant_name']) {
                // Dividir el nombre completo en first_name y first_last_name si es posible
                $nameParts = explode(' ', $data['applicant_name'], 2);
                $person->first_name = $nameParts[0] ?? '';
                if (isset($nameParts[1])) {
                    $person->first_last_name = $nameParts[1];
                }
            }
            if (isset($data['email']) && $data['email']) {
                $person->personal_email = $data['email'];
            }
            
            // Actualizar document_number solo si es diferente y no está vacío
            if (isset($data['document_number']) && $data['document_number'] && 
                $data['document_number'] != $person->document_number) {
                
                // Verificar que el nuevo número no exista ya para otro usuario
                $existingPerson = DB::table('people')
                    ->where('document_number', $data['document_number'])
                    ->where('id', '!=', $person->id)
                    ->first();
                    
                if (!$existingPerson) {
                    $person->document_number = intval($data['document_number']);
                } else {
                    // Si ya existe, agregar error a la sesión
                    session()->flash('error', 'El número de documento ya está registrado por otro usuario.');
                }
            }
            
            $person->save();
        }

        // Solo actualizar datos en NewRequest si ya existe una solicitud
        // No crear nuevas solicitudes desde el perfil del usuario
        if ($solicitud) {
            // Campos básicos para todos los roles
            $solicitud->phone = $data['phone'];
            $solicitud->applicant_name = $data['applicant_name'];
            $solicitud->document_type = $data['document_type'];
            $solicitud->document_number = $data['document_number'];
            
            // Campos específicos solo para clientes
            if (!$isAdminUpdate && !$isDesarrolladorUpdate) {
                // Campos de ubicación
                $solicitud->country = $data['country'];
                $solicitud->department_location = $data['department_location'];
                $solicitud->municipality = $data['municipality'];
                
                // Campos de empresa
                $solicitud->company_name = $data['company_name'];
                $solicitud->department = $data['department'];
                $solicitud->applicant_role = $data['applicant_role'];
            } else {
                // Para Admin y Aprendiz, asegurar que los campos de empresa y ubicación sean cadenas vacías
                $solicitud->country = '';
                $solicitud->department_location = '';
                $solicitud->municipality = '';
                $solicitud->company_name = '';
                $solicitud->department = '';
                $solicitud->applicant_role = '';
            }
            
            $solicitud->save();
        }

        // Determinar la ruta de redirección según la ruta actual
        $currentRoute = request()->route()->getName();
        
        if ($currentRoute === 'fabricasoft.admin.ajustes.update') {
            return redirect()->route('fabricasoft.admin.ajustes')->with('success', 'Datos actualizados correctamente.');
        } elseif ($currentRoute === 'fabricasoft.aprendiz.ajustes.update') {
            return redirect()->route('fabricasoft.aprendiz.ajustes')->with('success', 'Datos actualizados correctamente.');
        } else {
            return redirect()->route('fabricasoft.ajustes')->with('success', 'Datos actualizados correctamente.');
        }
    }
} 