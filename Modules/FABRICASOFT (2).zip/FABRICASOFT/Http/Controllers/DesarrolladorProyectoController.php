<?php

namespace Modules\FABRICASOFT\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Modules\FABRICASOFT\Entities\ProyectoTarea;
use Modules\FABRICASOFT\Entities\ProyectoRequerimiento;
use Modules\FABRICASOFT\Entities\ProyectoAvance;

class DesarrolladorProyectoController extends Controller
{
    public function misProyectos()
    {
        $usuario = Auth::user();
        
        // Obtener proyectos donde el usuario es líder o miembro
        $proyectos = DB::table('grupos')
            ->join('new_request', 'grupos.proyecto_id', '=', 'new_request.id')
            ->leftJoin('grupo_miembros', 'grupos.id', '=', 'grupo_miembros.grupo_id')
            ->where(function($query) use ($usuario) {
                $query->where('grupos.lider_id', $usuario->id)
                      ->orWhere('grupo_miembros.user_id', $usuario->id);
            })
            ->select('new_request.*', 'grupos.id as grupo_id', 'grupos.nombre as grupo_nombre')
            ->distinct()
            ->get();

        return view('fabricasoft::desarrollador.proyectos', compact('proyectos'));
    }

    public function proyectoDetalle($proyectoId)
    {
        $proyecto = DB::table('new_request')->where('id', $proyectoId)->first();
        
        if (!$proyecto) {
            return redirect()->back()->with('error', 'Proyecto no encontrado');
        }

        // Verificar que el usuario tenga acceso al proyecto
        $usuario = Auth::user();
        $tieneAcceso = DB::table('grupos')
            ->leftJoin('grupo_miembros', 'grupos.id', '=', 'grupo_miembros.grupo_id')
            ->where('grupos.proyecto_id', $proyectoId)
            ->where(function($query) use ($usuario) {
                $query->where('grupos.lider_id', $usuario->id)
                      ->orWhere('grupo_miembros.user_id', $usuario->id);
            })
            ->exists();

        if (!$tieneAcceso) {
            return redirect()->back()->with('error', 'No tienes acceso a este proyecto');
        }

        // Obtener tareas del proyecto
        $tareas = ProyectoTarea::where('proyecto_id', $proyectoId)
            ->with(['asignadoA', 'asignadoPor'])
            ->orderBy('prioridad', 'desc')
            ->orderBy('created_at', 'desc')
            ->get();

        // Obtener requerimientos del proyecto
        $requerimientos = ProyectoRequerimiento::where('proyecto_id', $proyectoId)
            ->with('creadoPor')
            ->orderBy('prioridad', 'desc')
            ->orderBy('created_at', 'desc')
            ->get();

        // Obtener avances del proyecto
        $avances = ProyectoAvance::where('proyecto_id', $proyectoId)
            ->with('usuario')
            ->orderBy('created_at', 'desc')
            ->get();

        // Calcular estadísticas
        $stats = [
            'total_tareas' => $tareas->count(),
            'tareas_completadas' => $tareas->where('estado', 'completada')->count(),
            'tareas_pendientes' => $tareas->whereIn('estado', ['pendiente', 'en_progreso'])->count(),
            'total_requerimientos' => $requerimientos->count(),
            'requerimientos_aprobados' => $requerimientos->where('estado', 'aprobado')->count(),
            'avance_general' => $avances->avg('porcentaje_avance') ?? 0
        ];

        return view('fabricasoft::desarrollador.proyecto-detalle', compact(
            'proyecto', 'tareas', 'requerimientos', 'avances', 'stats'
        ));
    }

    public function crearTarea(Request $request)
    {
        $request->validate([
            'proyecto_id' => 'required|exists:new_request,id',
            'titulo' => 'required|string|max:255',
            'descripcion' => 'required|string',
            'prioridad' => 'required|in:baja,media,alta,urgente',
            'asignado_a' => 'nullable|exists:users,id',
            'fecha_limite' => 'nullable|date',
            'tiempo_estimado' => 'nullable|integer|min:1|max:40',
            'progreso_inicial' => 'nullable|integer|min:0|max:100',
        ]);

        $tarea = ProyectoTarea::create([
            'proyecto_id' => $request->proyecto_id,
            'asignado_por' => Auth::id(),
            'asignado_a' => $request->asignado_a,
            'titulo' => $request->titulo,
            'descripcion' => $request->descripcion,
            'prioridad' => $request->prioridad,
            'fecha_limite' => $request->fecha_limite,
            'tiempo_estimado' => $request->tiempo_estimado ?? 8,
            'progreso' => $request->progreso_inicial ?? 0,
            'estado' => 'pendiente'
        ]);

        if ($request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Tarea creada correctamente',
                'tarea' => $tarea
            ]);
        }

        return redirect()->back()->with('success', 'Tarea creada correctamente');
    }

    public function actualizarTarea(Request $request, $tareaId)
    {
        $tarea = ProyectoTarea::findOrFail($tareaId);
        
        $request->validate([
            'estado' => 'required|in:pendiente,en_progreso,revision,completada,cancelada',
            'comentarios' => 'nullable|string'
        ]);

        $tarea->update([
            'estado' => $request->estado,
            'comentarios' => $request->comentarios
        ]);

        if ($request->estado === 'en_progreso' && !$tarea->fecha_inicio) {
            $tarea->update(['fecha_inicio' => now()]);
        }

        if ($request->estado === 'completada' && !$tarea->fecha_completado) {
            $tarea->update(['fecha_completado' => now()]);
        }

        return redirect()->back()->with('success', 'Tarea actualizada correctamente');
    }

    public function crearRequerimiento(Request $request)
    {
        $request->validate([
            'proyecto_id' => 'required|exists:new_request,id',
            'titulo' => 'required|string|max:255',
            'descripcion' => 'required|string',
            'tipo' => 'required|in:funcional,no_funcional,técnico,usuario',
            'prioridad' => 'required|in:baja,media,alta,crítica',
            'criterios_aceptacion' => 'nullable|string',
            'complejidad' => 'nullable|integer|min:1|max:10',
            'tiempo_estimado' => 'nullable|integer|min:1|max:80',
            'urgencia' => 'nullable|integer|min:1|max:5',
        ]);

        $requerimiento = ProyectoRequerimiento::create([
            'proyecto_id' => $request->proyecto_id,
            'creado_por' => Auth::id(),
            'titulo' => $request->titulo,
            'descripcion' => $request->descripcion,
            'tipo' => $request->tipo,
            'prioridad' => $request->prioridad,
            'criterios_aceptacion' => $request->criterios_aceptacion,
            'complejidad' => $request->complejidad ?? 5,
            'tiempo_estimado' => $request->tiempo_estimado ?? 16,
            'urgencia' => $request->urgencia ?? 3,
            'estado' => 'pendiente'
        ]);

        if ($request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Requerimiento creado correctamente',
                'requerimiento' => $requerimiento
            ]);
        }

        return redirect()->back()->with('success', 'Requerimiento creado correctamente');
    }

    public function registrarAvance(Request $request)
    {
        $request->validate([
            'proyecto_id' => 'required|exists:new_request,id',
            'titulo' => 'required|string|max:255',
            'descripcion' => 'required|string',
            'porcentaje_avance' => 'required|integer|min:0|max:100',
            'tipo' => 'required|in:desarrollo,diseño,testing,documentacion,reunion,otro',
            'comentarios' => 'nullable|string'
        ]);

        ProyectoAvance::create([
            'proyecto_id' => $request->proyecto_id,
            'usuario_id' => Auth::id(),
            'titulo' => $request->titulo,
            'descripcion' => $request->descripcion,
            'porcentaje_avance' => $request->porcentaje_avance,
            'tipo' => $request->tipo,
            'comentarios' => $request->comentarios
        ]);

        return redirect()->back()->with('success', 'Avance registrado correctamente');
    }
} 