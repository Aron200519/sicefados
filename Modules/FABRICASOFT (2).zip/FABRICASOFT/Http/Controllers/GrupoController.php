<?php

namespace Modules\FABRICASOFT\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class GrupoController extends Controller
{
    public function store(Request $request)
    {
        Log::info('Iniciando creación de grupo', $request->all());
        
        $request->validate([
            'nombre_grupo' => 'required|string|max:255',
            'proyecto_id' => 'required|exists:new_request,id',
            'lider_id' => 'required|exists:users,id',
            'equipo_ids' => 'nullable|array',
            'equipo_ids.*' => 'exists:users,id',
            'equipo_roles' => 'nullable|array',
            'equipo_roles.*' => 'in:desarrollador,disenador,tester,analista'
        ]);

        // Verificar que el líder no esté ya asignado como líder en otro grupo
        $liderYaAsignado = DB::table('grupos')->where('lider_id', $request->lider_id)->exists();
        if ($liderYaAsignado) {
            return redirect()->back()->with('error', 'El desarrollador seleccionado ya es líder de otro grupo.');
        }

        // Verificar que los miembros del equipo no sean líderes de otros grupos
        if ($request->has('equipo_ids')) {
            foreach ($request->equipo_ids as $equipoId) {
                if (!empty($equipoId)) {
                    $esLider = DB::table('grupos')->where('lider_id', $equipoId)->exists();
                    if ($esLider) {
                        Log::warning("Intento de agregar líder como miembro: $equipoId");
                        Log::info("Saltando líder como miembro: $equipoId");
                    }
                }
            }
        }

        // Insertar el grupo
        $grupoId = DB::table('grupos')->insertGetId([
            'nombre' => $request->nombre_grupo,
            'proyecto_id' => $request->proyecto_id,
            'lider_id' => $request->lider_id,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Guardar equipo adicional si se proporciona
        Log::info('Verificando datos del equipo...');
        Log::info('Request completo:', $request->all());
        
        if ($request->has('equipo_ids') && $request->has('equipo_roles')) {
            Log::info('Datos del equipo recibidos:', [
                'equipo_ids' => $request->equipo_ids,
                'equipo_roles' => $request->equipo_roles
            ]);
            
            $equipoData = [];
            
            for ($i = 0; $i < count($request->equipo_ids); $i++) {
                Log::info("Procesando índice $i: equipo_id = '{$request->equipo_ids[$i]}', rol = '{$request->equipo_roles[$i]}'");
                
                if (!empty($request->equipo_ids[$i]) && !empty($request->equipo_roles[$i])) {
                    $equipoData[] = [
                        'grupo_id' => $grupoId,
                        'user_id' => $request->equipo_ids[$i],
                        'rol' => $request->equipo_roles[$i],
                        'created_at' => now(),
                        'updated_at' => now(),
                    ];
                    Log::info("Miembro agregado: {$request->equipo_ids[$i]} con rol {$request->equipo_roles[$i]}");
                } else {
                    Log::info("Índice $i vacío o incompleto");
                }
            }
            
            Log::info('Datos del equipo a insertar:', $equipoData);
            
            if (!empty($equipoData)) {
                try {
                    DB::table('grupo_miembros')->insert($equipoData);
                    Log::info('Equipo insertado correctamente');
                } catch (\Exception $e) {
                    Log::error('Error al insertar equipo: ' . $e->getMessage());
                }
            } else {
                Log::info('No hay datos válidos para insertar');
            }
        } else {
            Log::info('No se recibieron datos del equipo');
        }

        $mensaje = 'Grupo creado correctamente';
        if ($request->has('equipo_ids') && count($request->equipo_ids) > 0) {
            $mensaje .= ' con ' . count(array_filter($request->equipo_ids)) . ' miembro(s) adicional(es) del equipo';
        }

        return redirect()->back()->with('success', $mensaje);
    }

    public function update(Request $request, $id)
    {
        Log::info('=== UPDATE GRUPO ===');
        Log::info('ID del grupo:', ['id' => $id]);
        Log::info('Datos recibidos:', $request->all());
        
        $request->validate([
            'nombre_grupo' => 'required|string|max:255',
            'proyecto_id' => 'required|exists:new_request,id',
            'lider_id' => 'required|exists:users,id',
            'trello_url' => 'nullable|url',
            'github_url' => 'nullable|url',
            'equipo_ids' => 'nullable|array',
            'equipo_ids.*' => 'exists:users,id',
            'equipo_roles' => 'nullable|array',
            'equipo_roles.*' => 'in:desarrollador,disenador,tester,analista'
        ]);

        // Verificar que el líder no esté ya asignado como líder en otro grupo (excepto el actual)
        $liderYaAsignado = DB::table('grupos')
            ->where('lider_id', $request->lider_id)
            ->where('id', '!=', $id)
            ->exists();
        if ($liderYaAsignado) {
            return redirect()->back()->with('error', 'El desarrollador seleccionado ya es líder de otro grupo.');
        }

        DB::table('grupos')
            ->where('id', $id)
            ->update([
                'nombre' => $request->nombre_grupo,
                'proyecto_id' => $request->proyecto_id,
                'lider_id' => $request->lider_id,
                'trello_url' => $request->trello_url,
                'github_url' => $request->github_url,
                'updated_at' => now(),
            ]);

        // Actualizar equipo adicional
        // Primero eliminar miembros existentes
        DB::table('grupo_miembros')->where('grupo_id', $id)->delete();
        
        // Luego agregar los nuevos miembros
        if ($request->has('equipo_ids') && $request->has('equipo_roles')) {
            $equipoData = [];
            $equipoIds = $request->equipo_ids;
            $equipoRoles = $request->equipo_roles;
            
            Log::info('Equipo IDs recibidos:', $equipoIds);
            Log::info('Equipo Roles recibidos:', $equipoRoles);
            
            for ($i = 0; $i < count($equipoIds); $i++) {
                if (!empty($equipoIds[$i]) && !empty($equipoRoles[$i])) {
                    $equipoData[] = [
                        'grupo_id' => $id,
                        'user_id' => $equipoIds[$i],
                        'rol' => $equipoRoles[$i],
                        'created_at' => now(),
                        'updated_at' => now(),
                    ];
                }
            }
            
            Log::info('Datos del equipo a insertar:', $equipoData);
            
            if (!empty($equipoData)) {
                try {
                    DB::table('grupo_miembros')->insert($equipoData);
                    Log::info('Equipo insertado correctamente');
                } catch (\Exception $e) {
                    Log::error('Error al insertar equipo: ' . $e->getMessage());
                }
            } else {
                Log::info('No hay datos válidos para insertar');
            }
        } else {
            Log::info('No se recibieron datos del equipo');
        }

        $mensaje = 'Grupo actualizado correctamente';
        if ($request->has('equipo_ids') && count($request->equipo_ids) > 0) {
            $mensaje .= ' con ' . count(array_filter($request->equipo_ids)) . ' miembro(s) adicional(es) del equipo';
        }

        // Si es una petición AJAX, devolver JSON
        if ($request->ajax()) {
            return response()->json(['success' => true, 'message' => $mensaje]);
        }

        return redirect()->back()->with('success', $mensaje);
    }

    public function destroy($id)
    {
        DB::table('grupos')->where('id', $id)->delete();
        return redirect()->back()->with('success', 'Grupo eliminado correctamente');
    }

    public function getEquipo($id)
    {
        $grupo = DB::table('grupos')->where('id', $id)->first();
        
        if (!$grupo) {
            return response()->json(['error' => 'Grupo no encontrado'], 404);
        }
        
        // Obtener miembros del equipo
        $miembros = DB::table('grupo_miembros')
            ->join('users', 'grupo_miembros.user_id', '=', 'users.id')
            ->where('grupo_miembros.grupo_id', $id)
            ->select('users.id', 'users.nickname', 'users.email', 'grupo_miembros.rol')
            ->get();
        
        $miembrosArray = [];
        foreach ($miembros as $miembro) {
            $miembrosArray[] = [
                'user_id' => $miembro->id,
                'nickname' => $miembro->nickname,
                'email' => $miembro->email,
                'rol' => $miembro->rol
            ];
        }
        
        return response()->json([
            'success' => true,
            'miembros' => $miembrosArray
        ]);
    }
} 