<?php

namespace Modules\FABRICASOFT\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Modules\FABRICASOFT\Entities\FormularioSeguimiento;
use Modules\FABRICASOFT\Entities\Formulario;
use Modules\FABRICASOFT\Entities\NewRequest;
use Modules\FABRICASOFT\Entities\RespuestaFormulario;
use App\Models\User;

class FormularioSeguimientoController extends Controller
{
    /**
     * Vista de seguimiento para Admin
     */
    public function adminSeguimiento(Request $request)
    {
        $query = FormularioSeguimiento::with(['formulario', 'user', 'assignedUser', 'servicio']);

        // Filtros
        if ($request->filled('estado')) {
            $query->where('estado', $request->estado);
        }

        if ($request->filled('formulario_id')) {
            $query->where('formulario_id', $request->formulario_id);
        }

        if ($request->filled('desarrollador_id')) {
            $query->where('assigned_user_id', $request->desarrollador_id);
        }

        if ($request->filled('prioridad')) {
            $query->where('prioridad', $request->prioridad);
        }

        if ($request->filled('fecha_desde')) {
            $query->where('fecha_envio', '>=', $request->fecha_desde);
        }

        if ($request->filled('fecha_hasta')) {
            $query->where('fecha_envio', '<=', $request->fecha_hasta);
        }

        $seguimientos = $query->orderBy('prioridad', 'desc')
            ->orderBy('fecha_envio', 'desc')
            ->paginate(20);

        // Estadísticas generales
        $stats = FormularioSeguimiento::getGeneralStats();

        // Datos para filtros
        $formularios = Formulario::orderBy('nombre')->get();
        $desarrolladores = User::whereHas('roles', function($q) {
            $q->where('slug', 'like', 'fabricasoft.%');
        })->get();

        return view('fabricasoft::admin.seguimiento_formularios', compact(
            'seguimientos', 
            'stats', 
            'formularios', 
            'desarrolladores'
        ));
    }

    /**
     * Vista de seguimiento para Usuario
     */
    public function usuarioSeguimiento(Request $request)
    {
        $user = Auth::user();
        
        $query = FormularioSeguimiento::with(['formulario', 'assignedUser'])
            ->where('user_id', $user->id);

        // Filtros para usuario
        if ($request->filled('estado')) {
            $query->where('estado', $request->estado);
        }

        if ($request->filled('formulario_id')) {
            $query->where('formulario_id', $request->formulario_id);
        }

        $seguimientos = $query->orderBy('fecha_envio', 'desc')
            ->paginate(15);

        // Estadísticas del usuario
        $stats = FormularioSeguimiento::getStatsByUser($user->id);

        // Formularios del usuario
        $formularios = Formulario::whereHas('seguimientos', function($q) use ($user) {
            $q->where('user_id', $user->id);
        })->orderBy('nombre')->get();

        return view('fabricasoft::usuario.seguimiento_formularios', compact(
            'seguimientos', 
            'stats', 
            'formularios'
        ));
    }

    /**
     * Vista de seguimiento para Desarrollador
     */
    public function desarrolladorSeguimiento(Request $request)
    {
        $user = Auth::user();
        
        $query = FormularioSeguimiento::with(['formulario', 'user', 'servicio'])
            ->where('assigned_user_id', $user->id);

        // Filtros para desarrollador
        if ($request->filled('estado')) {
            $query->where('estado', $request->estado);
        }

        if ($request->filled('prioridad')) {
            $query->where('prioridad', $request->prioridad);
        }

        $seguimientos = $query->orderBy('prioridad', 'desc')
            ->orderBy('fecha_envio', 'asc')
            ->paginate(15);

        // Estadísticas del desarrollador
        $stats = FormularioSeguimiento::getStatsByDeveloper($user->id);

        return view('fabricasoft::desarrollador.seguimiento_formularios', compact(
            'seguimientos', 
            'stats'
        ));
    }

    /**
     * Detalles de un seguimiento específico
     */
    public function detalles($id)
    {
        $seguimiento = FormularioSeguimiento::with([
            'formulario', 
            'user', 
            'assignedUser', 
            'servicio'
        ])->findOrFail($id);

        // Verificar permisos
        $user = Auth::user();
        $isAdmin = $user->roles()->where('slug', 'like', 'fabricasoft.admin.%')->exists();
        $isDesarrollador = $user->roles()->where('slug', 'like', 'fabricasoft.%')->exists();
        
        if (!$isAdmin && $seguimiento->user_id !== $user->id && $seguimiento->assigned_user_id !== $user->id) {
            abort(403, 'No tienes permisos para ver este seguimiento.');
        }

        // Obtener respuestas del formulario usando el modelo
        $respuestas = RespuestaFormulario::where('servicio_id', $seguimiento->servicio_id)->get();

        return view('fabricasoft::seguimiento.detalles', compact('seguimiento', 'respuestas'));
    }

    /**
     * Actualizar estado del seguimiento (Admin/Desarrollador)
     */
    public function actualizarEstado(Request $request, $id)
    {
        $seguimiento = FormularioSeguimiento::findOrFail($id);
        $user = Auth::user();

        // Verificar permisos
        $isAdmin = $user->roles()->where('slug', 'like', 'fabricasoft.admin.%')->exists();
        $isDesarrollador = $user->roles()->where('slug', 'like', 'fabricasoft.%')->exists();
        
        if (!$isAdmin && $seguimiento->assigned_user_id !== $user->id) {
            return response()->json(['error' => 'No tienes permisos para actualizar este seguimiento.'], 403);
        }

        $request->validate([
            'estado' => 'required|in:pendiente,en_revision,en_desarrollo,testing,completado,rechazado,pausado',
            'comentarios' => 'nullable|string|max:1000',
            'prioridad' => 'nullable|integer|between:1,4'
        ]);

        // Actualizar estado
        $seguimiento->updateEstado($request->estado);

        // Actualizar comentarios según el rol
        if ($isAdmin) {
            $seguimiento->respuesta_admin = $request->comentarios;
        } else {
            $seguimiento->respuesta_desarrollador = $request->comentarios;
        }

        // Actualizar prioridad si es admin
        if ($isAdmin && $request->filled('prioridad')) {
            $seguimiento->prioridad = $request->prioridad;
        }

        $seguimiento->save();

        return response()->json([
            'success' => true,
            'message' => 'Estado actualizado correctamente',
            'seguimiento' => $seguimiento->load(['formulario', 'user', 'assignedUser'])
        ]);
    }

    /**
     * Asignar desarrollador (Admin)
     */
    public function asignarDesarrollador(Request $request, $id)
    {
        $seguimiento = FormularioSeguimiento::findOrFail($id);
        $user = Auth::user();

        // Verificar que sea admin
        $isAdmin = $user->roles()->where('slug', 'like', 'fabricasoft.admin.%')->exists();
        if (!$isAdmin) {
            return response()->json(['error' => 'No tienes permisos para asignar desarrolladores.'], 403);
        }

        $request->validate([
            'desarrollador_id' => 'required|exists:users,id'
        ]);

        $seguimiento->assigned_user_id = $request->desarrollador_id;
        $seguimiento->save();

        return response()->json([
            'success' => true,
            'message' => 'Desarrollador asignado correctamente'
        ]);
    }

    /**
     * Crear seguimiento automático cuando se envía un formulario
     */
    public static function crearSeguimiento($formularioId, $servicioId, $userId)
    {
        return FormularioSeguimiento::create([
            'formulario_id' => $formularioId,
            'servicio_id' => $servicioId,
            'user_id' => $userId,
            'estado' => FormularioSeguimiento::ESTADO_PENDIENTE,
            'fecha_envio' => now(),
            'prioridad' => FormularioSeguimiento::PRIORIDAD_MEDIA
        ]);
    }

    /**
     * Exportar seguimientos (Admin)
     */
    public function exportar(Request $request)
    {
        $user = Auth::user();
        $isAdmin = $user->roles()->where('slug', 'like', 'fabricasoft.admin.%')->exists();
        
        if (!$isAdmin) {
            abort(403, 'No tienes permisos para exportar datos.');
        }

        $query = FormularioSeguimiento::with(['formulario', 'user', 'assignedUser']);

        // Aplicar filtros
        if ($request->filled('estado')) {
            $query->where('estado', $request->estado);
        }

        if ($request->filled('fecha_desde')) {
            $query->where('fecha_envio', '>=', $request->fecha_desde);
        }

        if ($request->filled('fecha_hasta')) {
            $query->where('fecha_envio', '<=', $request->fecha_hasta);
        }

        $seguimientos = $query->orderBy('fecha_envio', 'desc')->get();

        // Generar CSV
        $filename = 'seguimiento_formularios_' . date('Y-m-d_H-i-s') . '.csv';
        
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ];

        $callback = function() use ($seguimientos) {
            $file = fopen('php://output', 'w');
            
            // Headers del CSV
            fputcsv($file, [
                'ID',
                'Formulario',
                'Usuario',
                'Desarrollador',
                'Estado',
                'Prioridad',
                'Fecha Envío',
                'Fecha Revisión',
                'Fecha Desarrollo',
                'Fecha Completado',
                'Comentarios'
            ]);

            // Datos
            foreach ($seguimientos as $seguimiento) {
                fputcsv($file, [
                    $seguimiento->id,
                    $seguimiento->formulario->nombre ?? 'N/A',
                    $seguimiento->user->name ?? 'N/A',
                    $seguimiento->assignedUser->name ?? 'Sin asignar',
                    $seguimiento->estado_legible,
                    $seguimiento->prioridad_legible,
                    $seguimiento->fecha_envio->format('Y-m-d H:i:s'),
                    $seguimiento->fecha_revision ? $seguimiento->fecha_revision->format('Y-m-d H:i:s') : 'N/A',
                    $seguimiento->fecha_desarrollo ? $seguimiento->fecha_desarrollo->format('Y-m-d H:i:s') : 'N/A',
                    $seguimiento->fecha_completado ? $seguimiento->fecha_completado->format('Y-m-d H:i:s') : 'N/A',
                    $seguimiento->comentarios ?? 'N/A'
                ]);
            }

            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
}

