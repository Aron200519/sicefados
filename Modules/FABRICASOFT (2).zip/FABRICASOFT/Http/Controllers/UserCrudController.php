<?php

namespace Modules\FABRICASOFT\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Routing\Controller;

class UserCrudController extends Controller
{
    public function index()
    {
        $users = User::all();
        return view('fabricasoft::admin.users.index', compact('users'));
    }

    public function create()
    {
        return view('fabricasoft::admin.users.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nickname' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:6',
            'person_id' => 'required|numeric',
        ]);
        $user = new User();
        $user->nickname = $request->nickname;
        $user->email = $request->email;
        $user->person_id = $request->person_id;
        $user->password = Hash::make($request->password);
        $user->save();
        return redirect()->route('fabricasoft.admin.users.index')->with('success', 'Usuario creado correctamente');
    }

    public function edit($id)
    {
        $user = User::findOrFail($id);
        return view('fabricasoft::admin.users.edit', compact('user'));
    }

    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);
        $request->validate([
            'nickname' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $user->id,
            'password' => 'nullable|string|min:6',
        ]);
        $user->nickname = $request->nickname;
        $user->email = $request->email;
        if ($request->filled('password')) {
            $user->password = Hash::make($request->password);
        }
        $user->save();
        return redirect()->route('fabricasoft.admin.users.index')->with('success', 'Usuario actualizado correctamente');
    }

    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->delete();
        return redirect()->route('fabricasoft.admin.users.index')->with('success', 'Usuario eliminado correctamente');
    }
} 