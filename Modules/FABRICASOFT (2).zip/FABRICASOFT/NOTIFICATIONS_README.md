# Sistema de Notificaciones FABRICASOFT

## 📋 Descripción

El módulo FABRICASOFT ahora incluye un sistema completo de notificaciones integrado con el sistema global de SICEFA. Este sistema permite a todos los usuarios (administradores, desarrolladores, clientes) recibir notificaciones en tiempo real sobre eventos importantes del módulo.

## 🎯 Características

### ✅ Notificaciones Automáticas
- **Nuevas Solicitudes**: Los administradores reciben notificaciones cuando se crea una nueva solicitud de proyecto
- **Cambios de Estado**: Los clientes son notificados cuando cambia el estado de su proyecto
- **Asignación de Proyectos**: Los desarrolladores reciben notificaciones cuando se les asigna un nuevo proyecto
- **Confirmación de Recepción**: Los clientes reciben confirmación cuando su solicitud es recibida

### ✅ Interfaz de Usuario
- **Icono de Campana**: Visible en todos los layouts de FABRICASOFT (admin, desarrollador, cliente)
- **Contador de Notificaciones**: Muestra el número de notificaciones no leídas
- **Dropdown Interactivo**: Muestra las notificaciones más recientes con iconos por tipo
- **Marcado Automático**: Las notificaciones se marcan como leídas al hacer clic
- **Actualización en Tiempo Real**: Se actualiza cada 30 segundos

### ✅ Tipos de Notificaciones
- **Info** (azul): Información general
- **Success** (verde): Confirmaciones y éxitos
- **Warning** (amarillo): Advertencias y alertas
- **Error** (rojo): Errores y problemas

## 🚀 Uso del Sistema

### Desde Controladores

```php
use App\Models\UserNotification;

// Notificar a un usuario específico
UserNotification::create([
    'user_id' => $userId,
    'title' => 'Título de la notificación',
    'message' => 'Mensaje de la notificación',
    'type' => 'info',
    'module' => 'FABRICASOFT',
    'data' => ['key' => 'value'] // Datos adicionales opcionales
]);

// Notificar a administradores
$adminUsers = User::whereHas('roles', function($query) {
    $query->where('slug', 'superadmin');
})->get();

foreach ($adminUsers as $admin) {
    UserNotification::create([
        'user_id' => $admin->id,
        'title' => 'Nueva Solicitud',
        'message' => 'Se ha recibido una nueva solicitud de proyecto',
        'type' => 'info',
        'module' => 'FABRICASOFT'
    ]);
}
```

### Desde Línea de Comandos

```bash
# Notificar a todos los usuarios
php artisan fabricasoft:notify "Título" "Mensaje" --all

# Notificar solo a desarrolladores
php artisan fabricasoft:notify "Nuevo Proyecto" "Se ha asignado un nuevo proyecto" --developers

# Notificar solo a clientes
php artisan fabricasoft:notify "Actualización" "Su proyecto ha sido actualizado" --clients

# Notificar por rol específico
php artisan fabricasoft:notify "Mantenimiento" "Sistema en mantenimiento" --role=superadmin

# Notificar a usuario específico
php artisan fabricasoft:notify "Mensaje Personal" "Mensaje específico" --user=1

# Diferentes tipos de notificación
php artisan fabricasoft:notify "Éxito" "Operación completada" --type=success
php artisan fabricasoft:notify "Advertencia" "Atención requerida" --type=warning
php artisan fabricasoft:notify "Error" "Problema detectado" --type=error
```

### Desde el Helper Global

```php
use App\Helpers\NotificationHelper;

// Notificar al usuario actual
NotificationHelper::notifyCurrentUser('Título', 'Mensaje', 'info', 'FABRICASOFT');

// Notificar a todos los usuarios
NotificationHelper::notifyAll('Mantenimiento', 'Sistema en mantenimiento', 'warning', 'FABRICASOFT');

// Notificar por rol
NotificationHelper::notifyByRole('superadmin', 'Nueva funcionalidad', 'Descripción', 'info', 'FABRICASOFT');
```

## 📁 Archivos Modificados

### Controladores
- `Modules/FABRICASOFT/Http/Controllers/FABRICASOFTController.php`
  - Método `notifications()` actualizado para usar el sistema global
  - Método `storeNewRequest()` con notificaciones automáticas
  - Método `updateStatus()` con notificaciones de cambio de estado

### Layouts
- `Modules/FABRICASOFT/Resources/views/layouts/masteradmin.blade.php`
- `Modules/FABRICASOFT/Resources/views/layouts/masterdesarrolladores.blade.php`
  - JavaScript actualizado para el sistema global
  - Interfaz mejorada con iconos y tipos
  - Funcionalidad de marcado como leído

### Comandos
- `app/Console/Commands/FabricasoftNotification.php`
  - Comando específico para notificaciones de FABRICASOFT
  - Opciones para diferentes tipos de destinatarios

## 🔧 Configuración

### Rutas
Las notificaciones se obtienen a través de la ruta existente:
```
GET /fabricasoft/admin/notifications
```

### Base de Datos
El sistema utiliza la tabla `user_notifications` del sistema global de SICEFA.

### Permisos
- **Lectura**: Todos los usuarios autenticados pueden ver sus notificaciones
- **Escritura**: Solo el sistema puede crear notificaciones
- **Marcado como leído**: Los usuarios pueden marcar sus notificaciones como leídas

## 🎨 Personalización

### Estilos CSS
Las notificaciones usan las clases CSS existentes del módulo FABRICASOFT:
- `.notification-item`: Estilo base de cada notificación
- `.notification-item.unread`: Notificaciones no leídas
- `.notification-item.read`: Notificaciones leídas

### Iconos
- **Info**: `fas fa-bell` (azul)
- **Success**: `fas fa-check-circle` (verde)
- **Warning**: `fas fa-exclamation-triangle` (amarillo)
- **Error**: `fas fa-times-circle` (rojo)

## 📊 Eventos que Generan Notificaciones

### Automáticos
1. **Nueva Solicitud de Proyecto**
   - Destinatarios: Administradores
   - Tipo: Info
   - Contenido: Detalles del proyecto y cliente

2. **Confirmación de Recepción**
   - Destinatarios: Cliente
   - Tipo: Success
   - Contenido: Confirmación de que la solicitud fue recibida

3. **Cambio de Estado de Proyecto**
   - Destinatarios: Cliente
   - Tipo: Info/Success (dependiendo del estado)
   - Contenido: Nuevo estado del proyecto

4. **Asignación de Proyecto**
   - Destinatarios: Desarrollador asignado
   - Tipo: Info
   - Contenido: Detalles del proyecto asignado

### Manuales
- Notificaciones creadas por administradores
- Notificaciones del sistema global de SICEFA
- Notificaciones por comandos de línea

## 🔍 Monitoreo y Mantenimiento

### Verificar Estado
```bash
# Verificar notificaciones en la base de datos
php artisan tinker
>>> App\Models\UserNotification::count();

# Verificar notificaciones por módulo
>>> App\Models\UserNotification::where('module', 'FABRICASOFT')->count();
```

### Limpieza
```bash
# Eliminar notificaciones antiguas (más de 30 días)
php artisan tinker
>>> App\Models\UserNotification::where('created_at', '<', now()->subDays(30))->delete();
```

## 🚨 Solución de Problemas

### Notificaciones no aparecen
1. Verificar que el usuario esté autenticado
2. Verificar que existan notificaciones en la base de datos
3. Verificar la consola del navegador para errores JavaScript

### Error en la carga
1. Verificar que la ruta `/fabricasoft/admin/notifications` funcione
2. Verificar permisos de usuario
3. Verificar logs de Laravel

### Comandos no funcionan
1. Verificar que el comando esté registrado
2. Verificar sintaxis del comando
3. Verificar que existan los usuarios/roles especificados

## 📈 Próximas Mejoras

- [ ] Notificaciones push en tiempo real
- [ ] Plantillas de notificaciones personalizables
- [ ] Configuración de preferencias por usuario
- [ ] Exportación de historial de notificaciones
- [ ] Integración con email automático

## 📞 Soporte

Para problemas o preguntas sobre el sistema de notificaciones de FABRICASOFT:
- Revisar los logs de Laravel
- Verificar la documentación del sistema global de notificaciones
- Contactar al equipo de desarrollo de SICEFA 