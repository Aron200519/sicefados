/**
 * FABRICASOFT Security Module
 * Maneja la seguridad y autenticación del módulo FABRICASOFT
 */

class FabricasoftSecurity {
    constructor() {
        this.init();
    }

    init() {
        // Interceptar todas las peticiones AJAX para manejar errores de autenticación
        this.setupAjaxInterceptor();
        
        // Manejar errores de autenticación en la carga de la página
        this.handlePageLoadErrors();
        
        // Configurar SweetAlert2 si está disponible
        this.setupSweetAlert();
    }

    setupAjaxInterceptor() {
        // Interceptar peticiones AJAX usando jQuery si está disponible
        if (typeof $ !== 'undefined') {
            $(document).ajaxError((event, xhr, settings, error) => {
                this.handleAjaxError(xhr, settings);
            });
        }

        // Interceptar peticiones fetch nativas
        this.interceptFetch();
    }

    interceptFetch() {
        const originalFetch = window.fetch;
        const self = this;

        window.fetch = function(...args) {
            return originalFetch.apply(this, args).then(response => {
                if (!response.ok && response.status === 403) {
                    return response.json().then(data => {
                        self.handleSecurityError(data);
                        throw new Error('Security error');
                    });
                }
                return response;
            });
        };
    }

    handleAjaxError(xhr, settings) {
        if (xhr.status === 403) {
            try {
                const response = JSON.parse(xhr.responseText);
                this.handleSecurityError(response);
            } catch (e) {
                this.showDefaultSecurityError();
            }
        }
    }

    handleSecurityError(data) {
        if (data.script) {
            // Ejecutar el script de error devuelto por el servidor
            this.executeScript(data.script);
        } else if (data.message) {
            // Mostrar mensaje de error personalizado
            this.showSecurityAlert(data.message, data.error ? 'error' : 'warning');
        } else {
            this.showDefaultSecurityError();
        }
    }

    executeScript(scriptContent) {
        // Crear un elemento script temporal y ejecutarlo
        const script = document.createElement('script');
        script.textContent = scriptContent;
        document.head.appendChild(script);
        document.head.removeChild(script);
    }

    showSecurityAlert(message, type = 'error') {
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                icon: type,
                title: type === 'error' ? 'Acceso Denegado' : 'Permisos Insuficientes',
                text: message,
                confirmButtonText: 'Ir al Inicio',
                allowOutsideClick: false
            }).then((result) => {
                window.location.href = this.getHomeUrl();
            });
        } else {
            // Fallback si SweetAlert2 no está disponible
            alert(message);
            window.location.href = this.getHomeUrl();
        }
    }

    showDefaultSecurityError() {
        this.showSecurityAlert('No tienes permisos para acceder a esta sección. Debes estar registrado e iniciar sesión.');
    }

    handlePageLoadErrors() {
        // Verificar si hay mensajes de error en la sesión (Laravel)
        if (typeof window.errorMessages !== 'undefined') {
            window.errorMessages.forEach(message => {
                this.showSecurityAlert(message);
            });
        }

        // Verificar si hay mensaje de error en el DOM
        const errorElement = document.querySelector('.alert-danger, .error-message');
        if (errorElement && errorElement.textContent.includes('permisos')) {
            this.showSecurityAlert(errorElement.textContent.trim());
        }
    }

    setupSweetAlert() {
        // Configurar SweetAlert2 si está disponible
        if (typeof Swal !== 'undefined') {
            Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true
            });
        }
    }

    getHomeUrl() {
        // Obtener la URL del inicio desde las rutas de Laravel o usar una por defecto
        if (typeof window.homeUrl !== 'undefined') {
            return window.homeUrl;
        }
        
        // Intentar obtener la URL base
        const baseUrl = window.location.origin;
        return baseUrl + '/';
    }

    // Método para verificar si el usuario está autenticado
    isAuthenticated() {
        // Verificar si hay un token CSRF (indicador de sesión activa en Laravel)
        const token = document.querySelector('meta[name="csrf-token"]');
        return token !== null;
    }

    // Método para verificar si el usuario tiene un rol específico
    hasRole(roleSlug) {
        // Esta función puede ser extendida para verificar roles específicos
        // Por ahora, solo verifica autenticación
        return this.isAuthenticated();
    }

    // Método para redirigir al login
    redirectToLogin() {
        window.location.href = this.getHomeUrl();
    }
}

// Inicializar la seguridad cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    window.fabricasoftSecurity = new FabricasoftSecurity();
});

// También inicializar si el DOM ya está cargado
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        window.fabricasoftSecurity = new FabricasoftSecurity();
    });
} else {
    window.fabricasoftSecurity = new FabricasoftSecurity();
}

// Exportar para uso en módulos
if (typeof module !== 'undefined' && module.exports) {
    module.exports = FabricasoftSecurity;
} 