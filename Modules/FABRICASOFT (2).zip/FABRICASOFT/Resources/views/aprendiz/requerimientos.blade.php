@extends('fabricasoft::layouts.masteraprendiz')

@section('content')
<div class="container mx-auto px-4 py-6">
    <!-- Header -->
    <div class="mb-8">
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-bold text-gray-800 mb-2">Análisis de Requerimientos</h1>
                <p class="text-gray-600">Gestiona y analiza los requerimientos de tus proyectos</p>
            </div>
            <div class="flex space-x-3">
                <button onclick="agregarRequerimiento()" class="px-4 py-2 rounded-lg bg-green-600 text-white hover:bg-green-700 transition-colors">
                    <i class="fas fa-plus mr-2"></i>Agregar Requerimiento
                </button>
                <button onclick="cambiarVista('lista')" class="btn-vista active px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">
                    <i class="fas fa-list mr-2"></i>Lista
                </button>
                <button onclick="cambiarVista('kanban')" class="btn-vista px-4 py-2 rounded-lg bg-gray-200 text-gray-700 hover:bg-gray-300">
                    <i class="fas fa-columns mr-2"></i>Kanban
                </button>
            </div>
        </div>
    </div>

    <!-- Estadísticas Rápidas -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                    <i class="fas fa-file-alt text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Total Requerimientos</p>
                    <p class="text-2xl font-semibold text-gray-900" id="contador-total">{{ $estadisticas['total'] ?? 0 }}</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-green-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-green-100 text-green-600">
                    <i class="fas fa-clipboard-check text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Con Formulario</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $estadisticas['conFormulario'] ?? 0 }}</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-yellow-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-yellow-100 text-yellow-600">
                    <i class="fas fa-clock text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Pendientes</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $estadisticas['pendientes'] ?? 0 }}</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-purple-100 text-purple-600">
                    <i class="fas fa-code text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">En Desarrollo</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $estadisticas['en_desarrollo'] ?? 0 }}</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Filtros -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-8">
        <div class="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Proyecto</label>
                <select id="filtro-proyecto" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Todos los proyectos</option>
                    @if(isset($proyectos))
                        @foreach($proyectos as $proyecto)
                            @php
                                $formularioNombre = null;
                                if ($proyecto->formulario_id) {
                                    $formulario = \DB::table('formularios')->where('id', $proyecto->formulario_id)->first();
                                    $formularioNombre = $formulario ? $formulario->nombre : null;
                                }
                            @endphp
                            <option value="{{ $proyecto->id }}">
                                {{ $proyecto->project_name }}
                                @if($formularioNombre)
                                    ({{ $formularioNombre }})
                                @endif
                            </option>
                        @endforeach
                    @endif
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Tipo</label>
                <select id="filtro-tipo" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Todos los tipos</option>
                    <option value="funcional">Funcional</option>
                    <option value="no_funcional">No Funcional</option>
                    <option value="tecnico">Técnico</option>
                    <option value="usuario">Usuario</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Prioridad</label>
                <select id="filtro-prioridad" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Todas las prioridades</option>
                    <option value="alta">Alta</option>
                    <option value="media">Media</option>
                    <option value="baja">Baja</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Estado</label>
                <select id="filtro-estado" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Todos los estados</option>
                    <option value="pendiente">Pendiente</option>
                    <option value="en_analisis">En Análisis</option>
                    <option value="aprobado">Aprobado</option>
                    <option value="rechazado">Rechazado</option>
                    <option value="implementado">Implementado</option>
                </select>
            </div>
            <div class="flex items-end">
                <button onclick="aplicarFiltros()" class="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                    <i class="fas fa-search mr-2"></i>Filtrar
                </button>
            </div>
        </div>
    </div>

    <!-- Vista Lista -->
    <div id="vista-lista" class="vista-contenido">
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800 flex items-center">
                    <i class="fas fa-file-alt text-blue-500 mr-3"></i>
                    Lista de Requerimientos
                </h3>
            </div>
        
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Requerimiento
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Proyecto
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Tipo
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Prioridad
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Estado
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Fecha
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Acciones
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200" id="requerimientos-tbody">
                    @if(isset($requerimientosConRespuestas) && count($requerimientosConRespuestas) > 0)
                        @foreach($requerimientosConRespuestas as $req)
                            <tr class="requerimiento-row hover:bg-gray-50" 
                                data-requerimiento-id="{{ $req->id }}"
                                data-proyecto="{{ $req->proyecto_id ?? '' }}"
                                data-tipo="{{ $req->tipo ?? '' }}"
                                data-prioridad="{{ $req->prioridad ?? '' }}"
                                data-estado="{{ $req->estado ?? '' }}">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-10 w-10">
                                            <div class="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                                                <i class="fas fa-file-alt text-blue-600"></i>
                                            </div>
                                        </div>
                                        <div class="ml-4">
                                            <div class="text-sm font-medium text-gray-900">{{ $req->titulo ?? 'N/A' }}</div>
                                            <div class="text-sm text-gray-500 line-clamp-2">{{ $req->descripcion ?? 'Sin descripción' }}</div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900">{{ $req->project_name ?? 'N/A' }}</div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                        @if($req->tipo == 'funcional') bg-green-100 text-green-800
                                        @elseif($req->tipo == 'no_funcional') bg-blue-100 text-blue-800
                                        @elseif($req->tipo == 'tecnico') bg-purple-100 text-purple-800
                                        @else bg-gray-100 text-gray-800 @endif">
                                        {{ ucfirst(str_replace('_', ' ', $req->tipo ?? 'N/A')) }}
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                        @if($req->prioridad == 'alta') bg-red-100 text-red-800
                                        @elseif($req->prioridad == 'media') bg-yellow-100 text-yellow-800
                                        @else bg-green-100 text-green-800 @endif">
                                        <i class="fas fa-flag mr-1"></i>
                                        {{ ucfirst($req->prioridad ?? 'media') }}
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                        @if($req->estado == 'pendiente') bg-yellow-100 text-yellow-800
                                        @elseif($req->estado == 'en_analisis') bg-blue-100 text-blue-800
                                        @elseif($req->estado == 'aprobado') bg-green-100 text-green-800
                                        @elseif($req->estado == 'rechazado') bg-red-100 text-red-800
                                        @elseif($req->estado == 'implementado') bg-purple-100 text-purple-800
                                        @else bg-gray-100 text-gray-800 @endif">
                                        {{ ucfirst(str_replace('_', ' ', $req->estado ?? 'pendiente')) }}
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    {{ \Carbon\Carbon::parse($req->created_at)->format('d/m/Y') }}
                                </td>
                                                                 <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                     <div class="flex space-x-2">
                                         <button onclick="verDetalleRequerimiento({{ $req->id }})" 
                                                 class="text-blue-600 hover:text-blue-900" title="Ver detalle">
                                             <i class="fas fa-eye"></i>
                                         </button>
                                         <button onclick="editarRequerimiento({{ $req->id }})" 
                                                 class="text-green-600 hover:text-green-900" title="Editar">
                                             <i class="fas fa-edit"></i>
                                         </button>
                                         <button onclick="cambiarEstadoRequerimiento({{ $req->id }})" 
                                                 class="text-purple-600 hover:text-purple-900" title="Cambiar estado">
                                             <i class="fas fa-exchange-alt"></i>
                                         </button>
                                         <button onclick="eliminarRequerimiento({{ $req->id }}, '{{ $req->titulo }}')" 
                                                 class="text-red-600 hover:text-red-900" title="Eliminar">
                                             <i class="fas fa-trash"></i>
                                         </button>
                                     </div>
                                 </td>
                            </tr>
                        @endforeach
                    @else
                        <tr>
                            <td colspan="7" class="px-6 py-12 text-center">
                                <i class="fas fa-file-alt text-gray-400 text-4xl mb-4"></i>
                                <p class="text-gray-500">No hay requerimientos disponibles</p>
                            </td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal para Crear Requerimiento -->
<div id="modalRequerimiento" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50 p-4">
    <div class="relative mx-auto p-4 sm:p-6 border w-full max-w-md sm:max-w-lg md:max-w-xl lg:max-w-2xl shadow-xl rounded-lg bg-white max-h-[90vh] overflow-y-auto">
        <div class="mt-2">
            <!-- Header del Modal -->
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-lg sm:text-xl font-semibold text-gray-800">Crear Nuevo Requerimiento</h3>
                <button onclick="cerrarModal()" class="text-gray-400 hover:text-gray-600 transition-colors p-1">
                    <i class="fas fa-times text-xl sm:text-2xl"></i>
                </button>
            </div>

            <!-- Formulario -->
            <form id="formRequerimiento" action="{{ route('fabricasoft.aprendiz.requerimientos.guardar') }}" method="POST" class="space-y-4 sm:space-y-6">
                @csrf
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                    <!-- Proyecto -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Proyecto *</label>
                        <select name="proyecto_id" required 
                                class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500">
                            <option value="">Seleccionar proyecto</option>
                            @if(isset($proyectos))
                                @foreach($proyectos as $proyecto)
                                    <option value="{{ $proyecto->id }}">{{ $proyecto->project_name }}</option>
                                @endforeach
                            @endif
                        </select>
                        <div id="error_proyecto_id" class="hidden text-red-500 text-sm mt-1"></div>
                    </div>
                    
                    <!-- Tipo -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Tipo *</label>
                        <select name="tipo" required 
                                class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500">
                            <option value="funcional" selected>Funcional</option>
                            <option value="no_funcional">No Funcional</option>
                            <option value="tecnico">Técnico</option>
                            <option value="usuario">Usuario</option>
                        </select>
                        <div id="error_tipo" class="hidden text-red-500 text-sm mt-1"></div>
                    </div>
                </div>
                
                <!-- Título -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Título *</label>
                    <input type="text" name="titulo" required 
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
                           placeholder="Ingrese el título del requerimiento">
                    <div id="error_titulo" class="hidden text-red-500 text-sm mt-1"></div>
                </div>
                
                <!-- Descripción -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Descripción *</label>
                    <textarea name="descripcion" rows="3" required 
                              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 resize-none"
                              placeholder="Describa detalladamente el requerimiento"></textarea>
                    <div id="error_descripcion" class="hidden text-red-500 text-sm mt-1"></div>
                </div>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                    <!-- Prioridad -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Prioridad *</label>
                        <select name="prioridad" required 
                                class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500">
                            <option value="baja">Baja</option>
                            <option value="media" selected>Media</option>
                            <option value="alta">Alta</option>
                        </select>
                        <div id="error_prioridad" class="hidden text-red-500 text-sm mt-1"></div>
                    </div>
                    
                    <!-- Complejidad -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Complejidad: <span id="complejidad-valor" class="font-semibold text-purple-600">5</span>/10
                        </label>
                        <div class="relative">
                            <input type="range" id="complejidad-slider" name="complejidad" 
                                   min="1" max="10" value="5" step="1"
                                   class="w-full h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer slider">
                            <div class="flex justify-between text-xs text-gray-500 mt-2">
                                <span>Baja</span>
                                <span>Media</span>
                                <span>Alta</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Criterios de Aceptación -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Criterios de Aceptación</label>
                    <textarea name="criterios_aceptacion" rows="3" 
                              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 resize-none"
                              placeholder="Defina los criterios de aceptación"></textarea>
                </div>
                
                <!-- Barras deslizantes adicionales -->
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Tiempo Estimado: <span id="tiempo-estimado-valor" class="font-semibold text-blue-600">16</span> horas
                        </label>
                        <div class="relative">
                            <input type="range" id="tiempo-estimado-slider" name="tiempo_estimado" 
                                   min="1" max="80" value="16" step="1"
                                   class="w-full h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer slider">
                            <div class="flex justify-between text-xs text-gray-500 mt-2">
                                <span>1h</span>
                                <span>20h</span>
                                <span>40h</span>
                                <span>60h</span>
                                <span>80h</span>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Urgencia: <span id="urgencia-valor" class="font-semibold text-orange-600">3</span>/5
                        </label>
                        <div class="relative">
                            <input type="range" id="urgencia-slider" name="urgencia" 
                                   min="1" max="5" value="3" step="1"
                                   class="w-full h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer slider">
                            <div class="flex justify-between text-xs text-gray-500 mt-2">
                                <span>Muy Baja</span>
                                <span>Baja</span>
                                <span>Media</span>
                                <span>Alta</span>
                                <span>Crítica</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Botones -->
                <div class="flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 pt-4 border-t border-gray-200">
                    <button type="button" onclick="cerrarModal()" 
                            class="w-full sm:w-auto px-4 sm:px-6 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors">
                        Cancelar
                    </button>
                    <button type="submit" 
                            class="w-full sm:w-auto px-4 sm:px-6 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 transition-colors">
                        <i class="fas fa-plus mr-2"></i>Crear Requerimiento
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

 <script>
 // Funciones de vista
 function cambiarVista(tipo) {
     // Actualizar botones
     document.querySelectorAll('.btn-vista').forEach(btn => {
         btn.classList.remove('active', 'bg-blue-600', 'text-white');
         btn.classList.add('bg-gray-200', 'text-gray-700');
     });
     event.target.classList.add('active', 'bg-blue-600', 'text-white');
     event.target.classList.remove('bg-gray-200', 'text-gray-700');
     
     // Cambiar vista
     document.querySelectorAll('.vista-contenido').forEach(vista => {
         vista.classList.add('hidden');
     });
     
     if (tipo === 'lista') {
         document.getElementById('vista-lista').classList.remove('hidden');
     } else if (tipo === 'kanban') {
         document.getElementById('vista-kanban').classList.remove('hidden');
     }
 }

 // Funciones de filtrado
 function aplicarFiltros() {
     const proyecto = document.getElementById('filtro-proyecto').value;
     const tipo = document.getElementById('filtro-tipo').value;
     const prioridad = document.getElementById('filtro-prioridad').value;
     const estado = document.getElementById('filtro-estado').value;
     
     const rows = document.querySelectorAll('.requerimiento-row');
     rows.forEach(row => {
         const rowProyecto = row.dataset.proyecto;
         const rowTipo = row.dataset.tipo;
         const rowPrioridad = row.dataset.prioridad;
         const rowEstado = row.dataset.estado;
         
         let mostrar = true;
         
         if (proyecto && rowProyecto !== proyecto) mostrar = false;
         if (tipo && rowTipo !== tipo) mostrar = false;
         if (prioridad && rowPrioridad !== prioridad) mostrar = false;
         if (estado && rowEstado !== estado) mostrar = false;
         
         row.style.display = mostrar ? 'table-row' : 'none';
     });
 }

 // Funciones de requerimientos
 function verDetalleRequerimiento(id) {
     // Aquí se cargaría el detalle del requerimiento via AJAX
     fetch(`/fabricasoft/desarrollador/requerimientos/${id}/detalle`)
         .then(response => response.json())
         .then(data => {
             document.getElementById('modal-content').innerHTML = `
                 <div class="space-y-4">
                     <div>
                         <h4 class="font-semibold text-gray-800">${data.titulo}</h4>
                         <p class="text-gray-600 mt-2">${data.descripcion}</p>
                     </div>
                     <div class="grid grid-cols-2 gap-4">
                         <div>
                             <label class="block text-sm font-medium text-gray-700">Proyecto</label>
                             <p class="text-sm text-gray-900">${data.proyecto_nombre}</p>
                         </div>
                         <div>
                             <label class="block text-sm font-medium text-gray-700">Tipo</label>
                             <p class="text-sm text-gray-900">${data.tipo}</p>
                         </div>
                         <div>
                             <label class="block text-sm font-medium text-gray-700">Prioridad</label>
                             <p class="text-sm text-gray-900">${data.prioridad}</p>
                         </div>
                         <div>
                             <label class="block text-sm font-medium text-gray-700">Estado</label>
                             <p class="text-sm text-gray-900">${data.estado}</p>
                         </div>
                     </div>
                     <div>
                         <label class="block text-sm font-medium text-gray-700">Criterios de Aceptación</label>
                         <p class="text-sm text-gray-900">${data.criterios_aceptacion || 'No especificados'}</p>
                     </div>
                 </div>
             `;
             document.getElementById('modal-detalle').classList.remove('hidden');
         })
         .catch(error => {
             console.error('Error:', error);
             alert('Error al cargar el detalle del requerimiento');
         });
 }

 function editarRequerimiento(id) {
     window.location.href = `/fabricasoft/desarrollador/requerimientos/${id}/editar`;
 }

 function cambiarEstadoRequerimiento(id) {
     const estados = ['pendiente', 'en_analisis', 'aprobado', 'rechazado', 'implementado'];
     const nuevoEstado = prompt('Selecciona el nuevo estado:\n' + estados.join('\n'));
     
     if (nuevoEstado && estados.includes(nuevoEstado)) {
         fetch(`/fabricasoft/desarrollador/requerimientos/${id}/cambiar-estado`, {
             method: 'POST',
             headers: {
                 'Content-Type': 'application/json',
                 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
             },
             body: JSON.stringify({ estado: nuevoEstado })
         })
         .then(response => response.json())
         .then(data => {
             if (data.success) {
                 location.reload();
             } else {
                 alert('Error al cambiar el estado');
             }
         })
         .catch(error => {
             console.error('Error:', error);
             alert('Error al cambiar el estado');
         });
     }
 }

 // Variables globales
 let isSubmitting = false;

 let requerimientosCount = {{ $estadisticas['total'] ?? 0 }};

 // Inicialización cuando el DOM esté listo
 document.addEventListener('DOMContentLoaded', function() {
     initializeEventListeners();
 });

 function initializeEventListeners() {
     // Botón para abrir modal
     document.getElementById('btnAgregarRequerimiento').addEventListener('click', abrirModal);
     
     // Botones para cerrar modal
     document.getElementById('btnCerrarModal').addEventListener('click', cerrarModal);
     document.getElementById('btnCancelar').addEventListener('click', cerrarModal);
     
     // Cerrar modal al hacer clic fuera
     document.getElementById('modalRequerimiento').addEventListener('click', function(e) {
         if (e.target === this) {
             cerrarModal();
         }
     });
     
     // Manejo del formulario
     document.getElementById('formRequerimiento').addEventListener('submit', manejarEnvioFormulario);
 }

 // Funciones del Modal
 function agregarRequerimiento() {
     document.getElementById('modalRequerimiento').classList.remove('hidden');
     document.body.style.overflow = 'hidden';
     inicializarSlidersRequerimiento();
 }

 function abrirModal() {
     document.getElementById('modalRequerimiento').classList.remove('hidden');
     document.body.style.overflow = 'hidden';
     limpiarFormulario();
     inicializarSlidersRequerimiento();
 }

 function cerrarModal() {
     document.getElementById('modalRequerimiento').classList.add('hidden');
     document.getElementById('modal-detalle').classList.add('hidden');
     document.body.style.overflow = 'auto';
     limpiarFormulario();
     resetearSlidersRequerimiento();
 }

 function limpiarFormulario() {
     document.getElementById('formRequerimiento').reset();
     // Limpiar errores
     const errorElements = document.querySelectorAll('[id^="error_"]');
     errorElements.forEach(element => {
         element.classList.add('hidden');
         element.textContent = '';
     });
 }

 // Funciones para barras deslizantes de requerimientos
 function inicializarSlidersRequerimiento() {
     const complejidadSlider = document.getElementById('complejidad-slider');
     const complejidadValor = document.getElementById('complejidad-valor');
     const tiempoSlider = document.getElementById('tiempo-estimado-slider');
     const tiempoValor = document.getElementById('tiempo-estimado-valor');
     const urgenciaSlider = document.getElementById('urgencia-slider');
     const urgenciaValor = document.getElementById('urgencia-valor');
     
     if (complejidadSlider && complejidadValor) {
         complejidadSlider.addEventListener('input', function() {
             complejidadValor.textContent = this.value;
         });
     }
     
     if (tiempoSlider && tiempoValor) {
         tiempoSlider.addEventListener('input', function() {
             tiempoValor.textContent = this.value;
         });
     }
     
     if (urgenciaSlider && urgenciaValor) {
         urgenciaSlider.addEventListener('input', function() {
             const urgencias = ['Muy Baja', 'Baja', 'Media', 'Alta', 'Crítica'];
             urgenciaValor.textContent = urgencias[this.value - 1];
         });
     }
 }

 function resetearSlidersRequerimiento() {
     const complejidadSlider = document.getElementById('complejidad-slider');
     const complejidadValor = document.getElementById('complejidad-valor');
     const tiempoSlider = document.getElementById('tiempo-estimado-slider');
     const tiempoValor = document.getElementById('tiempo-estimado-valor');
     const urgenciaSlider = document.getElementById('urgencia-slider');
     const urgenciaValor = document.getElementById('urgencia-valor');
     
     if (complejidadSlider && complejidadValor) {
         complejidadSlider.value = 5;
         complejidadValor.textContent = '5';
     }
     
     if (tiempoSlider && tiempoValor) {
         tiempoSlider.value = 16;
         tiempoValor.textContent = '16';
     }
     
     if (urgenciaSlider && urgenciaValor) {
         urgenciaSlider.value = 3;
         urgenciaValor.textContent = 'Media';
     }
 }

 function ocultarTodosLosErrores() {
     const errorElements = document.querySelectorAll('[id^="error_"]');
     errorElements.forEach(element => {
         element.classList.add('hidden');
         element.textContent = '';
     });
 }

 // Cerrar modal al hacer clic fuera de él
 document.getElementById('modalRequerimiento').addEventListener('click', function(e) {
     if (e.target === this) {
         cerrarModal();
     }
 });

 document.getElementById('modal-detalle').addEventListener('click', function(e) {
     if (e.target === this) {
         cerrarModal();
     }
 });

 // Variable para evitar múltiples envíos
 let isSubmitting = false;

 // Manejo del formulario
 document.getElementById('formRequerimiento').addEventListener('submit', function(e) {
     e.preventDefault();
     
     // Evitar múltiples envíos
     if (isSubmitting) {
         return;
     }
     
     // Validación del lado del cliente
     if (!validarFormulario()) {
         return;
     }
     
     // Marcar como enviando
     isSubmitting = true;
     
     // Deshabilitar el botón de envío
     const submitButton = this.querySelector('button[type="submit"]');
     const originalText = submitButton.innerHTML;
     submitButton.disabled = true;
     submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Guardando...';
     
     // Enviar formulario
     const formData = new FormData(this);
     
     // Obtener el token CSRF del meta tag o del formulario
     const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || 
                      document.querySelector('input[name="_token"]')?.value;
     
     fetch(this.action, {
         method: 'POST',
         body: formData,
         headers: {
             'X-CSRF-TOKEN': csrfToken,
             'Accept': 'application/json'
         }
     })
     .then(response => {
         if (!response.ok) {
             throw new Error(`HTTP error! status: ${response.status}`);
         }
         return response.json();
     })
     .then(data => {
         console.log('Respuesta del servidor:', data); // Debug
         
         if (data.success) {
             // Cerrar modal inmediatamente
             cerrarModal();
             
             // Agregar el nuevo requerimiento dinámicamente a la tabla
             agregarRequerimientoATabla(data);
             
             // Actualizar contadores
             actualizarContadores();
             
             // Mostrar mensaje de éxito
             Swal.fire({
                 title: '¡Creado!',
                 text: 'El requerimiento ha sido creado exitosamente.',
                 icon: 'success',
                 timer: 2000,
                 showConfirmButton: false
             });
         } else {
             // Mostrar errores de validación
             if (data.errors) {
                 mostrarErrores(data.errors);
             } else if (data.message) {
                 // Mostrar mensaje de error general
                 Swal.fire(
                     'Error',
                     data.message,
                     'error'
                 );
             } else {
                 mostrarErrores({});
             }
         }
     })
     .catch(error => {
         console.error('Error:', error);
         Swal.fire(
             'Error',
             'Error al guardar el requerimiento. Por favor, inténtalo de nuevo.',
             'error'
         );
     })
     .finally(() => {
         // Restaurar estado del botón
         isSubmitting = false;
         submitButton.disabled = false;
         submitButton.innerHTML = originalText;
     });
 });

 function validarFormulario() {
     let esValido = true;
     
     // Validar título
     const titulo = document.getElementById('titulo').value.trim();
     if (titulo.length < 5) {
         mostrarError('titulo', 'El título debe tener al menos 5 caracteres');
         esValido = false;
     } else {
         ocultarError('titulo');
     }
     
     // Validar descripción
     const descripcion = document.getElementById('descripcion').value.trim();
     if (descripcion.length < 20) {
         mostrarError('descripcion', 'La descripción debe tener al menos 20 caracteres');
         esValido = false;
     } else {
         ocultarError('descripcion');
     }
     
     // Validar proyecto
     const proyecto = document.getElementById('proyecto_id').value;
     if (!proyecto) {
         mostrarError('proyecto_id', 'Debes seleccionar un proyecto');
         esValido = false;
     } else {
         ocultarError('proyecto_id');
     }
     
     // Validar tipo
     const tipo = document.getElementById('tipo').value;
     if (!tipo) {
         mostrarError('tipo', 'Debes seleccionar un tipo');
         esValido = false;
     } else {
         ocultarError('tipo');
     }
     
     // Validar prioridad
     const prioridad = document.getElementById('prioridad').value;
     if (!prioridad) {
         mostrarError('prioridad', 'Debes seleccionar una prioridad');
         esValido = false;
     } else {
         ocultarError('prioridad');
     }
     
     return esValido;
 }

 function mostrarError(campo, mensaje) {
     const errorElement = document.getElementById(`error_${campo}`);
     errorElement.textContent = mensaje;
     errorElement.classList.remove('hidden');
 }

 function ocultarError(campo) {
     const errorElement = document.getElementById(`error_${campo}`);
     errorElement.classList.add('hidden');
 }

  function mostrarErrores(errors) {
      // Limpiar todos los errores primero
      const errorElements = document.querySelectorAll('[id^="error_"]');
      errorElements.forEach(element => {
          element.classList.add('hidden');
      });
      
      // Mostrar los nuevos errores
      for (const [campo, mensajes] of Object.entries(errors)) {
          if (Array.isArray(mensajes)) {
              mostrarError(campo, mensajes[0]);
          } else {
              mostrarError(campo, mensajes);
          }
      }
  }

  function agregarRequerimientoATabla(data) {
      const tbody = document.getElementById('requerimientos-tbody');
      if (!tbody) return;
      
      // Verificar que no exista ya una fila con este ID
      const existingRow = document.querySelector(`tr[data-requerimiento-id="${data.id}"]`);
      if (existingRow) {
          console.log('Ya existe una fila con este ID:', data.id);
          return;
      }
      
      // Obtener datos del formulario (como respaldo)
      const titulo = document.getElementById('titulo').value;
      const descripcion = document.getElementById('descripcion').value;
      const proyectoId = document.getElementById('proyecto_id').value;
      const tipo = document.getElementById('tipo').value;
      const prioridad = document.getElementById('prioridad').value;
      
      // Obtener nombre del proyecto
      const proyectoSelect = document.getElementById('proyecto_id');
      const proyectoOption = proyectoSelect.options[proyectoSelect.selectedIndex];
      const proyectoNombre = proyectoOption ? proyectoOption.text : 'N/A';
      
      // Crear nueva fila
      const nuevaFila = document.createElement('tr');
      nuevaFila.className = 'requerimiento-row hover:bg-gray-50';
      nuevaFila.setAttribute('data-requerimiento-id', data.id);
      nuevaFila.setAttribute('data-proyecto', proyectoId);
      nuevaFila.setAttribute('data-tipo', tipo);
      nuevaFila.setAttribute('data-prioridad', prioridad);
      nuevaFila.setAttribute('data-estado', 'pendiente');
      
      // Obtener clases CSS para badges
      const tipoClasses = tipo === 'funcional' ? 'bg-green-100 text-green-800' :
                         tipo === 'no_funcional' ? 'bg-blue-100 text-blue-800' :
                         tipo === 'tecnico' ? 'bg-purple-100 text-purple-800' : 'bg-gray-100 text-gray-800';
      
      const prioridadClasses = prioridad === 'alta' ? 'bg-red-100 text-red-800' :
                              prioridad === 'media' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800';
      
      nuevaFila.innerHTML = `
          <td class="px-6 py-4 whitespace-nowrap">
              <div class="flex items-center">
                  <div class="flex-shrink-0 h-10 w-10">
                      <div class="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                          <i class="fas fa-file-alt text-blue-600"></i>
                      </div>
                  </div>
                  <div class="ml-4">
                      <div class="text-sm font-medium text-gray-900">${titulo}</div>
                      <div class="text-sm text-gray-500 line-clamp-2">${descripcion}</div>
                  </div>
              </div>
          </td>
          <td class="px-6 py-4 whitespace-nowrap">
              <div class="text-sm text-gray-900">${proyectoNombre}</div>
          </td>
          <td class="px-6 py-4 whitespace-nowrap">
              <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${tipoClasses}">
                  ${tipo.charAt(0).toUpperCase() + tipo.slice(1).replace('_', ' ')}
              </span>
          </td>
          <td class="px-6 py-4 whitespace-nowrap">
              <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${prioridadClasses}">
                  <i class="fas fa-flag mr-1"></i>
                  ${prioridad.charAt(0).toUpperCase() + prioridad.slice(1)}
              </span>
          </td>
          <td class="px-6 py-4 whitespace-nowrap">
              <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                  Pendiente
              </span>
          </td>
          <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
              ${new Date().toLocaleDateString('es-ES')}
          </td>
          <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
              <div class="flex space-x-2">
                  <button onclick="verDetalleRequerimiento(${data.id})" 
                          class="text-blue-600 hover:text-blue-900" title="Ver detalle">
                      <i class="fas fa-eye"></i>
                  </button>
                  <button onclick="editarRequerimiento(${data.id})" 
                          class="text-green-600 hover:text-green-900" title="Editar">
                      <i class="fas fa-edit"></i>
                  </button>
                  <button onclick="cambiarEstadoRequerimiento(${data.id})" 
                          class="text-purple-600 hover:text-purple-900" title="Cambiar estado">
                      <i class="fas fa-exchange-alt"></i>
                  </button>
                  <button onclick="eliminarRequerimiento(${data.id}, '${titulo}')" 
                          class="text-red-600 hover:text-red-900" title="Eliminar">
                      <i class="fas fa-trash"></i>
                  </button>
              </div>
          </td>
      `;
      
      // Agregar la nueva fila al inicio de la tabla
      tbody.insertBefore(nuevaFila, tbody.firstChild);
      
      // Limpiar el formulario
      limpiarFormulario();
  }

  function actualizarContadores() {
      // Contar elementos visibles en la tabla
      const filasVisibles = document.querySelectorAll('.requerimiento-row:not([style*="display: none"])').length;
      
      // Actualizar el contador total en las estadísticas
      const totalElements = document.querySelectorAll('.text-2xl.font-semibold.text-gray-900');
      totalElements.forEach(element => {
          element.textContent = filasVisibles;
      });
      
      // Actualizar contadores específicos por estado
      const estados = ['pendiente', 'en_analisis', 'aprobado', 'rechazado', 'implementado'];
      estados.forEach(estado => {
          const contador = document.querySelector(`[data-estado="${estado}"] .text-2xl`);
          if (contador) {
              const count = document.querySelectorAll(`.requerimiento-row[data-estado="${estado}"]:not([style*="display: none"])`).length;
              contador.textContent = count;
          }
      });
      
      // Si no hay elementos, mostrar mensaje de "no hay requerimientos"
      const tbody = document.getElementById('requerimientos-tbody');
      if (filasVisibles === 0 && tbody) {
          tbody.innerHTML = `
              <tr>
                  <td colspan="7" class="px-6 py-12 text-center">
                      <i class="fas fa-file-alt text-gray-400 text-4xl mb-4"></i>
                      <p class="text-gray-500">No hay requerimientos disponibles</p>
                  </td>
              </tr>
          `;
      }
      
      console.log('Contadores actualizados. Total:', filasVisibles);
  }

function eliminarRequerimiento(id, titulo) {
    Swal.fire({
        title: '¿Estás seguro?',
        text: `¿Deseas eliminar el requerimiento "${titulo}"? Esta acción no se puede deshacer.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
            
            fetch(`/fabricasoft/aprendiz/requerimientos/${id}/eliminar`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': csrfToken,
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('Respuesta de eliminación:', data);
                
                if (data.success) {
                    // Eliminar fila específica
                    const row = document.querySelector(`tr[data-requerimiento-id="${id}"]`);
                    if (row) {
                        row.remove();
                        requerimientosCount--;
                        actualizarContador();
                        
                        // Si no quedan requerimientos, mostrar mensaje
                        const tbody = document.getElementById('requerimientos-tbody');
                        if (tbody.children.length === 0) {
                            tbody.innerHTML = `
                                <tr>
                                    <td colspan="7" class="px-6 py-12 text-center">
                                        <i class="fas fa-file-alt text-gray-400 text-4xl mb-4"></i>
                                        <p class="text-gray-500">No hay requerimientos disponibles</p>
                                    </td>
                                </tr>
                            `;
                        }
                    }
                    
                    Swal.fire({
                        title: '¡Eliminado!',
                        text: 'El requerimiento ha sido eliminado exitosamente.',
                        icon: 'success',
                        timer: 2000,
                        showConfirmButton: false
                    });
                } else {
                    Swal.fire('Error', data.message || 'Error al eliminar el requerimiento.', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                let mensaje = 'Error al eliminar el requerimiento. Por favor, inténtalo de nuevo.';
                
                if (error.message.includes('403')) {
                    mensaje = 'No tienes permisos para eliminar este requerimiento.';
                } else if (error.message.includes('404')) {
                    mensaje = 'El requerimiento no fue encontrado.';
                } else if (error.message.includes('500')) {
                    mensaje = 'Error interno del servidor. Por favor, contacta al administrador.';
                }
                
                Swal.fire('Error', mensaje, 'error');
            });
        }
    });
}
</script>

<style>
.line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.btn-vista.active {
    background-color: #2563eb;
    color: white;
}

/* Estilos mejorados para las barras deslizantes */
.slider {
    -webkit-appearance: none;
    appearance: none;
    background: transparent;
    cursor: pointer;
    outline: none;
}

.slider::-webkit-slider-track {
    background: linear-gradient(to right, #e5e7eb 0%, #d1d5db 100%);
    height: 8px;
    border-radius: 4px;
    border: 1px solid #d1d5db;
}

.slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    height: 24px;
    width: 24px;
    border-radius: 50%;
    cursor: pointer;
    box-shadow: 0 4px 8px rgba(16, 185, 129, 0.3);
    border: 2px solid #ffffff;
    transition: all 0.2s ease;
}

.slider::-webkit-slider-thumb:hover {
    transform: scale(1.1);
    box-shadow: 0 6px 12px rgba(16, 185, 129, 0.4);
}

.slider::-webkit-slider-thumb:active {
    transform: scale(1.05);
    box-shadow: 0 2px 4px rgba(16, 185, 129, 0.5);
}

.slider::-moz-range-track {
    background: linear-gradient(to right, #e5e7eb 0%, #d1d5db 100%);
    height: 8px;
    border-radius: 4px;
    border: 1px solid #d1d5db;
}

.slider::-moz-range-thumb {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    height: 24px;
    width: 24px;
    border-radius: 50%;
    cursor: pointer;
    border: 2px solid #ffffff;
    box-shadow: 0 4px 8px rgba(16, 185, 129, 0.3);
    transition: all 0.2s ease;
}

.slider::-moz-range-thumb:hover {
    transform: scale(1.1);
    box-shadow: 0 6px 12px rgba(16, 185, 129, 0.4);
}

/* Estilos para el modal responsive */
@media (max-width: 640px) {
    #modalRequerimiento {
        padding: 0.5rem;
    }
    
    #modalRequerimiento .relative {
        margin: 0.5rem;
        max-height: calc(100vh - 1rem);
    }
    
    .slider::-webkit-slider-thumb {
        height: 20px;
        width: 20px;
    }
    
    .slider::-moz-range-thumb {
        height: 20px;
        width: 20px;
    }
}

@media (max-width: 480px) {
    #modalRequerimiento .relative {
        padding: 1rem;
    }
    
    .grid-cols-1.sm\\:grid-cols-2 {
        grid-template-columns: 1fr;
    }
}

/* Animaciones para el modal */
@keyframes modalFadeIn {
    from {
        opacity: 0;
        transform: scale(0.95);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

#modalRequerimiento:not(.hidden) .relative {
    animation: modalFadeIn 0.3s ease-out;
}

/* Transiciones suaves */
.transition-colors {
    transition: all 0.2s ease-in-out;
}

/* Estilos para valores de sliders */
#complejidad-valor,
#tiempo-estimado-valor,
#urgencia-valor {
    transition: color 0.2s ease;
}

/* Hover effects para botones */
button:hover {
    transform: translateY(-1px);
    transition: all 0.2s ease;
}

button:active {
    transform: translateY(0);
}

/* Estilos para el modal */
.modal-content {
    max-height: 90vh;
    overflow-y: auto;
}
</style>
@endsection 