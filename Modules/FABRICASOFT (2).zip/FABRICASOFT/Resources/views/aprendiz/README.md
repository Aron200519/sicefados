# Vistas del Desarrollador/Aprendiz - Módulo FABRICASOFT

Este directorio contiene todas las vistas específicas para desarrolladores y aprendices del módulo FABRICASOFT. Estas vistas proporcionan una interfaz completa para la gestión de proyectos, requerimientos, tareas y reportes.

## Estructura de Archivos

### Vistas Principales

1. **`dashboard.blade.php`** - Dashboard principal del desarrollador
   - Estadísticas rápidas de proyectos y tareas
   - Acceso rápido a funcionalidades principales
   - Vista de proyectos activos y tareas recientes

2. **`proyectos.blade.php`** - Gestión de proyectos
   - Listado de proyectos asignados
   - Filtros avanzados por estado, prioridad y fechas
   - Vista de tarjetas con información detallada
   - Acceso directo a detalles y requerimientos

3. **`requerimientos.blade.php`** - Análisis de requerimientos
   - Gestión completa de requerimientos de proyectos
   - Vista de lista y vista Kanban
   - Filtros por proyecto, tipo, prioridad y estado
   - Funcionalidades de edición y cambio de estado

4. **`tareas.blade.php`** - Gestión de tareas
   - Sistema completo de gestión de tareas
   - Estadísticas de rendimiento
   - Vista de lista y vista Kanban
   - Creación, edición y seguimiento de tareas

5. **`reportes.blade.php`** - Reportes y estadísticas
   - Métricas de rendimiento
   - Gráficos interactivos con Chart.js
   - Tabla de rendimiento por proyecto
   - Actividad reciente y logros

6. **`proyecto-detalle.blade.php`** - Detalle de proyecto
   - Información completa del proyecto
   - Pestañas para requerimientos, tareas, documentos y comentarios
   - Estadísticas del proyecto
   - Gestión de estado del proyecto

### Partials

1. **`partials/requerimiento-card.blade.php`** - Tarjeta de requerimiento para vista Kanban
2. **`partials/tarea-card.blade.php`** - Tarjeta de tarea para vista Kanban

## Características Principales

### Dashboard
- **Estadísticas Rápidas**: Proyectos activos, tareas pendientes, completados y horas trabajadas
- **Acceso Rápido**: Enlaces directos a las principales funcionalidades
- **Proyectos Activos**: Vista previa de proyectos en desarrollo
- **Tareas Recientes**: Lista de tareas más recientes

### Gestión de Proyectos
- **Filtros Avanzados**: Por estado, prioridad, fechas de inicio y fin
- **Vista de Tarjetas**: Información visual de cada proyecto
- **Barras de Progreso**: Indicadores visuales del avance
- **Acciones Rápidas**: Acceso directo a detalles y requerimientos

### Análisis de Requerimientos
- **Vista Dual**: Lista y Kanban
- **Filtros Específicos**: Por proyecto, tipo, prioridad y estado
- **Gestión de Estados**: Cambio de estado con modal
- **Detalles Completos**: Información completa de cada requerimiento

### Gestión de Tareas
- **Sistema Kanban**: Organización visual de tareas
- **Estadísticas**: Métricas de rendimiento
- **Creación de Tareas**: Modal para nueva tarea
- **Seguimiento de Progreso**: Barras de progreso y actualización

### Reportes y Estadísticas
- **Gráficos Interactivos**: Chart.js para visualización
- **Métricas Clave**: KPIs de rendimiento
- **Tabla de Rendimiento**: Comparación por proyecto
- **Exportación**: Funcionalidad de exportar reportes

### Detalle de Proyecto
- **Información Completa**: Todos los datos del proyecto
- **Pestañas Organizadas**: Requerimientos, tareas, documentos, comentarios
- **Estadísticas Específicas**: Métricas del proyecto
- **Gestión de Estado**: Actualización de estado del proyecto

## Tecnologías Utilizadas

- **Laravel Blade**: Motor de plantillas
- **Tailwind CSS**: Framework de estilos
- **Font Awesome**: Iconografía
- **Chart.js**: Gráficos interactivos
- **JavaScript**: Funcionalidades interactivas
- **AJAX**: Comunicación asíncrona

## Funcionalidades JavaScript

### Dashboard
- Preloader con animaciones
- Actualización automática de notificaciones
- Navegación responsive

### Gestión de Proyectos
- Filtrado dinámico de proyectos
- Cambio de vista (todos/activos/completados)
- Filtros avanzados con múltiples criterios

### Requerimientos
- Cambio entre vista lista y Kanban
- Filtrado por múltiples criterios
- Modales para edición y cambio de estado
- Drag & Drop (preparado para implementación)

### Tareas
- Sistema Kanban completo
- Creación de tareas con modal
- Actualización de progreso
- Cambio de estados

### Reportes
- Gráficos interactivos
- Filtros por período
- Exportación de reportes
- Actualización dinámica de datos

## Responsive Design

Todas las vistas están diseñadas para ser completamente responsivas:
- **Mobile First**: Diseño optimizado para móviles
- **Breakpoints**: Adaptación a tablets y desktop
- **Navegación**: Menú lateral colapsable en móviles
- **Tablas**: Scroll horizontal en dispositivos pequeños

## Integración con Backend

Las vistas están preparadas para integrarse con:
- **Controladores Laravel**: Para manejo de datos
- **Modelos Eloquent**: Para relaciones de datos
- **Rutas**: Sistema de rutas de Laravel
- **Middleware**: Autenticación y autorización
- **Base de Datos**: Consultas optimizadas

## Personalización

### Colores y Temas
- Variables CSS para colores principales
- Sistema de colores consistente
- Fácil personalización de temas

### Iconografía
- Font Awesome para iconos
- Iconos contextuales por funcionalidad
- Consistencia visual

### Tipografía
- Roboto como fuente principal
- Jerarquía tipográfica clara
- Legibilidad optimizada

## Próximas Mejoras

1. **Drag & Drop**: Implementación completa en Kanban
2. **Notificaciones en Tiempo Real**: WebSockets
3. **Filtros Avanzados**: Búsqueda por texto
4. **Exportación**: PDF y Excel
5. **Calendario**: Vista de calendario para tareas
6. **Chat**: Sistema de comunicación interna

## Notas de Implementación

- Todas las rutas están referenciadas con nombres de ruta de Laravel
- Los datos se pasan desde el controlador como variables
- Las funciones JavaScript están preparadas para AJAX
- Los modales están implementados con JavaScript vanilla
- Los gráficos requieren Chart.js incluido en la página

## Dependencias Externas

```html
<!-- Chart.js para gráficos -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Font Awesome para iconos -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<!-- Tailwind CSS -->
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
``` 