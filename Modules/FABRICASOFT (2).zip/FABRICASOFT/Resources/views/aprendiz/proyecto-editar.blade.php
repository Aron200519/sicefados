@extends('fabricasoft::layouts.masteraprendiz')

@section('content')
<div class="container mx-auto px-4 py-6">
    <!-- Header -->
    <div class="mb-8">
        <div class="flex items-center mb-4">
            <a href="{{ route('fabricasoft.aprendiz.proyectos') }}" class="text-blue-600 hover:text-blue-800 mr-3">
                <i class="fas fa-arrow-left"></i>
            </a>
            <h1 class="text-3xl font-bold text-gray-800">Editar Proyecto</h1>
        </div>
        <p class="text-gray-600">Actualiza la información de tu proyecto asignado</p>
    </div>

    <!-- Formulario de Edición -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <form action="{{ route('fabricasoft.aprendiz.proyecto.actualizar', $proyecto->id) }}" method="POST" class="space-y-6">
            @csrf
            @method('PUT')
            
            <!-- Información Básica -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Nombre del Proyecto</label>
                    <input type="text" name="project_name" value="{{ $proyecto->project_name }}" 
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" readonly>
                    <p class="text-xs text-gray-500 mt-1">El nombre del proyecto no se puede modificar</p>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Estado del Proyecto</label>
                    <select name="status" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="pendiente" {{ $proyecto->status == 'pendiente' ? 'selected' : '' }}>Pendiente</option>
                        <option value="en_desarrollo" {{ $proyecto->status == 'en_desarrollo' ? 'selected' : '' }}>En Desarrollo</option>
                        <option value="revision" {{ $proyecto->status == 'revision' ? 'selected' : '' }}>En Revisión</option>
                        <option value="testing" {{ $proyecto->status == 'testing' ? 'selected' : '' }}>En Testing</option>
                        <option value="completado" {{ $proyecto->status == 'completado' ? 'selected' : '' }}>Completado</option>
                        <option value="pausado" {{ $proyecto->status == 'pausado' ? 'selected' : '' }}>Pausado</option>
                    </select>
                </div>
            </div>

            <!-- Prioridad -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-flag mr-2"></i>Prioridad del Proyecto
                    </label>
                    <select name="prioridad" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="alta" {{ ($proyecto->prioridad ?? 'media') == 'alta' ? 'selected' : '' }}>Alta</option>
                        <option value="media" {{ ($proyecto->prioridad ?? 'media') == 'media' ? 'selected' : '' }}>Media</option>
                        <option value="baja" {{ ($proyecto->prioridad ?? 'media') == 'baja' ? 'selected' : '' }}>Baja</option>
                    </select>
                    <p class="text-xs text-gray-500 mt-1">Define la prioridad de desarrollo del proyecto</p>
                </div>
            </div>

            <!-- Objetivos -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Objetivo General</label>
                <textarea name="general_objective" rows="3" 
                          class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Describe el objetivo general del proyecto">{{ $proyecto->general_objective }}</textarea>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Objetivos Específicos</label>
                <textarea name="specific_objectives" rows="3" 
                          class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Describe los objetivos específicos del proyecto">{{ $proyecto->specific_objectives }}</textarea>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Propósito del Sistema</label>
                <textarea name="system_purpose" rows="3" 
                          class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Describe el propósito del sistema">{{ $proyecto->system_purpose }}</textarea>
            </div>

            <!-- Comentarios del Aprendiz -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Comentarios del Aprendiz</label>
                <textarea name="apprentice_comments" rows="4" 
                          class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder="Agrega comentarios sobre el progreso, dificultades encontradas, o cualquier información relevante">{{ $proyecto->apprentice_comments ?? '' }}</textarea>
            </div>

            <!-- Botones de Acción -->
            <div class="flex justify-end space-x-4 pt-6 border-t border-gray-200">
                <a href="{{ route('fabricasoft.aprendiz.proyectos') }}" 
                   class="px-6 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 transition-colors">
                    Cancelar
                </a>
                <button type="submit" 
                        class="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
                    <i class="fas fa-save mr-2"></i>Guardar Cambios
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Validación del formulario
document.querySelector('form').addEventListener('submit', function(e) {
    // Mostrar indicador de carga
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Guardando...';
    submitBtn.disabled = true;
    
    return true;
});
</script>
@endsection 