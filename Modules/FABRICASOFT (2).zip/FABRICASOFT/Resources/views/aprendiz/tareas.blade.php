@extends('fabricasoft::layouts.masteraprendiz')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-tasks"></i> Proyectos Asignados
                    </h3>
                </div>
                <div class="card-body">
                    <!-- Proyecto 1 -->
                    <div class="project-card mb-3">
                        <div class="row align-items-center">
                            <div class="col-md-4">
                                <h5 class="mb-1">Solicitud vía formulario</h5>
                                <span class="badge badge-primary">En curso</span>
                            </div>
                            <div class="col-md-3">
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 25%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%</div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <small class="text-muted">Última actualización: 13/08/2025</small>
                            </div>
                            <div class="col-md-2 text-right">
                                <button type="button" class="btn btn-primary btn-sm" onclick="toggleProjectTasks('proyecto1', 'Solicitud vía formulario')">
                                    <i class="fas fa-list"></i> Ver Tareas
                                </button>
                            </div>
                        </div>
                        
                        <!-- Acordeón para las tareas -->
                        <div class="accordion mt-3" id="tasks-proyecto1">
                            <div class="accordion-content" id="project-tasks-proyecto1" style="display: none;">
                                <!-- El contenido se cargará dinámicamente -->
                            </div>
                        </div>
                    </div>

                    <!-- Proyecto 2 -->
                    <div class="project-card mb-3">
                        <div class="row align-items-center">
                            <div class="col-md-4">
                                <h5 class="mb-1">Sistema de gestión</h5>
                                <span class="badge badge-warning">Pendiente</span>
                            </div>
                            <div class="col-md-3">
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">0%</div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <small class="text-muted">Última actualización: 13/08/2025</small>
                            </div>
                            <div class="col-md-2 text-right">
                                <button type="button" class="btn btn-primary btn-sm" onclick="toggleProjectTasks('proyecto2', 'Sistema de gestión')">
                                    <i class="fas fa-list"></i> Ver Tareas
                                </button>
                            </div>
                        </div>
                        
                        <!-- Acordeón para las tareas -->
                        <div class="accordion mt-3" id="tasks-proyecto2">
                            <div class="accordion-content" id="project-tasks-proyecto2" style="display: none;">
                                <!-- El contenido se cargará dinámicamente -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.project-card {
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.accordion-content {
    background: #f8f9fa;
    border-radius: 8px;
    overflow: hidden;
}

.phase-table {
    background: white;
    border-radius: 8px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    overflow: hidden;
}

.phase-header {
    padding: 15px 20px;
    color: white;
    font-weight: bold;
    font-size: 18px;
}

.phase-header.analisis { background: linear-gradient(135deg, #007bff 0%, #0056b3 100%); }
.phase-header.diseno { background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%); }
.phase-header.implementacion { background: linear-gradient(135deg, #ffc107 0%, #e0a800 100%); }
.phase-header.pruebas { background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); }
.phase-header.despliegue { background: linear-gradient(135deg, #6f42c1 0%, #5a2d91 100%); }

.table {
    margin-bottom: 0;
}

.table th {
    background: #f8f9fa;
    border-bottom: 2px solid #dee2e6;
    font-weight: 600;
    color: #495057;
}

.table td {
    vertical-align: middle;
    border-bottom: 1px solid #dee2e6;
}

.task-checkbox {
    transform: scale(1.2);
    cursor: pointer;
}

.task-title {
    font-weight: 600;
    color: #495057;
    margin-bottom: 5px;
}

.task-title.completed {
    text-decoration: line-through;
    color: #6c757d;
}

.task-description {
    color: #6c757d;
    font-size: 14px;
}

.task-actions {
    display: flex;
    gap: 5px;
    justify-content: center;
}

.btn-edit-task, .btn-delete-task {
    border: none;
    padding: 5px 8px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 12px;
}

.btn-edit-task {
    background: #ffc107;
    color: white;
}

.btn-delete-task {
    background: #dc3545;
    color: white;
}

.add-task-section {
    background: #f8f9fa;
    padding: 20px;
    border-top: 1px solid #dee2e6;
}

.add-task-form {
    display: flex;
    gap: 15px;
    align-items: end;
    flex-wrap: wrap;
}

.form-group {
    flex: 1;
    min-width: 200px;
}

.form-label {
    display: block;
    margin-bottom: 5px;
    font-weight: 600;
    color: #495057;
}

.form-input, .form-textarea, .form-select {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #ced4da;
    border-radius: 4px;
    font-size: 14px;
}

.form-textarea {
    height: 60px;
    resize: vertical;
}

.btn-add-task {
    background: #28a745;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    cursor: pointer;
    font-weight: 600;
}

.phase-progress {
    background: #e9ecef;
    padding: 15px 20px;
    border-top: 1px solid #dee2e6;
}

.progress-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.progress-label {
    font-weight: 600;
    color: #495057;
}

.progress-percentage {
    font-weight: bold;
    color: #007bff;
}

.progress-bar-container {
    margin-bottom: 10px;
}

.progress-bar {
    background: #dee2e6;
    height: 20px;
    border-radius: 10px;
    overflow: hidden;
    margin-bottom: 5px;
}

.progress-fill {
    height: 100%;
    background: #007bff;
    transition: width 0.3s ease;
}

.progress-fill.completed {
    background: #28a745;
}

.progress-stats {
    text-align: center;
    color: #6c757d;
    font-size: 14px;
}

.task-modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
}

.modal-content {
    background-color: white;
    margin: 5% auto;
    padding: 0;
    border-radius: 8px;
    width: 90%;
    max-width: 500px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.modal-header {
    background: #f8f9fa;
    padding: 15px 20px;
    border-bottom: 1px solid #dee2e6;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-title {
    margin: 0;
    color: #495057;
}

.close-modal {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #6c757d;
}

.modal-body {
    padding: 20px;
}

.modal-form-group {
    margin-bottom: 15px;
}

.modal-label {
    display: block;
    margin-bottom: 5px;
    font-weight: 600;
    color: #495057;
}

.modal-input, .modal-textarea, .modal-select {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #ced4da;
    border-radius: 4px;
    font-size: 14px;
}

.modal-textarea {
    height: 80px;
    resize: vertical;
}

.modal-actions {
    padding: 15px 20px;
    border-top: 1px solid #dee2e6;
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}

.btn-modal {
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-weight: 600;
}

.btn-modal.cancel {
    background: #6c757d;
    color: white;
}

.btn-modal.save {
    background: #28a745;
    color: white;
}

.enlace-section {
    background: #f8f9fa;
    padding: 15px 20px;
    border-top: 1px solid #dee2e6;
}

.enlace-container {
    width: 100%;
}

.enlace-label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #495057;
    font-size: 14px;
}

.task-link-input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ced4da;
    border-radius: 4px;
    font-size: 14px;
    height: 80px;
    resize: vertical;
    font-family: inherit;
}

.enlaces-clickables {
    margin-top: 10px;
    padding: 10px;
    background: #f8f9fa;
    border: 1px solid #dee2e6;
    border-radius: 4px;
    min-height: 20px;
}

.enlace-clickable {
    display: block;
    color: #007bff;
    text-decoration: underline;
    margin-bottom: 5px;
    cursor: pointer;
    word-break: break-all;
    font-size: 14px;
}

.enlace-clickable:hover {
    color: #0056b3;
    text-decoration: none;
}

.enlace-texto {
    color: #007bff;
    text-decoration: underline;
}

.enlace-hint {
    color: #495057;
    font-weight: bold;
    font-size: 14px;
    margin-bottom: 5px;
    text-align: center;
    background: #e3f2fd;
    padding: 8px;
    border-radius: 4px;
    border: 1px solid #bbdefb;
}

.enlace-flecha {
    color: #007bff;
    font-size: 16px;
    text-align: center;
    margin-bottom: 5px;
    font-weight: bold;
}

.overall-progress {
    background: #e8f5e8;
    border: 2px solid #28a745;
    border-radius: 8px;
    padding: 20px;
    text-align: center;
    margin-top: 30px;
}

.overall-progress h4 {
    color: #155724;
    margin-bottom: 10px;
}

.overall-progress p {
    color: #155724;
    margin: 5px 0;
}
</style>

<script>
// Estructura de datos para las tareas
const tareasData = {
    analisis: [
        { id: 'analisis-1', titulo: 'Historias de usuario con criterios de aceptación (.xlsx)', descripcion: 'Documento que describe las funcionalidades desde la perspectiva del usuario final, incluyendo criterios específicos para validar que cada historia esté completa.', completada: false, estado: 'pendiente' },
        { id: 'analisis-2', titulo: 'Historial de usuario (.xlsx)', descripcion: 'Registro detallado de todas las interacciones y cambios realizados por los usuarios en el sistema.', completada: false, estado: 'pendiente' },
        { id: 'analisis-3', titulo: 'Matriz de trazabilidad de requisitos (.xlsx)', descripcion: 'Tabla que relaciona cada requisito con su origen, implementación y pruebas, asegurando que ningún requisito se pierda durante el desarrollo.', completada: false, estado: 'pendiente' },
        { id: 'analisis-4', titulo: 'SRS completo y con diagramas iniciales (.docx)', descripcion: 'Especificación de Requisitos del Software que describe detalladamente qué debe hacer el sistema, incluyendo diagramas UML iniciales.', completada: false, estado: 'pendiente' },
        { id: 'analisis-5', titulo: 'Crear diagrama de contexto (nivel 0 de DFD)', descripcion: 'Diagrama de Flujo de Datos que muestra el sistema como un proceso central y su interacción con entidades externas.', completada: false, estado: 'pendiente' },
        { id: 'analisis-6', titulo: 'Crear diagrama de casos de uso (UML)', descripcion: 'Diagrama UML que identifica todos los actores del sistema y las funcionalidades principales que pueden realizar.', completada: false, estado: 'pendiente' },
        { id: 'analisis-7', titulo: 'Especificaciones de casos de uso', descripcion: 'Documento detallado que describe los flujos principales y alternativos para cada caso de uso identificado.', completada: false, estado: 'pendiente' },
        { id: 'analisis-8', titulo: 'Documento de análisis completo', descripcion: 'Resumen ejecutivo de todo el análisis realizado, incluyendo conclusiones y recomendaciones para las siguientes fases.', completada: false, estado: 'pendiente' }
    ],
    diseno: [
        { id: 'diseno-1', titulo: 'Documento de diseño técnico', descripcion: 'Especificación detallada de la arquitectura del sistema, patrones de diseño utilizados y estructura modular.', completada: false, estado: 'pendiente' },
        { id: 'diseno-2', titulo: 'Crear diagrama de clases (UML)', descripcion: 'Diagrama UML que muestra las entidades del sistema, sus atributos, métodos y las relaciones entre ellas.', completada: false, estado: 'pendiente' },
        { id: 'diseno-3', titulo: 'Crear diagrama de secuencia (UML)', descripcion: 'Diagrama UML que representa el flujo de mensajes entre objetos en un escenario específico del sistema.', completada: false, estado: 'pendiente' },
        { id: 'diseno-4', titulo: 'Crear diagrama de actividades (UML)', descripcion: 'Diagrama UML que describe los flujos de procesos internos y la lógica de negocio del sistema.', completada: false, estado: 'pendiente' },
        { id: 'diseno-5', titulo: 'Crear diagrama de flujo de procesos', descripcion: 'Flowchart que representa visualmente los procesos clave del sistema y su flujo de trabajo.', completada: false, estado: 'pendiente' },
        { id: 'diseno-6', titulo: 'Modelo entidad-relación (ERD)', descripcion: 'Diagrama que muestra las tablas de la base de datos, sus relaciones y cardinalidades.', completada: false, estado: 'pendiente' },
        { id: 'diseno-7', titulo: 'Diccionario de datos', descripcion: 'Definición detallada de cada campo de la base de datos, incluyendo tipos, restricciones y descripciones.', completada: false, estado: 'pendiente' },
        { id: 'diseno-8', titulo: 'Wireframes o mockups', descripcion: 'Bocetos visuales de las interfaces del sistema, mostrando la disposición de elementos y navegación.', completada: false, estado: 'pendiente' },
        { id: 'diseno-9', titulo: 'Prototipo funcional', descripcion: 'Prototipo interactivo creado en Figma, Adobe XD o herramienta similar para validar el diseño con usuarios.', completada: false, estado: 'pendiente' },
        { id: 'diseno-10', titulo: 'Presentación de diseño para cliente (.pptx)', descripcion: 'Presentación que explica el diseño del sistema al cliente para su aprobación antes de la implementación.', completada: false, estado: 'pendiente' }
    ],
    implementacion: [
        { id: 'implementacion-1', titulo: 'Manual de instalación y configuración', descripcion: 'Documento paso a paso para instalar y configurar el entorno de desarrollo y producción.', completada: false, estado: 'pendiente' },
        { id: 'implementacion-2', titulo: 'Documentación de API', descripcion: 'Documentación completa de la API usando Swagger, Postman o Redoc, incluyendo endpoints, parámetros y respuestas.', completada: false, estado: 'pendiente' },
        { id: 'implementacion-3', titulo: 'Estándares de codificación', descripcion: 'Documento que define las convenciones de nomenclatura, estructura de carpetas y mejores prácticas de código.', completada: false, estado: 'pendiente' },
        { id: 'implementacion-4', titulo: 'Bitácora de desarrollo', descripcion: 'Registro diario de avances, decisiones técnicas y problemas encontrados durante la implementación.', completada: false, estado: 'pendiente' },
        { id: 'implementacion-5', titulo: 'Logo y elementos visuales (.docx)', descripcion: 'Documento que contiene el logo del proyecto y todos los elementos visuales utilizados en la interfaz.', completada: false, estado: 'pendiente' },
        { id: 'implementacion-6', titulo: 'Repositorio Git con commits organizados', descripcion: 'Repositorio de código fuente con commits organizados por funcionalidad y documentación del historial de cambios.', completada: false, estado: 'pendiente' },
        { id: 'implementacion-7', titulo: 'Documentación de código', descripcion: 'Comentarios en el código y documentación técnica de las funciones y clases principales.', completada: false, estado: 'pendiente' },
        { id: 'implementacion-8', titulo: 'Manual de desarrollador', descripcion: 'Guía para desarrolladores que incluye configuración del entorno, flujo de trabajo y estándares del proyecto.', completada: false, estado: 'pendiente' }
    ],
    pruebas: [
        { id: 'pruebas-1', titulo: 'Plan de pruebas (.docx)', descripcion: 'Documento que define la estrategia de pruebas, tipos de pruebas a realizar y cronograma de ejecución.', completada: false, estado: 'pendiente' },
        { id: 'pruebas-2', titulo: 'Casos de prueba (.xlsx)', descripcion: 'Matriz de casos de prueba que cubre todos los escenarios y funcionalidades del sistema.', completada: false, estado: 'pendiente' },
        { id: 'pruebas-3', titulo: 'Resultados de pruebas (.docx)', descripcion: 'Reporte de los resultados obtenidos de la ejecución de todos los casos de prueba.', completada: false, estado: 'pendiente' },
        { id: 'pruebas-4', titulo: 'Plan de pruebas manuales (.docx)', descripcion: 'Plan específico para pruebas manuales que no pueden ser automatizadas.', completada: false, estado: 'pendiente' },
        { id: 'pruebas-5', titulo: 'Registro de errores/bugs', descripcion: 'Documento en Excel o herramienta de gestión que registra todos los errores encontrados durante las pruebas.', completada: false, estado: 'pendiente' },
        { id: 'pruebas-6', titulo: 'Pruebas de integración y validación', descripcion: 'Documentación de las pruebas que validan la integración entre módulos y la funcionalidad completa del sistema.', completada: false, estado: 'pendiente' },
        { id: 'pruebas-7', titulo: 'Informe final de pruebas', descripcion: 'Reporte final con el estatus de aprobación y recomendaciones para el despliegue.', completada: false, estado: 'pendiente' },
        { id: 'pruebas-8', titulo: 'Reporte de calidad', descripcion: 'Evaluación de la calidad del software basada en los resultados de las pruebas y métricas de calidad.', completada: false, estado: 'pendiente' }
    ],
    despliegue: [
        { id: 'despliegue-1', titulo: 'Manual de usuario', descripcion: 'Guía completa para usuarios finales con capturas de pantalla paso a paso de todas las funcionalidades.', completada: false, estado: 'pendiente' },
        { id: 'despliegue-2', titulo: 'Manual técnico', descripcion: 'Documentación técnica para administradores y personal de sistemas sobre la instalación y mantenimiento.', completada: false, estado: 'pendiente' },
        { id: 'despliegue-3', titulo: 'Registro de despliegue', descripcion: 'Documento que registra fecha, hora y todos los cambios realizados durante el despliegue en producción.', completada: false, estado: 'pendiente' },
        { id: 'despliegue-4', titulo: 'Plan de capacitación', descripcion: 'Plan detallado para capacitar a usuarios y administradores en el uso del sistema desplegado.', completada: false, estado: 'pendiente' }
    ]
};

// Función para alternar la visibilidad de las tareas del proyecto
function toggleProjectTasks(projectId, projectName) {
    const content = document.getElementById(`project-tasks-${projectId}`);
    const isVisible = content.style.display !== 'none';
    
    if (isVisible) {
        // Cerrar acordeón
        content.style.display = 'none';
    } else {
        // Abrir acordeón y cargar tareas
        content.style.display = 'block';
        renderizarTareasCompletas(projectId, projectName);
    }
}

// Función para renderizar todas las tareas
function renderizarTareasCompletas(projectId, projectName) {
    const content = document.getElementById(`project-tasks-${projectId}`);
    
    let html = `
        <div style="padding: 20px;">
            <h3 style="color: #2c3e50; margin-bottom: 20px; text-align: center;">📋 Tareas del Proyecto: ${projectName}</h3>
    `;
    
    // Definir fases
    const fases = [
        { key: 'analisis', nombre: 'Análisis', icon: 'fas fa-search', color: '#007bff' },
        { key: 'diseno', nombre: 'Diseño', icon: 'fas fa-pencil-ruler', color: '#28a745' },
        { key: 'implementacion', nombre: 'Implementación', icon: 'fas fa-code', color: '#ffc107' },
        { key: 'pruebas', nombre: 'Pruebas', icon: 'fas fa-vial', color: '#dc3545' },
        { key: 'despliegue', nombre: 'Despliegue', icon: 'fas fa-rocket', color: '#6f42c1' }
    ];
    
    fases.forEach(fase => {
        const tareasFase = tareasData[fase.key] || [];
        const completadas = tareasFase.filter(t => t.completada).length;
        const total = tareasFase.length;
        const porcentaje = total > 0 ? Math.round((completadas / total) * 100) : 0;
        
        html += `
            <div class="phase-table">
                <div class="phase-header ${fase.key}">
                    <i class="${fase.icon} mr-2"></i>Fase de ${fase.nombre}
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th width="5%">Estado</th>
                                <th width="35%">Tarea</th>
                                <th width="45%">Descripción</th>
                                <th width="15%">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
        `;
        
        tareasFase.forEach(tarea => {
            const estadoText = tarea.completada ? '✅ Completada' : '⏳ Pendiente';
            const tituloClass = tarea.completada ? 'task-title completed' : 'task-title';
            
            html += `
                <tr id="${tarea.id}">
                    <td class="text-center">
                        <input type="checkbox" class="task-checkbox" ${tarea.completada ? 'checked' : ''} 
                               onchange="toggleTarea('${tarea.id}', '${fase.key}', '${projectId}')">
                    </td>
                    <td>
                        <div class="${tituloClass}">${tarea.titulo}</div>
                        <small class="text-muted">${estadoText}</small>
                    </td>
                    <td>
                        <div class="task-description">${tarea.descripcion}</div>
                    </td>
                    <td>
                        <div class="task-actions">
                            <button class="btn-edit-task" onclick="openTaskModal('${tarea.id}', '${fase.key}', '${projectId}')" title="Editar tarea">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn-delete-task" onclick="deleteTask('${tarea.id}', '${fase.key}', '${projectId}')" title="Eliminar tarea">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        });
        
        html += `
                        </tbody>
                    </table>
                </div>
                
                <!-- Formulario para agregar nueva tarea -->
                <div class="add-task-section">
                    <form class="add-task-form" onsubmit="event.preventDefault(); addNewTask('${fase.key}', '${projectId}', this);">
                        <div class="form-group">
                            <label class="form-label">Título de la Tarea</label>
                            <input type="text" class="form-input" name="titulo" placeholder="Ingrese el título de la tarea" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Descripción</label>
                            <textarea class="form-textarea" name="descripcion" placeholder="Descripción detallada de la tarea" required></textarea>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Estado</label>
                            <select class="form-select" name="estado" required>
                                <option value="pendiente">Pendiente</option>
                                <option value="en_progreso">En Progreso</option>
                                <option value="revision">En Revisión</option>
                                <option value="completada">Completada</option>
                            </select>
                        </div>
                        <button type="submit" class="btn-add-task">
                            <i class="fas fa-plus"></i> Agregar Tarea
                        </button>
                    </form>
                </div>
                
                <!-- Sección de enlaces de documentos -->
                <div class="enlace-section">
                    <div class="enlace-container">
                        <label class="enlace-label">Enlaces de documentos de esta fase:</label>
                        <textarea class="task-link-input" id="enlaces-${fase.key}-${projectId}" placeholder="Pega aquí todos los enlaces de documentos de esta fase (Google Drive, GitHub, etc.)" onblur="guardarEnlacesFase('${fase.key}', '${projectId}')" oninput="convertirEnlacesAClickables('${fase.key}', '${projectId}')"></textarea>
                        <div class="enlaces-clickables" id="enlaces-clickables-${fase.key}-${projectId}"></div>
                    </div>
                </div>
                
                <!-- Progreso de la fase -->
                <div class="phase-progress">
                    <div class="progress-info">
                        <span class="progress-label">Progreso de la fase</span>
                        <span class="progress-percentage">${porcentaje}%</span>
                    </div>
                    <div class="progress-bar-container">
                        <div class="progress-bar">
                            <div class="progress-fill ${porcentaje === 100 ? 'completed' : ''}" style="width: ${porcentaje}%"></div>
                        </div>
                        <div class="progress-stats">
                            <strong>${completadas}</strong> de <strong>${total}</strong> tareas completadas
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    
    // Resumen general
    const totalTareas = Object.values(tareasData).flat().length;
    const totalCompletadas = Object.values(tareasData).flat().filter(t => t.completada).length;
    const progresoGeneral = totalTareas > 0 ? Math.round((totalCompletadas / totalTareas) * 100) : 0;
    
    html += `
            <div class="overall-progress">
                <h4>🎯 Resumen del Proyecto</h4>
                <p><strong>Total de Tareas:</strong> ${totalTareas} | <strong>Completadas:</strong> ${totalCompletadas} | <strong>Pendientes:</strong> ${totalTareas - totalCompletadas}</p>
                <p><strong>Progreso General:</strong> ${progresoGeneral}%</p>
            </div>
        </div>
    `;
    
    content.innerHTML = html;
    
    // Cargar enlaces guardados después de renderizar
    cargarEnlacesGuardados(projectId);
}

// Función para alternar el estado de una tarea
function toggleTarea(tareaId, fase, projectId) {
    const tarea = tareasData[fase].find(t => t.id === tareaId);
    if (tarea) {
        tarea.completada = !tarea.completada;
        tarea.estado = tarea.completada ? 'completada' : 'pendiente';
        
        // Actualizar la fila visualmente
        const fila = document.getElementById(tareaId);
        const titulo = fila.querySelector('.task-title');
        const estadoText = fila.querySelector('small');
        
        if (tarea.completada) {
            titulo.classList.add('completed');
        } else {
            titulo.classList.remove('completed');
        }
        
        if (estadoText) {
            estadoText.textContent = tarea.completada ? '✅ Completada' : '⏳ Pendiente';
        }
        
        // Re-renderizar para actualizar progresos
        const projectName = projectId === 'proyecto1' ? 'Solicitud vía formulario' : 'Sistema de gestión';
        renderizarTareasCompletas(projectId, projectName);
        
        // Guardar en localStorage
        guardarEnLocalStorage();
        
        // Mostrar notificación
        mostrarNotificacion(tarea.completada ? '¡Tarea marcada como completada!' : 'Tarea marcada como pendiente', 'success');
    }
}

// Función para agregar nueva tarea
function addNewTask(fase, projectId, form) {
    const formData = new FormData(form);
    const titulo = formData.get('titulo');
    const descripcion = formData.get('descripcion');
    const estado = formData.get('estado');
    
    const nuevaTarea = {
        id: `${fase}-${Date.now()}`,
        titulo: titulo,
        descripcion: descripcion,
        completada: estado === 'completada',
        estado: estado
    };
    
    tareasData[fase].push(nuevaTarea);
    
    // Limpiar formulario
    form.reset();
    
    // Re-renderizar
    const projectName = projectId === 'proyecto1' ? 'Solicitud vía formulario' : 'Sistema de gestión';
    renderizarTareasCompletas(projectId, projectName);
    
    // Guardar en localStorage
    guardarEnLocalStorage();
    
    // Mostrar notificación
    mostrarNotificacion('¡Nueva tarea agregada exitosamente!', 'success');
}

// Función para abrir modal de edición
function openTaskModal(tareaId, fase, projectId) {
    const tarea = tareasData[fase].find(t => t.id === tareaId);
    if (tarea) {
        // Crear modal dinámicamente
        const modal = document.createElement('div');
        modal.className = 'task-modal';
        modal.id = 'taskModal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">Editar Tarea</h3>
                    <button class="close-modal" onclick="closeTaskModal()">&times;</button>
                </div>
                <div class="modal-body">
                    <form id="editTaskForm">
                        <input type="hidden" id="editTaskId" value="${tareaId}">
                        <input type="hidden" id="editTaskPhase" value="${fase}">
                        <input type="hidden" id="editProjectId" value="${projectId}">
                        <div class="modal-form-group">
                            <label class="modal-label">Título de la Tarea</label>
                            <input type="text" class="modal-input" id="editTaskTitulo" value="${tarea.titulo}" required>
                        </div>
                        <div class="modal-form-group">
                            <label class="modal-label">Descripción</label>
                            <textarea class="modal-textarea" id="editTaskDescripcion" required>${tarea.descripcion}</textarea>
                        </div>
                        <div class="modal-form-group">
                            <label class="modal-label">Estado</label>
                            <select class="modal-select" id="editTaskEstado" required>
                                <option value="pendiente" ${tarea.estado === 'pendiente' ? 'selected' : ''}>Pendiente</option>
                                <option value="en_progreso" ${tarea.estado === 'en_progreso' ? 'selected' : ''}>En Progreso</option>
                                <option value="revision" ${tarea.estado === 'revision' ? 'selected' : ''}>En Revisión</option>
                                <option value="completada" ${tarea.estado === 'completada' ? 'selected' : ''}>Completada</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-actions">
                    <button type="button" class="btn-modal cancel" onclick="closeTaskModal()">Cancelar</button>
                    <button type="button" class="btn-modal save" onclick="saveTaskChanges()">Guardar Cambios</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'block';
    }
}

// Función para cerrar modal
function closeTaskModal() {
    const modal = document.getElementById('taskModal');
    if (modal) {
        modal.remove();
    }
}

// Función para guardar cambios de tarea
function saveTaskChanges() {
    const taskId = document.getElementById('editTaskId').value;
    const phase = document.getElementById('editTaskPhase').value;
    const projectId = document.getElementById('editProjectId').value;
    const titulo = document.getElementById('editTaskTitulo').value;
    const descripcion = document.getElementById('editTaskDescripcion').value;
    const estado = document.getElementById('editTaskEstado').value;
    
    if (!titulo || !descripcion) {
        mostrarNotificacion('Por favor complete todos los campos requeridos', 'error');
        return;
    }
    
    const task = tareasData[phase].find(t => t.id === taskId);
    if (task) {
        task.titulo = titulo;
        task.descripcion = descripcion;
        task.estado = estado;
        task.completada = estado === 'completada';
        
        closeTaskModal();
        
        // Re-renderizar
        const projectName = projectId === 'proyecto1' ? 'Solicitud vía formulario' : 'Sistema de gestión';
        renderizarTareasCompletas(projectId, projectName);
        
        // Guardar en localStorage
        guardarEnLocalStorage();
        
        // Mostrar notificación
        mostrarNotificacion('¡Tarea actualizada correctamente!', 'success');
    }
}

// Función para eliminar tarea
function deleteTask(taskId, phase, projectId) {
    if (confirm('¿Estás seguro de que quieres eliminar esta tarea?')) {
        tareasData[phase] = tareasData[phase].filter(t => t.id !== taskId);
        
        // Re-renderizar
        const projectName = projectId === 'proyecto1' ? 'Solicitud vía formulario' : 'Sistema de gestión';
        renderizarTareasCompletas(projectId, projectName);
        
        // Guardar en localStorage
        guardarEnLocalStorage();
        
        // Mostrar notificación
        mostrarNotificacion('¡Tarea eliminada exitosamente!', 'success');
    }
}

// Función para mostrar notificaciones
function mostrarNotificacion(mensaje, tipo) {
    const notificacion = document.createElement('div');
    notificacion.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 8px;
        color: white;
        font-weight: bold;
        z-index: 9999;
        animation: slideIn 0.3s ease;
        background: ${tipo === 'success' ? '#28a745' : tipo === 'error' ? '#dc3545' : '#17a2b8'};
    `;
    
    notificacion.textContent = mensaje;
    document.body.appendChild(notificacion);
    
    setTimeout(() => {
        notificacion.remove();
    }, 3000);
}

// Función para guardar en localStorage
function guardarEnLocalStorage() {
    localStorage.setItem('fabricasoft_tareas_proyectos', JSON.stringify(tareasData));
}

// Función para guardar enlaces de una fase
function guardarEnlacesFase(fase, projectId) {
    const textarea = document.getElementById(`enlaces-${fase}-${projectId}`);
    if (textarea) {
        const enlaces = textarea.value;
        localStorage.setItem(`enlaces-${fase}-${projectId}`, enlaces);
    }
}

// Función para convertir enlaces a clickeables
function convertirEnlacesAClickables(fase, projectId) {
    const textarea = document.getElementById(`enlaces-${fase}-${projectId}`);
    const containerClickables = document.getElementById(`enlaces-clickables-${fase}-${projectId}`);
    
    if (textarea && containerClickables) {
        const texto = textarea.value;
        const urls = extraerURLs(texto);
        
        containerClickables.innerHTML = '';
        
        urls.forEach(url => {
            const enlaceElement = document.createElement('div');
            enlaceElement.className = 'enlace-clickable';
            enlaceElement.innerHTML = `
                <div class="enlace-hint">(Haz click aquí para acceder al link)</div>
                <div class="enlace-flecha">↓</div>
                <div class="enlace-texto">${url}</div>
            `;
            enlaceElement.onclick = function() {
                window.open(url, '_blank');
            };
            containerClickables.appendChild(enlaceElement);
        });
    }
}

// Función para extraer URLs del texto
function extraerURLs(texto) {
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    return texto.match(urlRegex) || [];
}

// Función para cargar enlaces guardados
function cargarEnlacesGuardados(projectId) {
    const fases = ['analisis', 'diseno', 'implementacion', 'pruebas', 'despliegue'];
    fases.forEach(fase => {
        const enlacesGuardados = localStorage.getItem(`enlaces-${fase}-${projectId}`);
        if (enlacesGuardados) {
            const textarea = document.getElementById(`enlaces-${fase}-${projectId}`);
            if (textarea) {
                textarea.value = enlacesGuardados;
                // Convertir enlaces a clickeables después de cargar
                convertirEnlacesAClickables(fase, projectId);
            }
        }
    });
}

// Función para cargar desde localStorage
function cargarDesdeLocalStorage() {
    const guardado = localStorage.getItem('fabricasoft_tareas_proyectos');
    if (guardado) {
        const datos = JSON.parse(guardado);
        Object.keys(datos).forEach(fase => {
            if (tareasData[fase]) {
                tareasData[fase] = datos[fase];
            }
        });
    }
}

// Cargar datos al inicializar
document.addEventListener('DOMContentLoaded', function() {
    console.log('Página cargada correctamente');
    cargarDesdeLocalStorage();
});

// Cerrar modal al hacer click fuera de él
window.addEventListener('click', function(event) {
    const modal = document.getElementById('taskModal');
    if (event.target === modal) {
        closeTaskModal();
    }
});
</script>
@endsection

