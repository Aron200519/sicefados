@extends('fabricasoft::layouts.masteraprendiz')

@section('content')
<div class="container mx-auto px-4 py-6">
    <!-- Header del Dashboard -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-2">Dashboard del Aprendiz</h1>
        <p class="text-gray-600">Bienvenido al panel de gestión de proyectos y desarrollo</p>
    </div>

    <!-- Estadísticas Rápidas -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <!-- Proyectos Activos -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                    <i class="fas fa-code text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Proyectos Activos</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $proyectosActivos ?? 0 }}</p>
                    <p class="text-xs text-blue-600">En desarrollo y revisión</p>
                </div>
            </div>
        </div>

        <!-- Tareas Pendientes -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-yellow-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-yellow-100 text-yellow-600">
                    <i class="fas fa-tasks text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Tareas Pendientes</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $proyectosPendientes ?? 0 }}</p>
                    <p class="text-xs text-yellow-600">Esperando asignación</p>
                </div>
            </div>
        </div>

        <!-- Proyectos Completados -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-green-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-green-100 text-green-600">
                    <i class="fas fa-check-circle text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Completados</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $proyectosCompletados->count() ?? 0 }}</p>
                    <p class="text-xs text-green-600">Proyectos finalizados</p>
                </div>
            </div>
        </div>

        <!-- Total de Proyectos -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-purple-100 text-purple-600">
                    <i class="fas fa-project-diagram text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Total Proyectos</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $totalProyectos ?? 0 }}</p>
                    <p class="text-xs text-purple-600">Todos los asignados</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Acciones Rápidas -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <!-- Mis Proyectos Activos -->
        <div class="bg-white rounded-lg shadow-md">
            <div class="p-6 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800 flex items-center">
                    <i class="fas fa-rocket text-blue-500 mr-3"></i>
                    Mis Proyectos Activos
                </h3>
            </div>
            <div class="p-6">
                @if(isset($misProyectos) && $misProyectos->count() > 0)
                    <div class="space-y-4">
                        @foreach($misProyectos as $proyecto)
                        <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                                            <div class="flex-1">
                    @php
                        $formularioNombre = null;
                        if ($proyecto->formulario_id) {
                            $formulario = \DB::table('formularios')->where('id', $proyecto->formulario_id)->first();
                            $formularioNombre = $formulario ? $formulario->nombre : null;
                        }
                    @endphp
                    <h4 class="font-medium text-gray-800">
                        {{ $proyecto->project_name }}
                        @if($formularioNombre)
                            <span class="text-sm text-blue-600">({{ $formularioNombre }})</span>
                        @endif
                    </h4>
                    <p class="text-sm text-gray-600">{{ $proyecto->applicant_name }}</p>
                                <div class="flex items-center justify-between mt-2 mb-2">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                        {{ $proyecto->estado_legible }}
                                    </span>
                                    <span class="text-xs text-gray-600">{{ $progresosProyectos[$proyecto->id] ?? $proyecto->progreso_por_estado }}%</span>
                                </div>
                                <!-- Barra de progreso -->
                                <div class="w-full bg-gray-200 rounded-full h-2">
                                    <div class="bg-blue-600 h-2 rounded-full transition-all duration-300" style="width: {{ $progresosProyectos[$proyecto->id] ?? $proyecto->progreso_por_estado }}%"></div>
                                </div>
                            </div>
                            <div class="flex space-x-2">
                                <a href="{{ route('fabricasoft.aprendiz.proyecto.detalle', $proyecto->id) }}" 
                                   class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    <i class="fas fa-eye mr-2"></i>
                                    Ver
                                </a>
                            </div>
                        </div>
                        @endforeach
                    </div>
                @else
                    <div class="text-center py-8">
                        <i class="fas fa-folder-open text-gray-400 text-4xl mb-4"></i>
                        <p class="text-gray-500">No tienes proyectos activos asignados</p>
                    </div>
                @endif
            </div>
        </div>

        <!-- Tareas Recientes -->
        <div class="bg-white rounded-lg shadow-md">
            <div class="p-6 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800 flex items-center">
                    <i class="fas fa-list-check text-green-500 mr-3"></i>
                    Tareas Recientes
                </h3>
            </div>
            <div class="p-6">
                @if(isset($tareasRecientes) && $tareasRecientes->count() > 0)
                    <div class="space-y-4">
                        @foreach($tareasRecientes as $tarea)
                        <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                            <div class="flex-1">
                                <h4 class="font-medium text-gray-800">{{ $tarea->project_name }}</h4>
                                <p class="text-sm text-gray-600">{{ $tarea->applicant_name }}</p>
                                <div class="flex items-center mt-2">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                        Pendiente
                                    </span>
                                </div>
                            </div>
                            <div class="flex space-x-2">
                                <a href="{{ route('fabricasoft.aprendiz.proyecto.detalle', $tarea->id) }}" 
                                   class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                                    <i class="fas fa-eye mr-2"></i>
                                    Ver
                                </a>
                            </div>
                        </div>
                        @endforeach
                    </div>
                @else
                    <div class="text-center py-8">
                        <i class="fas fa-clipboard-list text-gray-400 text-4xl mb-4"></i>
                        <p class="text-gray-500">No hay tareas recientes</p>
                    </div>
                @endif
            </div>
        </div>
    </div>

    <!-- Acceso Rápido -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-6 flex items-center">
            <i class="fas fa-bolt text-yellow-500 mr-3"></i>
            Acceso Rápido
        </h3>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <a href="{{ route('fabricasoft.aprendiz.proyectos') }}" 
               class="flex items-center p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                <i class="fas fa-project-diagram text-blue-600 text-xl mr-3"></i>
                <div>
                    <p class="font-medium text-blue-800">Mis Proyectos</p>
                    <p class="text-sm text-blue-600">Gestionar proyectos</p>
                </div>
            </a>

            <a href="{{ route('fabricasoft.aprendiz.requerimientos') }}" 
               class="flex items-center p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
                <i class="fas fa-file-alt text-green-600 text-xl mr-3"></i>
                <div>
                    <p class="font-medium text-green-800">Requerimientos</p>
                    <p class="text-sm text-green-600">Analizar requerimientos</p>
                </div>
            </a>

            <a href="{{ route('fabricasoft.aprendiz.tareas') }}" 
               class="flex items-center p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
                <i class="fas fa-tasks text-purple-600 text-xl mr-3"></i>
                <div>
                    <p class="font-medium text-purple-800">Tareas</p>
                    <p class="text-sm text-purple-600">Gestionar tareas</p>
                </div>
            </a>

            <a href="{{ route('fabricasoft.aprendiz.reportes') }}" 
               class="flex items-center p-4 bg-orange-50 rounded-lg hover:bg-orange-100 transition-colors">
                <i class="fas fa-chart-bar text-orange-600 text-xl mr-3"></i>
                <div>
                    <p class="font-medium text-orange-800">Reportes</p>
                    <p class="text-sm text-orange-600">Ver estadísticas</p>
                </div>
            </a>
        </div>
    </div>
</div>
@endsection 