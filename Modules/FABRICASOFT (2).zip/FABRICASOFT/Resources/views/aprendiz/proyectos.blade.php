@extends('fabricasoft::layouts.masteraprendiz')

@section('content')
<div class="container mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
    <!-- Header -->
    <div class="mb-6 sm:mb-8">
        <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-4 sm:space-y-0">
            <div class="flex-1">
                <h1 class="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">Mis Proyectos</h1>
                <p class="text-sm sm:text-base text-gray-600">Gestiona y visualiza todos tus proyectos asignados</p>
            </div>
            <div class="flex flex-wrap gap-2 sm:gap-3">
                <button onclick="filtrarProyectos('todos')" class="btn-filtro active px-3 sm:px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 text-sm sm:text-base transition-colors">
                    Todos
                </button>
                <button onclick="filtrarProyectos('activos')" class="btn-filtro px-3 sm:px-4 py-2 rounded-lg bg-gray-200 text-gray-700 hover:bg-gray-300 text-sm sm:text-base transition-colors">
                    Activos
                </button>
                <button onclick="filtrarProyectos('completados')" class="btn-filtro px-3 sm:px-4 py-2 rounded-lg bg-gray-200 text-gray-700 hover:bg-gray-300 text-sm sm:text-base transition-colors">
                    Completados
                </button>
            </div>
        </div>
    </div>

    <!-- Estadísticas Rápidas -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 sm:gap-6 mb-6 sm:mb-8">
        <div class="statistics-card bg-white rounded-lg shadow-md p-4 sm:p-6 border-l-4 border-blue-500 hover:shadow-lg transition-shadow">
            <div class="flex items-center">
                <div class="p-2 sm:p-3 rounded-full bg-blue-100 text-blue-600 flex-shrink-0">
                    <i class="fas fa-project-diagram text-lg sm:text-xl"></i>
                </div>
                <div class="ml-3 sm:ml-4 flex-1">
                    <p class="text-sm sm:text-base font-semibold text-gray-700 mb-1">Total Proyectos</p>
                    <p class="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">{{ $estadisticas['total'] ?? 0 }}</p>
                    <p class="text-xs sm:text-sm text-blue-600 font-medium">Todos los asignados</p>
                </div>
            </div>
        </div>

        <div class="statistics-card bg-white rounded-lg shadow-md p-4 sm:p-6 border-l-4 border-yellow-500 hover:shadow-lg transition-shadow">
            <div class="flex items-center">
                <div class="p-2 sm:p-3 rounded-full bg-yellow-100 text-yellow-600 flex-shrink-0">
                    <i class="fas fa-clock text-lg sm:text-xl"></i>
                </div>
                <div class="ml-3 sm:ml-4 flex-1">
                    <p class="text-sm sm:text-base font-semibold text-gray-700 mb-1">Pendientes</p>
                    <p class="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">{{ $estadisticas['pendientes'] ?? 0 }}</p>
                    <p class="text-xs sm:text-sm text-yellow-600 font-medium">Esperando inicio</p>
                </div>
            </div>
        </div>

        <div class="statistics-card bg-white rounded-lg shadow-md p-4 sm:p-6 border-l-4 border-purple-500 hover:shadow-lg transition-shadow">
            <div class="flex items-center">
                <div class="p-2 sm:p-3 rounded-full bg-purple-100 text-purple-600 flex-shrink-0">
                    <i class="fas fa-code text-lg sm:text-xl"></i>
                </div>
                <div class="ml-3 sm:ml-4 flex-1">
                    <p class="text-sm sm:text-base font-semibold text-gray-700 mb-1">En Desarrollo</p>
                    <p class="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">{{ $estadisticas['en_desarrollo'] ?? 0 }}</p>
                    <p class="text-xs sm:text-sm text-purple-600 font-medium">Trabajando activamente</p>
                </div>
            </div>
        </div>

        <div class="statistics-card bg-white rounded-lg shadow-md p-4 sm:p-6 border-l-4 border-orange-500 hover:shadow-lg transition-shadow">
            <div class="flex items-center">
                <div class="p-2 sm:p-3 rounded-full bg-orange-100 text-orange-600 flex-shrink-0">
                    <i class="fas fa-search text-lg sm:text-xl"></i>
                </div>
                <div class="ml-3 sm:ml-4 flex-1">
                    <p class="text-sm sm:text-base font-semibold text-gray-700 mb-1">En Revisión</p>
                    <p class="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">{{ $estadisticas['revision'] ?? 0 }}</p>
                    <p class="text-xs sm:text-sm text-orange-600 font-medium">En proceso de revisión</p>
                </div>
            </div>
        </div>

        <div class="statistics-card bg-white rounded-lg shadow-md p-4 sm:p-6 border-l-4 border-green-500 hover:shadow-lg transition-shadow">
            <div class="flex items-center">
                <div class="p-2 sm:p-3 rounded-full bg-green-100 text-green-600 flex-shrink-0">
                    <i class="fas fa-check-circle text-lg sm:text-xl"></i>
                </div>
                <div class="ml-3 sm:ml-4 flex-1">
                    <p class="text-sm sm:text-base font-semibold text-gray-700 mb-1">Completados</p>
                    <p class="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">{{ $estadisticas['completados'] ?? 0 }}</p>
                    <p class="text-xs sm:text-sm text-green-600 font-medium">Proyectos finalizados</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Filtros Avanzados -->
    <div class="bg-white rounded-lg shadow-md p-4 sm:p-6 mb-6 sm:mb-8">
        <h3 class="text-base sm:text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <i class="fas fa-filter text-blue-500 mr-2 sm:mr-3"></i>
            Filtros Avanzados
        </h3>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label class="block text-xs sm:text-sm font-medium text-gray-700 mb-2">Estado</label>
                <select id="filtro-estado" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                    <option value="">Todos los estados</option>
                    <option value="en_desarrollo">En Desarrollo</option>
                    <option value="revision">En Revisión</option>
                    <option value="testing">En Testing</option>
                    <option value="completado">Completado</option>
                    <option value="pausado">Pausado</option>
                </select>
            </div>
            <div>
                <label class="block text-xs sm:text-sm font-medium text-gray-700 mb-2">Prioridad</label>
                <select id="filtro-prioridad" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                    <option value="">Todas las prioridades</option>
                    <option value="alta">Alta</option>
                    <option value="media">Media</option>
                    <option value="baja">Baja</option>
                </select>
            </div>
        </div>
        <div class="mt-4 flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-2">
            <button onclick="aplicarFiltros()" class="w-full sm:w-auto px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm transition-colors">
                <i class="fas fa-search mr-2"></i>Aplicar Filtros
            </button>
            <button onclick="limpiarFiltros()" class="w-full sm:w-auto px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 text-sm transition-colors">
                <i class="fas fa-times mr-2"></i>Limpiar
            </button>
        </div>
    </div>

    <!-- Lista de Proyectos -->
    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6" id="proyectos-container">
        @if(isset($proyectos) && $proyectos->count() > 0)
            @foreach($proyectos as $proyecto)
            <div class="proyecto-card bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow" 
                 data-estado="{{ $proyecto->status ?? 'en_desarrollo' }}" 
                 data-prioridad="{{ $proyecto->prioridad ?? 'media' }}"
                 data-fecha-inicio="{{ $proyecto->start_date ?? '' }}"
                 data-fecha-fin="{{ $proyecto->end_date ?? '' }}">
                
                <!-- Header del Proyecto -->
                <div class="p-4 sm:p-6 border-b border-gray-200">
                    <div class="flex flex-col sm:flex-row sm:justify-between sm:items-start mb-3 space-y-2 sm:space-y-0">
                        @php
                            $formularioNombre = null;
                            if ($proyecto->formulario_id) {
                                $formulario = \DB::table('formularios')->where('id', $proyecto->formulario_id)->first();
                                $formularioNombre = $formulario ? $formulario->nombre : null;
                            }
                        @endphp
                        <h3 class="text-base sm:text-lg font-semibold text-gray-800 line-clamp-2 flex-1">
                            {{ $proyecto->project_name }}
                            @if($formularioNombre)
                                <span class="text-sm text-blue-600">({{ $formularioNombre }})</span>
                            @endif
                        </h3>
                        <div class="flex flex-col space-y-1">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium {{ $proyecto->estado_clase_css }}">
                                {{ $proyecto->estado_legible }}
                            </span>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                @if($proyecto->prioridad == 'alta') bg-red-100 text-red-800
                                @elseif($proyecto->prioridad == 'media') bg-yellow-100 text-yellow-800
                                @else bg-green-100 text-green-800 @endif">
                                <i class="fas fa-flag mr-1"></i>{{ ucfirst($proyecto->prioridad ?? 'media') }}
                            </span>
                        </div>
                    </div>
                    
                    <div class="space-y-2">
                        <div class="flex items-center text-xs sm:text-sm text-gray-600">
                            <i class="fas fa-user mr-2"></i>
                            <span class="truncate">{{ $proyecto->applicant_name }}</span>
                        </div>
                        
                        <div class="flex items-center text-xs sm:text-sm text-gray-600">
                            <i class="fas fa-building mr-2"></i>
                            <span class="truncate">{{ $proyecto->company_name }}</span>
                        </div>
                        
                        <div class="flex items-center text-xs sm:text-sm text-gray-600">
                            <i class="fas fa-calendar mr-2"></i>
                            <span>Creado: {{ \Carbon\Carbon::parse($proyecto->created_at)->format('d/m/Y') }}</span>
                        </div>
                    </div>
                </div>
                
                <!-- Detalles del Proyecto -->
                <div class="p-4 sm:p-6">
                    <div class="space-y-4">
                        <div>
                            <h4 class="font-medium text-gray-800 mb-2 text-sm sm:text-base">Objetivo General</h4>
                            <p class="text-xs sm:text-sm text-gray-600 line-clamp-3">{{ $proyecto->general_objective ?? 'No especificado' }}</p>
                        </div>
                        
                        <div>
                            <h4 class="font-medium text-gray-800 mb-2 text-sm sm:text-base">Objetivo Específico</h4>
                            <p class="text-xs sm:text-sm text-gray-600 line-clamp-3">{{ $proyecto->specific_objectives ?? 'No especificado' }}</p>
                        </div>
                        
                        <div>
                            <h4 class="font-medium text-gray-800 mb-2 text-sm sm:text-base">Propósito del Sistema</h4>
                            <p class="text-xs sm:text-sm text-gray-600 line-clamp-3">{{ $proyecto->system_purpose ?? 'No especificado' }}</p>
                        </div>
                    </div>
                    
                    <!-- Progreso del Proyecto -->
                    <div class="mt-4">
                        <div class="flex justify-between text-xs sm:text-sm text-gray-600 mb-1">
                            <span>Progreso</span>
                            <span>{{ $progresosProyectos[$proyecto->id] ?? $proyecto->progreso_por_estado }}%</span>
                        </div>
                        <div class="w-full bg-gray-200 rounded-full h-2">
                            <div class="bg-blue-600 h-2 rounded-full transition-all duration-300" style="width: {{ $progresosProyectos[$proyecto->id] ?? $proyecto->progreso_por_estado }}%">
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Acciones del Proyecto -->
                <div class="p-4 sm:p-6 border-t border-gray-200 bg-gray-50">
                    <div class="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
                        <a href="{{ route('fabricasoft.aprendiz.proyecto.detalle', $proyecto->id) }}" 
                           class="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-center py-2 px-4 rounded-md transition-colors text-sm">
                            <i class="fas fa-eye mr-2"></i>Ver Detalles
                        </a>
                        <button onclick="editarProyecto({{ $proyecto->id }})" class="bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-md transition-colors text-sm">
                            <i class="fas fa-edit"></i>
                        </button>
                    </div>
                </div>
            </div>
            @endforeach
        @else
            <div class="col-span-full text-center py-8 sm:py-12">
                <div class="bg-white rounded-lg shadow-md p-6 sm:p-8">
                    <i class="fas fa-folder-open text-gray-400 text-4xl sm:text-6xl mb-4"></i>
                    <h3 class="text-lg sm:text-xl font-semibold text-gray-600 mb-2">No tienes proyectos asignados</h3>
                    <p class="text-sm sm:text-base text-gray-500">Cuando se te asignen proyectos, aparecerán aquí.</p>
                </div>
            </div>
        @endif
    </div>

    <!-- Paginación -->
    @if(isset($proyectos) && method_exists($proyectos, 'hasPages') && $proyectos->hasPages())
    <div class="mt-6 sm:mt-8 flex justify-center">
        {{ $proyectos->links() }}
    </div>
    @endif
</div>

<script>
// Funciones de filtrado
function filtrarProyectos(tipo) {
    // Actualizar botones
    document.querySelectorAll('.btn-filtro').forEach(btn => {
        btn.classList.remove('active', 'bg-blue-600', 'text-white');
        btn.classList.add('bg-gray-200', 'text-gray-700');
    });
    event.target.classList.add('active', 'bg-blue-600', 'text-white');
    event.target.classList.remove('bg-gray-200', 'text-gray-700');
    
    // Aplicar filtro
    const cards = document.querySelectorAll('.proyecto-card');
    cards.forEach(card => {
        const estado = card.dataset.estado;
        let mostrar = true;
        
        if (tipo === 'activos') {
            mostrar = estado !== 'completado';
        } else if (tipo === 'completados') {
            mostrar = estado === 'completado';
        }
        
        card.style.display = mostrar ? 'block' : 'none';
    });
}

function aplicarFiltros() {
    const estado = document.getElementById('filtro-estado').value;
    const prioridad = document.getElementById('filtro-prioridad').value;
    
    const cards = document.querySelectorAll('.proyecto-card');
    cards.forEach(card => {
        const cardEstado = card.dataset.estado;
        const cardPrioridad = card.dataset.prioridad;
        
        let mostrar = true;
        
        if (estado && cardEstado !== estado) mostrar = false;
        if (prioridad && cardPrioridad !== prioridad) mostrar = false;
        
        card.style.display = mostrar ? 'block' : 'none';
    });
}

function limpiarFiltros() {
    document.getElementById('filtro-estado').value = '';
    document.getElementById('filtro-prioridad').value = '';
    
    const cards = document.querySelectorAll('.proyecto-card');
    cards.forEach(card => {
        card.style.display = 'block';
    });
}

// Función para editar proyecto
function editarProyecto(proyectoId) {
    // Redirigir a la página de edición del proyecto
    window.location.href = `/fabricasoft/aprendiz/proyecto/${proyectoId}/editar`;
}
</script>

<style>
.line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.line-clamp-3 {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.btn-filtro.active {
    background-color: #2563eb;
    color: white;
}

/* Responsive adjustments */
@media (max-width: 640px) {
    .container {
        padding-left: 1rem;
        padding-right: 1rem;
    }
    
    .proyecto-card {
        margin-bottom: 1rem;
    }
}

@media (max-width: 768px) {
    .grid {
        gap: 1rem;
    }
}

/* Fix for statistics cards */
.statistics-card {
    min-height: 120px;
}

.statistics-card .flex {
    align-items: center;
}

.statistics-card .rounded-full {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 48px;
    height: 48px;
}

.statistics-card .text-lg {
    font-size: 1.125rem;
    line-height: 1.75rem;
}

.statistics-card .text-xl {
    font-size: 1.25rem;
    line-height: 1.75rem;
}

/* Ensure proper text wrapping */
.statistics-card .flex-1 {
    min-width: 0;
}

.statistics-card p {
    word-wrap: break-word;
    overflow-wrap: break-word;
}
</style>
@endsection 