@extends('fabricasoft::layouts.masteraprendiz')

@section('content')
<div class="container mx-auto px-4 py-6">
    <!-- Header del Proyecto -->
    <div class="mb-8">
        <div class="flex justify-between items-start">
            <div>
                <div class="flex items-center mb-2">
                    <a href="{{ route('fabricasoft.aprendiz.proyectos') }}" class="text-blue-600 hover:text-blue-800 mr-3">
                        <i class="fas fa-arrow-left"></i>
                    </a>
                    <h1 class="text-3xl font-bold text-gray-800">{{ $proyecto->project_name }}</h1>
                </div>
                <p class="text-gray-600">{{ $proyecto->applicant_name }} - {{ $proyecto->company_name }}</p>
            </div>
            <div class="flex space-x-3">
                <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium {{ $proyecto->estado_clase_css }}">
                    {{ $proyecto->estado_legible }}
                </span>
            </div>
        </div>
    </div>

    <!-- Información del Solicitante -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-6 flex items-center">
            <i class="fas fa-user text-blue-500 mr-3"></i>
            Información del Solicitante
        </h3>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Información Personal -->
            <div class="space-y-4">
                <h4 class="font-medium text-gray-900 mb-3 text-lg border-b pb-2">Datos Personales</h4>
                <div class="space-y-3">
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Nombre:</span>
                        <span class="text-sm font-medium text-gray-900">{{ $proyecto->applicant_name ?? 'N/A' }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Tipo de Documento:</span>
                        <span class="text-sm font-medium text-gray-900">{{ $proyecto->document_type ?? 'N/A' }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Número de Documento:</span>
                        <span class="text-sm font-medium text-gray-900">{{ $proyecto->document_number ?? 'N/A' }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Email:</span>
                        <span class="text-sm font-medium text-gray-900">{{ $proyecto->email ?? 'N/A' }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Teléfono:</span>
                        <span class="text-sm font-medium text-gray-900">{{ $proyecto->phone ?? 'N/A' }}</span>
                    </div>
                </div>
            </div>

            <!-- Información Empresarial -->
            <div class="space-y-4">
                <h4 class="font-medium text-gray-900 mb-3 text-lg border-b pb-2">Datos Empresariales</h4>
                <div class="space-y-3">
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Empresa:</span>
                        <span class="text-sm font-medium text-gray-900">{{ $proyecto->company_name ?? 'N/A' }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Departamento:</span>
                        <span class="text-sm font-medium text-gray-900">{{ $proyecto->department ?? 'N/A' }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Rol/Cargo:</span>
                        <span class="text-sm font-medium text-gray-900">{{ $proyecto->applicant_role ?? 'N/A' }}</span>
                    </div>
                </div>
            </div>

            <!-- Información de Ubicación -->
            <div class="space-y-4">
                <h4 class="font-medium text-gray-900 mb-3 text-lg border-b pb-2">Ubicación</h4>
                <div class="space-y-3">
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">País:</span>
                        <span class="text-sm font-medium text-gray-900">{{ $proyecto->country ?? 'N/A' }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Departamento/Localidad:</span>
                        <span class="text-sm font-medium text-gray-900">{{ $proyecto->department_location ?? 'N/A' }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Municipio:</span>
                        <span class="text-sm font-medium text-gray-900">{{ $proyecto->municipality ?? 'N/A' }}</span>
                    </div>
                </div>
            </div>

            <!-- Información del Proyecto -->
            <div class="space-y-4">
                <h4 class="font-medium text-gray-900 mb-3 text-lg border-b pb-2">Información del Proyecto</h4>
                <div class="space-y-3">
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Nombre del Proyecto:</span>
                        <span class="text-sm font-medium text-gray-900">{{ $proyecto->project_name ?? 'N/A' }}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Fecha de Solicitud:</span>
                        <span class="text-sm font-medium text-gray-900">
                            {{ $proyecto->created_at ? \Carbon\Carbon::parse($proyecto->created_at)->format('d/m/Y H:i:s') : 'N/A' }}
                        </span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Estado:</span>
                        <span class="text-sm font-medium text-gray-900">
                            {{ $proyecto->estado_legible }}
                        </span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-sm text-gray-600">Prioridad:</span>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                            @if($proyecto->prioridad == 'alta') bg-red-100 text-red-800
                            @elseif($proyecto->prioridad == 'media') bg-yellow-100 text-yellow-800
                            @else bg-green-100 text-green-800 @endif">
                            {{ ucfirst($proyecto->prioridad ?? 'media') }}
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Respuestas del Formulario -->
        @if($respuestas->count() > 0)
        <div class="mt-8 pt-6 border-t border-gray-200">
            <h4 class="font-medium text-gray-900 mb-4 text-lg flex items-center">
                <i class="fas fa-clipboard-list text-green-500 mr-3"></i>
                Respuestas del Formulario
            </h4>
            <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                <div class="space-y-3">
                    @foreach($respuestas as $respuesta)
                    <div class="flex justify-between items-start border-b border-green-100 pb-2 last:border-b-0">
                        <span class="text-sm font-medium text-gray-700 flex-1">{{ $respuesta->pregunta }}</span>
                        <span class="text-sm text-gray-900 ml-4 text-right">{{ $respuesta->respuesta ?? 'Sin respuesta' }}</span>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
        @endif

        <!-- Comentarios del Aprendiz -->
        @if($proyecto->apprentice_comments)
        <div class="mt-8 pt-6 border-t border-gray-200">
            <h4 class="font-medium text-gray-900 mb-4 text-lg">Comentarios del Aprendiz</h4>
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p class="text-sm text-gray-900">{{ $proyecto->apprentice_comments }}</p>
            </div>
        </div>
        @endif
    </div>
</div>
@endsection 