<div class="bg-white rounded-lg shadow-sm border border-gray-200 p-4 hover:shadow-md transition-shadow" data-requerimiento-id="{{ $requerimiento->id }}">
    <div class="flex justify-between items-start mb-3">
        <h4 class="text-sm font-medium text-gray-900 line-clamp-2">{{ $requerimiento->titulo ?? 'Sin título' }}</h4>
        <div class="flex space-x-1">
            <button onclick="verDetalleRequerimiento({{ $requerimiento->id }})" 
                    class="text-blue-600 hover:text-blue-900 text-xs" title="Ver detalle">
                <i class="fas fa-eye"></i>
            </button>
            <button onclick="editarRequerimiento({{ $requerimiento->id }})" 
                    class="text-green-600 hover:text-green-900 text-xs" title="Editar">
                <i class="fas fa-edit"></i>
            </button>
            <button onclick="eliminarRequerimiento({{ $requerimiento->id }}, '{{ $requerimiento->titulo }}')" 
                    class="text-red-600 hover:text-red-900 text-xs" title="Eliminar">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    </div>
    
    <p class="text-xs text-gray-600 mb-3 line-clamp-3">{{ $requerimiento->descripcion ?? 'Sin descripción' }}</p>
    
    <div class="space-y-2">
        <!-- Proyecto -->
        <div class="flex items-center text-xs text-gray-500">
            <i class="fas fa-project-diagram mr-1"></i>
            <span>{{ $requerimiento->project_name ?? 'N/A' }}</span>
        </div>
        
        <!-- Tipo -->
        <div class="flex items-center">
            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
                @if($requerimiento->tipo == 'funcional') bg-green-100 text-green-800
                @elseif($requerimiento->tipo == 'no_funcional') bg-blue-100 text-blue-800
                @elseif($requerimiento->tipo == 'tecnico') bg-purple-100 text-purple-800
                @else bg-gray-100 text-gray-800 @endif">
                {{ ucfirst(str_replace('_', ' ', $requerimiento->tipo ?? 'N/A')) }}
            </span>
        </div>
        
        <!-- Prioridad -->
        <div class="flex items-center">
            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
                @if($requerimiento->prioridad == 'alta') bg-red-100 text-red-800
                @elseif($requerimiento->prioridad == 'media') bg-yellow-100 text-yellow-800
                @else bg-green-100 text-green-800 @endif">
                <i class="fas fa-flag mr-1"></i>
                {{ ucfirst($requerimiento->prioridad ?? 'media') }}
            </span>
        </div>
        
        <!-- Fecha -->
        <div class="flex items-center text-xs text-gray-500">
            <i class="fas fa-calendar mr-1"></i>
            <span>{{ \Carbon\Carbon::parse($requerimiento->created_at)->format('d/m/Y') }}</span>
        </div>
    </div>
</div>

<style>
.line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.line-clamp-3 {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.truncate {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
</style> 