@extends('fabricasoft::layouts.masteraprendiz')

@section('content')
<div class="container mx-auto px-4 py-6">
    <!-- Header -->
    <div class="mb-8">
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-bold text-gray-800 mb-2">Reportes y Estadísticas</h1>
                <p class="text-gray-600">Analiza tu rendimiento y progreso en los proyectos</p>
            </div>
            <div class="flex space-x-3">
                <button onclick="exportarReporte()" class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                    <i class="fas fa-download mr-2"></i>Exportar
                </button>
                <select id="periodo-filtro" class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="mes">Este Mes</option>
                    <option value="trimestre">Este Trimestre</option>
                    <option value="año">Este Año</option>
                    <option value="personalizado">Personalizado</option>
                </select>
            </div>
        </div>
    </div>

    <!-- Métricas Principales -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                    <i class="fas fa-code text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Proyectos Completados</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $proyectosCompletados ?? 0 }}</p>
                    <p class="text-xs text-green-600">
                        <i class="fas fa-arrow-up mr-1"></i>
                        +{{ $incrementoProyectos ?? 0 }}% vs mes anterior
                    </p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-green-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-green-100 text-green-600">
                    <i class="fas fa-tasks text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Tareas Completadas</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $tareasCompletadas ?? 0 }}</p>
                    <p class="text-xs text-green-600">
                        <i class="fas fa-arrow-up mr-1"></i>
                        +{{ $incrementoTareas ?? 0 }}% vs mes anterior
                    </p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-purple-100 text-purple-600">
                    <i class="fas fa-clock text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Horas Trabajadas</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $horasTrabajadas ?? 0 }}h</p>
                    <p class="text-xs text-blue-600">
                        <i class="fas fa-chart-line mr-1"></i>
                        Promedio: {{ $promedioHoras ?? 0 }}h/día
                    </p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-orange-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-orange-100 text-orange-600">
                    <i class="fas fa-percentage text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Eficiencia</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ $eficiencia ?? 0 }}%</p>
                    <p class="text-xs text-orange-600">
                        <i class="fas fa-target mr-1"></i>
                        Meta: 85%
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Gráficos -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <!-- Gráfico de Progreso de Proyectos -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <i class="fas fa-chart-bar text-blue-500 mr-3"></i>
                Progreso de Proyectos
            </h3>
            <canvas id="proyectosChart" width="400" height="200"></canvas>
        </div>

        <!-- Gráfico de Tareas por Estado -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <i class="fas fa-chart-pie text-green-500 mr-3"></i>
                Distribución de Tareas
            </h3>
            <canvas id="tareasChart" width="400" height="200"></canvas>
        </div>
    </div>

    <!-- Tabla de Rendimiento -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden mb-8">
        <div class="px-6 py-4 border-b border-gray-200">
            <h3 class="text-lg font-semibold text-gray-800 flex items-center">
                <i class="fas fa-table text-purple-500 mr-3"></i>
                Rendimiento por Proyecto
            </h3>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Proyecto
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Progreso
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Tareas Completadas
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Tiempo Estimado
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Tiempo Real
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Eficiencia
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @if(isset($rendimientoProyectos) && count($rendimientoProyectos) > 0)
                        @foreach($rendimientoProyectos as $proyecto)
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 h-10 w-10">
                                        <div class="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                                            <i class="fas fa-project-diagram text-blue-600"></i>
                                        </div>
                                    </div>
                                    <div class="ml-4">
                                        @php
                            $formularioNombre = null;
                            if ($proyecto->formulario_id) {
                                $formulario = \DB::table('formularios')->where('id', $proyecto->formulario_id)->first();
                                $formularioNombre = $formulario ? $formulario->nombre : null;
                            }
                        @endphp
                        <div class="text-sm font-medium text-gray-900">
                            {{ $proyecto->project_name }}
                            @if($formularioNombre)
                                <span class="text-sm text-blue-600">({{ $formularioNombre }})</span>
                            @endif
                        </div>
                                        <div class="text-sm text-gray-500">{{ $proyecto->applicant_name }}</div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="w-16 bg-gray-200 rounded-full h-2 mr-2">
                                        <div class="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                                             style="width: {{ $proyecto->progreso ?? 0 }}%"></div>
                                    </div>
                                    <span class="text-sm text-gray-500">{{ $proyecto->progreso ?? 0 }}%</span>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {{ $proyecto->tareas_completadas ?? 0 }} / {{ $proyecto->total_tareas ?? 0 }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {{ $proyecto->tiempo_estimado ?? 0 }}h
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {{ $proyecto->tiempo_real ?? 0 }}h
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                @php
                                    $eficiencia = $proyecto->tiempo_estimado > 0 ? 
                                        round(($proyecto->tiempo_estimado / $proyecto->tiempo_real) * 100, 1) : 0;
                                    $clase = $eficiencia >= 90 ? 'text-green-600' : ($eficiencia >= 70 ? 'text-yellow-600' : 'text-red-600');
                                @endphp
                                <span class="text-sm font-medium {{ $clase }}">
                                    {{ $eficiencia }}%
                                </span>
                            </td>
                        </tr>
                        @endforeach
                    @else
                        <tr>
                            <td colspan="6" class="px-6 py-12 text-center">
                                <i class="fas fa-chart-line text-gray-400 text-4xl mb-4"></i>
                                <p class="text-gray-500">No hay datos de rendimiento disponibles</p>
                            </td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>

    <!-- Actividad Reciente -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <!-- Actividad de Tareas -->
        <div class="bg-white rounded-lg shadow-md">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800 flex items-center">
                    <i class="fas fa-history text-blue-500 mr-3"></i>
                    Actividad Reciente
                </h3>
            </div>
            <div class="p-6">
                <div class="space-y-4">
                    @if(isset($actividadReciente) && count($actividadReciente) > 0)
                        @foreach($actividadReciente as $actividad)
                        <div class="flex items-start space-x-3">
                            <div class="flex-shrink-0">
                                <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                                    <i class="fas fa-{{ $actividad->icono ?? 'circle' }} text-blue-600 text-sm"></i>
                                </div>
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="text-sm text-gray-900">{{ $actividad->descripcion }}</p>
                                <p class="text-xs text-gray-500">{{ \Carbon\Carbon::parse($actividad->created_at)->diffForHumans() }}</p>
                            </div>
                        </div>
                        @endforeach
                    @else
                        <div class="text-center py-8">
                            <i class="fas fa-history text-gray-400 text-4xl mb-4"></i>
                            <p class="text-gray-500">No hay actividad reciente</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Logros y Metas -->
        <div class="bg-white rounded-lg shadow-md">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800 flex items-center">
                    <i class="fas fa-trophy text-yellow-500 mr-3"></i>
                    Logros y Metas
                </h3>
            </div>
            <div class="p-6">
                <div class="space-y-4">
                    @if(isset($logros) && count($logros) > 0)
                        @foreach($logros as $logro)
                        <div class="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                            <div class="flex-shrink-0">
                                <i class="fas fa-{{ $logro->completado ? 'check-circle' : 'circle' }} text-{{ $logro->completado ? 'green' : 'gray' }}-500"></i>
                            </div>
                            <div class="flex-1">
                                <p class="text-sm font-medium text-gray-900">{{ $logro->titulo }}</p>
                                <p class="text-xs text-gray-500">{{ $logro->descripcion }}</p>
                            </div>
                            @if($logro->progreso)
                                <div class="text-xs text-gray-500">{{ $logro->progreso }}%</div>
                            @endif
                        </div>
                        @endforeach
                    @else
                        <div class="text-center py-8">
                            <i class="fas fa-trophy text-gray-400 text-4xl mb-4"></i>
                            <p class="text-gray-500">No hay logros disponibles</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts para gráficos -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Gráfico de Progreso de Proyectos
const proyectosCtx = document.getElementById('proyectosChart').getContext('2d');
const proyectosChart = new Chart(proyectosCtx, {
    type: 'bar',
    data: {
        labels: {!! json_encode($proyectosLabels ?? []) !!},
        datasets: [{
            label: 'Progreso (%)',
            data: {!! json_encode($proyectosData ?? []) !!},
            backgroundColor: 'rgba(59, 130, 246, 0.8)',
            borderColor: 'rgba(59, 130, 246, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true,
                max: 100
            }
        },
        plugins: {
            legend: {
                display: false
            }
        }
    }
});

// Gráfico de Distribución de Tareas
const tareasCtx = document.getElementById('tareasChart').getContext('2d');
const tareasChart = new Chart(tareasCtx, {
    type: 'doughnut',
    data: {
        labels: ['Pendientes', 'En Progreso', 'En Revisión', 'Completadas', 'Canceladas'],
        datasets: [{
            data: {!! json_encode($tareasDistribucion ?? [0, 0, 0, 0, 0]) !!},
            backgroundColor: [
                'rgba(245, 158, 11, 0.8)',
                'rgba(59, 130, 246, 0.8)',
                'rgba(147, 51, 234, 0.8)',
                'rgba(34, 197, 94, 0.8)',
                'rgba(239, 68, 68, 0.8)'
            ],
            borderColor: [
                'rgba(245, 158, 11, 1)',
                'rgba(59, 130, 246, 1)',
                'rgba(147, 51, 234, 1)',
                'rgba(34, 197, 94, 1)',
                'rgba(239, 68, 68, 1)'
            ],
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});

// Función para exportar reporte
function exportarReporte() {
    const periodo = document.getElementById('periodo-filtro').value;
    
    // Crear un enlace temporal para descargar
    const link = document.createElement('a');
    link.href = `/fabricasoft/desarrollador/reportes/exportar?periodo=${periodo}`;
    link.download = `reporte-desarrollador-${periodo}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Actualizar gráficos cuando cambie el período
document.getElementById('periodo-filtro').addEventListener('change', function() {
    const periodo = this.value;
    
    // Aquí se haría una llamada AJAX para obtener nuevos datos
    fetch(`/fabricasoft/desarrollador/reportes/datos?periodo=${periodo}`)
        .then(response => response.json())
        .then(data => {
            // Actualizar datos de los gráficos
            proyectosChart.data.datasets[0].data = data.proyectos;
            proyectosChart.update();
            
            tareasChart.data.datasets[0].data = data.tareas;
            tareasChart.update();
        })
        .catch(error => {
            console.error('Error al cargar datos:', error);
        });
});
</script>

<style>
/* Estilos adicionales para los gráficos */
canvas {
    max-height: 300px;
}
</style>
@endsection 