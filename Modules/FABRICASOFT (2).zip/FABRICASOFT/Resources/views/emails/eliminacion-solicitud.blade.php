<body style="font-family: Arial, sans-serif; background: #f8fafc; color: #222;">
    <div style="max-width: 600px; margin: 0 auto; background: #fff; border-radius: 12px; box-shadow: 0 2px 8px #0001; padding: 32px;">
        <h2 style="color: #e53e3e;">Notificación de Eliminación de Solicitud</h2>
        <p>Hola <strong>{{ $solicitud->applicant_name }}</strong>,</p>
        <p>Lamentamos informarte que tu solicitud con el proyecto <strong>"{{ $solicitud->project_name }}"</strong> fue <span style="color: #e53e3e; font-weight: bold;">rechazada</span> y ha sido eliminada automáticamente del sistema tras 24 horas.</p>
        <p>Si tienes dudas o deseas volver a enviar una solicitud, puedes hacerlo desde la plataforma o contactarnos para más información.</p>
        <hr style="margin: 24px 0;">
        <p><strong>Detalles de la solicitud eliminada:</strong></p>
        <ul>
            <li><strong>Proyecto:</strong> {{ $solicitud->project_name }}</li>
            <li><strong>Empresa:</strong> {{ $solicitud->company_name }}</li>
            <li><strong>Fecha de creación:</strong> {{ $solicitud->created_at }}</li>
            <li><strong>Estado:</strong> Rechazada</li>
        </ul>
        <p style="margin-top: 32px;">Gracias por tu interés en nuestros servicios.<br>Equipo FABRICASOFT</p>
        <p style="font-size: 12px; color: #888; margin-top: 24px;">Este es un mensaje automático, por favor no responder a este correo.</p>
    </div>
</body> 