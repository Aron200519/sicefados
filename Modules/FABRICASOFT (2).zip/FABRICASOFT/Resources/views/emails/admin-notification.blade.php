<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Nueva solicitud de pre-registro</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background-color: #2ECC71;
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 5px 5px 0 0;
        }
        .content {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 0 0 5px 5px;
        }
        .info-section {
            background-color: white;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            border-left: 4px solid #2ECC71;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #2ECC71;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 15px;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            color: #666;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Nueva Solicitud de Pre-registro</h1>
        <p>FABRICASOFT - Sistema de Gestión</p>
    </div>
    
    <div class="content">
        <p>Se ha recibido una nueva solicitud de pre-registro que requiere su revisión.</p>
        
        <div class="info-section">
            <h3>Información del Solicitante:</h3>
            <p><strong>Nombre:</strong> {{ $preregistration->full_name }}</p>
            <p><strong>Empresa:</strong> {{ $preregistration->company_name }}</p>
            <p><strong>Email:</strong> {{ $preregistration->email }}</p>
            <p><strong>Teléfono:</strong> {{ $preregistration->phone }}</p>
            <p><strong>Cargo:</strong> {{ $preregistration->position }}</p>
            <p><strong>Departamento:</strong> {{ $preregistration->department }}</p>
            <p><strong>País:</strong> {{ $preregistration->country }}</p>
            <p><strong>Departamento:</strong> {{ $preregistration->state }}</p>
            <p><strong>Municipio:</strong> {{ $preregistration->municipality }}</p>
        </div>
        
        <div class="info-section">
            <h3>Descripción del Proyecto:</h3>
            <p>{{ $preregistration->project_description }}</p>
        </div>
        
        <p>Para revisar y gestionar esta solicitud, acceda al panel de administración:</p>
        
        <a href="{{ route('fabricasoft.admin.preregistration.index') }}" class="btn">
            Ver Solicitudes de Pre-registro
        </a>
        
        <div class="footer">
            <p>Este es un mensaje automático del sistema FABRICASOFT.</p>
            <p>Fecha: {{ $preregistration->created_at->format('d/m/Y H:i:s') }}</p>
        </div>
    </div>
</body>
</html> 