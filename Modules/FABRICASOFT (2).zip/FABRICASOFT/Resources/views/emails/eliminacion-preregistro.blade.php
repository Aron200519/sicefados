<body style="font-family: Arial, sans-serif; background: #f8fafc; color: #222;">
    <div style="max-width: 600px; margin: 0 auto; background: #fff; border-radius: 12px; box-shadow: 0 2px 8px #0001; padding: 32px;">
        <h2 style="color: #e53e3e;">Notificación de Eliminación de Pre-registro</h2>
        <p>Hola <strong>{{ $preregistro->full_name }}</strong>,</p>
        <p>Lamentamos informarte que tu pre-registro fue <span style="color: #e53e3e; font-weight: bold;">rechazado</span> y ha sido eliminado automáticamente del sistema tras 24 horas.</p>
        <p>Si tienes dudas o deseas volver a enviar un pre-registro, puedes hacerlo desde la plataforma o contactarnos para más información.</p>
        <hr style="margin: 24px 0;">
        <p><strong>Detalles del pre-registro eliminado:</strong></p>
        <ul>
            <li><strong>Nombre:</strong> {{ $preregistro->full_name }}</li>
            <li><strong>Empresa:</strong> {{ $preregistro->company_name }}</li>
            <li><strong>Email:</strong> {{ $preregistro->email }}</li>
            <li><strong>Fecha de creación:</strong> {{ $preregistro->created_at }}</li>
            <li><strong>Estado:</strong> Rechazado</li>
        </ul>
        <p style="margin-top: 32px;">Gracias por tu interés en nuestros servicios.<br>Equipo FABRICASOFT</p>
        <p style="font-size: 12px; color: #888; margin-top: 24px;">Este es un mensaje automático, por favor no responder a este correo.</p>
    </div>
</body> 