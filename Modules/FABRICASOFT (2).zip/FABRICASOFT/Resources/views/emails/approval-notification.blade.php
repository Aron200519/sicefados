<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Solicitud Aprobada - FABRICASOFT</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background-color: #27AE60;
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 5px 5px 0 0;
        }
        .content {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 0 0 5px 5px;
        }
        .success-section {
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
        }
        .info-section {
            background-color: white;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            border-left: 4px solid #27AE60;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #27AE60;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 15px;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            color: #666;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>¡Solicitud Aprobada!</h1>
        <p>FABRICASOFT - Sistema de Gestión</p>
    </div>
    
    <div class="content">
        <div class="success-section">
            <h3>🎉 ¡Felicitaciones!</h3>
            <p>Su solicitud de pre-registro ha sido <strong>APROBADA</strong> por nuestro equipo administrativo.</p>
        </div>
        
        <div class="info-section">
            <h3>Información de su Solicitud:</h3>
            <p><strong>Nombre:</strong> {{ $preregistration->full_name }}</p>
            <p><strong>Empresa:</strong> {{ $preregistration->company_name }}</p>
            <p><strong>Email:</strong> {{ $preregistration->email }}</p>
            <p><strong>Cargo:</strong> {{ $preregistration->position }}</p>
            <p><strong>Departamento:</strong> {{ $preregistration->department }}</p>
        </div>
        
        <div class="info-section">
            <h3>Próximos Pasos:</h3>
            <ol>
                <li>Nuestro equipo se pondrá en contacto con usted en las próximas 24-48 horas.</li>
                <li>Se le proporcionará acceso al dashboard de cliente.</li>
                <li>Recibirá capacitación sobre el uso del sistema.</li>
                <li>Podrá comenzar a gestionar sus proyectos.</li>
            </ol>
        </div>
        
        <p>Si tiene alguna pregunta, no dude en contactarnos:</p>
        <ul>
            <li><strong>Email:</strong> soporte@fabricasoft.com</li>
            <li><strong>Teléfono:</strong> +57 XXX XXX XXXX</li>
        </ul>
        
        <a href="{{ route('fabricasoft.admin.welcome') }}" class="btn">
            Acceder a FABRICASOFT
        </a>
        
        <div class="footer">
            <p>Este es un mensaje automático del sistema FABRICASOFT.</p>
            <p>Fecha de aprobación: {{ $preregistration->approved_at->format('d/m/Y H:i:s') }}</p>
        </div>
    </div>
</body>
</html> 