<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Solicitud Rechazada - FABRICASOFT</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background-color: #E74C3C;
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 5px 5px 0 0;
        }
        .content {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 0 0 5px 5px;
        }
        .rejection-section {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
        }
        .info-section {
            background-color: white;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            border-left: 4px solid #E74C3C;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #E74C3C;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 15px;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            color: #666;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Solicitud Rechazada</h1>
        <p>FABRICASOFT - Sistema de Gestión</p>
    </div>
    
    <div class="content">
        <div class="rejection-section">
            <h3>📋 Información Importante</h3>
            <p>Su solicitud de pre-registro ha sido <strong>RECHAZADA</strong> por nuestro equipo administrativo.</p>
        </div>
        
        <div class="info-section">
            <h3>Información de su Solicitud:</h3>
            <p><strong>Nombre:</strong> {{ $preregistration->full_name }}</p>
            <p><strong>Empresa:</strong> {{ $preregistration->company_name }}</p>
            <p><strong>Email:</strong> {{ $preregistration->email }}</p>
            <p><strong>Cargo:</strong> {{ $preregistration->position }}</p>
            <p><strong>Departamento:</strong> {{ $preregistration->department }}</p>
        </div>
        
        @if($preregistration->admin_notes)
        <div class="info-section">
            <h3>Comentarios del Administrador:</h3>
            <p>{{ $preregistration->admin_notes }}</p>
        </div>
        @endif
        
        <div class="info-section">
            <h3>Opciones Disponibles:</h3>
            <ul>
                <li>Puede enviar una nueva solicitud con información actualizada.</li>
                <li>Contactar directamente con nuestro equipo para aclarar dudas.</li>
                <li>Solicitar una reunión para discutir los requisitos específicos.</li>
            </ul>
        </div>
        
        <p>Si tiene alguna pregunta o desea más información, no dude en contactarnos:</p>
        <ul>
            <li><strong>Email:</strong> soporte@fabricasoft.com</li>
            <li><strong>Teléfono:</strong> +57 XXX XXX XXXX</li>
        </ul>
        
        <a href="{{ route('fabricasoft.admin.welcome') }}" class="btn">
            Enviar Nueva Solicitud
        </a>
        
        <div class="footer">
            <p>Este es un mensaje automático del sistema FABRICASOFT.</p>
            <p>Fecha de rechazo: {{ $preregistration->rejected_at->format('d/m/Y H:i:s') }}</p>
        </div>
    </div>
</body>
</html> 