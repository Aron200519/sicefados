@extends('fabricasoft::layouts.master')
@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-home"></i>
                        Bienvenido a FABRICASOFT
                    </h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="info-box">
                                <span class="info-box-icon bg-info">
                                    <i class="fas fa-users"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Usuarios Registrados</span>
                                    <span class="info-box-number">{{ \App\Models\User::count() }}</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-box">
                                <span class="info-box-icon bg-success">
                                    <i class="fas fa-project-diagram"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Proyectos Activos</span>
                                    <span class="info-box-number">{{ \DB::table('new_request')->where('status', 'aprobada')->count() }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="alert alert-info">
                                <h5><i class="fas fa-info-circle"></i> Información del Sistema</h5>
                                <p>FABRICASOFT es el sistema de gestión de proyectos y desarrollo de software del CEFA.</p>
                                <p>Para acceder a las funcionalidades específicas, por favor inicia sesión con tu cuenta.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>@endsection
