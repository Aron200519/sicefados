@extends('fabricasoft::layouts.masterdesarrolladores')
@section('content')

<!-- Filtros de equipos -->
<div class="mb-6">
    <div class="bg-white rounded-lg shadow border p-4">
        <h3 class="text-lg font-medium text-gray-900 mb-4">Filtros de Equipos</h3>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <!-- Filtro por Líder -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Líder del Equipo</label>
                <select id="filtro-lider" class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" onchange="aplicarFiltros()">
                    <option value="">Todos los líderes</option>
                    @foreach($desarrolladores as $dev)
                        <option value="{{ $dev->id }}">{{ $dev->nickname }}</option>
                    @endforeach
                </select>
            </div>
            
            <!-- Filtro por Proyecto -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Proyecto</label>
                <select id="filtro-proyecto" class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" onchange="aplicarFiltros()">
                    <option value="">Todos los proyectos</option>
                    @foreach($proyectosAprobados as $proyecto)
                        <option value="{{ $proyecto->id }}">{{ $proyecto->project_name }}</option>
                    @endforeach
                </select>
            </div>
            
            <!-- Filtro por Rol -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Rol en Equipo</label>
                <select id="filtro-rol" class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" onchange="aplicarFiltros()">
                    <option value="">Todos los roles</option>
                    <option value="lider">Líder</option>
                    <option value="desarrollador">Desarrollador</option>
                    <option value="disenador">Diseñador</option>
                    <option value="tester">Tester</option>
                    <option value="analista">Analista</option>
                </select>
            </div>
            
            <!-- Filtro por Estado -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Estado del Proyecto</label>
                <select id="filtro-estado" class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" onchange="aplicarFiltros()">
                    <option value="">Todos los estados</option>
                    <option value="pendiente">Pendiente</option>
                    <option value="en_desarrollo">En Desarrollo</option>
                    <option value="revision">En Revisión</option>
                    <option value="testing">Testing</option>
                    <option value="completado">Completado</option>
                </select>
            </div>
        </div>
        
        <!-- Botones de acción -->
        <div class="flex justify-between items-center mt-4">
            <div class="flex space-x-2">
                <button onclick="limpiarFiltros()" class="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors">
                    <i class="fas fa-eraser mr-2"></i>
                    Limpiar Filtros
                </button>
                <button onclick="exportarEquipos()" class="inline-flex items-center px-3 py-2 border border-green-300 rounded-md text-sm font-medium text-green-700 bg-green-50 hover:bg-green-100 transition-colors">
                    <i class="fas fa-download mr-2"></i>
                    Exportar
                </button>
            </div>
            
            <div class="text-sm text-gray-600">
                <span id="contador-equipos">{{ $grupos->count() }}</span> equipos encontrados
            </div>
        </div>
    </div>
</div>

<!-- Sección de grupos y creación -->
<div class="mb-8">
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
        <!-- Card para crear grupo -->
        <div class="flex justify-center items-center">
            <div class="w-full h-48 sm:h-56 md:h-64 flex items-center justify-center bg-white rounded-xl shadow-lg border-2 border-dashed border-green-400 cursor-pointer hover:shadow-2xl transition" onclick="abrirModalCrearGrupo()">
                <span class="text-4xl sm:text-5xl md:text-7xl text-green-500 font-bold">+</span>
            </div>
        </div>
        
        <!-- Grupos creados -->
        @foreach($grupos as $grupo)
            <div class="grupo-card bg-white rounded-xl shadow-lg border border-gray-200 p-4 md:p-6" 
                 data-lider="{{ $grupo->lider_id }}"
                 data-proyecto="{{ $grupo->proyecto_id }}"
                 data-estado="{{ $grupo->status ?? 'pendiente' }}"
                 data-roles="{{ json_encode($grupo->roles ?? []) }}">
                <div class="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-3 mb-4">
                    <h3 class="text-base md:text-lg font-semibold text-green-700 break-words">{{ $grupo->nombre }}</h3>
                    <div class="flex items-center gap-2 flex-wrap">
                        <span class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">Grupo</span>

                        <button onclick="openEditModal({{ $grupo->id }}, '{{ $grupo->nombre }}', {{ $grupo->proyecto_id }}, {{ $grupo->lider_id }})" class="text-blue-500 hover:text-blue-700 p-1">
                            <i class="fas fa-edit"></i>
                        </button>
                        <form action="{{ route('fabricasoft.grupos.destroy', $grupo->id) }}" method="POST" class="inline" onsubmit="return confirm('¿Estás seguro de eliminar este grupo?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-red-500 hover:text-red-700 p-1">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>
                <div class="space-y-3">
                    <!-- Líder del Grupo -->
                    <div class="flex items-start">
                        <i class="fas fa-user-tie text-green-500 mr-2 mt-0.5 flex-shrink-0"></i>
                        <div class="min-w-0 flex-1">
                            <div class="flex items-center">
                                <p class="text-sm font-medium text-gray-800 break-words">{{ $grupo->lider_nombre }}</p>
                                <span class="inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 ml-1">
                                    <i class="fas fa-star text-yellow-500 mr-1"></i>Líder
                                </span>
                            </div>
                            <p class="text-xs text-gray-500 break-all">{{ $grupo->lider_email }}</p>
                        </div>
                    </div>
                    
                    <!-- Equipo Adicional -->
                    @php
                        $miembros = DB::table('grupo_miembros')
                            ->join('users', 'grupo_miembros.user_id', '=', 'users.id')
                            ->where('grupo_miembros.grupo_id', $grupo->id)
                            ->select('users.nickname', 'users.email', 'grupo_miembros.rol')
                            ->get();

                    @endphp
                    @if($miembros->count() > 0)
                        <div class="ml-6 space-y-1">
                            @foreach($miembros as $miembro)
                                @php
                                    $rolColors = [
                                        'desarrollador' => 'bg-blue-100 text-blue-800',
                                        'disenador' => 'bg-green-100 text-green-800',
                                        'tester' => 'bg-red-100 text-red-800',
                                        'analista' => 'bg-purple-100 text-purple-800'
                                    ];
                                    $rolIcons = [
                                        'desarrollador' => 'fas fa-code',
                                        'disenador' => 'fas fa-palette',
                                        'tester' => 'fas fa-bug',
                                        'analista' => 'fas fa-chart-line'
                                    ];
                                @endphp
                                <div class="flex items-center text-xs">
                                    <i class="fas fa-user text-blue-500 mr-2"></i>
                                    <span class="text-gray-700">{{ $miembro->nickname }}</span>
                                    <span class="inline-flex items-center px-1 py-0.5 rounded-full text-xs font-medium {{ $rolColors[$miembro->rol] ?? 'bg-gray-100 text-gray-800' }} ml-1">
                                        <i class="{{ $rolIcons[$miembro->rol] ?? 'fas fa-user' }} mr-1"></i>{{ ucfirst($miembro->rol) }}
                                    </span>
                                </div>
                            @endforeach
                        </div>
                    @endif
                    
                    <!-- Proyecto -->
                    <div class="flex items-start">
                        <i class="fas fa-project-diagram text-blue-500 mr-2 mt-0.5 flex-shrink-0"></i>
                        <div class="min-w-0 flex-1">
                            <p class="text-sm font-medium text-gray-800 break-words">{{ $grupo->project_name }}</p>
                            <p class="text-xs text-gray-500 break-words">Cliente: {{ $grupo->applicant_name }}</p>
                            <p class="text-xs text-gray-500 break-words">Tipo de Documento: {{ $grupo->document_type ?? 'No especificado' }}</p>
                            <p class="text-xs text-gray-500 break-words">Número de Documento: {{ $grupo->document_number ?? 'No especificado' }}</p>
                        </div>
                    </div>
                    <div class="flex items-center">
                        <i class="fas fa-calendar-alt text-white mr-2 flex-shrink-0"></i>
                        <p class="text-xs text-gray-500">Creado: {{ \Carbon\Carbon::parse($grupo->created_at)->format('d/m/Y H:i') }}</p>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>

<!-- Sección de proyectos aprobados -->
<div class="mb-8">
    <div class="card bg-white">
        <div class="p-4 flex justify-between items-center border-b">
            <h3 class="text-xl font-semibold text-gray-800">Proyectos Aprobados</h3>
        </div>
        <div class="p-4">
            @php
                // Mostrar solo proyectos aprobados y en desarrollo
                $proyectosFiltrados = $proyectosAprobados->filter(function($proyecto) {
                    return in_array($proyecto->status, ['aprobada', 'en_desarrollo']);
                });
                $proyectosAsignados = DB::table('grupos')->pluck('proyecto_id')->toArray();
            @endphp
            
            @if($proyectosFiltrados->count() > 0)
                <!-- Información general -->
                <div class="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <div class="flex items-center justify-between">
                        <div>
                            <h4 class="text-lg font-semibold text-blue-800">📊 Resumen de Proyectos</h4>
                            <p class="text-sm text-blue-600">Proyectos aprobados y en desarrollo: <strong>{{ $proyectosFiltrados->count() }}</strong></p>
                        </div>
                        <div class="text-right">
                            <p class="text-xs text-blue-500">Desplázate hacia abajo para ver todos los proyectos</p>
                        </div>
                    </div>
                </div>
                
                <!-- Contadores de estados -->
                <div class="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                    @php
                        $contadores = [
                            'aprobada' => $proyectosFiltrados->where('status', 'aprobada')->count(),
                            'en_desarrollo' => $proyectosFiltrados->where('status', 'en_desarrollo')->count()
                        ];
                    @endphp
                    
                    <div class="bg-green-50 border border-green-200 rounded-lg p-3 text-center">
                        <div class="text-2xl font-bold text-green-600">{{ $contadores['aprobada'] }}</div>
                        <div class="text-sm text-green-700">✅ Aprobadas</div>
                    </div>
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-3 text-center">
                        <div class="text-2xl font-bold text-blue-600">{{ $contadores['en_desarrollo'] }}</div>
                        <div class="text-sm text-blue-700">🔄 En Desarrollo</div>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 md:gap-4 max-h-96 overflow-y-auto">
                    @foreach($proyectosFiltrados as $proyecto)
                        @php
                            $yaAsignado = in_array($proyecto->id, $proyectosAsignados);
                            $borderClass = $yaAsignado ? 'border-orange-300 bg-orange-50' : 'border-gray-200 bg-gray-50';
                            $asignadoBadge = $yaAsignado ? '<span class="inline-block bg-orange-100 text-orange-800 text-xs px-2 py-1 rounded-full mb-2">👥 Asignado a grupo</span>' : '';
                        @endphp
                        <div class="p-3 md:p-4 rounded-lg border {{ $borderClass }} relative proyecto-card">
                            {!! $asignadoBadge !!}
                            <h4 class="font-semibold text-green-700 mb-2 text-sm md:text-base break-words">{{ $proyecto->project_name }}</h4>
                            <p class="text-xs md:text-sm text-gray-600 mb-1 break-words"><strong>Cliente:</strong> {{ $proyecto->applicant_name }}</p>
                            <p class="text-xs md:text-sm text-gray-600 mb-1 break-words"><strong>Tipo de Documento:</strong> {{ $proyecto->document_type ?? 'No especificado' }}</p>
                            <p class="text-xs md:text-sm text-gray-600 mb-1 break-words"><strong>Número de Documento:</strong> {{ $proyecto->document_number ?? 'No especificado' }}</p>
                            <p class="text-xs md:text-sm text-gray-600 mb-1 break-words"><strong>Empresa:</strong> {{ $proyecto->company_name }}</p>
                            <p class="text-xs font-semibold 
                                @if($proyecto->status == 'pendiente') text-yellow-600
                                @elseif($proyecto->status == 'aprobada') text-green-600
                                @elseif($proyecto->status == 'rechazado') text-red-600
                                @elseif($proyecto->status == 'en_desarrollo') text-blue-600
                                @elseif($proyecto->status == 'testing') text-orange-600
                                @elseif($proyecto->status == 'completado') text-purple-600
                                @else text-gray-600
                                @endif">
                                @if($proyecto->status == 'pendiente')
                                    ⏳ Pendiente
                                @elseif($proyecto->status == 'aprobada')
                                    ✅ Aprobada
                                @elseif($proyecto->status == 'rechazado')
                                    ❌ Rechazada
                                @elseif($proyecto->status == 'en_desarrollo')
                                    🔄 En Desarrollo
                                @elseif($proyecto->status == 'testing')
                                    🧪 Testing
                                @elseif($proyecto->status == 'completado')
                                    ✅ Completado
                                @else
                                    {{ ucfirst($proyecto->status ?? 'Pendiente') }}
                                @endif
                            </p>
                        </div>
                    @endforeach
                </div>
            @else
                <div class="text-center py-8 text-gray-500">
                    <i class="fas fa-folder-open text-4xl mb-4"></i>
                    <p>No hay proyectos aprobados o en desarrollo disponibles</p>
                </div>
            @endif
        </div>
    </div>
</div>

<!-- Modal para crear grupo -->
<div id="modalGrupo" class="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50 hidden p-4">
    <div class="bg-white rounded-lg shadow-lg w-full max-w-lg p-4 md:p-8 relative max-h-[90vh] overflow-y-auto custom-scrollbar">
        <button class="absolute top-2 right-2 text-gray-500 text-2xl" onclick="document.getElementById('modalGrupo').classList.add('hidden')">&times;</button>
        <h2 class="text-2xl font-bold mb-6 text-green-700">Crear Grupo</h2>
        <form action="{{ route('fabricasoft.grupos.store') }}" method="POST" onsubmit="debugForm(this); return false;">
            @csrf
            <div class="mb-4">
                <label for="nombre_grupo" class="block font-semibold mb-1">Nombre del Grupo</label>
                <input type="text" name="nombre_grupo" id="nombre_grupo" class="form-input w-full border border-green-300 rounded px-3 py-2" required>
            </div>
            <div class="mb-4">
                <label for="proyecto_id" class="block font-semibold mb-1">Proyecto Asignado</label>
                <select name="proyecto_id" id="proyecto_id" class="form-select w-full border border-green-300 rounded px-3 py-2" required>
                    <option value="">Seleccione un proyecto</option>
                    @foreach($proyectosAprobados as $proyecto)
                        @php
                            $yaAsignado = DB::table('grupos')->where('proyecto_id', $proyecto->id)->exists();
                            $estado = $yaAsignado ? ' (Ya asignado a otro grupo)' : '';
                        @endphp
                        <option value="{{ $proyecto->id }}">
                            {{ $proyecto->project_name }} - {{ $proyecto->applicant_name }} [
                            @if($proyecto->status == 'pendiente')
                                ⏳ Pendiente
                            @elseif($proyecto->status == 'aprobada')
                                ✅ Aprobada
                            @elseif($proyecto->status == 'rechazado')
                                ❌ Rechazada
                            @elseif($proyecto->status == 'en_desarrollo')
                                🔄 En Desarrollo
                            @elseif($proyecto->status == 'testing')
                                🧪 Testing
                            @elseif($proyecto->status == 'completado')
                                ✅ Completado
                            @else
                                {{ ucfirst($proyecto->status ?? 'Pendiente') }}
                            @endif
                            ]{{ $estado }}
                        </option>
                    @endforeach
                </select>
                <p class="text-xs text-gray-500 mt-1">
                    <i class="fas fa-info-circle mr-1"></i>Todos los proyectos están disponibles para asignación (incluye todos los status)
                </p>
            </div>
            <div class="mb-4">
                <label for="lider_id" class="block font-semibold mb-1">
                    <i class="fas fa-star text-yellow-500 mr-1"></i>Líder del Grupo
                </label>
                <select name="lider_id" id="lider_id" class="form-select w-full border border-green-300 rounded px-3 py-2" required>
                    <option value="">Seleccione un desarrollador</option>
                    @foreach($desarrolladores as $dev)
                        @php
                            $esLider = DB::table('grupos')->where('lider_id', $dev->id)->exists();
                            $esMiembro = DB::table('grupo_miembros')->where('user_id', $dev->id)->exists();
                            $estado = '';
                            if ($esLider) {
                                $estado = ' (Ya es líder de otro grupo)';
                            } elseif ($esMiembro) {
                                $estado = ' (Ya es miembro de otro grupo)';
                            }
                        @endphp
                        <option value="{{ $dev->id }}" {{ $esLider ? 'disabled' : '' }}>
                            {{ $dev->nickname }} ({{ $dev->email }}){{ $estado }}
                        </option>
                    @endforeach
                </select>
                <p class="text-xs text-gray-500 mt-1">
                    <i class="fas fa-info-circle mr-1"></i>Los desarrolladores que ya son líderes aparecen deshabilitados
                </p>
            </div>
            
            <!-- Equipo Adicional -->
            <div class="mb-6">
                <div class="flex items-center justify-between mb-3">
                    <label class="block font-semibold mb-1">
                        <i class="fas fa-users text-blue-500 mr-1"></i>Equipo Adicional (Opcional)
                    </label>
                    <button type="button" onclick="agregarMiembroEquipo('crear')" class="text-sm bg-blue-500 text-white px-3 py-1 rounded-md hover:bg-blue-600 transition-colors">
                        + Agregar
                    </button>
                </div>
                
                <div id="equipo-container-crear" class="space-y-3">
                    <!-- Los miembros del equipo se agregarán aquí dinámicamente -->
                </div>
                
                <p class="text-xs text-gray-500 mt-2">
                    <i class="fas fa-info-circle mr-1"></i>Puedes agregar hasta 3 desarrolladores adicionales al equipo
                </p>
            </div>

            <!-- Roles del Equipo -->
            <div class="mb-6">
                <label class="block font-semibold mb-2">
                    <i class="fas fa-tasks text-purple-500 mr-1"></i>Distribución de Roles
                </label>
                <div class="bg-gray-50 p-3 rounded-md text-sm text-gray-600">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                        <div><i class="fas fa-star text-yellow-500 mr-1"></i><strong>Principal:</strong> Líder del proyecto</div>
                        <div><i class="fas fa-code text-blue-500 mr-1"></i><strong>Desarrollador:</strong> Programación</div>
                        <div><i class="fas fa-palette text-green-500 mr-1"></i><strong>Diseñador:</strong> UI/UX</div>
                        <div><i class="fas fa-bug text-red-500 mr-1"></i><strong>Tester:</strong> Pruebas</div>
                    </div>
                </div>
            </div>
            
            <div class="flex justify-end gap-2 mt-6">
                <button type="button" class="px-4 py-2 rounded bg-gray-300 text-gray-700" onclick="document.getElementById('modalGrupo').classList.add('hidden')">Cancelar</button>
                <button type="submit" class="px-4 py-2 rounded bg-green-600 text-white font-semibold hover:bg-green-700">
                    <i class="fas fa-users mr-1"></i>Crear Grupo
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal para editar grupo -->
<div id="modalEditGrupo" class="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50 hidden p-4">
    <div class="bg-white rounded-lg shadow-lg w-full max-w-lg p-4 md:p-8 relative max-h-[90vh] overflow-y-auto custom-scrollbar">
        <button class="absolute top-2 right-2 text-gray-500 text-2xl" onclick="document.getElementById('modalEditGrupo').classList.add('hidden')">&times;</button>
        <h2 class="text-2xl font-bold mb-6 text-blue-700">Editar Grupo</h2>
        <form id="editForm" method="POST">
            @csrf
            @method('PUT')
            <div class="mb-4">
                <label for="edit_nombre_grupo" class="block font-semibold mb-1">Nombre del Grupo</label>
                <input type="text" name="nombre_grupo" id="edit_nombre_grupo" class="form-input w-full border border-blue-300 rounded px-3 py-2" required>
            </div>
            <div class="mb-4">
                <label for="edit_proyecto_id" class="block font-semibold mb-1">Proyecto Asignado</label>
                <select name="proyecto_id" id="edit_proyecto_id" class="form-select w-full border border-blue-300 rounded px-3 py-2" required>
                    <option value="">Seleccione un proyecto</option>
                    @foreach($proyectosAprobados as $proyecto)
                        @php
                            $yaAsignado = DB::table('grupos')->where('proyecto_id', $proyecto->id)->exists();
                            $estado = $yaAsignado ? ' (Ya asignado a otro grupo)' : '';
                        @endphp
                        <option value="{{ $proyecto->id }}">
                            {{ $proyecto->project_name }} - {{ $proyecto->applicant_name }} [
                            @if($proyecto->status == 'pendiente')
                                ⏳ Pendiente
                            @elseif($proyecto->status == 'aprobada')
                                ✅ Aprobada
                            @elseif($proyecto->status == 'rechazado')
                                ❌ Rechazada
                            @elseif($proyecto->status == 'en_desarrollo')
                                🔄 En Desarrollo
                            @elseif($proyecto->status == 'testing')
                                🧪 Testing
                            @elseif($proyecto->status == 'completado')
                                ✅ Completado
                            @else
                                {{ ucfirst($proyecto->status ?? 'Pendiente') }}
                            @endif
                            ]{{ $estado }}
                        </option>
                    @endforeach
                </select>
                <p class="text-xs text-gray-500 mt-1">
                    <i class="fas fa-info-circle mr-1"></i>Todos los proyectos están disponibles para asignación (incluye todos los status)
                </p>
            </div>
            <div class="mb-4">
                <label for="edit_lider_id" class="block font-semibold mb-1">
                    <i class="fas fa-star text-yellow-500 mr-1"></i>Líder del Grupo
                </label>
                <select name="lider_id" id="edit_lider_id" class="form-select w-full border border-blue-300 rounded px-3 py-2" required>
                    <option value="">Seleccione un desarrollador</option>
                    @foreach($desarrolladores as $dev)
                        @php
                            $esLider = DB::table('grupos')->where('lider_id', $dev->id)->exists();
                            $esMiembro = DB::table('grupo_miembros')->where('user_id', $dev->id)->exists();
                            $estado = '';
                            if ($esLider) {
                                $estado = ' (Ya es líder de otro grupo)';
                            } elseif ($esMiembro) {
                                $estado = ' (Ya es miembro de otro grupo)';
                            }
                        @endphp
                        <option value="{{ $dev->id }}" {{ $esLider ? 'disabled' : '' }}>
                            {{ $dev->nickname }} ({{ $dev->email }}){{ $estado }}
                        </option>
                    @endforeach
                </select>
                <p class="text-xs text-gray-500 mt-1">
                    <i class="fas fa-info-circle mr-1"></i>Los desarrolladores que ya son líderes aparecen deshabilitados
                </p>
            </div>
            
            <!-- Equipo Adicional -->
            <div class="mb-6">
                <div class="flex items-center justify-between mb-3">
                    <label class="block font-semibold mb-1">
                        <i class="fas fa-users text-blue-500 mr-1"></i>Equipo Adicional (Opcional)
                    </label>
                    <button type="button" onclick="agregarMiembroEquipo('editar')" class="text-sm bg-blue-500 text-white px-3 py-1 rounded-md hover:bg-blue-600 transition-colors">
                        + Agregar
                    </button>
                </div>
                
                <div id="equipo-container-editar" class="space-y-3">
                    <!-- Los miembros del equipo se agregarán aquí dinámicamente -->
                </div>
                
                <p class="text-xs text-gray-500 mt-2">
                    <i class="fas fa-info-circle mr-1"></i>Puedes agregar hasta 3 desarrolladores adicionales al equipo
                </p>
            </div>

            <!-- Roles del Equipo -->
            <div class="mb-6">
                <label class="block font-semibold mb-2">
                    <i class="fas fa-tasks text-purple-500 mr-1"></i>Distribución de Roles
                </label>
                <div class="bg-gray-50 p-3 rounded-md text-sm text-gray-600">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                        <div><i class="fas fa-star text-yellow-500 mr-1"></i><strong>Principal:</strong> Líder del proyecto</div>
                        <div><i class="fas fa-code text-blue-500 mr-1"></i><strong>Desarrollador:</strong> Programación</div>
                        <div><i class="fas fa-palette text-green-500 mr-1"></i><strong>Diseñador:</strong> UI/UX</div>
                        <div><i class="fas fa-bug text-red-500 mr-1"></i><strong>Tester:</strong> Pruebas</div>
                    </div>
                </div>
            </div>
            
            <div class="flex justify-end gap-2 mt-6">
                <button type="button" class="px-4 py-2 rounded bg-gray-300 text-gray-700" onclick="document.getElementById('modalEditGrupo').classList.add('hidden')">Cancelar</button>
                <button type="button" onclick="guardarGrupo()" class="px-4 py-2 rounded bg-blue-600 text-white font-semibold hover:bg-blue-700">
                    <i class="fas fa-save mr-1"></i>Actualizar Grupo
                </button>
            </div>
        </form>
    </div>
</div>

<style>
/* Barra de desplazamiento personalizada para modales */
.custom-scrollbar::-webkit-scrollbar {
    width: 12px;
}

.custom-scrollbar::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 6px;
    border: 1px solid #e0e0e0;
}

.custom-scrollbar::-webkit-scrollbar-thumb {
    background: linear-gradient(180deg, #9ca3af 0%, #6b7280 100%);
    border-radius: 6px;
    border: 1px solid #4b5563;
    box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);
}

.custom-scrollbar::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(180deg, #6b7280 0%, #4b5563 100%);
    box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.2);
}

.custom-scrollbar::-webkit-scrollbar-thumb:active {
    background: linear-gradient(180deg, #4b5563 0%, #374151 100%);
}

.custom-scrollbar::-webkit-scrollbar-corner {
    background: #f1f1f1;
}

/* Barra de desplazamiento para Firefox */
.custom-scrollbar {
    scrollbar-width: auto;
    scrollbar-color: #6b7280 #f1f1f1;
}

/* Mejorar la visibilidad del scrollbar en el modal */
#modalGrupo .custom-scrollbar::-webkit-scrollbar,
#modalEditGrupo .custom-scrollbar::-webkit-scrollbar {
    width: 14px;
}

#modalGrupo .custom-scrollbar::-webkit-scrollbar-track,
#modalEditGrupo .custom-scrollbar::-webkit-scrollbar-track {
    background: #f8f9fa;
    border-radius: 7px;
    border: 2px solid #e9ecef;
    margin: 2px;
}

#modalGrupo .custom-scrollbar::-webkit-scrollbar-thumb,
#modalEditGrupo .custom-scrollbar::-webkit-scrollbar-thumb {
    background: linear-gradient(180deg, #9ca3af 0%, #6b7280 100%);
    border-radius: 7px;
    border: 2px solid #f8f9fa;
    box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.15);
    min-height: 40px;
}

#modalGrupo .custom-scrollbar::-webkit-scrollbar-thumb:hover,
#modalEditGrupo .custom-scrollbar::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(180deg, #6b7280 0%, #4b5563 100%);
    box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.25);
}

#modalGrupo .custom-scrollbar::-webkit-scrollbar-thumb:active,
#modalEditGrupo .custom-scrollbar::-webkit-scrollbar-thumb:active {
    background: linear-gradient(180deg, #4b5563 0%, #374151 100%);
}

/* Asegurar que el contenido del modal tenga suficiente espacio para scroll */
#modalGrupo .bg-white,
#modalEditGrupo .bg-white {
    max-height: 85vh;
    overflow-y: auto;
    padding-bottom: 2rem;
}

/* Mejorar el espaciado en móviles */
@media (max-width: 640px) {
    #modalGrupo .custom-scrollbar::-webkit-scrollbar,
    #modalEditGrupo .custom-scrollbar::-webkit-scrollbar,
    #modalViewGrupo .custom-scrollbar::-webkit-scrollbar {
        width: 10px;
    }
    
    #modalGrupo .bg-white,
    #modalEditGrupo .bg-white,
    #modalViewGrupo .bg-white {
        max-height: 90vh;
        padding: 1rem;
    }
    
    /* Estilos para estados de proyectos */
    .estado-pendiente {
        color: #d97706;
        font-weight: 600;
    }
    .estado-aprobada {
        color: #059669;
        font-weight: 600;
    }
    .estado-rechazado {
        color: #dc2626;
        font-weight: 600;
    }
    .estado-en-desarrollo {
        color: #2563eb;
        font-weight: 600;
    }
    .estado-testing {
        color: #ea580c;
        font-weight: 600;
    }
    .estado-completado {
        color: #7c3aed;
        font-weight: 600;
    }
    
    /* Estilos para el scroll de proyectos */
    .overflow-y-auto {
        scrollbar-width: thin;
        scrollbar-color: #2ECC71 #f3f4f6;
    }
    
    .overflow-y-auto::-webkit-scrollbar {
        width: 8px;
    }
    
    .overflow-y-auto::-webkit-scrollbar-track {
        background: #f3f4f6;
        border-radius: 4px;
    }
    
    .overflow-y-auto::-webkit-scrollbar-thumb {
        background: #2ECC71;
        border-radius: 4px;
    }
    
    .overflow-y-auto::-webkit-scrollbar-thumb:hover {
        background: #27AE60;
    }
    
    /* Estilos para las tarjetas de proyectos */
    .proyecto-card {
        transition: all 0.3s ease;
    }
    
    .proyecto-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
}
</style>

<script>
function debugForm(form) {
    console.log('=== DEBUG FORM ===');
    console.log('Form data:', new FormData(form));
    
    const formData = new FormData(form);
    for (let [key, value] of formData.entries()) {
        console.log(`${key}: ${value}`);
    }
    
    // Verificar específicamente los campos del equipo
    const equipoIds = form.querySelectorAll('select[name="equipo_ids[]"]');
    const equipoRoles = form.querySelectorAll('select[name="equipo_roles[]"]');
    
    console.log('Equipo IDs encontrados:', equipoIds.length);
    console.log('Equipo Roles encontrados:', equipoRoles.length);
    
    const equipoIdsArray = [];
    const equipoRolesArray = [];
    
    equipoIds.forEach((select, index) => {
        equipoIdsArray.push(select.value);
        console.log(`Equipo ID ${index + 1}: "${select.value}"`);
    });
    
    equipoRoles.forEach((select, index) => {
        equipoRolesArray.push(select.value);
        console.log(`Equipo Rol ${index + 1}: "${select.value}"`);
    });
    
    console.log('Equipo IDs:', equipoIdsArray);
    console.log('Equipo Roles:', equipoRolesArray);
    
    // Verificar selects del equipo
    const selectsEquipo = form.querySelectorAll('select[name="equipo_ids[]"]');
    console.log('Selects del equipo encontrados:', selectsEquipo.length);
    selectsEquipo.forEach((select, index) => {
        console.log(`Select ${index + 1}: valor = "${select.value}", texto = "${select.options[select.selectedIndex]?.text}"`);
    });
    
    console.log('=== FIN DEBUG ===');
    
    // Preguntar si enviar el formulario
    if (confirm('¿Deseas enviar el formulario?')) {
        form.submit();
    }
}

function openEditModal(grupoId, nombre, proyectoId, liderId) {
    document.getElementById('modalEditGrupo').classList.remove('hidden');
    
    // Llenar el formulario con los datos actuales
    document.getElementById('edit_nombre_grupo').value = nombre;
    document.getElementById('edit_proyecto_id').value = proyectoId;
    document.getElementById('edit_lider_id').value = liderId;
    
    // Configurar la acción del formulario
    document.getElementById('editForm').action = `/fabricasoft/grupos/${grupoId}/update`;
    
    // Limpiar el contenedor de equipo
    document.getElementById('equipo-container-editar').innerHTML = '';
    
    // Cargar equipo existente
    cargarEquipoExistente(grupoId);
}

function agregarMiembroEquipo(tipo) {
    console.log('=== AGREGAR MIEMBRO EQUIPO ===');
    console.log('Tipo:', tipo);
    
    const container = document.getElementById(`equipo-container-${tipo}`);
    console.log('Container encontrado:', container);
    
    if (!container) {
        console.error('No se encontró el container:', `equipo-container-${tipo}`);
        return;
    }
    
    const miembrosActuales = container.children.length;
    console.log('Miembros actuales:', miembrosActuales);
    
    if (miembrosActuales >= 3) {
        alert('Ya has agregado el máximo de 3 miembros adicionales');
        return;
    }
    
    const miembroDiv = document.createElement('div');
    miembroDiv.className = 'flex items-center gap-2 p-3 bg-gray-50 rounded-lg border border-gray-200';
    miembroDiv.innerHTML = `
        <div class="flex-1">
            <label class="block text-xs font-medium text-gray-700 mb-1">Desarrollador</label>
            <select name="equipo_ids[]" class="w-full border border-gray-300 rounded px-3 py-2 text-sm" onchange="actualizarSeleccionDesarrollador(this)" required>
                <option value="">Seleccione un desarrollador</option>
                @foreach($desarrolladores as $dev)
                    <option value="{{ $dev->id }}">{{ $dev->nickname }} ({{ $dev->email }})</option>
                @endforeach
            </select>
        </div>
        <div class="flex-1">
            <label class="block text-xs font-medium text-gray-700 mb-1">Rol</label>
            <select name="equipo_roles[]" class="w-full border border-gray-300 rounded px-3 py-2 text-sm" required>
                <option value="">Seleccione un rol</option>
                <option value="desarrollador">Desarrollador</option>
                <option value="disenador">Diseñador</option>
                <option value="tester">Tester</option>
                <option value="analista">Analista</option>
            </select>
        </div>
        <div class="flex items-end">
            <button type="button" onclick="eliminarMiembroEquipo(this, '${tipo}')" class="text-red-500 hover:text-red-700 p-2 bg-red-50 rounded-lg transition-colors" title="Eliminar miembro">
                <i class="fas fa-trash text-sm"></i>
            </button>
        </div>
    `;
    
    container.appendChild(miembroDiv);
    console.log('Miembro agregado exitosamente');
    console.log('Total de miembros después de agregar:', container.children.length);
    
    // Hacer scroll al nuevo elemento
    miembroDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function testEliminar(button, tipo) {
    console.log('=== TEST ELIMINAR ===');
    console.log('Botón clickeado:', button);
    console.log('Tipo:', tipo);
    
    // Buscar el elemento padre inmediato
    const miembroDiv = button.parentElement.parentElement;
    console.log('Elemento a eliminar:', miembroDiv);
    
    if (miembroDiv) {
        miembroDiv.remove();
        console.log('Miembro eliminado exitosamente');
        alert('¡Miembro eliminado!');
    } else {
        console.error('No se pudo eliminar');
        alert('Error al eliminar');
    }
}

function eliminarMiembroEquipo(button, tipo) {
    console.log('=== ELIMINAR MIEMBRO EQUIPO ===');
    console.log('Tipo:', tipo);
    console.log('Botón clickeado:', button);
    
    // Buscar el elemento padre que contiene todo el miembro
    let miembroDiv = button.closest('.flex.items-center.gap-2.p-3.bg-gray-50.rounded-lg.border.border-gray-200');
    
    if (!miembroDiv) {
        // Si no encuentra con la clase específica, buscar el div padre
        miembroDiv = button.closest('div');
    }
    
    if (!miembroDiv) {
        // Último intento: subir 3 niveles desde el botón
        miembroDiv = button.parentElement.parentElement.parentElement;
    }
    
    console.log('Elemento a eliminar:', miembroDiv);
    
    if (miembroDiv) {
        miembroDiv.remove();
        console.log('Miembro eliminado exitosamente');
        
        // Actualizar contador
        const container = document.getElementById(`equipo-container-${tipo}`);
        if (container) {
            console.log('Miembros restantes:', container.children.length);
        }
        
        // Mostrar confirmación visual
        alert('Miembro eliminado correctamente');
    } else {
        console.error('No se pudo encontrar el elemento a eliminar');
        alert('Error: No se pudo eliminar el miembro');
    }
}

function cargarEquipoExistente(grupoId) {
    console.log('=== CARGAR EQUIPO EXISTENTE ===');
    console.log('Grupo ID:', grupoId);
    
    fetch(`/fabricasoft/grupos/${grupoId}/equipo`)
        .then(response => {
            console.log('Response status:', response.status);
            return response.json();
        })
        .then(data => {
            console.log('Datos recibidos:', data);
            
            const container = document.getElementById('equipo-container-editar');
            console.log('Container encontrado:', container);
            
            if (!container) {
                console.error('No se encontró el container equipo-container-editar');
                return;
            }
            
            container.innerHTML = '';
            
            if (data.miembros && data.miembros.length > 0) {
                console.log('Miembros encontrados:', data.miembros.length);
                data.miembros.forEach((miembro, index) => {
                    console.log(`Agregando miembro ${index + 1}:`, miembro);
                    agregarMiembroEquipoConDatos(miembro, 'editar');
                });
            } else {
                console.log('No hay miembros en el equipo');
            }
        })
        .catch(error => {
            console.error('Error al cargar equipo:', error);
        });
}

function agregarMiembroEquipoConDatos(miembro, tipo) {
    console.log('=== AGREGAR MIEMBRO CON DATOS ===');
    console.log('Miembro:', miembro);
    console.log('Tipo:', tipo);
    
    const container = document.getElementById(`equipo-container-${tipo}`);
    console.log('Container encontrado:', container);
    
    if (!container) {
        console.error('No se encontró el container:', `equipo-container-${tipo}`);
        return;
    }
    
    const miembrosActuales = container.children.length;
    console.log('Miembros actuales:', miembrosActuales);
    
    if (miembrosActuales >= 3) {
        console.log('Ya hay 3 miembros, no se puede agregar más');
        return;
    }
    
    const miembroDiv = document.createElement('div');
    miembroDiv.className = 'flex items-center gap-2 p-3 bg-gray-50 rounded-lg border border-gray-200';
    miembroDiv.innerHTML = `
        <div class="flex-1">
            <label class="block text-xs font-medium text-gray-700 mb-1">Desarrollador</label>
            <select name="equipo_ids[]" class="w-full border border-gray-300 rounded px-3 py-2 text-sm" onchange="actualizarSeleccionDesarrollador(this)" required>
                <option value="">Seleccione un desarrollador</option>
                @foreach($desarrolladores as $dev)
                    <option value="{{ $dev->id }}">{{ $dev->nickname }} ({{ $dev->email }})</option>
                @endforeach
            </select>
        </div>
        <div class="flex-1">
            <label class="block text-xs font-medium text-gray-700 mb-1">Rol</label>
            <select name="equipo_roles[]" class="w-full border border-gray-300 rounded px-3 py-2 text-sm" required>
                <option value="">Seleccione un rol</option>
                <option value="desarrollador">Desarrollador</option>
                <option value="disenador">Diseñador</option>
                <option value="tester">Tester</option>
                <option value="analista">Analista</option>
            </select>
        </div>
        <div class="flex items-end">
            <button type="button" onclick="testEliminar(this, '${tipo}')" class="text-red-500 hover:text-red-700 p-2 bg-red-50 rounded-lg transition-colors" title="Eliminar miembro">
                <i class="fas fa-trash text-sm"></i>
            </button>
        </div>
    `;
    
    container.appendChild(miembroDiv);
    console.log('Miembro con datos agregado exitosamente');
    
    // Establecer los valores seleccionados
    const selectDesarrollador = miembroDiv.querySelector('select[name="equipo_ids[]"]');
    const selectRol = miembroDiv.querySelector('select[name="equipo_roles[]"]');
    
    if (selectDesarrollador) {
        selectDesarrollador.value = miembro.user_id;
        console.log('Valor del desarrollador establecido:', miembro.user_id);
    }
    
    if (selectRol) {
        selectRol.value = miembro.rol;
        console.log('Valor del rol establecido:', miembro.rol);
    }
    
    // Aplicar selección visual después de un breve delay
    setTimeout(() => {
        if (selectDesarrollador && selectDesarrollador.value) {
            actualizarSeleccionDesarrollador(selectDesarrollador);
            console.log('Selección visual aplicada');
        } else {
            console.log('No hay valor seleccionado');
        }
    }, 200);
}

function actualizarSeleccionDesarrollador(select) {
    // Remover selección previa
    select.style.backgroundColor = '';
    select.style.borderColor = '';
    
    if (select.value) {
        // Aplicar selección visual
        select.style.backgroundColor = '#dbeafe';
        select.style.borderColor = '#3b82f6';
    }
}

function inicializarSelects() {
    // Aplicar selección visual a todos los selects que tengan valor
    document.querySelectorAll('select[name="equipo_ids[]"]').forEach(select => {
        if (select.value) {
            actualizarSeleccionDesarrollador(select);
        }
    });
}

function abrirModalCrearGrupo() {
    document.getElementById('modalGrupo').classList.remove('hidden');
}

function abrirModalEditarGrupo() {
    document.getElementById('modalEditGrupo').classList.remove('hidden');
}

function guardarGrupo() {
    console.log('=== GUARDANDO GRUPO ===');
    
    const form = document.getElementById('editForm');
    const formData = new FormData();
    
    // Agregar datos básicos del formulario
    formData.append('_token', document.querySelector('input[name="_token"]').value);
    formData.append('_method', 'PUT');
    formData.append('nombre_grupo', document.getElementById('edit_nombre_grupo').value);
    formData.append('proyecto_id', document.getElementById('edit_proyecto_id').value);
    formData.append('lider_id', document.getElementById('edit_lider_id').value);
    
    // Agregar datos del equipo
    const equipoIds = form.querySelectorAll('select[name="equipo_ids[]"]');
    const equipoRoles = form.querySelectorAll('select[name="equipo_roles[]"]');
    
    console.log('Miembros encontrados:', equipoIds.length);
    
    equipoIds.forEach((select, index) => {
        const id = select.value;
        const rol = equipoRoles[index] ? equipoRoles[index].value : '';
        
        if (id && rol) {
            formData.append('equipo_ids[]', id);
            formData.append('equipo_roles[]', rol);
            console.log(`Agregando: ID=${id}, Rol=${rol}`);
        }
    });
    
    // Mostrar datos que se van a enviar
    console.log('Datos a enviar:');
    for (let [key, value] of formData.entries()) {
        console.log(`${key}: ${value}`);
    }
    
    // Enviar datos
    fetch(form.action, {
        method: 'POST',
        body: formData
    })
    .then(response => {
        console.log('Status:', response.status);
        if (response.ok) {
            alert('¡Grupo actualizado correctamente!');
            window.location.reload();
        } else {
            throw new Error('Error en la respuesta');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error al guardar. Revisa la consola.');
    });
}

// Funciones de filtrado
function aplicarFiltros() {
    const filtroLider = document.getElementById('filtro-lider').value;
    const filtroProyecto = document.getElementById('filtro-proyecto').value;
    const filtroRol = document.getElementById('filtro-rol').value;
    const filtroEstado = document.getElementById('filtro-estado').value;
    
    const grupos = document.querySelectorAll('.grupo-card');
    let equiposVisibles = 0;
    
    grupos.forEach(grupo => {
        let mostrar = true;
        
        // Filtro por líder
        if (filtroLider && grupo.dataset.lider !== filtroLider) {
            mostrar = false;
        }
        
        // Filtro por proyecto
        if (filtroProyecto && grupo.dataset.proyecto !== filtroProyecto) {
            mostrar = false;
        }
        
        // Filtro por estado
        if (filtroEstado && grupo.dataset.estado !== filtroEstado) {
            mostrar = false;
        }
        
        // Filtro por rol (más complejo porque puede haber múltiples roles)
        if (filtroRol) {
            const roles = JSON.parse(grupo.dataset.roles || '[]');
            const tieneRol = roles.includes(filtroRol) || 
                           (filtroRol === 'lider' && grupo.dataset.lider);
            
            if (!tieneRol) {
                mostrar = false;
            }
        }
        
        // Mostrar u ocultar el grupo
        if (mostrar) {
            grupo.style.display = 'block';
            equiposVisibles++;
        } else {
            grupo.style.display = 'none';
        }
    });
    
    // Actualizar contador
    document.getElementById('contador-equipos').textContent = equiposVisibles;
    
    // Mostrar mensaje si no hay resultados
    const mensajeNoResultados = document.getElementById('mensaje-no-resultados');
    if (equiposVisibles === 0) {
        if (!mensajeNoResultados) {
            const mensaje = document.createElement('div');
            mensaje.id = 'mensaje-no-resultados';
            mensaje.className = 'col-span-full text-center py-8 text-gray-500';
            mensaje.innerHTML = `
                <i class="fas fa-search text-4xl mb-4"></i>
                <p>No se encontraron equipos con los filtros seleccionados</p>
            `;
            document.querySelector('.grid').appendChild(mensaje);
        }
    } else {
        if (mensajeNoResultados) {
            mensajeNoResultados.remove();
        }
    }
}

function limpiarFiltros() {
    document.getElementById('filtro-lider').value = '';
    document.getElementById('filtro-proyecto').value = '';
    document.getElementById('filtro-rol').value = '';
    document.getElementById('filtro-estado').value = '';
    
    // Mostrar todos los grupos
    const grupos = document.querySelectorAll('.grupo-card');
    grupos.forEach(grupo => {
        grupo.style.display = 'block';
    });
    
    // Actualizar contador
    document.getElementById('contador-equipos').textContent = grupos.length;
    
    // Remover mensaje de no resultados si existe
    const mensajeNoResultados = document.getElementById('mensaje-no-resultados');
    if (mensajeNoResultados) {
        mensajeNoResultados.remove();
    }
}

function exportarEquipos() {
    const gruposVisibles = document.querySelectorAll('.grupo-card:not([style*="display: none"])');
    let csvContent = 'data:text/csv;charset=utf-8,';
    
    // Encabezados
    csvContent += 'Grupo,Líder,Email Líder,Proyecto,Cliente,Estado,Equipo\n';
    
    gruposVisibles.forEach(grupo => {
        const nombre = grupo.querySelector('h3').textContent;
        const lider = grupo.querySelector('.text-gray-800').textContent;
        const emailLider = grupo.querySelector('.text-gray-500').textContent;
        const proyecto = grupo.querySelector('.text-blue-500').nextElementSibling.textContent;
        const cliente = grupo.querySelector('.text-xs.text-gray-500').textContent.replace('Cliente: ', '');
        const estado = grupo.dataset.estado || 'pendiente';
        
        // Obtener miembros del equipo
        const miembros = [];
        grupo.querySelectorAll('.fas.fa-user').forEach(miembro => {
            const nombreMiembro = miembro.nextElementSibling.textContent;
            const rol = miembro.nextElementSibling.nextElementSibling.textContent;
            miembros.push(`${nombreMiembro} (${rol})`);
        });
        
        const equipo = miembros.join('; ');
        
        csvContent += `"${nombre}","${lider}","${emailLider}","${proyecto}","${cliente}","${estado}","${equipo}"\n`;
    });
    
    // Crear y descargar archivo
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'equipos_desarrollo.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    inicializarSelects();
    
    // Agregar datos de roles a las tarjetas de grupos
    document.querySelectorAll('.grupo-card').forEach(grupo => {
        const roles = [];
        
        // Agregar rol de líder
        roles.push('lider');
        
        // Agregar roles de miembros del equipo
        grupo.querySelectorAll('.fas.fa-user').forEach(miembro => {
            const rolElement = miembro.nextElementSibling.nextElementSibling;
            const rolTexto = rolElement.textContent.toLowerCase();
            if (rolTexto.includes('desarrollador')) roles.push('desarrollador');
            if (rolTexto.includes('diseñador')) roles.push('disenador');
            if (rolTexto.includes('tester')) roles.push('tester');
            if (rolTexto.includes('analista')) roles.push('analista');
        });
        
        grupo.dataset.roles = JSON.stringify(roles);
    });
});
</script>
@endsection
