@extends('fabricasoft::layouts.masteradmin')

@section('content')
<div class="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
    <!-- Header Section -->
    <div class="bg-white shadow-sm border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-6">
                <div class="flex items-center">
                    <a href="{{ route('fabricasoft.admin.formularios.listado') }}" 
                       class="mr-4 p-2 text-gray-400 hover:text-gray-600 transition-colors duration-200">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                        </svg>
                    </a>
                    <div>
                        <h1 class="text-3xl font-bold text-gray-900">Crear Formulario Personalizado</h1>
                        <p class="mt-2 text-sm text-gray-600">Diseña un formulario personalizado para tus proyectos</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Content Section -->
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <form id="form-crear-formulario" action="{{ route('fabricasoft.admin.formularios.store') }}" method="POST" class="p-8">
                @csrf
                
                <!-- Form Header -->
                <div class="mb-8">
                    <div class="flex items-center mb-4">
                        <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                            <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                        </div>
                        <div>
                            <h2 class="text-xl font-semibold text-gray-900">Información del Formulario</h2>
                            <p class="text-sm text-gray-500">Define el nombre y las características básicas</p>
                        </div>
                    </div>
                    
                    <div class="space-y-4">
                        <div>
                            <label for="nombre" class="block text-sm font-medium text-gray-700 mb-2">
                                Nombre del Formulario <span class="text-red-500">*</span>
                            </label>
                            <input type="text" 
                                   id="nombre"
                                   name="nombre" 
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200"
                                   placeholder="Ej: Formulario de Requerimientos Técnicos"
                                   required>
                            <p class="mt-1 text-sm text-gray-500">Usa un nombre descriptivo que identifique claramente el propósito del formulario</p>
                        </div>
                    </div>
                </div>

                <!-- Questions Section -->
                <div class="mb-8">
                    <div class="flex items-center justify-between mb-6">
                        <div class="flex items-center">
                            <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                                <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <div>
                                <h2 class="text-xl font-semibold text-gray-900">Preguntas del Formulario</h2>
                                <p class="text-sm text-gray-500">Agrega las preguntas que conformarán tu formulario</p>
                            </div>
                        </div>
                        <button type="button" 
                                id="agregar-pregunta" 
                                class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg shadow-sm text-white bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-all duration-200">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                            </svg>
                            Agregar Pregunta
                        </button>
                    </div>
                    
                    <div id="preguntas-container" class="space-y-6">
                        <!-- Las preguntas se agregarán dinámicamente aquí -->
                    </div>
                    
                    <div id="empty-state" class="text-center py-12 border-2 border-dashed border-gray-300 rounded-lg">
                        <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                        </div>
                        <h3 class="text-lg font-medium text-gray-900 mb-2">No hay preguntas agregadas</h3>
                        <p class="text-gray-500 mb-4">Comienza agregando la primera pregunta a tu formulario</p>
                        <button type="button" 
                                onclick="agregarPregunta()"
                                class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg shadow-sm text-white bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-all duration-200">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                            </svg>
                            Agregar Primera Pregunta
                        </button>
                    </div>
                </div>

                <!-- Form Actions -->
                <div class="flex items-center justify-between pt-6 border-t border-gray-200">
                    <a href="{{ route('fabricasoft.admin.formularios.listado') }}" 
                       class="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                        </svg>
                        Cancelar
                    </a>
                    <button type="submit" 
                            class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                        </svg>
                        Guardar Formulario
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
let preguntaIndex = 0;

function agregarPregunta() {
    const container = document.getElementById('preguntas-container');
    const emptyState = document.getElementById('empty-state');
    
    // Ocultar el empty state si existe
    if (emptyState) {
        emptyState.style.display = 'none';
    }
    
    const preguntaDiv = document.createElement('div');
    preguntaDiv.className = 'bg-gray-50 rounded-xl p-6 border border-gray-200 relative';
    preguntaDiv.innerHTML = `
        <div class="flex items-start justify-between mb-4">
            <div class="flex items-center">
                <div class="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                    <span class="text-sm font-semibold text-blue-600">${preguntaIndex + 1}</span>
                </div>
                <h3 class="text-lg font-medium text-gray-900">Pregunta ${preguntaIndex + 1}</h3>
            </div>
            <button type="button" 
                    onclick="eliminarPregunta(this)" 
                    class="text-red-500 hover:text-red-700 transition-colors duration-200 p-1 rounded-full hover:bg-red-50"
                    title="Eliminar pregunta">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                </svg>
            </button>
        </div>
        
        <div class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    Texto de la pregunta <span class="text-red-500">*</span>
                </label>
                <input type="text" 
                       name="preguntas[${preguntaIndex}][texto]" 
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200"
                       placeholder="Ej: ¿Cuál es el objetivo principal del proyecto?"
                       required>
            </div>
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    Tipo de campo <span class="text-red-500">*</span>
                </label>
                <select name="preguntas[${preguntaIndex}][tipo]" 
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200"
                        onchange="toggleOpciones(this, ${preguntaIndex})"
                        required>
                    <option value="">Selecciona un tipo</option>
                    <option value="texto">Texto libre</option>
                    <option value="seleccion">Selección múltiple</option>
                    <option value="fecha">Fecha</option>
                    <option value="numero">Número</option>
                </select>
            </div>
            
            <div id="opciones-container-${preguntaIndex}" class="opciones-seleccion" style="display: none;">
                <label class="block text-sm font-medium text-gray-700 mb-2">Opciones de selección</label>
                <div class="opciones-lista space-y-2">
                    <div class="flex items-center gap-2">
                        <input type="text" 
                               name="preguntas[${preguntaIndex}][opciones][]" 
                               class="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200"
                               placeholder="Opción 1">
                        <button type="button" 
                                class="text-red-500 hover:text-red-700 p-1 rounded-full hover:bg-red-50 transition-colors duration-200"
                                onclick="eliminarOpcion(this)"
                                title="Eliminar opción">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                            </svg>
                        </button>
                    </div>
                </div>
                <button type="button" 
                        class="mt-2 inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
                        onclick="agregarOpcion(${preguntaIndex})">
                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                    </svg>
                    Agregar Opción
                </button>
            </div>
            
            <div class="flex items-center">
                <input type="checkbox" 
                       name="preguntas[${preguntaIndex}][cliente]" 
                       id="cliente-${preguntaIndex}"
                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                <label for="cliente-${preguntaIndex}" class="ml-2 block text-sm text-gray-700">
                    Campo para que el cliente lo llene
                </label>
            </div>
        </div>
    `;
    
    container.appendChild(preguntaDiv);
    preguntaIndex++;
}

function eliminarPregunta(button) {
    const preguntaDiv = button.closest('.bg-gray-50');
    preguntaDiv.remove();
    
    // Mostrar empty state si no hay preguntas
    const container = document.getElementById('preguntas-container');
    const emptyState = document.getElementById('empty-state');
    if (container.children.length === 0 && emptyState) {
        emptyState.style.display = 'block';
    }
    
    // Renumerar las preguntas
    renumerarPreguntas();
}

function renumerarPreguntas() {
    const preguntas = document.querySelectorAll('#preguntas-container > div');
    preguntas.forEach((pregunta, index) => {
        const numeroSpan = pregunta.querySelector('.w-8.h-8 span');
        const tituloH3 = pregunta.querySelector('h3');
        if (numeroSpan) numeroSpan.textContent = index + 1;
        if (tituloH3) tituloH3.textContent = `Pregunta ${index + 1}`;
    });
}

function toggleOpciones(select, index) {
    const opcionesContainer = document.getElementById(`opciones-container-${index}`);
    if (select.value === 'seleccion') {
        opcionesContainer.style.display = 'block';
    } else {
        opcionesContainer.style.display = 'none';
    }
}

function agregarOpcion(index) {
    const lista = document.querySelector(`#opciones-container-${index} .opciones-lista`);
    const optionRow = document.createElement('div');
    optionRow.className = 'flex items-center gap-2';
    optionRow.innerHTML = `
        <input type="text" 
               name="preguntas[${index}][opciones][]" 
               class="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200"
               placeholder="Nueva opción">
        <button type="button" 
                class="text-red-500 hover:text-red-700 p-1 rounded-full hover:bg-red-50 transition-colors duration-200"
                onclick="eliminarOpcion(this)"
                title="Eliminar opción">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
            </svg>
        </button>
    `;
    lista.appendChild(optionRow);
}

function eliminarOpcion(button) {
    button.closest('.flex').remove();
}

// Event listener para el botón agregar pregunta
document.getElementById('agregar-pregunta').addEventListener('click', agregarPregunta);
</script>
@endsection 