@extends('fabricasoft::layouts.app')

@section('title', 'Seguimiento de Formularios - Admin')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-tasks"></i> Seguimiento de Formularios
                    </h3>
                    <div class="card-tools">
                        <a href="{{ route('fabricasoft.admin.seguimiento.exportar') }}" class="btn btn-success btn-sm">
                            <i class="fas fa-download"></i> Exportar
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Estadísticas -->
                    <div class="row mb-4">
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-info">
                                <div class="inner">
                                    <h3>{{ $stats->total ?? 0 }}</h3>
                                    <p>Total Formularios</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-clipboard-list"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-warning">
                                <div class="inner">
                                    <h3>{{ $stats->pendientes ?? 0 }}</h3>
                                    <p>Pendientes</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-clock"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-primary">
                                <div class="inner">
                                    <h3>{{ $stats->en_desarrollo ?? 0 }}</h3>
                                    <p>En Desarrollo</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-code"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-success">
                                <div class="inner">
                                    <h3>{{ $stats->completados ?? 0 }}</h3>
                                    <p>Completados</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Filtros -->
                    <div class="row mb-3">
                        <div class="col-12">
                            <form method="GET" action="{{ route('fabricasoft.admin.seguimiento.formularios') }}" class="form-inline">
                                <div class="form-group mr-2">
                                    <select name="estado" class="form-control form-control-sm">
                                        <option value="">Todos los estados</option>
                                        <option value="pendiente" {{ request('estado') == 'pendiente' ? 'selected' : '' }}>Pendiente</option>
                                        <option value="en_revision" {{ request('estado') == 'en_revision' ? 'selected' : '' }}>En Revisión</option>
                                        <option value="en_desarrollo" {{ request('estado') == 'en_desarrollo' ? 'selected' : '' }}>En Desarrollo</option>
                                        <option value="testing" {{ request('estado') == 'testing' ? 'selected' : '' }}>Testing</option>
                                        <option value="completado" {{ request('estado') == 'completado' ? 'selected' : '' }}>Completado</option>
                                        <option value="rechazado" {{ request('estado') == 'rechazado' ? 'selected' : '' }}>Rechazado</option>
                                        <option value="pausado" {{ request('estado') == 'pausado' ? 'selected' : '' }}>Pausado</option>
                                    </select>
                                </div>
                                <div class="form-group mr-2">
                                    <select name="formulario_id" class="form-control form-control-sm">
                                        <option value="">Todos los formularios</option>
                                        @foreach($formularios as $formulario)
                                            <option value="{{ $formulario->id }}" {{ request('formulario_id') == $formulario->id ? 'selected' : '' }}>
                                                {{ $formulario->nombre }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group mr-2">
                                    <select name="desarrollador_id" class="form-control form-control-sm">
                                        <option value="">Todos los desarrolladores</option>
                                        @foreach($desarrolladores as $desarrollador)
                                            <option value="{{ $desarrollador->id }}" {{ request('desarrollador_id') == $desarrollador->id ? 'selected' : '' }}>
                                                {{ $desarrollador->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group mr-2">
                                    <select name="prioridad" class="form-control form-control-sm">
                                        <option value="">Todas las prioridades</option>
                                        <option value="1" {{ request('prioridad') == '1' ? 'selected' : '' }}>Baja</option>
                                        <option value="2" {{ request('prioridad') == '2' ? 'selected' : '' }}>Media</option>
                                        <option value="3" {{ request('prioridad') == '3' ? 'selected' : '' }}>Alta</option>
                                        <option value="4" {{ request('prioridad') == '4' ? 'selected' : '' }}>Urgente</option>
                                    </select>
                                </div>
                                <div class="form-group mr-2">
                                    <input type="date" name="fecha_desde" class="form-control form-control-sm" 
                                           placeholder="Desde" value="{{ request('fecha_desde') }}">
                                </div>
                                <div class="form-group mr-2">
                                    <input type="date" name="fecha_hasta" class="form-control form-control-sm" 
                                           placeholder="Hasta" value="{{ request('fecha_hasta') }}">
                                </div>
                                <button type="submit" class="btn btn-primary btn-sm">
                                    <i class="fas fa-search"></i> Filtrar
                                </button>
                                <a href="{{ route('fabricasoft.admin.seguimiento.formularios') }}" class="btn btn-secondary btn-sm ml-1">
                                    <i class="fas fa-times"></i> Limpiar
                                </a>
                            </form>
                        </div>
                    </div>

                    <!-- Tabla de seguimientos -->
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Formulario</th>
                                    <th>Usuario</th>
                                    <th>Desarrollador</th>
                                    <th>Estado</th>
                                    <th>Prioridad</th>
                                    <th>Fecha Envío</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($seguimientos as $seguimiento)
                                    <tr>
                                        <td>{{ $seguimiento->id }}</td>
                                        <td>{{ $seguimiento->formulario->nombre ?? 'N/A' }}</td>
                                        <td>{{ $seguimiento->user->name ?? 'N/A' }}</td>
                                        <td>
                                            @if($seguimiento->assignedUser)
                                                {{ $seguimiento->assignedUser->name }}
                                            @else
                                                <span class="text-muted">Sin asignar</span>
                                            @endif
                                        </td>
                                        <td>
                                            <span class="badge {{ $seguimiento->estado_class }}">
                                                {{ $seguimiento->estado_legible }}
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge {{ $seguimiento->prioridad_class }}">
                                                {{ $seguimiento->prioridad_legible }}
                                            </span>
                                        </td>
                                        <td>{{ $seguimiento->fecha_envio->format('d/m/Y H:i') }}</td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('fabricasoft.admin.seguimiento.detalles', $seguimiento->id) }}" 
                                                   class="btn btn-info btn-sm" title="Ver detalles">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <button type="button" class="btn btn-warning btn-sm" 
                                                        onclick="editarSeguimiento({{ $seguimiento->id }})" title="Editar">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                @if(!$seguimiento->assignedUser)
                                                    <button type="button" class="btn btn-success btn-sm" 
                                                            onclick="asignarDesarrollador({{ $seguimiento->id }})" title="Asignar desarrollador">
                                                        <i class="fas fa-user-plus"></i>
                                                    </button>
                                                @endif
                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="8" class="text-center">No hay formularios para mostrar</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    <!-- Paginación -->
                    <div class="d-flex justify-content-center">
                        {{ $seguimientos->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal para editar seguimiento -->
<div class="modal fade" id="modalEditarSeguimiento" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Seguimiento</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="formEditarSeguimiento">
                    <input type="hidden" id="seguimiento_id" name="seguimiento_id">
                    
                    <div class="form-group">
                        <label for="estado">Estado</label>
                        <select id="estado" name="estado" class="form-control" required>
                            <option value="pendiente">Pendiente</option>
                            <option value="en_revision">En Revisión</option>
                            <option value="en_desarrollo">En Desarrollo</option>
                            <option value="testing">Testing</option>
                            <option value="completado">Completado</option>
                            <option value="rechazado">Rechazado</option>
                            <option value="pausado">Pausado</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="prioridad">Prioridad</label>
                        <select id="prioridad" name="prioridad" class="form-control">
                            <option value="1">Baja</option>
                            <option value="2">Media</option>
                            <option value="3">Alta</option>
                            <option value="4">Urgente</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="comentarios">Comentarios</label>
                        <textarea id="comentarios" name="comentarios" class="form-control" rows="3"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" onclick="guardarSeguimiento()">Guardar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal para asignar desarrollador -->
<div class="modal fade" id="modalAsignarDesarrollador" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Asignar Desarrollador</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="formAsignarDesarrollador">
                    <input type="hidden" id="seguimiento_id_asignar" name="seguimiento_id">
                    
                    <div class="form-group">
                        <label for="desarrollador_id">Desarrollador</label>
                        <select id="desarrollador_id" name="desarrollador_id" class="form-control" required>
                            <option value="">Seleccionar desarrollador</option>
                            @foreach($desarrolladores as $desarrollador)
                                <option value="{{ $desarrollador->id }}">{{ $desarrollador->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" onclick="guardarAsignacion()">Asignar</button>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
function editarSeguimiento(id) {
    // Cargar datos del seguimiento
    fetch(`/fabricasoft/admin/seguimiento-formularios/${id}/detalles`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('seguimiento_id').value = id;
            document.getElementById('estado').value = data.seguimiento.estado;
            document.getElementById('prioridad').value = data.seguimiento.prioridad;
            document.getElementById('comentarios').value = data.seguimiento.comentarios || '';
            $('#modalEditarSeguimiento').modal('show');
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al cargar los datos del seguimiento');
        });
}

function guardarSeguimiento() {
    const id = document.getElementById('seguimiento_id').value;
    const formData = new FormData(document.getElementById('formEditarSeguimiento'));
    
    fetch(`/fabricasoft/admin/seguimiento-formularios/${id}/estado`, {
        method: 'PUT',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            estado: formData.get('estado'),
            prioridad: formData.get('prioridad'),
            comentarios: formData.get('comentarios')
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            $('#modalEditarSeguimiento').modal('hide');
            location.reload();
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error al guardar el seguimiento');
    });
}

function asignarDesarrollador(id) {
    document.getElementById('seguimiento_id_asignar').value = id;
    $('#modalAsignarDesarrollador').modal('show');
}

function guardarAsignacion() {
    const id = document.getElementById('seguimiento_id_asignar').value;
    const desarrolladorId = document.getElementById('desarrollador_id').value;
    
    if (!desarrolladorId) {
        alert('Por favor seleccione un desarrollador');
        return;
    }
    
    fetch(`/fabricasoft/admin/seguimiento-formularios/${id}/asignar-desarrollador`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            desarrollador_id: desarrolladorId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            $('#modalAsignarDesarrollador').modal('hide');
            location.reload();
        } else {
            alert('Error: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error al asignar el desarrollador');
    });
}
</script>
@endpush

