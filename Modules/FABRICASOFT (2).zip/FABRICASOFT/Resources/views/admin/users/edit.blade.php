@extends('fabricasoft::layouts.masteradmin')

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Editar Usuario</h3>
    </div>
    <div class="card-body">
        @if($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <form action="{{ route('fabricasoft.admin.users.update', $user->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label>ID</label>
                <input type="text" class="form-control" value="{{ $user->id }}" readonly>
            </div>
            <div class="form-group">
                <label for="nickname">Nickname</label>
                <input type="text" name="nickname" class="form-control" value="{{ old('nickname', $user->nickname) }}" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" class="form-control" value="{{ old('email', $user->email) }}" required>
            </div>
            <div class="form-group">
                <label for="password">Password (dejar vacío para no cambiar)</label>
                <input type="password" name="password" class="form-control">
            </div>
            <div class="form-group">
                <label>Person ID</label>
                <input type="text" class="form-control" value="{{ $user->person_id }}" readonly>
            </div>
            <div class="form-group">
                <label for="role_id">Rol</label>
                <select name="role_id" class="form-control" required>
                    <option value="">Seleccione un rol</option>
                    @foreach($roles as $role)
                        @if($role->slug !== 'fabricasoft.users')
                            <option value="{{ $role->id }}" {{ (old('role_id', $user->roles->first()->id ?? '') == $role->id) ? 'selected' : '' }}>
                                {{ $role->name }} - {{ $role->description }}
                            </option>
                        @endif
                    @endforeach
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
            <a href="{{ route('fabricasoft.admin.users.index') }}" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</div>
@endsection 