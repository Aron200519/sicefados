@extends('fabricasoft::layouts.masteradmin')

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Crear Usuario</h3>
    </div>
    <div class="card-body">
        @if($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <form action="{{ route('fabricasoft.admin.users.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="nickname">Nickname</label>
                <input type="text" name="nickname" class="form-control" value="{{ old('nickname') }}" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" class="form-control" value="{{ old('email') }}" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="person_id">Person ID</label>
                <input type="number" name="person_id" class="form-control" value="{{ old('person_id') }}" required>
            </div>
            <div class="form-group">
                <label for="role_id">Rol</label>
                <select name="role_id" class="form-control" required>
                    <option value="">Seleccione un rol</option>
                    @foreach($roles as $role)
                        @if($role->slug !== 'fabricasoft.users')
                            <option value="{{ $role->id }}" {{ old('role_id') == $role->id ? 'selected' : '' }}>
                                {{ $role->name }} - {{ $role->description }}
                            </option>
                        @endif
                    @endforeach
                </select>
            </div>
            <button type="submit" class="btn btn-success">Crear</button>
            <a href="{{ route('fabricasoft.admin.users.index') }}" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</div>
@endsection 