@extends('fabricasoft::layouts.masteradmin')

@section('content')
<div class="p-4 border-b bg-white">
    <div class="flex justify-between items-center">
        <h1 class="text-2xl font-semibold text-gray-800">Gestión de Pre-registros</h1>
    </div>
</div>
<div class="p-4">
    <div class="card bg-white">
        <div class="p-4 flex justify-between items-center border-b">
            <h3 class="text-xl font-semibold text-gray-800">Solicitudes de Pre-registro</h3>
        </div>
        <div class="p-4">
            @if(session('success'))
                <div class="bg-green-100 text-green-700 p-4 rounded-lg mb-4" id="alert-success">{{ session('success') }}</div>
            @endif
            @if(session('error'))
                <div class="bg-red-100 text-red-700 p-4 rounded-lg mb-4" id="alert-error">{{ session('error') }}</div>
            @endif

            <div class="overflow-x-auto">
                <table class="w-full border-collapse">
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="p-3 text-left">ID</th>
                            <th class="p-3 text-left">Nombre</th>
                            <th class="p-3 text-left">Empresa</th>
                            <th class="p-3 text-left">Email</th>
                            <th class="p-3 text-left">Teléfono</th>
                            <th class="p-3 text-left">Estado</th>
                            <th class="p-3 text-left">Fecha</th>
                            <th class="p-3 text-left">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($requests as $request)
                            <tr class="border-t">
                                <td class="p-3">{{ $request->id }}</td>
                                <td class="p-3">{{ $request->full_name }}</td>
                                <td class="p-3">{{ $request->company_name }}</td>
                                <td class="p-3">{{ $request->email }}</td>
                                <td class="p-3">{{ $request->phone }}</td>
                                <td class="p-3">
                                    @if($request->status === 'pending')
                                        <span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">Pendiente</span>
                                    @elseif($request->status === 'approved')
                                        <span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Aprobado</span>
                                    @else
                                        <span class="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">Rechazado</span>
                                    @endif
                                </td>
                                <td class="p-3">{{ $request->created_at->format('d/m/Y H:i') }}</td>
                                <td class="p-3 flex space-x-2">
                                    @if($request->status === 'pending')
                                        <button type="button" class="bg-green-600 hover:bg-green-700 text-white font-bold px-4 py-2 rounded-lg shadow transition" onclick="toggleModal('approveModal{{ $request->id }}')">
                                            <i class="fas fa-check"></i> Aprobar
                                        </button>
                                        <button type="button" class="bg-red-600 hover:bg-red-700 text-white font-bold px-4 py-2 rounded-lg shadow transition" onclick="toggleModal('rejectModal{{ $request->id }}')">
                                            <i class="fas fa-times"></i> Rechazar
                                        </button>
                                    @endif
                                    <button type="button" class="bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2 rounded-lg shadow transition" onclick="toggleModal('viewModal{{ $request->id }}')">
                                        <i class="fas fa-eye"></i> Ver
                                    </button>
                                </td>
                            </tr>

                            <!-- Modal para ver detalles -->
                            <div class="modal fade fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center hidden p-2 sm:p-4 z-[9999] modal-with-sidebar" id="viewModal{{ $request->id }}" tabindex="-1">
                                <div class="modal-content bg-white w-full max-w-4xl rounded-lg shadow-2xl flex flex-col max-h-[85vh]">
                                    <!-- Header del modal -->
                                    <div class="flex justify-between items-center p-4 md:p-6 border-b bg-gray-50 rounded-t-lg">
                                        <h5 class="text-lg md:text-xl font-semibold break-words">Detalles de la Solicitud #{{ $request->id }}</h5>
                                        <button type="button" class="text-gray-500 text-xl md:text-2xl hover:text-red-500 p-1 transition-colors" onclick="closeModal('viewModal{{ $request->id }}')" title="Cerrar">×</button>
                                    </div>
                                    
                                    <!-- Contenido scrolleable del modal -->
                                    <div class="flex-1 overflow-y-auto p-4 md:p-6 custom-scrollbar" style="max-height: 60vh;">
                                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
                                            <div class="bg-gray-50 p-4 rounded-lg">
                                                <h6 class="font-semibold text-gray-800 mb-3 text-base md:text-lg">Información Personal</h6>
                                                <div class="space-y-3">
                                                    <div class="flex flex-col sm:flex-row sm:items-center">
                                                        <strong class="text-gray-700 min-w-[120px] sm:min-w-[140px]">Nombre:</strong>
                                                        <span class="text-gray-800 break-words">{{ $request->full_name }}</span>
                                                    </div>
                                                    <div class="flex flex-col sm:flex-row sm:items-center">
                                                        <strong class="text-gray-700 min-w-[120px] sm:min-w-[140px]">Email:</strong>
                                                        <span class="text-gray-800 break-all">{{ $request->email }}</span>
                                                    </div>
                                                    <div class="flex flex-col sm:flex-row sm:items-center">
                                                        <strong class="text-gray-700 min-w-[120px] sm:min-w-[140px]">Teléfono:</strong>
                                                        <span class="text-gray-800">{{ $request->phone }}</span>
                                                    </div>
                                                    <div class="flex flex-col sm:flex-row sm:items-center">
                                                        <strong class="text-gray-700 min-w-[120px] sm:min-w-[140px]">País:</strong>
                                                        <span class="text-gray-800">{{ $request->country }}</span>
                                                    </div>
                                                    <div class="flex flex-col sm:flex-row sm:items-center">
                                                        <strong class="text-gray-700 min-w-[120px] sm:min-w-[140px]">Departamento:</strong>
                                                        <span class="text-gray-800">{{ $request->state }}</span>
                                                    </div>
                                                    <div class="flex flex-col sm:flex-row sm:items-center">
                                                        <strong class="text-gray-700 min-w-[120px] sm:min-w-[140px]">Municipio:</strong>
                                                        <span class="text-gray-800">{{ $request->municipality }}</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="bg-gray-50 p-4 rounded-lg">
                                                <h6 class="font-semibold text-gray-800 mb-3 text-base md:text-lg">Información Empresarial</h6>
                                                <div class="space-y-3">
                                                    <div class="flex flex-col sm:flex-row sm:items-center">
                                                        <strong class="text-gray-700 min-w-[120px] sm:min-w-[140px]">Empresa:</strong>
                                                        <span class="text-gray-800 break-words">{{ $request->company_name }}</span>
                                                    </div>
                                                    <div class="flex flex-col sm:flex-row sm:items-center">
                                                        <strong class="text-gray-700 min-w-[120px] sm:min-w-[140px]">Cargo:</strong>
                                                        <span class="text-gray-800">{{ $request->position }}</span>
                                                    </div>
                                                    <div class="flex flex-col sm:flex-row sm:items-center">
                                                        <strong class="text-gray-700 min-w-[120px] sm:min-w-[140px]">Departamento:</strong>
                                                        <span class="text-gray-800">{{ $request->department }}</span>
                                                    </div>
                                                    <div class="flex flex-col sm:flex-row sm:items-center">
                                                        <strong class="text-gray-700 min-w-[120px] sm:min-w-[140px]">Estado:</strong>
                                                        <span class="inline-block">
                                                            @if($request->status === 'pending')
                                                                <span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">Pendiente</span>
                                                            @elseif($request->status === 'approved')
                                                                <span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Aprobado</span>
                                                            @else
                                                                <span class="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">Rechazado</span>
                                                            @endif
                                                        </span>
                                                    </div>
                                                    @if($request->admin_notes)
                                                    <div class="flex flex-col sm:flex-row sm:items-start">
                                                        <strong class="text-gray-700 min-w-[120px] sm:min-w-[140px] mt-1">Notas del Admin:</strong>
                                                        <span class="text-gray-800 break-words">{{ $request->admin_notes }}</span>
                                                    </div>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                                                                 <div class="mt-6 bg-gray-50 p-4 rounded-lg">
                                             <h6 class="font-semibold text-gray-800 mb-3 text-base md:text-lg">Descripción del Proyecto</h6>
                                             <p class="text-gray-700 leading-relaxed break-words">{{ $request->project_description }}</p>
                                         </div>
                                    </div>
                                    
                                    <!-- Footer del modal -->
                                    <div class="flex justify-end p-4 md:p-6 border-t bg-gray-50 rounded-b-lg">
                                        <button type="button" class="bg-gray-300 text-gray-700 px-3 md:px-4 py-2 rounded-lg text-sm md:text-base hover:bg-gray-400 transition-colors" onclick="closeModal('viewModal{{ $request->id }}')">Cerrar</button>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal para aprobar -->
                            <div class="modal fade fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center hidden p-2 sm:p-4 z-[9999] modal-with-sidebar" id="approveModal{{ $request->id }}" tabindex="-1">
                                <div class="modal-content bg-white w-full max-w-md rounded-lg shadow-2xl">
                                    <div class="flex justify-between items-center p-4 md:p-6 border-b">
                                        <h5 class="text-lg md:text-xl font-semibold break-words">Aprobar Solicitud #{{ $request->id }}</h5>
                                        <button type="button" class="text-gray-500 text-xl md:text-2xl hover:text-red-500 p-1 transition-colors" onclick="closeModal('approveModal{{ $request->id }}')" title="Cerrar">×</button>
                                    </div>
                                    <div class="p-4 md:p-6">
                                        <form action="{{ route('fabricasoft.admin.preregistration.approve', $request->id) }}" method="POST">
                                            @csrf
                                            <div class="mb-4">
                                                <p>¿Está seguro de que desea aprobar la solicitud de <strong>{{ $request->full_name }}</strong> de <strong>{{ $request->company_name }}</strong>?</p>
                                                <p class="text-sm text-gray-600 mt-2">Al aprobar, se enviará una notificación por correo electrónico al solicitante.</p>
                                            </div>
                                            <div class="flex flex-col sm:flex-row justify-end gap-2 sm:space-x-2">
                                                <button type="button" class="bg-gray-300 text-gray-700 px-3 md:px-4 py-2 rounded-lg text-sm md:text-base hover:bg-gray-400 transition-colors" onclick="closeModal('approveModal{{ $request->id }}')">Cancelar</button>
                                                <button type="submit" class="btn-success text-white px-3 md:px-4 py-2 rounded-lg text-sm md:text-base hover:bg-green-700 transition-colors">Aprobar</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal para rechazar -->
                            <div class="modal fade fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-50 flex items-center justify-center hidden p-2 sm:p-4 z-[9999] modal-with-sidebar" id="rejectModal{{ $request->id }}" tabindex="-1">
                                <div class="modal-content bg-white w-full max-w-md rounded-lg shadow-2xl">
                                    <div class="flex justify-between items-center p-4 md:p-6 border-b">
                                        <h5 class="text-lg md:text-xl font-semibold break-words">Rechazar Solicitud #{{ $request->id }}</h5>
                                        <button type="button" class="text-gray-500 text-xl md:text-2xl hover:text-red-500 p-1 transition-colors" onclick="closeModal('rejectModal{{ $request->id }}')" title="Cerrar">×</button>
                                    </div>
                                    <div class="p-4 md:p-6">
                                        <form action="{{ route('fabricasoft.admin.preregistration.reject', $request->id) }}" method="POST">
                                            @csrf
                                            <div class="mb-4">
                                                <p>¿Está seguro de que desea rechazar la solicitud de <strong>{{ $request->full_name }}</strong> de <strong>{{ $request->company_name }}</strong>?</p>
                                                <div class="mt-4">
                                                    <label for="admin_notes" class="block text-sm font-medium text-gray-700">Notas (opcional)</label>
                                                    <textarea class="w-full border rounded-lg p-2" id="admin_notes" name="admin_notes" rows="3" placeholder="Explique el motivo del rechazo..."></textarea>
                                                </div>
                                                <p class="text-sm text-gray-600 mt-2">Al rechazar, se enviará una notificación por correo electrónico al solicitante.</p>
                                            </div>
                                            <div class="flex flex-col sm:flex-row justify-end gap-2 sm:space-x-2">
                                                <button type="button" class="bg-gray-300 text-gray-700 px-3 md:px-4 py-2 rounded-lg text-sm md:text-base hover:bg-gray-400 transition-colors" onclick="closeModal('rejectModal{{ $request->id }}')">Cancelar</button>
                                                <button type="submit" class="bg-red-500 text-white px-3 md:px-4 py-2 rounded-lg text-sm md:text-base hover:bg-red-600 transition-colors">Rechazar</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @empty
                            <tr>
                                <td colspan="8" class="p-3 text-center text-gray-500">No hay solicitudes de pre-registro</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
/* Estilos específicos para el modal de detalles */
.modal {
    backdrop-filter: blur(4px);
}

.modal-content {
    transform: translateY(0);
    transition: all 0.3s ease;
}

.modal.show .modal-content {
    transform: translateY(0);
}

/* Mejoras para el contenido del modal */
.modal-content {
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
    border: 1px solid rgba(0, 0, 0, 0.1);
}

 /* Barra de desplazamiento personalizada en gris */
 .custom-scrollbar {
     scrollbar-width: auto !important;
     scrollbar-color: #6B7280 #f1f1f1 !important;
 }
 
 .custom-scrollbar::-webkit-scrollbar {
     width: 16px !important;
     display: block !important;
 }
 
 .custom-scrollbar::-webkit-scrollbar-track {
     background: #f1f1f1 !important;
     border-radius: 8px !important;
     border: 2px solid #e0e0e0 !important;
     margin: 4px !important;
 }
 
 .custom-scrollbar::-webkit-scrollbar-thumb {
     background: linear-gradient(180deg, #6B7280 0%, #4B5563 100%) !important;
     border-radius: 8px !important;
     border: 2px solid #f1f1f1 !important;
     box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.2) !important;
     min-height: 40px !important;
 }
 
 .custom-scrollbar::-webkit-scrollbar-thumb:hover {
     background: linear-gradient(180deg, #4B5563 0%, #374151 100%) !important;
     box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.3) !important;
 }
 
 .custom-scrollbar::-webkit-scrollbar-thumb:active {
     background: linear-gradient(180deg, #374151 0%, #1F2937 100%) !important;
 }

.custom-scrollbar::-webkit-scrollbar-corner {
    background: #f1f1f1 !important;
}

 /* Scroll personalizado para el modal principal */
 .modal-content::-webkit-scrollbar {
     width: 16px !important;
     display: block !important;
 }
 
 .modal-content::-webkit-scrollbar-track {
     background: #f1f1f1 !important;
     border-radius: 8px !important;
     border: 2px solid #e0e0e0 !important;
     margin: 4px !important;
 }
 
 .modal-content::-webkit-scrollbar-thumb {
     background: linear-gradient(180deg, #6B7280 0%, #4B5563 100%) !important;
     border-radius: 8px !important;
     border: 2px solid #f1f1f1 !important;
     box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.2) !important;
     min-height: 40px !important;
 }
 
 .modal-content::-webkit-scrollbar-thumb:hover {
     background: linear-gradient(180deg, #4B5563 0%, #374151 100%) !important;
     box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.3) !important;
 }
 
 .modal-content::-webkit-scrollbar-thumb:active {
     background: linear-gradient(180deg, #374151 0%, #1F2937 100%) !important;
 }

 /* Scroll personalizado para el contenido interno */
 .overflow-y-auto::-webkit-scrollbar {
     width: 16px !important;
     display: block !important;
 }
 
 .overflow-y-auto::-webkit-scrollbar-track {
     background: #f1f1f1 !important;
     border-radius: 8px !important;
     border: 2px solid #e0e0e0 !important;
     margin: 4px !important;
 }
 
 .overflow-y-auto::-webkit-scrollbar-thumb {
     background: linear-gradient(180deg, #6B7280 0%, #4B5563 100%) !important;
     border-radius: 8px !important;
     border: 2px solid #f1f1f1 !important;
     box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.2) !important;
     min-height: 40px !important;
 }
 
 .overflow-y-auto::-webkit-scrollbar-thumb:hover {
     background: linear-gradient(180deg, #4B5563 0%, #374151 100%) !important;
     box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.3) !important;
 }
 
 .overflow-y-auto::-webkit-scrollbar-thumb:active {
     background: linear-gradient(180deg, #374151 0%, #1F2937 100%) !important;
 }

/* Clase para ajustar el modal cuando el sidebar está visible */
.modal-with-sidebar {
    margin-left: 250px;
}

/* Responsive para el modal */
@media (max-width: 768px) {
    .modal-with-sidebar {
        margin-left: 0 !important;
    }
}

@media (max-width: 640px) {
    .modal-content {
        margin: 8px;
        max-height: calc(100vh - 16px);
    }
    
    /* Scrollbar más delgada en móviles */
    .custom-scrollbar::-webkit-scrollbar,
    .modal-content::-webkit-scrollbar,
    .overflow-y-auto::-webkit-scrollbar {
        width: 12px !important;
    }
}

/* Mejoras adicionales para el centrado */
.modal {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    padding: 1rem;
}

/* Animación suave para el modal */
.modal.show {
    animation: fadeIn 0.3s ease-out;
}

.modal-content {
    animation: slideIn 0.3s ease-out;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

@keyframes slideIn {
    from { 
        opacity: 0;
        transform: translateY(-20px) scale(0.95);
    }
    to { 
        opacity: 1;
        transform: translateY(0) scale(1);
    }
}

/* Mejoras para el contenido interno */
.bg-gray-50 {
    background-color: #f9fafb;
    border: 1px solid #e5e7eb;
}

/* Mejoras para los labels */
strong {
    font-weight: 600;
    color: #374151;
}

/* Mejoras para el texto */
.text-gray-800 {
    color: #1f2937;
    line-height: 1.5;
}
</style>

<!-- Script que se ejecuta inmediatamente para cerrar todos los modales al cargar la página -->
<script>
// Cerrar todos los modales inmediatamente al cargar la página
(function() {
    // Cerrar todos los modales que puedan estar abiertos
    document.querySelectorAll('.modal').forEach(modal => {
        modal.style.display = 'none';
        modal.classList.add('hidden');
    });
    
    // Restaurar el scroll del body
    document.body.style.overflow = '';
    document.body.style.pointerEvents = 'auto';
})();
</script>

<script>
// JavaScript simple y funcional para los modales
document.addEventListener('DOMContentLoaded', function() {
    // Asegurar que todos los modales estén cerrados al cargar
    document.querySelectorAll('.modal').forEach(modal => {
        modal.style.display = 'none';
        modal.classList.add('hidden');
    });
    document.body.style.overflow = '';
    
    // Función para detectar si el sidebar está visible
    function isSidebarVisible() {
        const sidebar = document.querySelector('.sidebar');
        if (!sidebar) return false;
        
        // Verificar si el sidebar tiene la clase que lo oculta
        return !sidebar.classList.contains('sidebar-hidden');
    }
    
    // Función para ajustar el posicionamiento del modal
    function adjustModalPosition(modal) {
        if (isSidebarVisible()) {
            modal.classList.add('modal-with-sidebar');
        } else {
            modal.classList.remove('modal-with-sidebar');
        }
    }
    
    // Función para abrir modal
    window.toggleModal = function(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            // Ajustar posición antes de mostrar
            adjustModalPosition(modal);
            modal.style.display = 'flex';
            modal.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        }
    };
    
    // Función para cerrar modal
    window.closeModal = function(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'none';
            modal.classList.add('hidden');
            document.body.style.overflow = '';
        }
    };
    
    // Cerrar modal al hacer clic en el overlay
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
                this.classList.add('hidden');
                document.body.style.overflow = '';
            }
        });
        
        // Prevenir que el clic dentro del modal lo cierre
        const modalContent = modal.querySelector('.modal-content');
        if (modalContent) {
            modalContent.addEventListener('click', function(e) {
                e.stopPropagation();
            });
        }
    });
    
    // Cerrar modal con la tecla Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal').forEach(modal => {
                if (!modal.classList.contains('hidden')) {
                    modal.style.display = 'none';
                    modal.classList.add('hidden');
                    document.body.style.overflow = '';
                }
            });
        }
    });
    
    // Observar cambios en el sidebar para ajustar modales abiertos
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) {
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                    // Ajustar todos los modales abiertos
                    document.querySelectorAll('.modal:not(.hidden)').forEach(modal => {
                        adjustModalPosition(modal);
                    });
                }
            });
        });
        
        observer.observe(sidebar, {
            attributes: true,
            attributeFilter: ['class']
        });
    }
    
    // También escuchar eventos de redimensionamiento de ventana
    window.addEventListener('resize', function() {
        document.querySelectorAll('.modal:not(.hidden)').forEach(modal => {
            adjustModalPosition(modal);
        });
    });
});
</script>
@endsection 