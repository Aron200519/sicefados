@extends('fabricasoft::layouts.masteradmin')

@section('content')
<div class="container mx-auto px-4 py-6">
    <!-- Header -->
    <div class="mb-8">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-3xl font-bold text-gray-800 mb-2">Detalles de la Solicitud</h1>
                <p class="text-gray-600">Información completa de la solicitud #{{ $request->id }}</p>
            </div>
            <div class="flex space-x-3">
                <a href="{{ route('fabricasoft.admin.proyectos') }}" class="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700 transition-colors">
                    <i class="fas fa-arrow-left mr-2"></i>Volver
                </a>
            </div>
        </div>
    </div>

    <div class="space-y-6">
        <!-- Información básica -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">
                <i class="fas fa-info-circle mr-2 text-blue-500"></i>Información Básica
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">ID de Solicitud</label>
                    <p class="text-sm text-gray-900 font-semibold">{{ $request->id ?? 'No especificado' }}</p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <p class="text-sm text-gray-900">{{ $request->email ?? 'No especificado' }}</p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nombre del Solicitante</label>
                    <p class="text-sm text-gray-900">{{ $request->applicant_name ?? 'No especificado' }}</p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tipo de Documento</label>
                    <p class="text-sm text-gray-900">{{ $request->document_type ?? 'No especificado' }}</p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Número de Documento</label>
                    <p class="text-sm text-gray-900">{{ $request->document_number ?? 'No especificado' }}</p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nombre del Proyecto</label>
                    <p class="text-sm text-gray-900">{{ $request->project_name ?? 'No especificado' }}</p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Empresa</label>
                    <p class="text-sm text-gray-900">{{ $request->company_name ?? 'No especificado' }}</p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Estado</label>
                    <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full 
                        @if(($request->status ?? '') == 'pendiente') bg-yellow-100 text-yellow-800
                        @elseif(($request->status ?? '') == 'aprobada') bg-green-100 text-green-800
                        @elseif(($request->status ?? '') == 'rechazada') bg-red-100 text-red-800
                        @elseif(($request->status ?? '') == 'en_desarrollo') bg-blue-100 text-blue-800
                        @else bg-gray-100 text-gray-800 @endif">
                        {{ ucfirst(str_replace('_', ' ', $request->status ?? 'pendiente')) }}
                    </span>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Fecha de Creación</label>
                    <p class="text-sm text-gray-900">{{ $request->created_at ? \Carbon\Carbon::parse($request->created_at)->format('d/m/Y H:i') : 'No especificado' }}</p>
                </div>
            </div>
        </div>

        <!-- Información adicional si existe -->
        @if($request->phone || $request->applicant_role || $request->department)
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">
                <i class="fas fa-user mr-2 text-green-500"></i>Información Adicional
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                @if($request->phone)
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Teléfono</label>
                    <p class="text-sm text-gray-900">{{ $request->phone }}</p>
                </div>
                @endif
                @if($request->applicant_role)
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Rol/Cargo</label>
                    <p class="text-sm text-gray-900">{{ $request->applicant_role }}</p>
                </div>
                @endif
                @if($request->department)
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Departamento</label>
                    <p class="text-sm text-gray-900">{{ $request->department }}</p>
                </div>
                @endif
            </div>
        </div>
        @endif

        <!-- Información del proyecto -->
        @if($request->general_objective || $request->specific_objectives || $request->system_goals)
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">
                <i class="fas fa-project-diagram mr-2 text-purple-500"></i>Información del Proyecto
            </h3>
            <div class="space-y-4">
                @if($request->general_objective)
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Objetivo General</label>
                    <p class="text-sm text-gray-900 bg-gray-50 p-3 rounded-md">{{ $request->general_objective }}</p>
                </div>
                @endif
                @if($request->specific_objectives)
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Objetivos Específicos</label>
                    <p class="text-sm text-gray-900 bg-gray-50 p-3 rounded-md">{{ $request->specific_objectives }}</p>
                </div>
                @endif
                                 @if($request->system_goals && trim($request->system_goals) !== '' && trim($request->system_goals) !== '[')
                 <div>
                     <label class="block text-sm font-medium text-gray-700 mb-2">Metas del Sistema</label>
                     <p class="text-sm text-gray-900 bg-gray-50 p-3 rounded-md">{{ $request->system_goals }}</p>
                 </div>
                 @else
                 <div>
                     <label class="block text-sm font-medium text-gray-700 mb-2">Metas del Sistema</label>
                     <p class="text-sm text-gray-500 bg-gray-50 p-3 rounded-md italic">No especificado</p>
                 </div>
                 @endif
            </div>
        </div>
        @endif

          <!-- Tareas del Proyecto -->
          <div class="bg-white rounded-lg shadow-md p-6">
              <h3 class="text-lg font-semibold text-gray-800 mb-4">
                  <i class="fas fa-tasks mr-2 text-blue-500"></i>Tareas del Proyecto
                  <span class="ml-2 text-sm font-normal text-gray-500">({{ $tareas->count() }} tareas)</span>
              </h3>
              
              @if($tareas->count() > 0)
                  <div class="space-y-4">
                      @foreach($tareas as $tarea)
                      <div class="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                          <div class="flex items-start justify-between">
                              <div class="flex-1">
                                  <div class="flex items-center mb-2">
                                      <h4 class="text-sm font-semibold text-gray-800 mr-3">{{ $tarea->titulo }}</h4>
                                      <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full
                                          @if($tarea->estado == 'pendiente') bg-yellow-100 text-yellow-800
                                          @elseif($tarea->estado == 'en_progreso') bg-blue-100 text-blue-800
                                          @elseif($tarea->estado == 'completada') bg-green-100 text-green-800
                                          @elseif($tarea->estado == 'cancelada') bg-red-100 text-red-800
                                          @else bg-gray-100 text-gray-800 @endif">
                                          {{ ucfirst(str_replace('_', ' ', $tarea->estado)) }}
                                      </span>
                                      @if($tarea->prioridad)
                                      <span class="ml-2 inline-flex px-2 py-1 text-xs font-semibold rounded-full
                                          @if($tarea->prioridad == 'alta') bg-red-100 text-red-800
                                          @elseif($tarea->prioridad == 'media') bg-yellow-100 text-yellow-800
                                          @else bg-green-100 text-green-800 @endif">
                                          {{ ucfirst($tarea->prioridad) }}
                                      </span>
                                      @endif
                                  </div>
                                  <p class="text-sm text-gray-600 mb-2">{{ $tarea->descripcion }}</p>
                                  <div class="flex items-center text-xs text-gray-500 space-x-4">
                                      @if($tarea->fecha_limite)
                                      <span><i class="fas fa-calendar-alt mr-1"></i>Límite: {{ \Carbon\Carbon::parse($tarea->fecha_limite)->format('d/m/Y') }}</span>
                                      @endif
                                      @if($tarea->tiempo_estimado)
                                      <span><i class="fas fa-clock mr-1"></i>Estimado: {{ $tarea->tiempo_estimado }}h</span>
                                      @endif
                                      <span><i class="fas fa-calendar mr-1"></i>Creada: {{ \Carbon\Carbon::parse($tarea->created_at)->format('d/m/Y H:i') }}</span>
                                  </div>
                              </div>
                          </div>
                      </div>
                      @endforeach
                  </div>
              @else
                  <div class="text-center py-8 text-gray-500">
                      <i class="fas fa-tasks text-4xl mb-4"></i>
                      <p>No hay tareas registradas para este proyecto</p>
                  </div>
              @endif
          </div>

          <!-- Requerimientos del Proyecto -->
          <div class="bg-white rounded-lg shadow-md p-6">
              <h3 class="text-lg font-semibold text-gray-800 mb-4">
                  <i class="fas fa-clipboard-list mr-2 text-purple-500"></i>Requerimientos del Proyecto
                  <span class="ml-2 text-sm font-normal text-gray-500">({{ $requerimientos->count() }} requerimientos)</span>
              </h3>
              
              @if($requerimientos->count() > 0)
                  <div class="space-y-4">
                      @foreach($requerimientos as $requerimiento)
                      <div class="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                          <div class="flex items-start justify-between">
                              <div class="flex-1">
                                  <div class="flex items-center mb-2">
                                      <h4 class="text-sm font-semibold text-gray-800 mr-3">{{ $requerimiento->titulo }}</h4>
                                      <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full
                                          @if($requerimiento->estado == 'pendiente') bg-yellow-100 text-yellow-800
                                          @elseif($requerimiento->estado == 'en_revision') bg-blue-100 text-blue-800
                                          @elseif($requerimiento->estado == 'aprobado') bg-green-100 text-green-800
                                          @elseif($requerimiento->estado == 'rechazado') bg-red-100 text-red-800
                                          @else bg-gray-100 text-gray-800 @endif">
                                          {{ ucfirst(str_replace('_', ' ', $requerimiento->estado)) }}
                                      </span>
                                      @if($requerimiento->tipo)
                                      <span class="ml-2 inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800">
                                          {{ ucfirst($requerimiento->tipo) }}
                                      </span>
                                      @endif
                                      @if($requerimiento->prioridad)
                                      <span class="ml-2 inline-flex px-2 py-1 text-xs font-semibold rounded-full
                                          @if($requerimiento->prioridad == 'alta') bg-red-100 text-red-800
                                          @elseif($requerimiento->prioridad == 'media') bg-yellow-100 text-yellow-800
                                          @else bg-green-100 text-green-800 @endif">
                                          {{ ucfirst($requerimiento->prioridad) }}
                                      </span>
                                      @endif
                                  </div>
                                  <p class="text-sm text-gray-600 mb-2">{{ $requerimiento->descripcion }}</p>
                                  @if($requerimiento->criterios_aceptacion)
                                  <div class="mb-2">
                                      <label class="block text-xs font-medium text-gray-700 mb-1">Criterios de Aceptación:</label>
                                      <p class="text-xs text-gray-600 bg-gray-50 p-2 rounded">{{ $requerimiento->criterios_aceptacion }}</p>
                                  </div>
                                  @endif
                                  <div class="flex items-center text-xs text-gray-500">
                                      <span><i class="fas fa-calendar mr-1"></i>Creado: {{ \Carbon\Carbon::parse($requerimiento->created_at)->format('d/m/Y H:i') }}</span>
                                  </div>
                              </div>
                          </div>
                      </div>
                      @endforeach
                  </div>
              @else
                  <div class="text-center py-8 text-gray-500">
                      <i class="fas fa-clipboard-list text-4xl mb-4"></i>
                      <p>No hay requerimientos registrados para este proyecto</p>
                  </div>
              @endif
          </div>
     </div>
 </div>
@endsection 