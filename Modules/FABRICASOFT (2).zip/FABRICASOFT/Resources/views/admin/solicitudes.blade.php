@extends('fabricasoft::layouts.mastersolicitudes')

@section('content')
<div class="p-4">
    @if(request('email'))
        <div class="bg-blue-50 border border-blue-200 rounded-md p-4 mb-6">
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-info-circle text-blue-400"></i>
                </div>
                <div class="ml-3">
                    <h3 class="text-sm font-medium text-blue-800">Filtro Aplicado</h3>
                    <div class="mt-2 text-sm text-blue-700">
                        <ul class="list-disc list-inside">
                            <li>Email: <strong>{{ request('email') }}</strong></li>
                        </ul>
                    </div>
                    <div class="mt-3">
                        <a href="{{ route('fabricasoft.solicitudes') }}" class="text-sm text-blue-600 hover:text-blue-500">
                            <i class="fas fa-times mr-1"></i>Limpiar filtro
                        </a>
                    </div>
                </div>
            </div>
        </div>
    @endif
    <!-- Filtro de búsqueda por email -->
    <div class="card bg-white mb-6">
        <div class="p-4 border-b">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Filtro de Búsqueda por Email</h3>
            <form method="GET" action="{{ route('fabricasoft.solicitudes') }}" class="flex flex-col md:flex-row gap-4 items-end">
                <div class="flex-1">
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-2">Email del Cliente</label>
                    <input type="email" id="email" name="email" value="{{ request('email') }}" 
                           class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
                           placeholder="Ingrese el email para filtrar...">
                </div>
                <div class="flex space-x-2">
                    <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700 transition-colors">
                        <i class="fas fa-search mr-2"></i>Buscar
                    </button>
                    <a href="{{ route('fabricasoft.solicitudes') }}" class="bg-gray-500 text-white px-6 py-2 rounded-md hover:bg-gray-600 transition-colors text-center">
                        <i class="fas fa-eraser mr-2"></i>Limpiar
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <div class="card bg-white">
        <div class="p-4 flex justify-between items-center border-b">
            <h3 class="text-xl font-semibold text-gray-800">Solicitudes</h3>
            <div class="text-sm text-gray-600">
                Mostrando {{ $allRequests->count() }} solicitudes
                @if(request('email'))
                    <span class="text-blue-600 font-medium">
                        (Filtrado por email)
                    </span>
                @endif
                <!-- Debug info -->
                <div class="text-xs text-gray-500 mt-1">
                    Email filtro: {{ request('email') ?: 'Ninguno' }}
                </div>
            </div>
        </div>
        <div class="p-4">
            <div class="overflow-x-auto">
                <table class="w-full border-collapse min-w-full">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="p-2 sm:p-3 text-left text-xs sm:text-sm font-medium">Nombre del Proyecto</th>
                        <th class="p-2 sm:p-3 text-left text-xs sm:text-sm font-medium">Nombre del Cliente</th>
                        <th class="p-2 sm:p-3 text-left text-xs sm:text-sm font-medium">Email del Cliente</th>
                        <th class="p-2 sm:p-3 text-left text-xs sm:text-sm font-medium">Estado</th>
                        <th class="p-2 sm:p-3 text-left text-xs sm:text-sm font-medium">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($allRequests as $request)
                    <tr class="border-t">
                        <td class="p-2 sm:p-3 text-xs sm:text-sm break-words">
                            @if($request->formulario_id)
                                @php
                                    $formulario = \Modules\FABRICASOFT\Entities\Formulario::find($request->formulario_id);
                                @endphp
                                                                <div class="font-bold text-blue-700 text-lg">
                                    <i class="fas fa-file-alt mr-2 text-xl"></i>
                                    Solicitud vía formulario
                                </div>
                                <div class="text-sm text-gray-600 font-semibold mt-1">
                                    ({{ $formulario->nombre ?? 'Formulario' }})
                                </div>
                            @else
                                {{ $request->project_name ?? 'Sin nombre' }}
                            @endif
                        </td>
                        <td class="p-2 sm:p-3 text-xs sm:text-sm break-words">
                            <div class="font-bold text-gray-800 text-base">
                                {{ $request->applicant_name ?? 'Sin nombre' }}
                            </div>
                            <div class="text-xs text-gray-500 mt-1">
                                <i class="fas fa-id-card mr-1"></i>
                                Tipo: {{ $request->document_type ?? 'N/A' }}
                            </div>
                            <div class="text-xs text-gray-500">
                                <i class="fas fa-hashtag mr-1"></i>
                                Número: {{ $request->document_number ?? 'N/A' }}
                            </div>
                        </td>
                        <td class="p-2 sm:p-3 text-xs sm:text-sm break-words">
                            <div class="font-semibold text-blue-600">
                                <i class="fas fa-envelope mr-1"></i>
                                {{ $request->email ?? 'Sin email' }}
                            </div>
                    </td>
                        <td class="p-2 sm:p-3">
                            @php
                                $statusClass = '';
                                $statusText = '';
                                $statusIcon = '';
                                
                                switch($request->status) {
                                    case 'pendiente':
                                        $statusClass = 'bg-yellow-100 text-yellow-800 border-yellow-200';
                                        $statusText = 'Pendiente';
                                        $statusIcon = '⏳';
                                        break;
                                    case 'aprobada':
                                        $statusClass = 'bg-green-100 text-green-800 border-green-200';
                                        $statusText = 'Aprobada';
                                        $statusIcon = '✅';
                                        break;
                                    case 'rechazado':
                                        $statusClass = 'bg-red-100 text-red-800 border-red-200';
                                        $statusText = 'Rechazada';
                                        $statusIcon = '❌';
                                        break;
                                    default:
                                        $statusClass = 'bg-gray-100 text-gray-800 border-gray-200';
                                        $statusText = ucfirst($request->status ?? 'Pendiente');
                                        $statusIcon = '⏳';
                                }
                            @endphp
                            <span class="px-3 py-1 rounded-full text-xs font-bold border {{ $statusClass }}">
                                {{ $statusIcon }} {{ $statusText }}
                            </span>
                        </td>
                        <td class="p-2 sm:p-3">
                            <div class="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:gap-3">
                                <button class="btn-info toggle-details text-sm font-semibold px-4 py-2 rounded-lg shadow-md hover:shadow-lg transition-all duration-200" data-target="details-{{ $request->id }}">
                                    <i class="fas fa-eye mr-1"></i>Detalles
                                </button>
                                
                                @if($request->status == 'pendiente')
                                    <form action="{{ route('fabricasoft.solicitudes.update_status', $request->id) }}" method="POST" class="inline-block approve-form" id="approve-form-{{ $request->id }}">
                                        @csrf
                                        @method('PUT')
                                        <input type="hidden" name="status" value="aprobada">
                                        <button type="button" class="btn-success text-sm font-semibold px-4 py-2 rounded-lg shadow-md hover:shadow-lg transition-all duration-200" onclick="confirmStatusChange(event, 'approve-form-{{ $request->id }}', 'aprobar')">
                                            <i class="fas fa-check mr-1"></i>Aprobar
                                        </button>
                                    </form>
                                    <form action="{{ route('fabricasoft.solicitudes.update_status', $request->id) }}" method="POST" class="inline-block reject-form" id="reject-form-{{ $request->id }}">
                                        @csrf
                                        @method('PUT')
                                        <input type="hidden" name="status" value="rechazado">
                                        <button type="button" class="btn-danger text-sm font-semibold px-4 py-2 rounded-lg shadow-md hover:shadow-lg transition-all duration-200" onclick="confirmStatusChange(event, 'reject-form-{{ $request->id }}', 'rechazar')">
                                            <i class="fas fa-times mr-1"></i>Rechazar
                                        </button>
                                    </form>
                                @endif
                            </div>
                        </td>
                    </tr>
                    <tr id="details-{{ $request->id }}" class="hidden">
                        <td colspan="5" class="p-0 border-t">
                            <div class="details-row">
                                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                    <!-- Columna Izquierda -->
                                    <div class="space-y-4">
                                        <!-- Información Personal -->
                                        <div class="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500 shadow-sm">
                                            <h5 class="font-bold text-blue-800 mb-3 text-lg">
                                                <i class="fas fa-user mr-2"></i>Información Personal
                                            </h5>
                                            <div class="space-y-3">
                                                <div class="flex justify-between items-center py-2 border-b border-blue-200">
                                                    <span class="font-semibold text-blue-700">Nombre del Cliente:</span>
                                                    <span class="text-blue-600 font-bold">{{ $request->applicant_name ?? 'No especificado' }}</span>
                                                </div>
                                                <div class="flex justify-between items-center py-2 border-b border-blue-200">
                                                    <span class="font-semibold text-blue-700">Email:</span>
                                                    <span class="text-blue-600 font-bold">{{ $request->email ?? 'No especificado' }}</span>
                                                </div>
                                                <div class="flex justify-between items-center py-2 border-b border-blue-200">
                                                    <span class="font-semibold text-blue-700">Teléfono:</span>
                                                    <span class="text-blue-600 font-bold">{{ $request->phone ?? 'No especificado' }}</span>
                                                </div>
                                                <div class="flex justify-between items-center py-2 border-b border-blue-200">
                                                    <span class="font-semibold text-blue-700">Tipo de Documento:</span>
                                                    <span class="text-blue-600 font-bold">{{ $request->document_type ?? 'No especificado' }}</span>
                                                </div>
                                                <div class="flex justify-between items-center py-2 border-b border-blue-200">
                                                    <span class="font-semibold text-blue-700">Número de Documento:</span>
                                                    <span class="text-blue-600 font-bold">{{ $request->document_number ?? 'No especificado' }}</span>
                                                </div>
                                                <div class="flex justify-between items-center py-2">
                                                    <span class="font-semibold text-blue-700">Cargo:</span>
                                                    <span class="text-blue-600 font-bold">{{ $request->applicant_role ?? 'No especificado' }}</span>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Información Empresarial -->
                                        <div class="bg-green-50 p-4 rounded-lg border-l-4 border-green-500 shadow-sm">
                                            <h5 class="font-bold text-green-800 mb-3 text-lg">
                                                <i class="fas fa-building mr-2"></i>Información Empresarial
                                            </h5>
                                            <div class="space-y-3">
                                                <div class="flex justify-between items-center py-2 border-b border-green-200">
                                                    <span class="font-semibold text-green-700">Nombre de la Empresa:</span>
                                                    <span class="text-green-600 font-bold">{{ $request->company_name ?? 'No especificado' }}</span>
                                                </div>
                                                <div class="flex justify-between items-center py-2">
                                                    <span class="font-semibold text-green-700">Departamento:</span>
                                                    <span class="text-green-600 font-bold">{{ $request->department ?? 'No especificado' }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Columna Derecha -->
                                    <div class="space-y-4">
                                        <!-- Información de Ubicación -->
                                        <div class="bg-purple-50 p-4 rounded-lg border-l-4 border-purple-500 shadow-sm">
                                            <h5 class="font-bold text-purple-800 mb-3 text-lg">
                                                <i class="fas fa-map-marker-alt mr-2"></i>Información de Ubicación
                                            </h5>
                                            <div class="space-y-3">
                                                <div class="flex justify-between items-center py-2 border-b border-purple-200">
                                                    <span class="font-semibold text-purple-700">País:</span>
                                                    <span class="text-purple-600 font-bold">{{ $request->country ?? 'No especificado' }}</span>
                                                </div>
                                                <div class="flex justify-between items-center py-2 border-b border-purple-200">
                                                    <span class="font-semibold text-purple-700">Departamento:</span>
                                                    <span class="text-purple-600 font-bold">{{ $request->department_location ?? 'No especificado' }}</span>
                                                </div>
                                                <div class="flex justify-between items-center py-2">
                                                    <span class="font-semibold text-purple-700">Municipio:</span>
                                                    <span class="text-purple-600 font-bold">{{ $request->municipality ?? 'No especificado' }}</span>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Información de la Solicitud -->
                                        <div class="bg-orange-50 p-4 rounded-lg border-l-4 border-orange-500 shadow-sm">
                                            <h5 class="font-bold text-orange-800 mb-3 text-lg">
                                                <i class="fas fa-calendar-alt mr-2"></i>Información de la Solicitud
                                            </h5>
                                            <div class="space-y-3">
                                                <div class="flex justify-between items-center py-2 border-b border-orange-200">
                                                    <span class="font-semibold text-orange-700">Fecha de Solicitud:</span>
                                                    <span class="text-orange-600 font-bold">{{ $request->created_at ? \Carbon\Carbon::parse($request->created_at)->format('d/m/Y H:i:s') : 'No especificado' }}</span>
                                                </div>
                                                <div class="flex justify-between items-center py-2">
                                                    <span class="font-semibold text-orange-700">Estado:</span>
                                                    @php
                                                        $statusClass = '';
                                                        $statusText = '';
                                                        $statusIcon = '';
                                                        
                                                        switch($request->status) {
                                                            case 'pendiente':
                                                                $statusClass = 'bg-yellow-100 text-yellow-800 border-yellow-200';
                                                                $statusText = 'Pendiente';
                                                                $statusIcon = '⏳';
                                                                break;
                                                            case 'aprobada':
                                                                $statusClass = 'bg-green-100 text-green-800 border-green-200';
                                                                $statusText = 'Aprobada';
                                                                $statusIcon = '✅';
                                                                break;
                                                            case 'rechazado':
                                                                $statusClass = 'bg-red-100 text-red-800 border-red-200';
                                                                $statusText = 'Rechazada';
                                                                $statusIcon = '❌';
                                                                break;
                                                            default:
                                                                $statusClass = 'bg-gray-100 text-gray-800 border-gray-200';
                                                                $statusText = ucfirst($request->status ?? 'Pendiente');
                                                                $statusIcon = '⏳';
                                                        }
                                                    @endphp
                                                    <span class="px-3 py-1 rounded-full text-xs font-bold border {{ $statusClass }}">
                                                        {{ $statusIcon }} {{ $statusText }}
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @if($request->formulario_id)
                                    @php
                                        // Obtener el formulario
                                        $formulario = \Modules\FABRICASOFT\Entities\Formulario::find($request->formulario_id);
                                        // Obtener las respuestas del formulario
                                        $respuestas = \Modules\FABRICASOFT\Entities\RespuestaFormulario::where('servicio_id', $request->id)->get();
                                    @endphp
                                    <div class="mt-8">
                                        <div class="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 shadow-lg">
                                            <h4 class="font-bold text-white text-xl mb-4 flex items-center">
                                                <i class="fas fa-file-alt mr-3 text-2xl"></i>
                                                Respuestas del Formulario: {{ $formulario->nombre ?? 'Formulario' }}
                                            </h4>
                                        </div>
                                        
                                        @if($formulario && $formulario->preguntas)
                                            <div class="bg-white rounded-lg shadow-md border border-gray-200 mt-4">
                                                <div class="p-6">
                                                    <div class="grid gap-4">
                                            @forelse($respuestas as $respuesta)
                                                            @php
                                                                // Buscar la pregunta correspondiente en el formulario
                                                                $pregunta = null;
                                                                if ($formulario->preguntas && is_array($formulario->preguntas)) {
                                                                    foreach ($formulario->preguntas as $index => $preg) {
                                                                        if ($index == $respuesta->pregunta_id) {
                                                                            $pregunta = $preg;
                                                                            break;
                                                                        }
                                                                    }
                                                                }
                                                            @endphp
                                                            <div class="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-5 border-l-4 border-blue-500 shadow-sm hover:shadow-md transition-all duration-300">
                                                                <div class="flex items-start space-x-4">
                                                                    <div class="flex-shrink-0">
                                                                        <div class="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                                                                            <i class="fas fa-question text-white text-sm"></i>
                                                                        </div>
                                                                    </div>
                                                                    <div class="flex-1 min-w-0">
                                                                        <div class="font-bold text-gray-800 text-lg mb-2">
                                                                            {{ $pregunta['texto'] ?? 'Pregunta ' . ($respuesta->pregunta_id + 1) }}
                                                                        </div>
                                                                        <div class="bg-white rounded-lg p-4 border border-blue-200 shadow-sm">
                                                                            <div class="flex items-center">
                                                                                <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mr-3">
                                                                                    <i class="fas fa-arrow-right text-white text-xs"></i>
                                                                                </div>
                                                                                <span class="font-bold text-blue-700 text-lg">
                                                                                    {{ $respuesta->respuesta }}
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                            @empty
                                                            <div class="text-center py-8">
                                                                <div class="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                                                    <i class="fas fa-exclamation-triangle text-yellow-500 text-2xl"></i>
                                                                </div>
                                                                <h5 class="text-lg font-semibold text-gray-700 mb-2">No hay respuestas registradas</h5>
                                                                <p class="text-gray-500">Este formulario aún no tiene respuestas del usuario.</p>
                                                            </div>
                                            @endforelse
                                                    </div>
                                                </div>
                                            </div>
                                        @else
                                            <div class="bg-white rounded-lg shadow-md border border-gray-200 mt-4">
                                                <div class="text-center py-8">
                                                    <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                                        <i class="fas fa-exclamation-triangle text-red-500 text-2xl"></i>
                                                    </div>
                                                    <h5 class="text-lg font-semibold text-gray-700 mb-2">Información del formulario no disponible</h5>
                                                    <p class="text-gray-500">No se pudo cargar la información del formulario asociado.</p>
                                                </div>
                                            </div>
                                        @endif
                                    </div>
                                @endif
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
@endsection
