@extends('fabricasoft::layouts.masteradmin')

@section('content')
<!-- Incluir librerías necesarias -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
.container-fluid {
    padding: 2rem;
    background: #f8f9fa;
    min-height: 100vh;
}

.header-section {
    background: white;
    border-radius: 12px;
    padding: 2rem;
    margin-bottom: 2rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    text-align: center;
}

.seguimiento-overview {
    background: white;
    border-radius: 16px;
    padding: 2rem;
    margin-bottom: 2rem;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    border: 1px solid #f0f0f0;
}

.overview-header {
    text-align: center;
    margin-bottom: 2rem;
    padding-bottom: 1rem;
    border-bottom: 2px solid #f8f9fa;
}

.overview-title {
    color: #2c3e50;
    font-weight: 700;
    font-size: 1.5rem;
    margin: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.75rem;
}

.overview-title i {
    color: #3498db;
    font-size: 1.3rem;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.stat-card {
    background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    border: 1px solid #e2e8f0;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.12);
}

.stat-card.pendiente {
    border-left: 4px solid #f39c12;
}

.stat-card.en-desarrollo {
    border-left: 4px solid #3498db;
}

.stat-card.revision {
    border-left: 4px solid #9b59b6;
}

.stat-card.testing {
    border-left: 4px solid #e67e22;
}

.stat-card.aprobada {
    border-left: 4px solid #27ae60;
}

.stat-card.completado {
    border-left: 4px solid #2ecc71;
}

.stat-number {
    font-size: 2.5rem;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 0.5rem;
}

.stat-label {
    color: #7f8c8d;
    font-weight: 500;
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.projects-section {
    background: white;
    border-radius: 16px;
    padding: 2rem;
    margin-bottom: 2rem;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    border: 1px solid #f0f0f0;
}

.section-title {
    color: #2c3e50;
    font-weight: 600;
    font-size: 1.25rem;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.project-card {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 1rem;
    margin-bottom: 1rem;
    border-left: 4px solid #3498db;
    transition: all 0.3s ease;
}

.project-card:hover {
    background: #e3f2fd;
    transform: translateX(4px);
}

.project-header {
    display: flex;
    justify-content: between;
    align-items: center;
    margin-bottom: 0.5rem;
}

.project-title {
    font-weight: 600;
    color: #2c3e50;
    margin: 0;
}

.project-status {
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 500;
    text-transform: uppercase;
}

.status-pendiente {
    background: #fff3cd;
    color: #856404;
}

.status-en-desarrollo {
    background: #d1ecf1;
    color: #0c5460;
}

.status-revision {
    background: #e2d9f3;
    color: #6f42c1;
}

.status-testing {
    background: #fde2d1;
    color: #d63384;
}

.status-aprobada {
    background: #d1f2eb;
    color: #0f5132;
}

.status-completado {
    background: #d4edda;
    color: #155724;
}

.project-info {
    display: flex;
    gap: 1rem;
    font-size: 0.85rem;
    color: #6c757d;
}

.progress-bar {
    width: 100%;
    height: 8px;
    background: #e9ecef;
    border-radius: 4px;
    overflow: hidden;
    margin-top: 0.5rem;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #3498db, #2ecc71);
    border-radius: 4px;
    transition: width 0.3s ease;
}

.empty-state {
    text-align: center;
    padding: 3rem;
    color: #6c757d;
}

.empty-state i {
    font-size: 3rem;
    margin-bottom: 1rem;
    opacity: 0.5;
}

@media (max-width: 768px) {
    .container-fluid {
        padding: 1rem;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
    
    .stat-number {
        font-size: 2rem;
    }
    
    .project-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 0.5rem;
    }
    
    .project-info {
        flex-direction: column;
        gap: 0.25rem;
    }
}
</style>

<div class="container-fluid">
    <!-- Header Section -->
    <div class="header-section">
        <h1 class="text-4xl font-bold text-gray-800 mb-3">Seguimiento de Proyectos FABRICASOFT</h1>
        <p class="text-gray-600 text-lg">Monitoreo y seguimiento detallado del estado de todos los proyectos</p>
    </div>

    <!-- Overview Section -->
    <div class="seguimiento-overview">
        <div class="overview-header">
            <h2 class="overview-title">
                <i class="fas fa-tasks"></i>
                Resumen de Seguimiento
            </h2>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card pendiente">
                <div class="stat-number">{{ $totalProyectos }}</div>
                <div class="stat-label">Total de Proyectos</div>
            </div>
            <div class="stat-card pendiente">
                <div class="stat-number">{{ $proyectosPendientes }}</div>
                <div class="stat-label">Pendientes</div>
            </div>
            <div class="stat-card en-desarrollo">
                <div class="stat-number">{{ $proyectosEnDesarrollo }}</div>
                <div class="stat-label">En Desarrollo</div>
            </div>
            <div class="stat-card revision">
                <div class="stat-number">{{ $proyectosPorEstado['revision']->count() }}</div>
                <div class="stat-label">En Revisión</div>
            </div>
            <div class="stat-card testing">
                <div class="stat-number">{{ $proyectosPorEstado['testing']->count() }}</div>
                <div class="stat-label">En Testing</div>
            </div>
            <div class="stat-card aprobada">
                <div class="stat-number">{{ $proyectosAprobados }}</div>
                <div class="stat-label">Aprobados</div>
            </div>
            <div class="stat-card completado">
                <div class="stat-number">{{ $proyectosCompletados }}</div>
                <div class="stat-label">Completados</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{{ number_format($progresoPromedio, 1) }}%</div>
                <div class="stat-label">Progreso Promedio</div>
            </div>
        </div>
    </div>

    <!-- Projects by Status Sections -->
    <div class="projects-section">
        <h2 class="section-title">
            <i class="fas fa-list"></i>
            Proyectos por Estado
        </h2>

        <!-- Pendientes -->
        <div class="mb-6">
            <h3 class="text-lg font-semibold text-gray-700 mb-3 flex items-center gap-2">
                <i class="fas fa-clock text-yellow-500"></i>
                Pendientes ({{ $proyectosPendientes }})
            </h3>
            @if($proyectosPorEstado['pendiente']->count() > 0)
                @foreach($proyectosPorEstado['pendiente'] as $proyecto)
                    <div class="project-card">
                        <div class="project-header">
                            <h4 class="project-title">{{ $proyecto->title }}</h4>
                            <span class="project-status status-pendiente">Pendiente</span>
                        </div>
                        <div class="project-info">
                            <span><i class="fas fa-user"></i> {{ $proyecto->assignedUser ? $proyecto->assignedUser->name : 'Sin asignar' }}</span>
                            <span><i class="fas fa-calendar"></i> {{ $proyecto->created_at->format('d/m/Y') }}</span>
                            <span><i class="fas fa-envelope"></i> {{ $proyecto->email }}</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: {{ $progresos[$proyecto->id] ?? 0 }}%"></div>
                        </div>
                    </div>
                @endforeach
            @else
                <div class="empty-state">
                    <i class="fas fa-check-circle"></i>
                    <p>No hay proyectos pendientes</p>
                </div>
            @endif
        </div>

        <!-- En Desarrollo -->
        <div class="mb-6">
            <h3 class="text-lg font-semibold text-gray-700 mb-3 flex items-center gap-2">
                <i class="fas fa-code text-blue-500"></i>
                En Desarrollo ({{ $proyectosEnDesarrollo }})
            </h3>
            @if($proyectosPorEstado['en_desarrollo']->count() > 0)
                @foreach($proyectosPorEstado['en_desarrollo'] as $proyecto)
                    <div class="project-card">
                        <div class="project-header">
                            <h4 class="project-title">{{ $proyecto->title }}</h4>
                            <span class="project-status status-en-desarrollo">En Desarrollo</span>
                        </div>
                        <div class="project-info">
                            <span><i class="fas fa-user"></i> {{ $proyecto->assignedUser ? $proyecto->assignedUser->name : 'Sin asignar' }}</span>
                            <span><i class="fas fa-calendar"></i> {{ $proyecto->created_at->format('d/m/Y') }}</span>
                            <span><i class="fas fa-envelope"></i> {{ $proyecto->email }}</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: {{ $progresos[$proyecto->id] ?? 0 }}%"></div>
                        </div>
                    </div>
                @endforeach
            @else
                <div class="empty-state">
                    <i class="fas fa-code"></i>
                    <p>No hay proyectos en desarrollo</p>
                </div>
            @endif
        </div>

        <!-- En Revisión -->
        <div class="mb-6">
            <h3 class="text-lg font-semibold text-gray-700 mb-3 flex items-center gap-2">
                <i class="fas fa-search text-purple-500"></i>
                En Revisión ({{ $proyectosPorEstado['revision']->count() }})
            </h3>
            @if($proyectosPorEstado['revision']->count() > 0)
                @foreach($proyectosPorEstado['revision'] as $proyecto)
                    <div class="project-card">
                        <div class="project-header">
                            <h4 class="project-title">{{ $proyecto->title }}</h4>
                            <span class="project-status status-revision">En Revisión</span>
                        </div>
                        <div class="project-info">
                            <span><i class="fas fa-user"></i> {{ $proyecto->assignedUser ? $proyecto->assignedUser->name : 'Sin asignar' }}</span>
                            <span><i class="fas fa-calendar"></i> {{ $proyecto->created_at->format('d/m/Y') }}</span>
                            <span><i class="fas fa-envelope"></i> {{ $proyecto->email }}</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: {{ $progresos[$proyecto->id] ?? 0 }}%"></div>
                        </div>
                    </div>
                @endforeach
            @else
                <div class="empty-state">
                    <i class="fas fa-search"></i>
                    <p>No hay proyectos en revisión</p>
                </div>
            @endif
        </div>

        <!-- En Testing -->
        <div class="mb-6">
            <h3 class="text-lg font-semibold text-gray-700 mb-3 flex items-center gap-2">
                <i class="fas fa-vial text-orange-500"></i>
                En Testing ({{ $proyectosPorEstado['testing']->count() }})
            </h3>
            @if($proyectosPorEstado['testing']->count() > 0)
                @foreach($proyectosPorEstado['testing'] as $proyecto)
                    <div class="project-card">
                        <div class="project-header">
                            <h4 class="project-title">{{ $proyecto->title }}</h4>
                            <span class="project-status status-testing">En Testing</span>
                        </div>
                        <div class="project-info">
                            <span><i class="fas fa-user"></i> {{ $proyecto->assignedUser ? $proyecto->assignedUser->name : 'Sin asignar' }}</span>
                            <span><i class="fas fa-calendar"></i> {{ $proyecto->created_at->format('d/m/Y') }}</span>
                            <span><i class="fas fa-envelope"></i> {{ $proyecto->email }}</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: {{ $progresos[$proyecto->id] ?? 0 }}%"></div>
                        </div>
                    </div>
                @endforeach
            @else
                <div class="empty-state">
                    <i class="fas fa-vial"></i>
                    <p>No hay proyectos en testing</p>
                </div>
            @endif
        </div>

        <!-- Aprobados -->
        <div class="mb-6">
            <h3 class="text-lg font-semibold text-gray-700 mb-3 flex items-center gap-2">
                <i class="fas fa-thumbs-up text-green-500"></i>
                Aprobados ({{ $proyectosAprobados }})
            </h3>
            @if($proyectosPorEstado['aprobada']->count() > 0)
                @foreach($proyectosPorEstado['aprobada'] as $proyecto)
                    <div class="project-card">
                        <div class="project-header">
                            <h4 class="project-title">{{ $proyecto->title }}</h4>
                            <span class="project-status status-aprobada">Aprobado</span>
                        </div>
                        <div class="project-info">
                            <span><i class="fas fa-user"></i> {{ $proyecto->assignedUser ? $proyecto->assignedUser->name : 'Sin asignar' }}</span>
                            <span><i class="fas fa-calendar"></i> {{ $proyecto->created_at->format('d/m/Y') }}</span>
                            <span><i class="fas fa-envelope"></i> {{ $proyecto->email }}</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: {{ $progresos[$proyecto->id] ?? 0 }}%"></div>
                        </div>
                    </div>
                @endforeach
            @else
                <div class="empty-state">
                    <i class="fas fa-thumbs-up"></i>
                    <p>No hay proyectos aprobados</p>
                </div>
            @endif
        </div>

        <!-- Completados -->
        <div class="mb-6">
            <h3 class="text-lg font-semibold text-gray-700 mb-3 flex items-center gap-2">
                <i class="fas fa-check-circle text-green-600"></i>
                Completados ({{ $proyectosCompletados }})
            </h3>
            @if($proyectosPorEstado['completado']->count() > 0)
                @foreach($proyectosPorEstado['completado'] as $proyecto)
                    <div class="project-card">
                        <div class="project-header">
                            <h4 class="project-title">{{ $proyecto->title }}</h4>
                            <span class="project-status status-completado">Completado</span>
                        </div>
                        <div class="project-info">
                            <span><i class="fas fa-user"></i> {{ $proyecto->assignedUser ? $proyecto->assignedUser->name : 'Sin asignar' }}</span>
                            <span><i class="fas fa-calendar"></i> {{ $proyecto->created_at->format('d/m/Y') }}</span>
                            <span><i class="fas fa-envelope"></i> {{ $proyecto->email }}</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: 100%"></div>
                        </div>
                    </div>
                @endforeach
            @else
                <div class="empty-state">
                    <i class="fas fa-check-circle"></i>
                    <p>No hay proyectos completados</p>
                </div>
            @endif
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Animación de entrada para las tarjetas de estadísticas
    const statCards = document.querySelectorAll('.stat-card');
    statCards.forEach((card, index) => {
        setTimeout(() => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            
            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, 100);
        }, index * 100);
    });

    // Animación de entrada para las tarjetas de proyectos
    const projectCards = document.querySelectorAll('.project-card');
    projectCards.forEach((card, index) => {
        setTimeout(() => {
            card.style.opacity = '0';
            card.style.transform = 'translateX(-20px)';
            card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            
            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'translateX(0)';
            }, 100);
        }, index * 50);
    });
});
</script>
@endsection
