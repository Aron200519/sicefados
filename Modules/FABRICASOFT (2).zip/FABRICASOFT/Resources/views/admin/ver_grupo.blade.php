@extends('fabricasoft::layouts.masteradmin')

@section('content')
<div class="p-4 border-b bg-white">
    <div class="flex justify-between items-center">
        <h1 class="text-2xl font-semibold text-gray-800">Detalles del Grupo: {{ $grupo->nombre }}</h1>
        <a href="{{ route('fabricasoft.desarrolladores') }}" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg">
            <i class="fas fa-arrow-left mr-2"></i>Volver
        </a>
    </div>
</div>

<div class="p-6">
    <!-- Información del Grupo -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <!-- Información del Líder -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-green-700 mb-4">
                <i class="fas fa-user-tie mr-2"></i>Líder del Grupo
            </h3>
            <div class="space-y-3">
                <div class="flex items-center">
                    <i class="fas fa-user text-green-500 mr-3 w-5"></i>
                    <div>
                        <p class="font-semibold text-gray-800">{{ $grupo->lider_nombre }}</p>
                        <p class="text-sm text-gray-600">{{ $grupo->lider_email }}</p>
                    </div>
                </div>
                <div class="flex items-center">
                    <i class="fas fa-calendar text-blue-500 mr-3 w-5"></i>
                    <p class="text-sm text-gray-600">Creado: {{ \Carbon\Carbon::parse($grupo->created_at)->format('d/m/Y H:i') }}</p>
                </div>
            </div>
        </div>

        <!-- Información del Proyecto -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-blue-700 mb-4">
                <i class="fas fa-project-diagram mr-2"></i>Proyecto Asignado
            </h3>
            <div class="space-y-3">
                <div class="flex items-center">
                    <i class="fas fa-folder text-blue-500 mr-3 w-5"></i>
                    <div>
                        <p class="font-semibold text-gray-800">{{ $grupo->project_name }}</p>
                        <p class="text-sm text-gray-600">Cliente: {{ $grupo->applicant_name }}</p>
                        <p class="text-sm text-gray-600">Tipo de Documento: {{ $grupo->document_type ?? 'No especificado' }}</p>
                        <p class="text-sm text-gray-600">Número de Documento: {{ $grupo->document_number ?? 'No especificado' }}</p>
                    </div>
                </div>
                <div class="flex items-center">
                                            <i class="fas fa-building text-white mr-3 w-5"></i>
                    <p class="text-sm text-gray-600">{{ $grupo->company_name }}</p>
                </div>
            </div>
        </div>
    </div>

    <!-- URLs de Trello y GitHub -->
    <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
        <h3 class="text-xl font-bold text-gray-800 mb-4">
            <i class="fas fa-link mr-2"></i>Enlaces del Proyecto
        </h3>
        <form action="{{ route('fabricasoft.grupos.update', $grupo->id) }}" method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-6">
            @csrf
            @method('PUT')
            <input type="hidden" name="nombre_grupo" value="{{ $grupo->nombre }}">
            <input type="hidden" name="proyecto_id" value="{{ $grupo->proyecto_id }}">
            <input type="hidden" name="lider_id" value="{{ $grupo->lider_id }}">
            
            <div>
                <label for="trello_url" class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fab fa-trello text-blue-500 mr-2"></i>URL de Trello
                </label>
                <input type="url" name="trello_url" id="trello_url" 
                       value="{{ $grupo->trello_url }}" 
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                       placeholder="https://trello.com/b/...">
            </div>
            
            <div>
                <label for="github_url" class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fab fa-github text-gray-800 mr-2"></i>URL de GitHub
                </label>
                <input type="url" name="github_url" id="github_url" 
                       value="{{ $grupo->github_url }}" 
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                       placeholder="https://github.com/...">
            </div>
            
            <div class="md:col-span-2">
                <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg font-semibold">
                    <i class="fas fa-save mr-2"></i>Guardar Enlaces
                </button>
            </div>
        </form>
    </div>

    <!-- Información del Cliente -->
    <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
        <h3 class="text-xl font-bold text-gray-800 mb-4">
            <i class="fas fa-user mr-2"></i>Información del Cliente
        </h3>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div>
                <p class="text-sm font-medium text-gray-500">Nombre del Cliente</p>
                                        <p class="text-lg font-semibold text-gray-800">{{ $grupo->applicant_name }}</p>
                        <p class="text-sm text-gray-600">Tipo de Documento: {{ $grupo->document_type ?? 'No especificado' }}</p>
                        <p class="text-sm text-gray-600">Número de Documento: {{ $grupo->document_number ?? 'No especificado' }}</p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">Rol</p>
                <p class="text-lg font-semibold text-gray-800">{{ $grupo->applicant_role }}</p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">Empresa</p>
                <p class="text-lg font-semibold text-gray-800">{{ $grupo->company_name }}</p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">Departamento</p>
                <p class="text-lg font-semibold text-gray-800">{{ $grupo->department }}</p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">Email</p>
                <p class="text-lg font-semibold text-gray-800">{{ $grupo->email }}</p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">Teléfono</p>
                <p class="text-lg font-semibold text-gray-800">{{ $grupo->phone }}</p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">País</p>
                <p class="text-lg font-semibold text-gray-800">{{ $grupo->country }}</p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">Ubicación</p>
                <p class="text-lg font-semibold text-gray-800">{{ $grupo->department_location }}</p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">Municipio</p>
                <p class="text-lg font-semibold text-gray-800">{{ $grupo->municipality }}</p>
            </div>
        </div>
    </div>

    <!-- Detalles del Proyecto -->
    <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
        <h3 class="text-xl font-bold text-gray-800 mb-4">
            <i class="fas fa-info-circle mr-2"></i>Detalles del Proyecto
        </h3>
        <div class="space-y-4">
            <div>
                <p class="text-sm font-medium text-gray-500">Nombre del Proyecto</p>
                <p class="text-lg font-semibold text-gray-800">{{ $grupo->project_name }}</p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">Propósito del Sistema</p>
                <p class="text-gray-800">{{ $grupo->system_purpose }}</p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">Objetivo General</p>
                <p class="text-gray-800">{{ $grupo->general_objective }}</p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">Objetivos Específicos</p>
                <p class="text-gray-800">{{ $grupo->specific_objectives }}</p>
            </div>
        </div>
    </div>

    <!-- Formulario Llenado (si existe y tiene respuestas) -->
    @if($grupo->formulario_id && $grupo->formulario_nombre && $respuestas && $respuestas->count() > 0)
    <div class="bg-white rounded-xl shadow-lg p-6">
        <h3 class="text-xl font-bold text-gray-800 mb-4">
            <i class="fas fa-clipboard-list mr-2"></i>Formulario: {{ $grupo->formulario_nombre }}
        </h3>
        <div class="space-y-4">
            @foreach($respuestas as $respuesta)
                <div class="border-b border-gray-200 pb-4">
                    <p class="font-semibold text-gray-800 mb-2">{{ $respuesta->pregunta }}</p>
                    <p class="text-gray-600">{{ $respuesta->respuesta ?: 'Sin respuesta' }}</p>
                </div>
            @endforeach
        </div>
    </div>
    @endif
</div>
@endsection 