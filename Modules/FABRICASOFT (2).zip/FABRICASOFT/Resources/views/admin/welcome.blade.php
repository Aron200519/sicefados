@extends('fabricasoft::layouts.masteradmin')

@section('content')
<div class="p-4 border-b bg-white">   <h1 class="text-2xl font-semibold text-gray-800">Gestión de usuarios</h1>
</div>
<div class="p-4">
    <div class="card bg-white">
        <div class="p-4 flex justify-between items-center border-b">
            <h3 class="text-xl font-semibold text-gray-800">Usuarios</h3>
            <button class="btn-success text-white px-4 rounded-lg" onclick="toggleModal('createUserModal')">Crear Usuario</button>
        </div>
        <div class="p-4">
            @if(session('success'))
                <div class="bg-green-100 text-green-700 p-4 rounded-lg mb-4" id="alert-success">{{ session('success') }}</div>
            @endif
            @if(session('error'))
                <div class="bg-red-100 text-red-700 p-4 rounded-lg mb-4" id="alert-error">{{ session('error') }}</div>
            @endif
            @if($errors->any())
                <div class="bg-red-100 text-red-700 p-4 rounded-lg mb-4">
                    <ul>
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            @isset($users)
            @php
                $protegidos = [145822,145823];
                $nicknames_protegidos = [];
                foreach($users as $u) {
                    if(in_array($u->person_id, $protegidos)) $nicknames_protegidos[] = $u->nickname;
                }
            @endphp
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="p-3 text-left">ID</th>
                        <th class="p-3 text-left">Nickname</th>
                        <th class="p-3 text-left">Person ID</th>
                        <th class="p-3 text-left">Email</th>
                        <th class="p-3 text-left">Rol</th>
                        <th class="p-3 text-left">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($users as $user)
                    <tr class="border-t">
                        <td class="p-3">{{ $user->id }}</td>
                        <td class="p-3">
                            @if(in_array($user->person_id, $protegidos))
                                <span title="Usuario protegido, no editable">⚠️</span>
                            @endif
                            {{ $user->nickname }}
                        </td>
                        <td class="p-3">{{ $user->person_id }}</td>
                        <td class="p-3">{{ $user->email }}</td>
                        <td class="p-3">
                            @if($user->roles->count() > 0)
                                @foreach($user->roles as $role)
                                    @switch($role->slug)
                                        @case('fabricasoft.admin')
                                            <span class="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">Administrador</span>
                                            @break
                                        @case('fabricasoft.apprentice')
                                            <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">Desarrollador</span>
                                            @break
                                        @case('fabricasoft.users')
                                            <span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Cliente</span>
                                            @break
                                        @default
                                            <span class="bg-gray-100 text-gray-800 px-2 py-1 rounded-full text-xs">{{ $role->name }}</span>
                                    @endswitch
                                @endforeach
                            @else
                                <span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">Sin rol</span>
                            @endif
                        </td>
                        <td class="p-3 flex space-x-2">
                            @if(in_array($user->person_id, $protegidos))
                                <button class="bg-gray-300 text-gray-600 px-3 rounded-lg cursor-not-allowed" disabled title="Usuario protegido, no editable">Editar</button>
                                <button class="bg-gray-300 text-gray-600 px-3 rounded-lg cursor-not-allowed" disabled title="Usuario protegido, no eliminable">Eliminar</button>
                            @else
                                <button class="btn-success text-white px-3 rounded-lg" onclick="toggleModal('editUserModal{{ $user->id }}')">Editar</button>
                                <form action="/fabricasoft/admin/users/destroy/{{ $user->id }}" method="POST" class="inline-block">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="bg-red-500 text-white px-3 rounded-lg" onclick="return confirm('¿Seguro que deseas eliminar este usuario?')">Eliminar</button>
                                </form>
                            @endif
                        </td>
                    </tr>
                    <!-- Modal Editar Usuario -->
                    <div class="modal fade fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden p-2 sm:p-4" id="editUserModal{{ $user->id }}" tabindex="-1" role="dialog" aria-labelledby="editUserModalLabel{{ $user->id }}">
                        <div class="modal-content bg-white w-full max-w-md p-4 md:p-6 rounded-lg max-h-[90vh] overflow-y-auto">
                            <div class="flex justify-between items-center mb-3 md:mb-4">
                                <h5 class="text-lg md:text-xl font-semibold break-words" id="editUserModalLabel{{ $user->id }}">Editar Usuario</h5>
                                <button type="button" class="text-gray-500 text-xl md:text-2xl hover:text-gray-700 p-1" onclick="toggleModal('editUserModal{{ $user->id }}')">×</button>
                            </div>
                            <form action="/fabricasoft/admin/users/update/{{ $user->id }}" method="POST">
                                @csrf
                                @method('PUT')
                                <div class="space-y-3 md:space-y-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700">ID</label>
                                        <input type="text" class="w-full border rounded-lg p-2 bg-gray-100" value="{{ $user->id }}" readonly>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700">Nickname</label>
                                        <input type="text" name="nickname" class="w-full border rounded-lg p-2" value="{{ $user->nickname }}" required>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700">Email</label>
                                        <input type="email" name="email" class="w-full border rounded-lg p-2" value="{{ $user->email }}" required>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700">Password (dejar vacío para no cambiar)</label>
                                        <input type="password" name="password" class="w-full border rounded-lg p-2">
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700">Person ID</label>
                                        <input type="text" class="w-full border rounded-lg p-2 bg-gray-100" value="{{ $user->person_id }}" readonly>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700">Rol</label>
                                        <select name="role_id" class="w-full border rounded-lg p-2" required>
                                            <option value="">Seleccione un rol</option>
                                            @foreach(\Modules\SICA\Entities\Role::where('slug','like', 'fabricasoft.%')->get() as $role)
                                                <option value="{{ $role->id }}" {{ $user->roles->first() && $user->roles->first()->id == $role->id ? 'selected' : '' }}>
                                                    {{ $role->name }} - {{ $role->description }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="mt-4 md:mt-6 flex flex-col sm:flex-row justify-end gap-2 sm:space-x-2">
                                    <button type="button" class="bg-gray-300 text-gray-700 px-3 md:px-4 py-2 rounded-lg text-sm md:text-base" onclick="toggleModal('editUserModal{{ $user->id }}')">Cancelar</button>
                                    <button type="submit" class="btn-success text-white px-3 md:px-4 py-2 rounded-lg text-sm md:text-base">Actualizar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    @endforeach
                </tbody>
            </table>
            @endisset
        </div>
    </div>
    <!-- Modal Crear Usuario -->
    <div class="modal fade fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden p-2 sm:p-4" id="createUserModal" tabindex="-1" role="dialog" aria-labelledby="createUserModalLabel">
        <div class="modal-content bg-white w-full max-w-md p-4 md:p-6 rounded-lg max-h-[90vh] overflow-y-auto">
            <div class="flex justify-between items-center mb-3 md:mb-4">
                <h5 class="text-lg md:text-xl font-semibold break-words" id="createUserModalLabel">Crear Usuario</h5>
                <button type="button" class="text-gray-500 text-xl md:text-2xl hover:text-gray-700 p-1" onclick="toggleModal('createUserModal')">×</button>
            </div>
            <form action="/fabricasoft/admin/users/store" method="POST">
                @csrf
                <div class="space-y-3 md:space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Nickname</label>
                        <input type="text" name="nickname" class="w-full border rounded-lg p-2" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Email</label>
                        <input type="email" name="email" class="w-full border rounded-lg p-2" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Password</label>
                        <input type="password" name="password" class="w-full border rounded-lg p-2" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Person ID</label>
                        <input type="number" name="person_id" class="w-full border rounded-lg p-2 bg-gray-100 text-green-700 font-semibold" id="person_id_random" placeholder="Person ID generado" readonly required>
                        <button type="button" class="btn-success text-white px-4 py-2 rounded-lg mt-2" onclick="generarPersonId()">Generar</button>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Rol</label>
                        <select name="role_id" class="w-full border rounded-lg p-2" required>
                            <option value="">Seleccione un rol</option>
                            @foreach(\Modules\SICA\Entities\Role::where('slug','like', 'fabricasoft.%')->get() as $role)
                                @if($role->slug !== 'fabricasoft.users')
                                    <option value="{{ $role->id }}">{{ $role->name }} - {{ $role->description }}</option>
                                @endif
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="mt-4 md:mt-6 flex flex-col sm:flex-row justify-end gap-2 sm:space-x-2">
                    <button type="button" class="bg-gray-300 text-gray-700 px-3 md:px-4 py-2 rounded-lg text-sm md:text-base" onclick="toggleModal('createUserModal')">Cancelar</button>
                    <button type="submit" class="btn-success text-white px-3 md:px-4 py-2 rounded-lg text-sm md:text-base">Crear</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Generate Random Person ID
function generarPersonId() {
    @isset($users)
    const usados = [@foreach($users as $user){{ $user->person_id }},@endforeach 145822,145823];
    let randomId;
    do {
        randomId = Math.floor(Math.random() * 90000000);
    } while (usados.includes(randomId));
    document.getElementById('person_id_random').value = randomId;
    @endisset
}

// Validate Protected Nickname
@isset($nicknames_protegidos)
document.querySelector('#createUserModal form').addEventListener('submit', function(e) {
    const nickname = this.nickname.value.trim();
    const protegidos = @json($nicknames_protegidos);
    if (protegidos.includes(nickname)) {
        e.preventDefault();
        alert('Este nickname está protegido y no puede ser usado.');
    }
});
@endisset
</script>
@endsection 