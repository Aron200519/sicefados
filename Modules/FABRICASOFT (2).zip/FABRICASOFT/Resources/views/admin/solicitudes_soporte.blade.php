@extends('fabricasoft::layouts.masteradmin')

@section('content')
<!-- Alertas de sesión -->
@if(session('success'))
    <div class="fixed top-20 right-4 z-50 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg shadow-lg transition-all duration-300 transform translate-x-0" id="alert-success">
        <div class="flex items-center">
            <i class="fas fa-check-circle mr-2"></i>
            <span class="font-semibold">{{ session('success') }}</span>
            <button onclick="closeAlert('alert-success')" class="ml-4 text-green-500 hover:text-green-700">
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>
@endif

@if(session('error'))
    <div class="fixed top-20 right-4 z-50 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg shadow-lg transition-all duration-300 transform translate-x-0" id="alert-error">
        <div class="flex items-center">
            <i class="fas fa-exclamation-circle mr-2"></i>
            <span class="font-semibold">{{ session('error') }}</span>
            <button onclick="closeAlert('alert-error')" class="ml-4 text-red-500 hover:text-red-700">
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>
@endif

<div class="p-4 border-b bg-white rounded-t-2xl shadow-md">
    <h1 class="text-3xl font-bold text-gray-800 tracking-tight">Creación de Servicios</h1>
</div>
<div class="p-4">
    <div class="card bg-white rounded-2xl shadow-lg border border-gray-100 transition-shadow hover:shadow-2xl">
        <div class="p-4 flex justify-between items-center border-b border-gray-100">
            <h3 class="text-2xl font-bold text-gray-800">Formularios Personalizados</h3>
            <!-- Botón para abrir el modal -->
            <a href="#" id="abrir-modal-formulario" class="bg-green-500 hover:bg-green-600 transition text-white px-6 py-2 rounded-xl shadow font-semibold">Crear Formulario Personalizado</a>
        </div>
        <div class="p-4">
            <table class="min-w-full divide-y divide-gray-200 rounded-xl overflow-hidden">
                <thead>
                    <tr class="bg-gray-50">
                        <th class="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">ID</th>
                        <th class="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">Nombre</th>
                        <th class="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">Fecha de creación</th>
                        <th class="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">Acciones</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-100">
                    @forelse($formularios as $formulario)
                    <tr class="hover:bg-green-50 transition">
                        <td class="px-6 py-4 whitespace-nowrap text-gray-700 font-semibold">{{ $formulario->id ?? '-' }}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-gray-700">{{ $formulario->nombre }}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-gray-500">{{ $formulario->created_at->format('Y-m-d') }}</td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <a href="#" class="text-blue-600 hover:text-blue-800 font-semibold transition btn-ver-formulario mr-2" data-id="{{ $formulario->id }}">Ver</a>
                            <a href="#" class="text-yellow-600 hover:text-yellow-800 font-semibold transition btn-editar-formulario mr-2" data-id="{{ $formulario->id }}">Editar</a>
                            <form action="{{ route('fabricasoft.admin.formularios.eliminar', $formulario->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-600 hover:text-red-800 font-semibold transition" onclick="return confirm('¿Seguro que deseas eliminar este formulario?')">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="4" class="px-6 py-4 text-center text-gray-400">No hay formularios creados.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="card bg-white mt-10 rounded-2xl shadow-lg border border-gray-100 transition-shadow hover:shadow-2xl">
    <div class="p-4 border-b border-gray-100">
        <h3 class="text-2xl font-bold text-gray-800">Servicios Solicitados</h3>
    </div>
    <div class="p-4">
        @php
            $servicios = \DB::table('new_request')->orderByDesc('created_at')->get();
        @endphp
        @if($servicios->count() > 0)
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200 rounded-xl overflow-hidden">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">Proyecto</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">Empresa</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">Estado</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">Asignado a</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">Fecha</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">Acciones</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-100">
                        @foreach($servicios as $servicio)
                        <tr class="hover:bg-blue-50 transition">
                            <td class="px-6 py-4 whitespace-nowrap">
                                @php
                                    $formularioNombre = null;
                                    if ($servicio->formulario_id) {
                                        $formulario = \DB::table('formularios')->where('id', $servicio->formulario_id)->first();
                                        $formularioNombre = $formulario ? $formulario->nombre : null;
                                    }
                                @endphp
                                <div class="font-semibold text-gray-700">
                                    {{ $servicio->project_name }}
                                    @if($formularioNombre)
                                        <span class="text-sm text-blue-600">({{ $formularioNombre }})</span>
                                    @endif
                                </div>
                                <div class="text-xs text-gray-400">{{ $servicio->applicant_name }}</div>
                        <div class="text-xs text-gray-400">Tipo de Documento: {{ $servicio->document_type ?? 'No especificado' }}</div>
                        <div class="text-xs text-gray-400">Número de Documento: {{ $servicio->document_number ?? 'No especificado' }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-gray-700">{{ $servicio->company_name }}</td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                @php
                                    $servicioModel = \Modules\FABRICASOFT\Entities\NewRequest::find($servicio->id);
                                @endphp
                                @if($servicioModel)
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium {{ $servicioModel->estado_clase_css }}">
                                        {{ $servicioModel->estado_legible }}
                                    </span>
                                @else
                                    <span class="inline-flex items-center px-3 py-1 rounded-full bg-gray-100 text-gray-800 text-xs font-bold shadow-sm">
                                        <i class="fas fa-question-circle mr-1"></i> Desconocido
                                    </span>
                                @endif
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                @if($servicio->assigned_user_id)
                                    @php
                                        $assignedUser = \App\Models\User::find($servicio->assigned_user_id);
                                    @endphp
                                    <span class="inline-flex items-center px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-bold shadow-sm">
                                        <i class="fas fa-user mr-1"></i> {{ $assignedUser ? $assignedUser->name : 'Usuario no encontrado' }}
                                    </span>
                                @else
                                    <span class="inline-flex items-center px-3 py-1 rounded-full bg-gray-100 text-gray-600 text-xs font-bold shadow-sm">
                                        <i class="fas fa-user-slash mr-1"></i> Sin asignar
                                    </span>
                                @endif
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-gray-500">{{ \Carbon\Carbon::parse($servicio->created_at)->format('d/m/Y H:i') }}</td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <button class="bg-blue-500 hover:bg-blue-600 transition text-white px-4 py-2 rounded-xl shadow font-semibold mr-2" onclick="abrirModalAsociarFormulario({{ $servicio->id }}, {{ $servicio->formulario_id ?? 'null' }})">Asociar Formulario</button>
                                <button class="bg-green-500 hover:bg-green-600 transition text-white px-4 py-2 rounded-xl shadow font-semibold" onclick="abrirModalAsignarAprendiz({{ $servicio->id }}, '{{ $servicio->project_name }}', {{ $servicio->assigned_user_id ?? 'null' }})">Asignar Aprendiz</button>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <div class="text-gray-400">No hay servicios solicitados.</div>
        @endif
    </div>
</div>
<!-- Eliminar la tarjeta de Servicios Solicitados -->

<!-- Modal flotante -->
<div id="modal-formulario" class="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50 hidden transition-all duration-300 p-2 sm:p-4">
    <div class="bg-white rounded-3xl shadow-2xl w-full max-w-2xl p-4 md:p-10 relative border border-green-200 animate-fade-in"
         style="max-height: 90vh; overflow-y: auto;">
        <button class="absolute top-2 md:top-4 right-2 md:right-4 text-gray-400 text-2xl md:text-3xl hover:text-red-500 transition-all duration-200 p-1" onclick="document.getElementById('modal-formulario').classList.add('hidden')">&times;</button>
        <h2 class="text-xl md:text-3xl font-extrabold mb-4 md:mb-8 text-green-700 border-b pb-2 md:pb-3 tracking-tight break-words">Crear Formulario Personalizado</h2>
        <form id="form-crear-formulario" action="{{ route('fabricasoft.admin.formularios.store') }}" method="POST" class="space-y-4 md:space-y-8">
            @csrf
            <div>
                <label class="block text-lg font-semibold text-gray-700 mb-2">Nombre del Formulario</label>
                <input type="text" name="nombre" class="form-input w-full rounded-xl border border-gray-300 focus:border-green-500 focus:ring-green-200 shadow-sm" required>
            </div>
            <div id="preguntas-container-modal" class="space-y-4">
                <!-- Aquí se agregan dinámicamente las preguntas -->
            </div>
            <div class="flex flex-col sm:flex-row items-center gap-2 md:gap-4 mt-4 md:mt-6">
                <button type="button" id="agregar-pregunta-modal" class="w-full sm:w-auto px-3 md:px-5 py-2 bg-green-100 text-green-800 rounded-xl font-semibold hover:bg-green-200 transition-all duration-200 shadow text-sm md:text-base">+ Agregar Pregunta</button>
                <button type="submit" class="w-full sm:w-auto px-4 md:px-8 py-2 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all duration-200 shadow text-sm md:text-base">Guardar Formulario</button>
            </div>
        </form>
    </div>
</div>
<!-- Modal para ver formulario personalizado -->
<div id="modal-ver-formulario" class="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50 hidden transition-all duration-300 p-2 sm:p-4">
    <div class="bg-white rounded-3xl shadow-2xl w-full max-w-2xl p-4 md:p-10 relative animate-fade-in max-h-[90vh] overflow-y-auto">
        <button class="absolute top-2 md:top-4 right-2 md:right-4 text-gray-400 text-2xl md:text-3xl hover:text-red-500 transition-all duration-200 p-1" onclick="document.getElementById('modal-ver-formulario').classList.add('hidden')">&times;</button>
        <h2 class="text-xl md:text-3xl font-extrabold mb-4 md:mb-8 text-green-700 border-b pb-2 md:pb-3 tracking-tight break-words" id="modal-form-nombre">Formulario</h2>
        <div id="modal-form-detalle"></div>
    </div>
</div>
<!-- Modal para editar formulario personalizado -->
<div id="modal-editar-formulario" class="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50 hidden transition-all duration-300 p-2 sm:p-4">
    <div class="bg-white rounded-3xl shadow-2xl w-full max-w-2xl p-4 md:p-10 relative border border-yellow-200 animate-fade-in"
         style="max-height: 90vh; overflow-y: auto;">
        <button class="absolute top-2 md:top-4 right-2 md:right-4 text-gray-400 text-2xl md:text-3xl hover:text-red-500 transition-all duration-200 p-1" onclick="document.getElementById('modal-editar-formulario').classList.add('hidden')">&times;</button>
        <h2 class="text-xl md:text-3xl font-extrabold mb-4 md:mb-8 text-yellow-700 border-b pb-2 md:pb-3 tracking-tight break-words">Editar Formulario Personalizado</h2>
        <form id="form-editar-formulario" method="POST">
            @csrf
            @method('PUT')
            <div>
                <label class="block text-lg font-semibold text-gray-700 mb-2">Nombre del Formulario</label>
                <input type="text" name="nombre" id="editar-nombre-formulario" class="form-input w-full rounded-xl border border-gray-300 focus:border-yellow-500 focus:ring-yellow-200 shadow-sm" required>
            </div>
            <div id="preguntas-container-editar" class="space-y-4"></div>
            <div class="flex flex-col sm:flex-row items-center gap-2 md:gap-4 mt-4 md:mt-6">
                <button type="button" id="agregar-pregunta-editar" class="w-full sm:w-auto px-3 md:px-5 py-2 bg-yellow-100 text-yellow-800 rounded-xl font-semibold hover:bg-yellow-200 transition-all duration-200 shadow text-sm md:text-base">+ Agregar Pregunta</button>
                <button type="submit" class="w-full sm:w-auto px-4 md:px-8 py-2 bg-yellow-600 text-white rounded-xl font-bold hover:bg-yellow-700 transition-all duration-200 shadow text-sm md:text-base">Actualizar Formulario</button>
            </div>
        </form>
    </div>
</div>
<!-- Modal para asociar formulario -->
<div id="modal-asociar-formulario" class="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50 hidden transition-all duration-300 p-2 sm:p-4">
    <div class="bg-white rounded-3xl shadow-2xl w-full max-w-md p-4 md:p-10 relative border border-blue-200 animate-fade-in max-h-[90vh] overflow-y-auto">
        <button class="absolute top-2 md:top-4 right-2 md:right-4 text-gray-400 text-2xl md:text-3xl hover:text-red-500 transition-all duration-200 p-1" onclick="document.getElementById('modal-asociar-formulario').classList.add('hidden')">&times;</button>
        <h2 class="text-lg md:text-2xl font-extrabold mb-4 md:mb-8 text-blue-700 border-b pb-2 md:pb-3 tracking-tight break-words">Asociar Formulario Personalizado</h2>
        <form id="form-asociar-formulario" method="POST" action="{{ url('/fabricasoft/admin/servicios/asociar-formulario') }}">
            @csrf
            <input type="hidden" name="servicio_id" id="input-servicio-id">
            <div class="mb-6">
                <label class="block text-lg font-semibold text-gray-700 mb-2">Formulario Personalizado</label>
                <select name="formulario_id" id="select-formulario-id" class="form-select w-full rounded-xl border border-gray-300 focus:border-blue-500 shadow-sm">
                    <option value="">Sin formulario</option>
                    @foreach($formularios as $formulario)
                        <option value="{{ $formulario->id }}">{{ $formulario->nombre }}</option>
                    @endforeach
                </select>
            </div>
            <div class="flex flex-col sm:flex-row justify-end gap-2 md:gap-4 mt-4 md:mt-8">
                <button type="button" class="w-full sm:w-auto px-3 md:px-5 py-2 bg-gray-200 text-gray-700 rounded-xl font-semibold hover:bg-gray-300 transition-all duration-200 shadow text-sm md:text-base" onclick="document.getElementById('modal-asociar-formulario').classList.add('hidden')">Cancelar</button>
                <button type="submit" class="w-full sm:w-auto px-4 md:px-8 py-2 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all duration-200 shadow text-sm md:text-base">Guardar</button>
            </div>
        </form>
    </div>
</div>
<script>
document.getElementById('abrir-modal-formulario').onclick = function(e) {
    e.preventDefault();
    document.getElementById('modal-formulario').classList.remove('hidden');
}
let preguntaIndexModal = 0;
document.getElementById('agregar-pregunta-modal').onclick = function() {
    const container = document.getElementById('preguntas-container-modal');
    const div = document.createElement('div');
    div.className = 'mb-2 p-4 rounded-xl bg-gray-50 shadow flex flex-col gap-2 relative border border-gray-200';
    div.innerHTML = `
        <button type="button" title="Eliminar pregunta" style="top:8px;right:8px;" class="absolute text-red-500 text-lg hover:text-red-700 transition" onclick="this.parentNode.remove()">&times;</button>
        <label class="font-semibold">Pregunta</label>
        <input type="text" name="preguntas[${preguntaIndexModal}][texto]" class="form-input w-full rounded border border-gray-300 focus:border-green-500" required>
        <label class="font-semibold">Tipo de campo</label>
        <select name="preguntas[${preguntaIndexModal}][tipo]" class="form-select w-full rounded border border-gray-300 focus:border-green-500 tipo-campo-select" data-index="${preguntaIndexModal}" required>
            <option value="texto">Texto</option>
            <option value="seleccion">Selección</option>
            <option value="fecha">Fecha</option>
            <option value="numero">Número</option>
        </select>
        <div class="opciones-seleccion mb-2" id="opciones-seleccion-${preguntaIndexModal}" style="display:none;">
            <label class="font-semibold">Opciones de selección</label>
            <div class="opciones-lista flex flex-col gap-2"></div>
            <button type="button" class="btn-agregar-opcion px-3 py-1 bg-green-200 text-green-800 rounded hover:bg-green-300 mt-2 w-fit" data-index="${preguntaIndexModal}">+ Agregar Opción</button>
        </div>
        <label class="inline-flex items-center mt-2"><input type="checkbox" name="preguntas[${preguntaIndexModal}][cliente]" class="mr-2"> <span class="text-sm">Campo para que el cliente lo llene</span></label>
    `;
    container.appendChild(div);
    preguntaIndexModal++;
    // Agregar listeners para el select y el botón de agregar opción
    setTimeout(() => {
        const select = div.querySelector('.tipo-campo-select');
        const opcionesDiv = div.querySelector('.opciones-seleccion');
        const lista = div.querySelector('.opciones-lista');
        select.addEventListener('change', function() {
            if (this.value === 'seleccion') {
                opcionesDiv.style.display = '';
            } else {
                opcionesDiv.style.display = 'none';
                lista.innerHTML = '';
            }
        });
        div.querySelector('.btn-agregar-opcion').onclick = function() {
            const optionRow = document.createElement('div');
            optionRow.className = 'flex items-center gap-2';
            const input = document.createElement('input');
            input.type = 'text';
            input.name = `preguntas[${select.dataset.index}][opciones][]`;
            input.className = 'form-input flex-1 rounded border border-gray-300 focus:border-green-500';
            input.placeholder = 'Opción';
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'text-red-500 hover:text-red-700 text-lg px-2';
            btn.title = 'Eliminar opción';
            btn.innerHTML = '&times;';
            btn.onclick = function() { optionRow.remove(); };
            optionRow.appendChild(input);
            optionRow.appendChild(btn);
            lista.appendChild(optionRow);
        };
    }, 10);
}
function verFormularioEnModal(id) {
    fetch(`/fabricasoft/admin/formularios/${id}/ver-json`)
        .then(res => res.json())
        .then(data => {
            document.getElementById('modal-form-nombre').textContent = data.nombre;
            let html = '<h3 class="font-semibold mb-2">Preguntas:</h3><ol class="list-decimal ml-6">';
            data.preguntas.forEach(pregunta => {
                html += '<li class="mb-4">';
                html += '<div><strong>Pregunta:</strong> ' + pregunta.texto + '</div>';
                html += '<div><strong>Tipo de campo:</strong> ' + (pregunta.tipo.charAt(0).toUpperCase() + pregunta.tipo.slice(1)) + '</div>';
                if (pregunta.tipo === 'seleccion' && pregunta.opciones && pregunta.opciones.length > 0) {
                    html += '<div><strong>Opciones:</strong><ul class="list-disc ml-6">';
                    pregunta.opciones.forEach(op => { html += '<li>' + op + '</li>'; });
                    html += '</ul></div>';
                }
                if (pregunta.cliente) {
                    html += '<div class="text-green-600 text-xs mt-1">Campo para que el cliente lo llene</div>';
                }
                html += '</li>';
            });
            html += '</ol>';
            document.getElementById('modal-form-detalle').innerHTML = html;
            document.getElementById('modal-ver-formulario').classList.remove('hidden');
        });
}
document.querySelectorAll('.btn-ver-formulario').forEach(btn => {
    btn.onclick = function(e) {
        e.preventDefault();
        verFormularioEnModal(this.dataset.id);
    };
});
let preguntaIndexEditar = 0;
document.getElementById('agregar-pregunta-editar').onclick = function() {
    addPreguntaEditar();
};
function addPreguntaEditar(pregunta = null) {
    const container = document.getElementById('preguntas-container-editar');
    const div = document.createElement('div');
    div.className = 'mb-2 p-4 rounded-xl bg-gray-50 shadow flex flex-col gap-2 relative border border-gray-200';
    let texto = pregunta && pregunta.texto ? pregunta.texto : '';
    let tipo = pregunta && pregunta.tipo ? pregunta.tipo : 'texto';
    let cliente = pregunta && pregunta.cliente ? 'checked' : '';
    let opciones = pregunta && pregunta.opciones ? pregunta.opciones : [];
    div.innerHTML = `
        <button type=\"button\" title=\"Eliminar pregunta\" style=\"top:8px;right:8px;\" class=\"absolute text-red-500 text-lg hover:text-red-700 transition\" onclick=\"this.parentNode.remove()\">&times;</button>
        <label class=\"font-semibold\">Pregunta</label>
        <input type=\"text\" name=\"preguntas[${preguntaIndexEditar}][texto]\" class=\"form-input w-full rounded border border-gray-300 focus:border-yellow-500\" required value=\"${texto}\">
        <label class=\"font-semibold\">Tipo de campo</label>
        <select name=\"preguntas[${preguntaIndexEditar}][tipo]\" class=\"form-select w-full rounded border border-gray-300 focus:border-yellow-500 tipo-campo-select-editar\" data-index=\"${preguntaIndexEditar}\" required>
            <option value=\"texto\" ${tipo==='texto'?'selected':''}>Texto</option>
            <option value=\"seleccion\" ${tipo==='seleccion'?'selected':''}>Selección</option>
            <option value=\"fecha\" ${tipo==='fecha'?'selected':''}>Fecha</option>
            <option value=\"numero\" ${tipo==='numero'?'selected':''}>Número</option>
        </select>
        <div class=\"opciones-seleccion-editar mb-2\" id=\"opciones-seleccion-editar-${preguntaIndexEditar}\" style=\"display:${tipo==='seleccion'?'':'none'};\">
            <label class=\"font-semibold\">Opciones de selección</label>
            <div class=\"opciones-lista-editar flex flex-col gap-2\"></div>
            <button type=\"button\" class=\"btn-agregar-opcion-editar px-3 py-1 bg-yellow-200 text-yellow-800 rounded hover:bg-yellow-300 mt-2 w-fit\" data-index=\"${preguntaIndexEditar}\">+ Agregar Opción</button>
        </div>
        <label class=\"inline-flex items-center mt-2\"><input type=\"checkbox\" name=\"preguntas[${preguntaIndexEditar}][cliente]\" class=\"mr-2\" ${cliente}> <span class=\"text-sm\">Campo para que el cliente lo llene</span></label>
    `;
    container.appendChild(div);
    // Opciones de selección
    setTimeout(() => {
        const select = div.querySelector('.tipo-campo-select-editar');
        const opcionesDiv = div.querySelector('.opciones-seleccion-editar');
        const lista = div.querySelector('.opciones-lista-editar');
        select.addEventListener('change', function() {
            if (this.value === 'seleccion') {
                opcionesDiv.style.display = '';
            } else {
                opcionesDiv.style.display = 'none';
                lista.innerHTML = '';
            }
        });
        div.querySelector('.btn-agregar-opcion-editar').onclick = function() {
            const optionRow = document.createElement('div');
            optionRow.className = 'flex items-center gap-2';
            const input = document.createElement('input');
            input.type = 'text';
            input.name = `preguntas[${select.dataset.index}][opciones][]`;
            input.className = 'form-input flex-1 rounded border border-gray-300 focus:border-yellow-500';
            input.placeholder = 'Opción';
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'text-red-500 hover:text-red-700 text-lg px-2';
            btn.title = 'Eliminar opción';
            btn.innerHTML = '&times;';
            btn.onclick = function() { optionRow.remove(); };
            optionRow.appendChild(input);
            optionRow.appendChild(btn);
            lista.appendChild(optionRow);
        };
        // Si hay opciones iniciales
        if (opciones && opciones.length > 0) {
            opciones.forEach(op => {
                const optionRow = document.createElement('div');
                optionRow.className = 'flex items-center gap-2';
                const input = document.createElement('input');
                input.type = 'text';
                input.name = `preguntas[${select.dataset.index}][opciones][]`;
                input.className = 'form-input flex-1 rounded border border-gray-300 focus:border-yellow-500';
                input.placeholder = 'Opción';
                input.value = op;
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'text-red-500 hover:text-red-700 text-lg px-2';
                btn.title = 'Eliminar opción';
                btn.innerHTML = '&times;';
                btn.onclick = function() { optionRow.remove(); };
                optionRow.appendChild(input);
                optionRow.appendChild(btn);
                lista.appendChild(optionRow);
            });
        }
    }, 10);
    preguntaIndexEditar++;
}
document.querySelectorAll('.btn-editar-formulario').forEach(btn => {
    btn.onclick = function(e) {
        e.preventDefault();
        const id = this.dataset.id;
        fetch(`/fabricasoft/admin/formularios/${id}/ver-json`)
            .then(res => res.json())
            .then(data => {
                document.getElementById('editar-nombre-formulario').value = data.nombre;
                const container = document.getElementById('preguntas-container-editar');
                container.innerHTML = '';
                preguntaIndexEditar = 0;
                data.preguntas.forEach(pregunta => {
                    addPreguntaEditar(pregunta);
                });
                document.getElementById('form-editar-formulario').action = `/fabricasoft/admin/formularios/${id}/update`;
                document.getElementById('modal-editar-formulario').classList.remove('hidden');
            });
    };
});
function abrirModalAsociarFormulario(servicioId, formularioId) {
    document.getElementById('input-servicio-id').value = servicioId;
    document.getElementById('select-formulario-id').value = formularioId || '';
    document.getElementById('modal-asociar-formulario').classList.remove('hidden');
}

function abrirModalAsignarAprendiz(servicioId, projectName, assignedUserId) {
    document.getElementById('input-servicio-id-asignar').value = servicioId;
    document.getElementById('project-name-display').textContent = projectName;
    document.getElementById('select-aprendiz-id').value = assignedUserId || '';
    document.getElementById('modal-asignar-aprendiz').classList.remove('hidden');
}
</script>

<!-- Modal para asignar aprendiz -->
<div id="modal-asignar-aprendiz" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden">
    <div class="bg-white rounded-lg shadow-xl w-full max-w-md mx-4">
        <div class="p-6 border-b border-gray-200">
            <div class="flex justify-between items-center">
                <h3 class="text-lg font-semibold text-gray-800">Asignar Proyecto a Aprendiz</h3>
                <button onclick="document.getElementById('modal-asignar-aprendiz').classList.add('hidden')" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
        <form action="{{ route('fabricasoft.admin.asignar-aprendiz') }}" method="POST">
            @csrf
            <div class="p-6">
                <input type="hidden" id="input-servicio-id-asignar" name="servicio_id">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Proyecto:</label>
                    <p id="project-name-display" class="text-gray-900 font-semibold"></p>
                </div>
                
                <div class="mb-4">
                    <label for="select-aprendiz-id" class="block text-sm font-medium text-gray-700 mb-2">Seleccionar Aprendiz:</label>
                    <select id="select-aprendiz-id" name="aprendiz_id" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Seleccione un aprendiz</option>
                        @php
                            $aprendices = \App\Models\User::whereHas('roles', function($query) {
                                $query->where('slug', 'like', 'fabricasoft.%');
                            })->get();
                        @endphp
                        @foreach($aprendices as $aprendiz)
                            <option value="{{ $aprendiz->id }}">{{ $aprendiz->name }} ({{ $aprendiz->email }})</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="p-6 border-t border-gray-200 flex justify-end space-x-3">
                <button type="button" onclick="document.getElementById('modal-asignar-aprendiz').classList.add('hidden')" class="px-4 py-2 text-gray-600 bg-gray-200 rounded-md hover:bg-gray-300">
                    Cancelar
                </button>
                <button type="submit" class="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600">
                    Asignar Proyecto
                </button>
            </div>
        </form>
    </div>
</div>

@endsection 

<script>
// Función para cerrar alertas
function closeAlert(alertId) {
    const alert = document.getElementById(alertId);
    if (alert) {
        alert.style.transform = 'translateX(100%)';
        setTimeout(() => {
            alert.remove();
        }, 300);
    }
}

// Auto-cerrar alertas después de 5 segundos
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('[id^="alert-"]');
    alerts.forEach(alert => {
        setTimeout(() => {
            closeAlert(alert.id);
        }, 5000);
    });
});

// Mejorar confirmación de eliminación
document.addEventListener('DOMContentLoaded', function() {
    const deleteButtons = document.querySelectorAll('button[onclick*="confirm"]');
    deleteButtons.forEach(button => {
        button.onclick = function(e) {
            e.preventDefault();
            const form = this.closest('form');
            if (form) {
                Swal.fire({
                    title: '¿Estás seguro?',
                    text: "Esta acción no se puede deshacer",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Sí, eliminar',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });
            }
        };
    });
});
</script> 