@extends('fabricasoft::layouts.masteradmin')

@section('content')
<!-- Incluir librerías necesarias -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
.container-fluid {
    padding: 2rem;
    background: #f8f9fa;
    min-height: 100vh;
}

.header-section {
    background: white;
    border-radius: 12px;
    padding: 2rem;
    margin-bottom: 2rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    text-align: center;
}

.progress-overview {
    background: white;
    border-radius: 16px;
    padding: 2rem;
    margin-bottom: 2rem;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    border: 1px solid #f0f0f0;
}

.overview-header {
    text-align: center;
    margin-bottom: 2rem;
    padding-bottom: 1rem;
    border-bottom: 2px solid #f8f9fa;
}

.overview-title {
    color: #2c3e50;
    font-weight: 700;
    font-size: 1.5rem;
    margin: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.75rem;
}

.overview-title i {
    color: #3498db;
    font-size: 1.3rem;
}

.overview-content {
    display: flex;
    flex-direction: column;
    gap: 2rem;
}

.main-progress-section {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 1rem 0;
}

.progress-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    max-width: 1200px;
    margin: 0 auto;
    padding: 3rem;
    background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
    border-radius: 24px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
    border: 1px solid rgba(16, 185, 129, 0.1);
    gap: 4rem;
}

.progress-circle-wrapper {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 2rem;
    flex-shrink: 0;
    min-width: 300px;
}

.progress-circle {
    width: 180px;
    height: 180px;
    position: relative;
    filter: drop-shadow(0 8px 25px rgba(16, 185, 129, 0.25));
}

.progress-circle svg {
    width: 100%;
    height: 100%;
    transform: rotate(-90deg);
}

.progress-circle circle {
    fill: none;
    stroke-width: 10;
}

.progress-circle .bg {
    stroke: #f1f5f9;
}

.progress-circle .progress {
    stroke: url(#progressGradient);
    stroke-linecap: round;
    transition: stroke-dasharray 1s ease;
    filter: drop-shadow(0 4px 8px rgba(16, 185, 129, 0.4));
}

.progress-percentage {
    font-size: 0.8rem;
    font-weight: 600;
    color: #10b981;
    background: white;
    padding: 0.3rem 0.5rem;
    border-radius: 15px;
    border: 1px solid #10b981;
    box-shadow: 0 1px 4px rgba(16, 185, 129, 0.08);
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 35px;
    min-height: 25px;
    text-align: center;
    line-height: 1;
    margin-bottom: 1rem;
}

.progress-label {
    text-align: center;
}

.progress-label h3 {
    color: #1e293b;
    font-weight: 700;
    font-size: 1.6rem;
    margin: 0 0 0.75rem 0;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.progress-label p {
    color: #64748b;
    margin: 0;
    font-size: 1rem;
    font-weight: 500;
}

.stats-container {
    display: flex;
    flex-direction: column;
    gap: 2rem;
    flex: 1;
    margin-left: 0;
    min-width: 350px;
}

.stat-item {
    display: flex;
    align-items: center;
    gap: 1.5rem;
    padding: 2rem;
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
    min-width: 280px;
}

.stat-item:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
    border-color: #10b981;
}

.stat-icon {
    width: 65px;
    height: 65px;
    background: linear-gradient(135deg, #10b981, #059669);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.5rem;
    box-shadow: 0 6px 20px rgba(16, 185, 129, 0.3);
    flex-shrink: 0;
}

.stat-details {
    flex: 1;
}

.stat-number {
    display: block;
    font-size: 2.8rem;
    font-weight: 900;
    color: #10b981;
    line-height: 1;
    margin-bottom: 0.5rem;
}

.stat-text {
    display: block;
    font-size: 1rem;
    color: #64748b;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.phases-overview {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
    margin-top: 1rem;
}

.phase-card {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
    padding: 1.75rem;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    cursor: pointer;
    user-select: none;
}

.phase-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    border-color: #10b981;
}

.phase-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #10b981, #059669);
    opacity: 0;
    transition: opacity 0.3s ease;
}

.phase-card:hover::before {
    opacity: 1;
}

.phase-icon {
    width: 55px;
    height: 55px;
    background: linear-gradient(135deg, #10b981, #059669);
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 1.25rem;
    color: white;
    font-size: 1.3rem;
    box-shadow: 0 6px 20px rgba(16, 185, 129, 0.3);
    transition: all 0.3s ease;
}

.phase-card:hover .phase-icon {
    transform: scale(1.05);
    box-shadow: 0 8px 25px rgba(16, 185, 129, 0.4);
}

.phase-card:active {
    transform: translateY(-1px);
    box-shadow: 0 5px 20px rgba(0,0,0,0.15);
}

.phase-card.clicked {
    animation: cardClick 0.3s ease;
}

@keyframes cardClick {
    0% { transform: scale(1); }
    50% { transform: scale(0.95); }
    100% { transform: scale(1); }
}

.phase-card::after {
    content: 'Click para ir a la fase';
    position: absolute;
    bottom: 0.5rem;
    left: 50%;
    transform: translateX(-50%);
    font-size: 0.7rem;
    color: #64748b;
    opacity: 0;
    transition: opacity 0.3s ease;
    pointer-events: none;
    white-space: nowrap;
}

.phase-card:hover::after {
    opacity: 1;
}

.phase-info h5 {
    color: #1e293b;
    font-weight: 700;
    margin: 0 0 1rem 0;
    font-size: 1.2rem;
    text-align: center;
}

.phase-stats {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.25rem;
    margin-bottom: 1.25rem;
}

.completed-count {
    color: #10b981;
    font-weight: 800;
    font-size: 1.4rem;
}

.separator {
    color: #94a3b8;
    font-weight: 500;
    font-size: 1.1rem;
}

.total-count {
    color: #475569;
    font-weight: 600;
    font-size: 1.1rem;
}

.mini-progress {
    width: 100%;
}

.mini-bar {
    width: 100%;
    height: 6px;
    background: #ecf0f1;
    border-radius: 3px;
    overflow: hidden;
}

.mini-fill {
    height: 100%;
    background: linear-gradient(90deg, #27ae60, #2ecc71);
    border-radius: 3px;
    transition: width 0.6s ease;
    width: 0%;
}

.phase-table {
    background: white;
    border-radius: 12px;
    margin-bottom: 2rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    overflow: hidden;
}

.phase-header {
    padding: 1.5rem;
    color: white;
    font-weight: 600;
    font-size: 1.2rem;
}

.phase-header.analisis { background: linear-gradient(135deg, #007bff 0%, #0056b3 100%); }
.phase-header.diseno { background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%); }
.phase-header.implementacion { background: linear-gradient(135deg, #ffc107 0%, #e0a800 100%); }
.phase-header.pruebas { background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); }
.phase-header.despliegue { background: linear-gradient(135deg, #6f42c1 0%, #5a2d91 100%); }

.table-responsive {
    overflow-x: auto;
}

.table {
    width: 100%;
    margin-bottom: 0;
    border-collapse: collapse;
}

.table th {
    background: #f8f9fa;
    padding: 1rem;
    text-align: left;
    font-weight: 600;
    color: #495057;
    border-bottom: 2px solid #dee2e6;
}

.table td {
    padding: 1rem;
    border-bottom: 1px solid #dee2e6;
    vertical-align: top;
}

.table tbody tr:hover {
    background: #f8f9fa;
}

.task-checkbox {
    width: 20px;
    height: 20px;
    accent-color: #28a745;
    cursor: pointer;
}

.task-title {
    font-weight: 600;
    color: #495057;
    margin-bottom: 0.5rem;
}

.task-description {
    color: #6c757d;
    font-size: 0.9rem;
    line-height: 1.4;
}

.task-link-input {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid #dee2e6;
    border-radius: 4px;
    font-size: 0.85rem;
    background: #f8f9fa;
}

.task-link-input:focus {
    outline: none;
    border-color: #007bff;
    box-shadow: 0 0 0 2px rgba(0,123,255,0.1);
    background: white;
}

.task-link-input::placeholder {
    color: #6c757d;
    font-style: italic;
}

/* Estilos para el formulario de nueva tarea */
.add-task-section {
    background: #f8f9fa;
    padding: 1.5rem;
    border-top: 1px solid #dee2e6;
    border-bottom: 1px solid #dee2e6;
}

.add-task-form {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr auto;
    gap: 1rem;
    align-items: end;
}

.form-group {
    display: flex;
    flex-direction: column;
}

.form-label {
    font-weight: 600;
    color: #495057;
    margin-bottom: 0.5rem;
    font-size: 0.9rem;
}

.form-input {
    padding: 0.75rem;
    border: 2px solid #dee2e6;
    border-radius: 6px;
    font-size: 0.9rem;
    transition: border-color 0.3s ease;
}

.form-input:focus {
    outline: none;
    border-color: #007bff;
    box-shadow: 0 0 0 3px rgba(0,123,255,0.1);
}

.form-textarea {
    min-height: 60px;
    resize: vertical;
}

.btn-add-task {
    background: linear-gradient(135deg, #28a745, #20c997);
    color: white;
    border: none;
    padding: 0.75rem 1.5rem;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    white-space: nowrap;
}

.btn-add-task:hover {
    background: linear-gradient(135deg, #218838, #1e7e34);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(40, 167, 69, 0.3);
}

.btn-add-task:active {
    transform: translateY(0);
}

.task-actions {
    display: flex;
    gap: 0.5rem;
    align-items: center;
}

.btn-edit-task {
    background: #ffc107;
    color: #212529;
    border: none;
    padding: 0.25rem 0.5rem;
    border-radius: 4px;
    cursor: pointer;
    font-size: 0.8rem;
    transition: all 0.3s ease;
}

.btn-edit-task:hover {
    background: #e0a800;
    transform: translateY(-1px);
}

.btn-delete-task {
    background: #dc3545;
    color: white;
    border: none;
    padding: 0.25rem 0.5rem;
    border-radius: 4px;
    cursor: pointer;
    font-size: 0.8rem;
    transition: all 0.3s ease;
}

.btn-delete-task:hover {
    background: #c82333;
    transform: translateY(-1px);
}

/* Modal para editar tarea */
.task-modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
}

.modal-content {
    background-color: white;
    margin: 5% auto;
    padding: 2rem;
    border-radius: 12px;
    width: 90%;
    max-width: 600px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.3);
    position: relative;
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    padding-bottom: 1rem;
    border-bottom: 2px solid #f8f9fa;
}

.modal-title {
    font-size: 1.5rem;
    font-weight: 700;
    color: #2c3e50;
}

.close-modal {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: #6c757d;
    transition: color 0.3s ease;
}

.close-modal:hover {
    color: #dc3545;
}

.modal-body {
    display: grid;
    gap: 1rem;
}

.modal-form-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.modal-label {
    font-weight: 600;
    color: #495057;
}

.modal-input, .modal-textarea, .modal-select {
    padding: 0.75rem;
    border: 2px solid #dee2e6;
    border-radius: 6px;
    font-size: 0.9rem;
    transition: border-color 0.3s ease;
}

.modal-input:focus, .modal-textarea:focus, .modal-select:focus {
    outline: none;
    border-color: #007bff;
    box-shadow: 0 0 0 3px rgba(0,123,255,0.1);
}

.modal-textarea {
    min-height: 100px;
    resize: vertical;
}

.modal-actions {
    display: flex;
    gap: 1rem;
    justify-content: flex-end;
    margin-top: 1.5rem;
    padding-top: 1rem;
    border-top: 2px solid #f8f9fa;
}

.btn-modal {
    padding: 0.75rem 1.5rem;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-modal.cancel {
    background: #6c757d;
    color: white;
}

.btn-modal.cancel:hover {
    background: #5a6268;
}

.btn-modal.save {
    background: #28a745;
    color: white;
}

.btn-modal.save:hover {
    background: #218838;
}

@media (max-width: 768px) {
    .add-task-form {
        grid-template-columns: 1fr;
        gap: 0.75rem;
    }
    
    .btn-add-task {
        width: 100%;
        justify-content: center;
    }
    
    .modal-content {
        margin: 10% auto;
        width: 95%;
        padding: 1.5rem;
    }
    
    .modal-actions {
        flex-direction: column;
    }
    
    .btn-modal {
        width: 100%;
    }
}

.enlace-section {
    background: #f8f9fa;
    padding: 1.5rem;
    border-top: 1px solid #dee2e6;
}

.enlace-container {
    max-width: 100%;
}

.enlace-label {
    display: block;
    font-weight: 600;
    color: #495057;
    margin-bottom: 0.75rem;
    font-size: 0.95rem;
}

.enlace-textarea {
    width: 100%;
    min-height: 80px;
    padding: 0.75rem;
    border: 2px solid #dee2e6;
    border-radius: 6px;
    font-size: 0.9rem;
    font-family: inherit;
    resize: vertical;
    background: white;
    transition: border-color 0.3s ease;
}

.enlace-textarea:focus {
    outline: none;
    border-color: #007bff;
    box-shadow: 0 0 0 3px rgba(0,123,255,0.1);
}

.enlace-textarea::placeholder {
    color: #6c757d;
    font-style: italic;
}

.status-badge {
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
    text-transform: uppercase;
}

.status-completed {
    background: #d4edda;
    color: #155724;
}

.status-pending {
    background: #fff3cd;
    color: #856404;
}

.phase-progress {
    padding: 1.5rem;
    background: #f8f9fa;
    border-top: 1px solid #dee2e6;
}

.progress-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}

.progress-label {
    font-weight: 600;
    color: #495057;
    font-size: 0.95rem;
}

.progress-percentage {
    font-weight: 700;
    color: #28a745;
    font-size: 1.1rem;
    background: white;
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    border: 2px solid #28a745;
}

.progress-bar-container {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.progress-bar {
    width: 100%;
    height: 12px;
    background: #e9ecef;
    border-radius: 6px;
    overflow: hidden;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.1);
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #28a745, #20c997);
    transition: width 0.8s ease;
    border-radius: 6px;
    position: relative;
}

.progress-fill::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
    animation: shimmer 2s infinite;
}

@keyframes shimmer {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
}

.progress-stats {
    text-align: center;
    font-size: 0.9rem;
    color: #6c757d;
    font-weight: 500;
}

.progress-stats span:first-child {
    color: #28a745;
    font-weight: 700;
}

.progress-stats span:last-child {
    color: #495057;
    font-weight: 600;
}

.progress-fill.completed {
    background: linear-gradient(90deg, #28a745, #20c997);
    box-shadow: 0 0 10px rgba(40, 167, 69, 0.5);
}

.progress-fill.completed::after {
    animation: none;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent);
}

.phase-table.completed .phase-header {
    position: relative;
}

.phase-table.completed .phase-header::after {
    content: '✓';
    position: absolute;
    right: 1.5rem;
    top: 50%;
    transform: translateY(-50%);
    background: white;
    color: #28a745;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 1.2rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.2);
}

.export-section {
    background: white;
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 2rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.export-buttons {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
}

.btn-export {
    background: #6c757d;
    color: white;
    border: none;
    padding: 0.75rem 1.5rem;
    border-radius: 6px;
    cursor: pointer;
    transition: background 0.3s;
    font-weight: 600;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-export:hover {
    background: #5a6268;
    color: white;
    text-decoration: none;
}

.btn-export.primary { background: #007bff; }
.btn-export.primary:hover { background: #0056b3; }
.btn-export.success { background: #28a745; }
.btn-export.success:hover { background: #1e7e34; }

@media (max-width: 768px) {
    .container-fluid {
        padding: 1rem;
    }
    
    .progress-overview {
        padding: 1.5rem;
    }
    
    .overview-title {
        font-size: 1.3rem;
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .progress-container {
        flex-direction: column;
        gap: 3rem;
        padding: 2rem;
        text-align: center;
    }
    
    .progress-circle-wrapper {
        gap: 1.5rem;
        min-width: auto;
    }
    
    .progress-percentage {
        font-size: 0.7rem;
        padding: 0.25rem 0.4rem;
        min-width: 30px;
        min-height: 20px;
    }
    
    .stats-container {
        margin-left: 0;
        gap: 1.5rem;
        min-width: auto;
    }
    
    .stat-item {
        padding: 1.5rem;
        min-width: auto;
    }
    
    .stat-icon {
        width: 55px;
        height: 55px;
        font-size: 1.3rem;
    }
    
    .stat-number {
        font-size: 2.4rem;
    }
    
    .phases-overview {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
    
    .phase-card {
        padding: 1.25rem;
    }
    
    .table-responsive {
        font-size: 0.9rem;
    }
    
    .table th,
    .table td {
        padding: 0.75rem 0.5rem;
    }
    
    .export-buttons {
        flex-direction: column;
    }
    
    .btn-export {
        width: 100%;
        justify-content: center;
    }
}
</style>

<div class="container-fluid">
    <!-- Header -->
    <div class="header-section">
        <h1 class="text-4xl font-bold text-gray-800 mb-3">Avance de Proyectos FABRICASOFT</h1>
        <p class="text-xl text-gray-600">Seguimiento detallado del desarrollo de software</p>
    </div>

    <!-- Progress Overview -->
    <div class="progress-overview">
        <div class="overview-header">
            <h3 class="overview-title">
                <i class="fas fa-chart-line mr-2"></i>Resumen del Proyecto
            </h3>
        </div>
        <div class="overview-content">
            <div class="main-progress-section">
                <div class="progress-container">
                    <div class="progress-circle-wrapper">
                        <div class="progress-percentage" id="overallPercentage">0%</div>
                        <div class="progress-label">
                            <h3>Progreso General</h3>
                            <p>Estado del proyecto completo</p>
                        </div>
                    </div>
                    <div class="stats-container">
                        <div class="stat-item">
                            <div class="stat-icon">
                                <i class="fas fa-tasks"></i>
                            </div>
                            <div class="stat-details">
                                <span class="stat-number" id="total-tasks">0</span>
                                <span class="stat-text">Tareas Totales</span>
                            </div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <div class="stat-details">
                                <span class="stat-number" id="completed-tasks">0</span>
                                <span class="stat-text">Completadas</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="phases-overview">
                <div class="phase-card" data-phase="analisis">
                    <div class="phase-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <div class="phase-info">
                        <h5>Análisis</h5>
                        <div class="phase-stats">
                            <span class="completed-count" id="analisis-stats">0</span>
                            <span class="separator">/</span>
                            <span class="total-count">8</span>
                        </div>
                        <div class="mini-progress">
                            <div class="mini-bar">
                                <div class="mini-fill" id="mini-fill-analisis"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="phase-card" data-phase="diseno">
                    <div class="phase-icon">
                        <i class="fas fa-pencil-ruler"></i>
                    </div>
                    <div class="phase-info">
                        <h5>Diseño</h5>
                        <div class="phase-stats">
                            <span class="completed-count" id="diseno-stats">0</span>
                            <span class="separator">/</span>
                            <span class="total-count">10</span>
                        </div>
                        <div class="mini-progress">
                            <div class="mini-bar">
                                <div class="mini-fill" id="mini-fill-diseno"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="phase-card" data-phase="implementacion">
                    <div class="phase-icon">
                        <i class="fas fa-code"></i>
                    </div>
                    <div class="phase-info">
                        <h5>Implementación</h5>
                        <div class="phase-stats">
                            <span class="completed-count" id="implementacion-stats">0</span>
                            <span class="separator">/</span>
                            <span class="total-count">8</span>
                        </div>
                        <div class="mini-progress">
                            <div class="mini-bar">
                                <div class="mini-fill" id="mini-fill-implementacion"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="phase-card" data-phase="pruebas">
                    <div class="phase-icon">
                        <i class="fas fa-vial"></i>
                    </div>
                    <div class="phase-info">
                        <h5>Pruebas</h5>
                        <div class="phase-stats">
                            <span class="completed-count" id="pruebas-stats">0</span>
                            <span class="separator">/</span>
                            <span class="total-count">8</span>
                        </div>
                        <div class="mini-progress">
                            <div class="mini-bar">
                                <div class="mini-fill" id="mini-fill-pruebas"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="phase-card" data-phase="despliegue">
                    <div class="phase-icon">
                        <i class="fas fa-rocket"></i>
                    </div>
                    <div class="phase-info">
                        <h5>Despliegue</h5>
                        <div class="phase-stats">
                            <span class="completed-count" id="despliegue-stats">0</span>
                            <span class="separator">/</span>
                            <span class="total-count">4</span>
                        </div>
                        <div class="mini-progress">
                            <div class="mini-bar">
                                <div class="mini-fill" id="mini-fill-despliegue"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Export Section -->
    <div class="export-section">
        <h3 class="text-xl font-semibold text-gray-800 mb-3">Exportar Progreso</h3>
        <div class="export-buttons">
            <button onclick="exportarProgreso()" class="btn-export primary">
                <i class="fas fa-download"></i>Exportar Progreso
            </button>
            <button onclick="exportarImagen()" class="btn-export success">
                <i class="fas fa-image"></i>Exportar como Imagen
            </button>
            <button onclick="limpiarDatos()" class="btn-export">
                <i class="fas fa-trash"></i>Limpiar Datos
            </button>
        </div>
    </div>

    <!-- Phase 1: Análisis -->
    <div class="phase-table" id="fase-analisis">
        <div class="phase-header analisis">
            <i class="fas fa-search mr-2"></i>Fase 1: Análisis de Requisitos
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th width="5%">Estado</th>
                        <th width="35%">Tarea</th>
                        <th width="45%">Descripción</th>
                        <th width="15%">Acciones</th>
                    </tr>
                </thead>
                <tbody id="analisis-tbody">
                    <!-- Se genera dinámicamente -->
                </tbody>
            </table>
        </div>
        
        <!-- Formulario para agregar nueva tarea -->
        <div class="add-task-section">
            <form class="add-task-form" id="add-task-form-analisis" data-phase="analisis">
                <div class="form-group">
                    <label class="form-label">Título de la Tarea</label>
                    <input type="text" class="form-input" name="titulo" placeholder="Ingrese el título de la tarea" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Descripción</label>
                    <textarea class="form-input form-textarea" name="descripcion" placeholder="Descripción detallada de la tarea" required></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Estado</label>
                    <select class="form-input" name="estado" required>
                        <option value="pendiente">Pendiente</option>
                        <option value="en_progreso">En Progreso</option>
                        <option value="revision">En Revisión</option>
                        <option value="completada">Completada</option>
                    </select>
                </div>
                <button type="submit" class="btn-add-task">
                    <i class="fas fa-plus"></i>Agregar Tarea
                </button>
            </form>
        </div>
        <div class="enlace-section">
            <div class="enlace-container">
                <label class="enlace-label">Enlaces de documentos de esta fase:</label>
                <textarea class="task-link-input" id="enlaces-analisis" placeholder="Pega aquí todos los enlaces de documentos de esta fase (Google Drive, GitHub, etc.)"></textarea>
            </div>
        </div>
        <div class="phase-progress">
            <div class="progress-info">
                <span class="progress-label">Progreso de la fase</span>
                <span class="progress-percentage" id="progress-text-analisis">0%</span>
            </div>
            <div class="progress-bar-container">
                <div class="progress-bar">
                    <div class="progress-fill" id="progress-fill-analisis" style="width: 0%"></div>
                </div>
                <div class="progress-stats">
                    <span id="analisis-completadas">0</span> de <span id="analisis-total">8</span> tareas completadas
                </div>
            </div>
        </div>
    </div>

    <!-- Phase 2: Diseño -->
    <div class="phase-table" id="fase-diseno">
        <div class="phase-header diseno">
            <i class="fas fa-pencil-ruler mr-2"></i>Fase 2: Diseño del Sistema
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th width="5%">Estado</th>
                        <th width="35%">Tarea</th>
                        <th width="45%">Descripción</th>
                        <th width="15%">Acciones</th>
                    </tr>
                </thead>
                <tbody id="diseno-tbody">
                    <!-- Se genera dinámicamente -->
                </tbody>
            </table>
        </div>
        
        <!-- Formulario para agregar nueva tarea -->
        <div class="add-task-section">
            <form class="add-task-form" id="add-task-form-diseno" data-phase="diseno">
                <div class="form-group">
                    <label class="form-label">Título de la Tarea</label>
                    <input type="text" class="form-input" name="titulo" placeholder="Ingrese el título de la tarea" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Descripción</label>
                    <textarea class="form-input form-textarea" name="descripcion" placeholder="Descripción detallada de la tarea" required></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Estado</label>
                    <select class="form-input" name="estado" required>
                        <option value="pendiente">Pendiente</option>
                        <option value="en_progreso">En Progreso</option>
                        <option value="revision">En Revisión</option>
                        <option value="completada">Completada</option>
                    </select>
                </div>
                <button type="submit" class="btn-add-task">
                    <i class="fas fa-plus"></i>Agregar Tarea
                </button>
            </form>
        </div>
        <div class="enlace-section">
            <div class="enlace-container">
                <label class="enlace-label">Enlaces de documentos de esta fase:</label>
                <textarea class="task-link-input" id="enlaces-diseno" placeholder="Pega aquí todos los enlaces de documentos de esta fase (Google Drive, GitHub, etc.)"></textarea>
            </div>
        </div>
        <div class="phase-progress">
            <div class="progress-info">
                <span class="progress-label">Progreso de la fase</span>
                <span class="progress-percentage" id="progress-text-diseno">0%</span>
            </div>
            <div class="progress-bar-container">
                <div class="progress-bar">
                    <div class="progress-fill" id="progress-fill-diseno" style="width: 0%"></div>
                </div>
                <div class="progress-stats">
                    <span id="diseno-completadas">0</span> de <span id="diseno-total">10</span> tareas completadas
                </div>
            </div>
        </div>
    </div>

    <!-- Phase 3: Implementación -->
    <div class="phase-table" id="fase-implementacion">
        <div class="phase-header implementacion">
            <i class="fas fa-code mr-2"></i>Fase 3: Implementación
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th width="5%">Estado</th>
                        <th width="35%">Tarea</th>
                        <th width="45%">Descripción</th>
                        <th width="15%">Acciones</th>
                    </tr>
                </thead>
                <tbody id="implementacion-tbody">
                    <!-- Se genera dinámicamente -->
                </tbody>
            </table>
        </div>
        
        <!-- Formulario para agregar nueva tarea -->
        <div class="add-task-section">
            <form class="add-task-form" id="add-task-form-implementacion" data-phase="implementacion">
                <div class="form-group">
                    <label class="form-label">Título de la Tarea</label>
                    <input type="text" class="form-input" name="titulo" placeholder="Ingrese el título de la tarea" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Descripción</label>
                    <textarea class="form-input form-textarea" name="descripcion" placeholder="Descripción detallada de la tarea" required></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Estado</label>
                    <select class="form-input" name="estado" required>
                        <option value="pendiente">Pendiente</option>
                        <option value="en_progreso">En Progreso</option>
                        <option value="revision">En Revisión</option>
                        <option value="completada">Completada</option>
                    </select>
                </div>
                <button type="submit" class="btn-add-task">
                    <i class="fas fa-plus"></i>Agregar Tarea
                </button>
            </form>
        </div>
        <div class="enlace-section">
            <div class="enlace-container">
                <label class="enlace-label">Enlaces de documentos de esta fase:</label>
                <textarea class="task-link-input" id="enlaces-implementacion" placeholder="Pega aquí todos los enlaces de documentos de esta fase (Google Drive, GitHub, etc.)"></textarea>
            </div>
        </div>
        <div class="phase-progress">
            <div class="progress-info">
                <span class="progress-label">Progreso de la fase</span>
                <span class="progress-percentage" id="progress-text-implementacion">0%</span>
            </div>
            <div class="progress-bar-container">
                <div class="progress-bar">
                    <div class="progress-fill" id="progress-fill-implementacion" style="width: 0%"></div>
                </div>
                <div class="progress-stats">
                    <span id="implementacion-completadas">0</span> de <span id="implementacion-total">8</span> tareas completadas
                </div>
            </div>
        </div>
    </div>

    <!-- Phase 4: Pruebas -->
    <div class="phase-table" id="fase-pruebas">
        <div class="phase-header pruebas">
            <i class="fas fa-vial mr-2"></i>Fase 4: Pruebas
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th width="5%">Estado</th>
                        <th width="35%">Tarea</th>
                        <th width="45%">Descripción</th>
                        <th width="15%">Acciones</th>
                    </tr>
                </thead>
                <tbody id="pruebas-tbody">
                    <!-- Se genera dinámicamente -->
                </tbody>
            </table>
        </div>
        
        <!-- Formulario para agregar nueva tarea -->
        <div class="add-task-section">
            <form class="add-task-form" id="add-task-form-pruebas" data-phase="pruebas">
                <div class="form-group">
                    <label class="form-label">Título de la Tarea</label>
                    <input type="text" class="form-input" name="titulo" placeholder="Ingrese el título de la tarea" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Descripción</label>
                    <textarea class="form-input form-textarea" name="descripcion" placeholder="Descripción detallada de la tarea" required></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Estado</label>
                    <select class="form-input" name="estado" required>
                        <option value="pendiente">Pendiente</option>
                        <option value="en_progreso">En Progreso</option>
                        <option value="revision">En Revisión</option>
                        <option value="completada">Completada</option>
                    </select>
                </div>
                <button type="submit" class="btn-add-task">
                    <i class="fas fa-plus"></i>Agregar Tarea
                </button>
            </form>
        </div>
        <div class="enlace-section">
            <div class="enlace-container">
                <label class="enlace-label">Enlaces de documentos de esta fase:</label>
                <textarea class="task-link-input" id="enlaces-pruebas" placeholder="Pega aquí todos los enlaces de documentos de esta fase (Google Drive, GitHub, etc.)"></textarea>
            </div>
        </div>
        <div class="phase-progress">
            <div class="progress-info">
                <span class="progress-label">Progreso de la fase</span>
                <span class="progress-percentage" id="progress-text-pruebas">0%</span>
            </div>
            <div class="progress-bar-container">
                <div class="progress-bar">
                    <div class="progress-fill" id="progress-fill-pruebas" style="width: 0%"></div>
                </div>
                <div class="progress-stats">
                    <span id="pruebas-completadas">0</span> de <span id="pruebas-total">8</span> tareas completadas
                </div>
            </div>
        </div>
    </div>

    <!-- Phase 5: Despliegue -->
    <div class="phase-table" id="fase-despliegue">
        <div class="phase-header despliegue">
            <i class="fas fa-rocket mr-2"></i>Fase 5: Despliegue
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th width="5%">Estado</th>
                        <th width="35%">Tarea</th>
                        <th width="45%">Descripción</th>
                        <th width="15%">Acciones</th>
                    </tr>
                </thead>
                <tbody id="despliegue-tbody">
                    <!-- Se genera dinámicamente -->
                </tbody>
            </table>
        </div>
        
        <!-- Formulario para agregar nueva tarea -->
        <div class="add-task-section">
            <form class="add-task-form" id="add-task-form-despliegue" data-phase="despliegue">
                <div class="form-group">
                    <label class="form-label">Título de la Tarea</label>
                    <input type="text" class="form-input" name="titulo" placeholder="Ingrese el título de la tarea" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Descripción</label>
                    <textarea class="form-input form-textarea" name="descripcion" placeholder="Descripción detallada de la tarea" required></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Estado</label>
                    <select class="form-input" name="estado" required>
                        <option value="pendiente">Pendiente</option>
                        <option value="en_progreso">En Progreso</option>
                        <option value="revision">En Revisión</option>
                        <option value="completada">Completada</option>
                    </select>
                </div>
                <button type="submit" class="btn-add-task">
                    <i class="fas fa-plus"></i>Agregar Tarea
                </button>
            </form>
        </div>
        <div class="enlace-section">
            <div class="enlace-container">
                <label class="enlace-label">Enlaces de documentos de esta fase:</label>
                <textarea class="task-link-input" id="enlaces-despliegue" placeholder="Pega aquí todos los enlaces de documentos de esta fase (Google Drive, GitHub, etc.)"></textarea>
            </div>
        </div>
        <div class="phase-progress">
            <div class="progress-info">
                <span class="progress-label">Progreso de la fase</span>
                <span class="progress-percentage" id="progress-text-despliegue">0%</span>
            </div>
            <div class="progress-bar-container">
                <div class="progress-bar">
                    <div class="progress-fill" id="progress-fill-despliegue" style="width: 0%"></div>
                </div>
                <div class="progress-stats">
                    <span id="despliegue-completadas">0</span> de <span id="despliegue-total">4</span> tareas completadas
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Estructura de datos para las tareas
const tareasData = {
    analisis: [
        { id: 'analisis-1', titulo: 'Historias de usuario con criterios de aceptación (.xlsx)', descripcion: 'Documento que describe las funcionalidades desde la perspectiva del usuario final, incluyendo criterios específicos para validar que cada historia esté completa.', completada: true, enlace: '' },
        { id: 'analisis-2', titulo: 'Historial de usuario (.xlsx)', descripcion: 'Registro detallado de todas las interacciones y cambios realizados por los usuarios en el sistema.', completada: true, enlace: '' },
        { id: 'analisis-3', titulo: 'Matriz de trazabilidad de requisitos (.xlsx)', descripcion: 'Tabla que relaciona cada requisito con su origen, implementación y pruebas, asegurando que ningún requisito se pierda durante el desarrollo.', completada: true, enlace: '' },
        { id: 'analisis-4', titulo: 'SRS completo y con diagramas iniciales (.docx)', descripcion: 'Especificación de Requisitos del Software que describe detalladamente qué debe hacer el sistema, incluyendo diagramas UML iniciales.', completada: true, enlace: '' },
        { id: 'analisis-5', titulo: 'Crear diagrama de contexto (nivel 0 de DFD)', descripcion: 'Diagrama de Flujo de Datos que muestra el sistema como un proceso central y su interacción con entidades externas.', completada: false, enlace: '' },
        { id: 'analisis-6', titulo: 'Crear diagrama de casos de uso (UML)', descripcion: 'Diagrama UML que identifica todos los actores del sistema y las funcionalidades principales que pueden realizar.', completada: false, enlace: '' },
        { id: 'analisis-7', titulo: 'Especificaciones de casos de uso', descripcion: 'Documento detallado que describe los flujos principales y alternativos para cada caso de uso identificado.', completada: false, enlace: '' },
        { id: 'analisis-8', titulo: 'Documento de análisis completo', descripcion: 'Resumen ejecutivo de todo el análisis realizado, incluyendo conclusiones y recomendaciones para las siguientes fases.', completada: false, enlace: '' }
    ],
    diseno: [
        { id: 'diseno-1', titulo: 'Documento de diseño técnico', descripcion: 'Especificación detallada de la arquitectura del sistema, patrones de diseño utilizados y estructura modular.', completada: false, enlace: '' },
        { id: 'diseno-2', titulo: 'Crear diagrama de clases (UML)', descripcion: 'Diagrama UML que muestra las entidades del sistema, sus atributos, métodos y las relaciones entre ellas.', completada: false, enlace: '' },
        { id: 'diseno-3', titulo: 'Crear diagrama de secuencia (UML)', descripcion: 'Diagrama UML que representa el flujo de mensajes entre objetos en un escenario específico del sistema.', completada: false, enlace: '' },
        { id: 'diseno-4', titulo: 'Crear diagrama de actividades (UML)', descripcion: 'Diagrama UML que describe los flujos de procesos internos y la lógica de negocio del sistema.', completada: false, enlace: '' },
        { id: 'diseno-5', titulo: 'Crear diagrama de flujo de procesos', descripcion: 'Flowchart que representa visualmente los procesos clave del sistema y su flujo de trabajo.', completada: false, enlace: '' },
        { id: 'diseno-6', titulo: 'Modelo entidad-relación (ERD)', descripcion: 'Diagrama que muestra las tablas de la base de datos, sus relaciones y cardinalidades.', completada: false, enlace: '' },
        { id: 'diseno-7', titulo: 'Diccionario de datos', descripcion: 'Definición detallada de cada campo de la base de datos, incluyendo tipos, restricciones y descripciones.', completada: false, enlace: '' },
        { id: 'diseno-8', titulo: 'Wireframes o mockups', descripcion: 'Bocetos visuales de las interfaces del sistema, mostrando la disposición de elementos y navegación.', completada: false, enlace: '' },
        { id: 'diseno-9', titulo: 'Prototipo funcional', descripcion: 'Prototipo interactivo creado en Figma, Adobe XD o herramienta similar para validar el diseño con usuarios.', completada: false, enlace: '' },
        { id: 'diseno-10', titulo: 'Presentación de diseño para cliente (.pptx)', descripcion: 'Presentación que explica el diseño del sistema al cliente para su aprobación antes de la implementación.', completada: true, enlace: '' }
    ],
    implementacion: [
        { id: 'implementacion-1', titulo: 'Manual de instalación y configuración', descripcion: 'Documento paso a paso para instalar y configurar el entorno de desarrollo y producción.', completada: false, enlace: '' },
        { id: 'implementacion-2', titulo: 'Documentación de API', descripcion: 'Documentación completa de la API usando Swagger, Postman o Redoc, incluyendo endpoints, parámetros y respuestas.', completada: false, enlace: '' },
        { id: 'implementacion-3', titulo: 'Estándares de codificación', descripcion: 'Documento que define las convenciones de nomenclatura, estructura de carpetas y mejores prácticas de código.', completada: false, enlace: '' },
        { id: 'implementacion-4', titulo: 'Bitácora de desarrollo', descripcion: 'Registro diario de avances, decisiones técnicas y problemas encontrados durante la implementación.', completada: false, enlace: '' },
        { id: 'implementacion-5', titulo: 'Logo y elementos visuales (.docx)', descripcion: 'Documento que contiene el logo del proyecto y todos los elementos visuales utilizados en la interfaz.', completada: true, enlace: '' },
        { id: 'implementacion-6', titulo: 'Repositorio Git con commits organizados', descripcion: 'Repositorio de código fuente con commits organizados por funcionalidad y documentación del historial de cambios.', completada: false, enlace: '' },
        { id: 'implementacion-7', titulo: 'Documentación de código', descripcion: 'Comentarios en el código y documentación técnica de las funciones y clases principales.', completada: false, enlace: '' },
        { id: 'implementacion-8', titulo: 'Manual de desarrollador', descripcion: 'Guía para desarrolladores que incluye configuración del entorno, flujo de trabajo y estándares del proyecto.', completada: false, enlace: '' }
    ],
    pruebas: [
        { id: 'pruebas-1', titulo: 'Plan de pruebas (.docx)', descripcion: 'Documento que define la estrategia de pruebas, tipos de pruebas a realizar y cronograma de ejecución.', completada: true, enlace: '' },
        { id: 'pruebas-2', titulo: 'Casos de prueba (.xlsx)', descripcion: 'Matriz de casos de prueba que cubre todos los escenarios y funcionalidades del sistema.', completada: true, enlace: '' },
        { id: 'pruebas-3', titulo: 'Resultados de pruebas (.docx)', descripcion: 'Reporte de los resultados obtenidos de la ejecución de todos los casos de prueba.', completada: true, enlace: '' },
        { id: 'pruebas-4', titulo: 'Plan de pruebas manuales (.docx)', descripcion: 'Plan específico para pruebas manuales que no pueden ser automatizadas.', completada: true, enlace: '' },
        { id: 'pruebas-5', titulo: 'Registro de errores/bugs', descripcion: 'Documento en Excel o herramienta de gestión que registra todos los errores encontrados durante las pruebas.', completada: false, enlace: '' },
        { id: 'pruebas-6', titulo: 'Pruebas de integración y validación', descripcion: 'Documentación de las pruebas que validan la integración entre módulos y la funcionalidad completa del sistema.', completada: false, enlace: '' },
        { id: 'pruebas-7', titulo: 'Informe final de pruebas', descripcion: 'Reporte final con el estatus de aprobación y recomendaciones para el despliegue.', completada: false, enlace: '' },
        { id: 'pruebas-8', titulo: 'Reporte de calidad', descripcion: 'Evaluación de la calidad del software basada en los resultados de las pruebas y métricas de calidad.', completada: false, enlace: '' }
    ],
    despliegue: [
        { id: 'despliegue-1', titulo: 'Manual de usuario', descripcion: 'Guía completa para usuarios finales con capturas de pantalla paso a paso de todas las funcionalidades.', completada: false, enlace: '' },
        { id: 'despliegue-2', titulo: 'Manual técnico', descripcion: 'Documentación técnica para administradores y personal de sistemas sobre la instalación y mantenimiento.', completada: false, enlace: '' },
        { id: 'despliegue-3', titulo: 'Registro de despliegue', descripcion: 'Documento que registra fecha, hora y todos los cambios realizados durante el despliegue en producción.', completada: false, enlace: '' },
        { id: 'despliegue-4', titulo: 'Plan de capacitación', descripcion: 'Plan detallado para capacitar a usuarios y administradores en el uso del sistema desplegado.', completada: false, enlace: '' }
    ]
};

// Función para crear una fila de tabla
function crearFilaTarea(tarea, fase) {
    const tr = document.createElement('tr');
    tr.id = tarea.id;
    
    // Determinar el estado visual basado en completada y estado
    const estadoClass = tarea.completada ? 'text-decoration-line-through text-muted' : '';
    const estadoText = tarea.estado || (tarea.completada ? 'completada' : 'pendiente');
    
    tr.innerHTML = `
        <td class="text-center">
            <input type="checkbox" class="task-checkbox" ${tarea.completada ? 'checked' : ''} 
                   onchange="toggleTarea('${tarea.id}', '${fase}')">
        </td>
        <td>
            <div class="task-title ${estadoClass}">${tarea.titulo}</div>
            <small class="text-muted">Estado: ${estadoText}</small>
        </td>
        <td>
            <div class="task-description">${tarea.descripcion}</div>
        </td>
        <td>
            <div class="task-actions">
                <button class="btn-edit-task" onclick="openTaskModal('${tarea.id}', '${fase}')" title="Editar tarea">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-delete-task" onclick="deleteTask('${tarea.id}', '${fase}')" title="Eliminar tarea">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </td>
    `;
    
    return tr;
}

// Función para renderizar todas las fases
function renderizarFases() {
    Object.keys(tareasData).forEach(fase => {
        const tbody = document.getElementById(`${fase}-tbody`);
        tbody.innerHTML = '';
        
        tareasData[fase].forEach(tarea => {
            const fila = crearFilaTarea(tarea, fase);
            tbody.appendChild(fila);
        });
        
        actualizarProgresoFase(fase);
    });
    
    actualizarProgresoGeneral();
}

// Función para alternar el estado de una tarea
function toggleTarea(id, fase) {
    const tarea = tareasData[fase].find(t => t.id === id);
    if (tarea) {
        tarea.completada = !tarea.completada;
        
        // Actualizar el estado basado en completada
        if (tarea.completada) {
            tarea.estado = 'completada';
        } else {
            tarea.estado = 'pendiente';
        }
        
        const fila = document.getElementById(id);
        
        // Actualizar la fila
        const titulo = fila.querySelector('.task-title');
        const estadoText = fila.querySelector('small');
        
        if (tarea.completada) {
            titulo.classList.add('text-decoration-line-through', 'text-muted');
        } else {
            titulo.classList.remove('text-decoration-line-through', 'text-muted');
        }
        
        if (estadoText) {
            estadoText.textContent = `Estado: ${tarea.estado}`;
        }
        
        actualizarProgresoFase(fase);
        actualizarProgresoGeneral();
        guardarEnLocalStorage();
    }
}

// Función para guardar los enlaces de una fase
function guardarEnlacesFase(fase) {
    const textarea = document.getElementById(`enlaces-${fase}`);
    if (textarea) {
        const enlaces = textarea.value;
        // Guardar en localStorage
        localStorage.setItem(`enlaces-${fase}`, enlaces);
    }
}

// Función para cargar enlaces guardados
function cargarEnlacesGuardados() {
    const fases = ['analisis', 'diseno', 'implementacion', 'pruebas', 'despliegue'];
    fases.forEach(fase => {
        const enlacesGuardados = localStorage.getItem(`enlaces-${fase}`);
        if (enlacesGuardados) {
            const textarea = document.getElementById(`enlaces-${fase}`);
            if (textarea) {
                textarea.value = enlacesGuardados;
            }
        }
    });
}

// Función para actualizar progreso de una fase
function actualizarProgresoFase(fase) {
    const tareas = tareasData[fase];
    const completadas = tareas.filter(t => t.completada).length;
    const total = tareas.length;
    const porcentaje = Math.round((completadas / total) * 100);
    
    // Actualizar estadísticas generales
    const statsElement = document.getElementById(`${fase}-stats`);
    if (statsElement) {
        statsElement.textContent = completadas;
    }
    
    // Actualizar contadores de progreso
    const completadasElement = document.getElementById(`${fase}-completadas`);
    const totalElement = document.getElementById(`${fase}-total`);
    if (completadasElement && totalElement) {
        completadasElement.textContent = completadas;
        totalElement.textContent = total;
    }
    
    // Actualizar mini barra de progreso
    const miniFill = document.getElementById(`mini-fill-${fase}`);
    if (miniFill) {
        miniFill.style.width = `${porcentaje}%`;
    }
    
    // Actualizar barra de progreso principal
    const progressFill = document.getElementById(`progress-fill-${fase}`);
    const progressText = document.getElementById(`progress-text-${fase}`);
    if (progressFill && progressText) {
        progressFill.style.width = `${porcentaje}%`;
        progressText.textContent = `${porcentaje}%`;
        
        // Agregar clase de animación cuando se complete
        if (porcentaje === 100) {
            progressFill.classList.add('completed');
        } else {
            progressFill.classList.remove('completed');
        }
    }
}

// Función para actualizar progreso general
function actualizarProgresoGeneral() {
    let totalTareas = 0;
    let totalCompletadas = 0;
    
    Object.keys(tareasData).forEach(fase => {
        const tareas = tareasData[fase];
        totalTareas += tareas.length;
        totalCompletadas += tareas.filter(t => t.completada).length;
    });
    
    const porcentajeGeneral = Math.round((totalCompletadas / totalTareas) * 100);
    
    // Actualizar porcentaje general
    const overallPercentage = document.getElementById('overallPercentage');
    
    if (overallPercentage) {
        overallPercentage.textContent = `${porcentajeGeneral}%`;
    }
    
    // Actualizar estadísticas generales
    const totalTasksElement = document.getElementById('total-tasks');
    const completedTasksElement = document.getElementById('completed-tasks');
    
    if (totalTasksElement && completedTasksElement) {
        totalTasksElement.textContent = totalTareas;
        completedTasksElement.textContent = totalCompletadas;
    }
}

// Función para guardar datos en localStorage
function guardarEnLocalStorage() {
    localStorage.setItem('fabricasoftTareas', JSON.stringify(tareasData));
}

// Función para cargar datos desde localStorage
function cargarDesdeLocalStorage() {
    const datosGuardados = localStorage.getItem('fabricasoftTareas');
    if (datosGuardados) {
        const datos = JSON.parse(datosGuardados);
        Object.keys(datos).forEach(fase => {
            if (tareasData[fase]) {
                tareasData[fase] = datos[fase];
            }
        });
    }
}

// Función para exportar progreso
function exportarProgreso() {
    const progreso = {
        fecha: new Date().toISOString(),
        totalTareas: 0,
        tareasCompletadas: 0,
        progresoPorFase: {},
        tareas: tareasData,
        enlaces: {}
    };
    
    Object.keys(tareasData).forEach(fase => {
        const tareas = tareasData[fase];
        progreso.totalTareas += tareas.length;
        progreso.tareasCompletadas += tareas.filter(t => t.completada).length;
        progreso.progresoPorFase[fase] = {
            total: tareas.length,
            completadas: tareas.filter(t => t.completada).length,
            porcentaje: Math.round((tareas.filter(t => t.completada).length / tareas.length) * 100)
        };
        
        // Agregar enlaces de la fase
        const textarea = document.getElementById(`enlaces-${fase}`);
        if (textarea) {
            progreso.enlaces[fase] = textarea.value;
        }
    });
    
    const blob = new Blob([JSON.stringify(progreso, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `progreso-fabricasoft-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
}

// Función para exportar como imagen
function exportarImagen() {
    Swal.fire({
        title: 'Generando Imagen',
        text: 'Preparando la captura del tablero...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    const elemento = document.querySelector('.container-fluid');
    
    html2canvas(elemento, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff'
    }).then(canvas => {
        Swal.close();
        
        const link = document.createElement('a');
        link.download = `tablero-fabricasoft-${new Date().toISOString().split('T')[0]}.png`;
        link.href = canvas.toDataURL('image/png');
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        Swal.fire({
            title: 'Exportación Completada',
            text: 'La imagen se ha descargado correctamente',
            icon: 'success',
            timer: 2000,
            showConfirmButton: false
        });
    }).catch(error => {
        console.error('Error al generar imagen:', error);
        Swal.fire({
            title: 'Error en la Exportación',
            text: 'No se pudo generar la imagen',
            icon: 'error'
        });
    });
}

// Función para ir a una fase específica
function irAFase(fase) {
    // Agregar efecto visual de click
    const card = document.querySelector(`[data-phase="${fase}"]`);
    if (card) {
        card.classList.add('clicked');
        setTimeout(() => {
            card.classList.remove('clicked');
        }, 300);
    }
    
    // Hacer scroll suave a la fase correspondiente
    const faseElement = document.getElementById(`fase-${fase}`);
    if (faseElement) {
        faseElement.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
        
        // Agregar un resaltado temporal
        faseElement.style.boxShadow = '0 0 0 4px rgba(16, 185, 129, 0.3)';
        setTimeout(() => {
            faseElement.style.boxShadow = '';
        }, 2000);
    }
}

// Función para limpiar datos
function limpiarDatos() {
    Swal.fire({
        title: '¿Limpiar Datos?',
        text: 'Esta acción eliminará todos los datos guardados. ¿Estás seguro?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Sí, limpiar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            localStorage.removeItem('fabricasoftTareas');
            location.reload();
        }
    });
}

// Modal para editar tareas
const taskModal = document.createElement('div');
taskModal.className = 'task-modal';
taskModal.id = 'taskModal';
taskModal.innerHTML = `
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title">Editar Tarea</h3>
            <button class="close-modal" onclick="closeTaskModal()">&times;</button>
        </div>
        <div class="modal-body">
            <form id="editTaskForm">
                <input type="hidden" id="editTaskId" name="taskId">
                <input type="hidden" id="editTaskPhase" name="phase">
                <div class="modal-form-group">
                    <label class="modal-label">Título de la Tarea</label>
                    <input type="text" class="modal-input" id="editTaskTitulo" name="titulo" required>
                </div>
                <div class="modal-form-group">
                    <label class="modal-label">Descripción</label>
                    <textarea class="modal-textarea" id="editTaskDescripcion" name="descripcion" required></textarea>
                </div>
                <div class="modal-form-group">
                    <label class="modal-label">Estado</label>
                    <select class="modal-select" id="editTaskEstado" name="estado" required>
                        <option value="pendiente">Pendiente</option>
                        <option value="en_progreso">En Progreso</option>
                        <option value="revision">En Revisión</option>
                        <option value="completada">Completada</option>
                    </select>
                </div>
            </form>
        </div>
        <div class="modal-actions">
            <button type="button" class="btn-modal cancel" onclick="closeTaskModal()">Cancelar</button>
            <button type="button" class="btn-modal save" onclick="saveTaskChanges()">Guardar Cambios</button>
        </div>
    </div>
`;
document.body.appendChild(taskModal);

// Función para abrir modal de edición
function openTaskModal(taskId, phase) {
    const task = tareasData[phase].find(t => t.id === taskId);
    if (task) {
        document.getElementById('editTaskId').value = taskId;
        document.getElementById('editTaskPhase').value = phase;
        document.getElementById('editTaskTitulo').value = task.titulo;
        document.getElementById('editTaskDescripcion').value = task.descripcion;
        document.getElementById('editTaskEstado').value = task.estado || 'pendiente';
        
        document.getElementById('taskModal').style.display = 'block';
    }
}

// Función para cerrar modal
function closeTaskModal() {
    document.getElementById('taskModal').style.display = 'none';
}

// Función para guardar cambios de tarea
function saveTaskChanges() {
    const taskId = document.getElementById('editTaskId').value;
    const phase = document.getElementById('editTaskPhase').value;
    const titulo = document.getElementById('editTaskTitulo').value;
    const descripcion = document.getElementById('editTaskDescripcion').value;
    const estado = document.getElementById('editTaskEstado').value;
    
    if (!titulo || !descripcion) {
        Swal.fire({
            title: 'Error',
            text: 'Por favor complete todos los campos requeridos',
            icon: 'error'
        });
        return;
    }
    
    const task = tareasData[phase].find(t => t.id === taskId);
    if (task) {
        task.titulo = titulo;
        task.descripcion = descripcion;
        task.estado = estado;
        task.completada = estado === 'completada';
        
        renderizarFases();
        guardarEnLocalStorage();
        closeTaskModal();
        
        Swal.fire({
            title: 'Éxito',
            text: 'Tarea actualizada correctamente',
            icon: 'success',
            timer: 2000,
            showConfirmButton: false
        });
    }
}

// Función para eliminar tarea
function deleteTask(taskId, phase) {
    Swal.fire({
        title: '¿Eliminar Tarea?',
        text: 'Esta acción no se puede deshacer',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            tareasData[phase] = tareasData[phase].filter(t => t.id !== taskId);
            renderizarFases();
            guardarEnLocalStorage();
            
            Swal.fire({
                title: 'Eliminada',
                text: 'Tarea eliminada correctamente',
                icon: 'success',
                timer: 2000,
                showConfirmButton: false
            });
        }
    });
}

// Función para agregar nueva tarea
function addNewTask(phase, formData) {
    const newTaskId = `${phase}-${Date.now()}`;
    const newTask = {
        id: newTaskId,
        titulo: formData.get('titulo'),
        descripcion: formData.get('descripcion'),
        estado: formData.get('estado'),
        completada: formData.get('estado') === 'completada',
        enlace: ''
    };
    
    tareasData[phase].push(newTask);
    renderizarFases();
    guardarEnLocalStorage();
    
    // Limpiar formulario
    const form = document.getElementById(`add-task-form-${phase}`);
    form.reset();
    
    Swal.fire({
        title: 'Éxito',
        text: 'Nueva tarea agregada correctamente',
        icon: 'success',
        timer: 2000,
        showConfirmButton: false
    });
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    cargarDesdeLocalStorage();
    renderizarFases();
    cargarEnlacesGuardados();
    
    // Agregar event listeners para los campos de enlace
    const fases = ['analisis', 'diseno', 'implementacion', 'pruebas', 'despliegue'];
    fases.forEach(fase => {
        const textarea = document.getElementById(`enlaces-${fase}`);
        if (textarea) {
            textarea.addEventListener('blur', () => guardarEnlacesFase(fase));
            textarea.addEventListener('input', () => guardarEnlacesFase(fase));
        }
        
        // Agregar event listeners para formularios de nueva tarea
        const form = document.getElementById(`add-task-form-${fase}`);
        if (form) {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                const formData = new FormData(this);
                addNewTask(fase, formData);
            });
        }
    });
    
    // Agregar event listeners para las tarjetas de fases
    const phaseCards = document.querySelectorAll('.phase-card');
    phaseCards.forEach(card => {
        card.addEventListener('click', function() {
            const fase = this.getAttribute('data-phase');
            irAFase(fase);
        });
    });
    
    // Cerrar modal al hacer click fuera de él
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('taskModal');
        if (event.target === modal) {
            closeTaskModal();
        }
    });
});
</script>
@endsection 