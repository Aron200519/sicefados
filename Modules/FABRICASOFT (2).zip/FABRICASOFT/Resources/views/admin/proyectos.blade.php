@extends('fabricasoft::layouts.masteradmin')

@section('content')
<div class="container mx-auto px-4 py-6">
    <!-- Header -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-2">Gestión de Proyectos</h1>
        <p class="text-gray-600">Administra y monitorea todos los proyectos del sistema</p>
    </div>

    <!-- Filtros -->
    <div class="bg-white rounded-lg shadow-md mb-8">
        <div class="p-6">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label for="filtro_status" class="block text-sm font-medium text-gray-700 mb-2">Estado</label>
                    <select id="filtro_status" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="">Todos los estados</option>
                        <option value="pendiente">Pendiente</option>
                        <option value="en_desarrollo">En Desarrollo</option>
                        <option value="aprobada">Aprobada</option>
                        <option value="completado">Completado</option>
                        <option value="rechazado">Rechazado</option>
                    </select>
                </div>
                <div>
                    <label for="filtro_asignacion" class="block text-sm font-medium text-gray-700 mb-2">Asignación</label>
                    <select id="filtro_asignacion" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="">Todos</option>
                        <option value="asignado">Asignados</option>
                        <option value="sin_asignar">Sin Asignar</option>
                    </select>
                </div>
                <div>
                    <label for="filtro_fecha" class="block text-sm font-medium text-gray-700 mb-2">Fecha</label>
                    <select id="filtro_fecha" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value="">Todas las fechas</option>
                        <option value="hoy">Hoy</option>
                        <option value="semana">Esta semana</option>
                        <option value="mes">Este mes</option>
                        <option value="trimestre">Este trimestre</option>
                    </select>
                </div>
                <div class="flex items-end space-x-2">
                    <button onclick="aplicarFiltros()" class="flex-1 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors">
                        <i class="fas fa-filter mr-2"></i>Aplicar Filtros
                    </button>
                    <button onclick="limpiarFiltros()" class="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700 transition-colors">
                        <i class="fas fa-times mr-1"></i>Limpiar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabla de Proyectos -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex justify-between items-center">
                <h2 class="text-xl font-semibold text-gray-800">Lista de Proyectos</h2>
                <div class="flex space-x-2">
                    <button onclick="exportarProyectos()" class="bg-blue-600 text-white px-4 py-2 rounded-md text-sm hover:bg-blue-700 transition-colors">
                        <i class="fas fa-download mr-2"></i>Exportar
                    </button>
                    <button onclick="refrescarTabla()" class="bg-gray-600 text-white px-4 py-2 rounded-md text-sm hover:bg-gray-700 transition-colors">
                        <i class="fas fa-sync-alt mr-2"></i>Refrescar
                    </button>
                </div>
            </div>
        </div>
        
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Proyecto
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Cliente
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Estado
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Progreso
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Equipo de Desarrollo
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Fecha
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Acciones
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200" id="tabla-proyectos">
                    @foreach($proyectos as $proyecto)
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <div class="flex-shrink-0 h-10 w-10">
                                    <div class="h-10 w-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-semibold">
                                        <i class="fas fa-project-diagram"></i>
                                    </div>
                                </div>
                                <div class="ml-4">
                                    @php
                            $formularioNombre = null;
                            if ($proyecto->formulario_id) {
                                $formulario = \DB::table('formularios')->where('id', $proyecto->formulario_id)->first();
                                $formularioNombre = $formulario ? $formulario->nombre : null;
                            }
                        @endphp
                        <div class="text-sm font-medium text-gray-900">
                            {{ $proyecto->project_name }}
                            @if($formularioNombre)
                                <span class="text-sm text-blue-600">({{ $formularioNombre }})</span>
                            @endif
                        </div>
                                    <div class="text-sm text-gray-500">{{ $proyecto->company_name }}</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900">{{ $proyecto->applicant_name }}</div>
                            <div class="text-sm text-gray-500">{{ $proyecto->email }}</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium {{ $proyecto->estado_clase_css }}">
                                {{ $proyecto->estado_legible }}
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <div class="flex-1 bg-gray-200 rounded-full h-2 mr-2">
                                    <div class="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                                         style="width: {{ $proyecto->calcularProgresoCompleto() }}%"></div>
                                </div>
                                <span class="text-xs text-gray-600">{{ $proyecto->calcularProgresoCompleto() }}%</span>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            @if($proyecto->assignedUser)
                                <div class="space-y-2">
                                    <!-- Desarrollador Principal -->
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-8 w-8">
                                            <div class="h-8 w-8 rounded-full bg-green-500 flex items-center justify-center text-white font-semibold text-sm">
                                                {{ strtoupper(substr($proyecto->assignedUser->nickname, 0, 1)) }}
                                            </div>
                                        </div>
                                        <div class="ml-3">
                                            <div class="text-sm font-medium text-gray-900">
                                                {{ $proyecto->assignedUser->nickname }}
                                                <span class="inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 ml-1">
                                                    <i class="fas fa-star text-yellow-500 mr-1"></i>Principal
                                                </span>
                                            </div>
                                            <div class="text-sm text-gray-500">{{ $proyecto->assignedUser->email }}</div>
                                        </div>
                                    </div>
                                    
                                    <!-- Equipo Adicional -->
                                    @if($proyecto->equipo_desarrollo)
                                        @php
                                            $equipo = json_decode($proyecto->equipo_desarrollo, true);
                                        @endphp
                                        @if($equipo && count($equipo) > 0)
                                            <div class="ml-11 space-y-1">
                                                @foreach($equipo as $miembro)
                                                    @php
                                                        $usuario = \App\Models\User::find($miembro['user_id']);
                                                        $rolColors = [
                                                            'desarrollador' => 'bg-blue-100 text-blue-800',
                                                            'disenador' => 'bg-green-100 text-green-800',
                                                            'tester' => 'bg-red-100 text-red-800',
                                                            'analista' => 'bg-purple-100 text-purple-800'
                                                        ];
                                                        $rolIcons = [
                                                            'desarrollador' => 'fas fa-code',
                                                            'disenador' => 'fas fa-palette',
                                                            'tester' => 'fas fa-bug',
                                                            'analista' => 'fas fa-chart-line'
                                                        ];
                                                    @endphp
                                                    @if($usuario)
                                                        <div class="flex items-center text-xs">
                                                            <div class="flex-shrink-0 h-6 w-6">
                                                                <div class="h-6 w-6 rounded-full bg-blue-500 flex items-center justify-center text-white font-semibold text-xs">
                                                                    {{ strtoupper(substr($usuario->nickname, 0, 1)) }}
                                                                </div>
                                                            </div>
                                                            <div class="ml-2">
                                                                <span class="text-gray-700">{{ $usuario->nickname }}</span>
                                                                <span class="inline-flex items-center px-1 py-0.5 rounded-full text-xs font-medium {{ $rolColors[$miembro['rol']] ?? 'bg-gray-100 text-gray-800' }} ml-1">
                                                                    <i class="{{ $rolIcons[$miembro['rol']] ?? 'fas fa-user' }} mr-1"></i>{{ ucfirst($miembro['rol']) }}
                                                                </span>
                                                            </div>
                                                        </div>
                                                    @endif
                                                @endforeach
                                            </div>
                                        @endif
                                    @endif
                                </div>
                            @else
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                    Sin asignar
                                </span>
                            @endif
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {{ \Carbon\Carbon::parse($proyecto->created_at)->format('d/m/Y H:i') }}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <div class="flex space-x-2">
                                <button onclick="verDetallesProyecto({{ $proyecto->id }})" 
                                        class="text-blue-600 hover:text-blue-900">
                                    <i class="fas fa-eye"></i>
                                </button>
                                @if(!$proyecto->assignedUser)
                                    <button onclick="asignarDesarrollador({{ $proyecto->id }})" 
                                            class="text-green-600 hover:text-green-900" title="Asignar Equipo">
                                        <i class="fas fa-users"></i>
                                    </button>
                                @else
                                    <button onclick="editarEquipo({{ $proyecto->id }})" 
                                            class="text-yellow-600 hover:text-yellow-900" title="Editar Equipo">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                @endif
                                <button onclick="eliminarProyecto({{ $proyecto->id }})" 
                                        class="text-red-600 hover:text-red-900" title="Eliminar">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal para Asignar Desarrollador -->
<div id="modalAsignarDesarrollador" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50">
    <div class="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-1/2 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-medium text-gray-900">Asignar Equipo de Desarrollo</h3>
                <button type="button" onclick="cerrarModalAsignar()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form id="formAsignarEquipo" method="POST" action="{{ route('fabricasoft.admin.asignar-desarrollador') }}">
                @csrf
                <input type="hidden" name="proyecto_id" id="proyecto_id">
                
                <!-- Desarrollador Principal -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-star text-yellow-500 mr-1"></i>Desarrollador Principal
                    </label>
                    <select name="desarrollador_id" id="desarrollador_id" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500" required>
                        <option value="">Seleccionar desarrollador principal...</option>
                    </select>
                </div>
                
                <!-- Equipo Adicional -->
                <div class="mb-6">
                    <div class="flex justify-between items-center mb-2">
                        <label class="block text-sm font-medium text-gray-700">
                            <i class="fas fa-users text-blue-500 mr-1"></i>Equipo Adicional
                        </label>
                        <button type="button" onclick="agregarMiembroEquipo()" class="text-green-600 hover:text-green-800 text-sm">
                            <i class="fas fa-plus mr-1"></i>Agregar Miembro
                        </button>
                    </div>
                    <div id="equipo-container">
                        <!-- Los miembros del equipo se agregan aquí dinámicamente -->
                    </div>
                </div>
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="cerrarModalAsignar()" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">
                        Cancelar
                    </button>
                    <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">
                        <i class="fas fa-save mr-1"></i>Asignar Equipo
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection

@section('scripts')
<script>
let desarrolladores = [];
let equipoCounter = 0;

// Cargar desarrolladores al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    cargarDesarrolladores();
});

async function cargarDesarrolladores() {
    try {
        // Simular carga de desarrolladores - reemplazar con llamada real a la API
        desarrolladores = [
            { id: 1, nickname: 'Juan Pérez', email: 'juan@example.com' },
            { id: 2, nickname: 'María García', email: 'maria@example.com' },
            { id: 3, nickname: 'Carlos López', email: 'carlos@example.com' }
        ];
        
        console.log('Desarrolladores cargados:', desarrolladores.length);
    } catch (error) {
        console.error('Error cargando desarrolladores:', error);
    }
}

function aplicarFiltros() {
    const status = document.getElementById('filtro_status').value;
    const asignacion = document.getElementById('filtro_asignacion').value;
    const fecha = document.getElementById('filtro_fecha').value;
    
    const filas = document.querySelectorAll('#tabla-proyectos tr');
    let proyectosMostrados = 0;
    
    filas.forEach(fila => {
        let mostrar = true;
        
        // Filtro por estado
        if (status && mostrar) {
            const estadoSpan = fila.querySelector('span[class*="inline-flex"]');
            if (estadoSpan) {
                const estadoTexto = estadoSpan.textContent.trim().toLowerCase();
                const estadoBuscado = status.replace('_', ' ');
                if (!estadoTexto.includes(estadoBuscado)) {
                    mostrar = false;
                }
            }
        }
        
        // Filtro por asignación
        if (asignacion && mostrar) {
            const equipoCell = fila.cells[4]; // Columna de equipo
            if (equipoCell) {
                const tieneAsignacion = !equipoCell.textContent.includes('Sin asignar');
                if ((asignacion === 'asignado' && !tieneAsignacion) || 
                    (asignacion === 'sin_asignar' && tieneAsignacion)) {
                    mostrar = false;
                }
            }
        }
        
        // Filtro por fecha (básico - solo para demostración)
        if (fecha && mostrar) {
            const fechaCell = fila.cells[5]; // Columna de fecha
            if (fechaCell) {
                const fechaTexto = fechaCell.textContent.trim();
                const fechaProyecto = new Date(fechaTexto.split(' ')[0].split('/').reverse().join('-'));
                const hoy = new Date();
                
                switch(fecha) {
                    case 'hoy':
                        if (fechaProyecto.toDateString() !== hoy.toDateString()) {
                            mostrar = false;
                        }
                        break;
                    case 'semana':
                        const semanaAtras = new Date(hoy.getTime() - 7 * 24 * 60 * 60 * 1000);
                        if (fechaProyecto < semanaAtras) {
                            mostrar = false;
                        }
                        break;
                    case 'mes':
                        if (fechaProyecto.getMonth() !== hoy.getMonth() || 
                            fechaProyecto.getFullYear() !== hoy.getFullYear()) {
                            mostrar = false;
                        }
                        break;
                }
            }
        }
        
        // Mostrar u ocultar la fila
        if (mostrar) {
            fila.style.display = '';
            proyectosMostrados++;
        } else {
            fila.style.display = 'none';
        }
    });
    
    // Mostrar mensaje con resultados
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true
    });
    
    Toast.fire({
        icon: 'success',
        title: `Filtros aplicados (${proyectosMostrados} proyectos encontrados)`
    });
}

function limpiarFiltros() {
    // Limpiar todos los selects
    document.getElementById('filtro_status').value = '';
    document.getElementById('filtro_asignacion').value = '';
    document.getElementById('filtro_fecha').value = '';
    
    // Mostrar todas las filas
    const filas = document.querySelectorAll('#tabla-proyectos tr');
    filas.forEach(fila => {
        fila.style.display = '';
    });
    
    // Mostrar mensaje
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 2000,
        timerProgressBar: true
    });
    
    Toast.fire({
        icon: 'info',
        title: 'Filtros limpiados - Mostrando todos los proyectos'
    });
}

function exportarProyectos() {
    Swal.fire({
        icon: 'info',
        title: 'Exportar proyectos',
        text: 'Funcionalidad de exportación en desarrollo',
        confirmButtonColor: '#2ECC71'
    });
}

function refrescarTabla() {
    location.reload();
}

function asignarDesarrollador(proyectoId) {
    document.getElementById('proyecto_id').value = proyectoId;
    
    // Limpiar contenedor de equipo
    document.getElementById('equipo-container').innerHTML = '';
    
    // Llenar el select principal con desarrolladores
    const select = document.getElementById('desarrollador_id');
    select.innerHTML = '<option value="">Seleccionar desarrollador principal...</option>';
    
    desarrolladores.forEach(dev => {
        const option = document.createElement('option');
        option.value = dev.id;
        option.textContent = `${dev.nickname} (${dev.email})`;
        select.appendChild(option);
    });
    
    // Cargar datos existentes del equipo si los hay
    cargarEquipoExistente(proyectoId);
    
    document.getElementById('modalAsignarDesarrollador').classList.remove('hidden');
}

function cerrarModalAsignar() {
    document.getElementById('modalAsignarDesarrollador').classList.add('hidden');
}

function agregarMiembroEquipo() {
    equipoCounter++;
    const container = document.getElementById('equipo-container');
    
    const miembroDiv = document.createElement('div');
    miembroDiv.className = 'flex items-center space-x-2 mb-2';
    miembroDiv.id = `miembro-${equipoCounter}`;
    
    miembroDiv.innerHTML = `
        <select name="equipo[${equipoCounter}][user_id]" class="flex-1 border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
            <option value="">Seleccionar desarrollador...</option>
            ${desarrolladores.map(dev => `<option value="${dev.id}">${dev.nickname} (${dev.email})</option>`).join('')}
        </select>
        <select name="equipo[${equipoCounter}][rol]" class="w-32 border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
            <option value="desarrollador">Desarrollador</option>
            <option value="disenador">Diseñador</option>
            <option value="tester">Tester</option>
            <option value="analista">Analista</option>
        </select>
        <button type="button" onclick="eliminarMiembroEquipo(${equipoCounter})" class="text-red-600 hover:text-red-800">
            <i class="fas fa-trash"></i>
        </button>
    `;
    
    container.appendChild(miembroDiv);
}

function eliminarMiembroEquipo(id) {
    const elemento = document.getElementById(`miembro-${id}`);
    if (elemento) {
        elemento.remove();
    }
}

async function cargarEquipoExistente(proyectoId) {
    try {
        const response = await fetch(`{{ route('fabricasoft.admin.proyecto.equipo', '') }}/${proyectoId}`);
        const data = await response.json();
        
        if (data.success && data.equipo) {
            // Establecer desarrollador principal
            if (data.desarrollador_principal) {
                document.getElementById('desarrollador_id').value = data.desarrollador_principal.id;
            }
            
            // Agregar miembros del equipo
            data.equipo.forEach(miembro => {
                agregarMiembroEquipo();
                const lastMember = document.querySelector('#equipo-container > div:last-child');
                lastMember.querySelector('select[name*="[user_id]"]').value = miembro.user_id;
                lastMember.querySelector('select[name*="[rol]"]').value = miembro.rol;
            });
        }
    } catch (error) {
        console.error('Error cargando equipo existente:', error);
    }
}

function editarEquipo(proyectoId) {
    asignarDesarrollador(proyectoId); // Reutilizar la misma funcionalidad
}

function verDetallesProyecto(proyectoId) {
    Swal.fire({
        icon: 'info',
        title: 'Ver detalles',
        text: 'Funcionalidad en desarrollo',
        confirmButtonColor: '#2ECC71'
    });
}

function eliminarProyecto(proyectoId) {
    Swal.fire({
        title: '¿Estás seguro?',
        text: 'Esta acción no se puede deshacer',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            // Aquí harías la petición para eliminar
            Swal.fire(
                'Eliminado',
                'El proyecto ha sido eliminado.',
                'success'
            );
        }
    });
}
</script>
@endsection