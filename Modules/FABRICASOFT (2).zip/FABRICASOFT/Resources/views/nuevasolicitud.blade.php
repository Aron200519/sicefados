@extends('fabricasoft::layouts.masternuevasolicitud')
@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- Mensajes de sesión -->
    @if(session('success'))
        <div class="mb-6 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg relative shadow-md" role="alert" id="alert-success">
            <div class="flex items-center">
                <i class="fas fa-check-circle mr-3 text-green-600"></i>
                <span class="font-semibold">{{ session('success') }}</span>
                <button onclick="closeAlert('alert-success')" class="ml-auto text-green-500 hover:text-green-700">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
    @endif

    @if(session('error'))
        <div class="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg relative shadow-md" role="alert" id="alert-error">
            <div class="flex items-center">
                <i class="fas fa-exclamation-circle mr-3 text-red-600"></i>
                <span class="font-semibold">{{ session('error') }}</span>
                <button onclick="closeAlert('alert-error')" class="ml-auto text-red-500 hover:text-red-700">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
    @endif

    <!-- Header mejorado -->
    <div class="mb-8 bg-gradient-to-r from-green-600 to-green-700 rounded-xl shadow-lg p-6 text-white">
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-bold mb-2 flex items-center">
                    <i class="fas fa-clipboard-list mr-3"></i>
                    Solicitudes Enviadas
                </h1>
                <p class="text-green-100">Gestiona y monitorea el estado de todas tus solicitudes de desarrollo de software con información detallada de formularios</p>
            </div>
            <div>
                <a href="{{ route('fabricasoft.usuario.seguimiento.formularios') }}" 
                   class="bg-white text-green-600 px-6 py-3 rounded-lg hover:bg-green-50 transition-all duration-200 flex items-center font-semibold shadow-md hover:shadow-lg transform hover:scale-105">
                    <i class="fas fa-tasks mr-2"></i>
                    Ver Seguimiento
                </a>
            </div>
        </div>
    </div>
    
    <!-- Filtros de búsqueda mejorados -->
    <div class="bg-white rounded-xl shadow-lg mb-8 border border-gray-100">
        <div class="p-6 border-b border-gray-100">
            <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <i class="fas fa-filter text-green-600 mr-2"></i>
                Filtros de Búsqueda
            </h3>
            <form method="GET" action="{{ route('fabricasoft.nuevasolicitud') }}" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div>
                    <label for="status" class="block text-sm font-semibold text-gray-700 mb-2">Estado de la Solicitud</label>
                    <select id="status" name="status" class="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200">
                        <option value="">Todos los estados</option>
                        <option value="pendiente" {{ request('status') == 'pendiente' ? 'selected' : '' }}>⏳ Pendiente</option>
                        <option value="aprobada" {{ request('status') == 'aprobada' ? 'selected' : '' }}>✅ Aprobada</option>
                        <option value="rechazada" {{ request('status') == 'rechazada' ? 'selected' : '' }}>❌ Rechazada</option>
                        <option value="en_desarrollo" {{ request('status') == 'en_desarrollo' ? 'selected' : '' }}>🚀 En Desarrollo</option>
                    </select>
                </div>
                <div>
                    <label for="project_name" class="block text-sm font-semibold text-gray-700 mb-2">Nombre del Proyecto</label>
                    <input type="text" id="project_name" name="project_name" value="{{ request('project_name') }}" 
                           class="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                           placeholder="Buscar por proyecto...">
                </div>
                <div class="flex items-end space-x-3">
                    <button type="submit" class="flex-1 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-all duration-200 flex items-center justify-center font-semibold shadow-md hover:shadow-lg transform hover:scale-105">
                        <i class="fas fa-search mr-2"></i>
                        Buscar
                    </button>
                    <a href="{{ route('fabricasoft.nuevasolicitud') }}" 
                       class="flex-1 bg-gray-500 text-white px-6 py-3 rounded-lg hover:bg-gray-600 transition-all duration-200 flex items-center justify-center font-semibold shadow-md hover:shadow-lg transform hover:scale-105">
                        <i class="fas fa-eraser mr-2"></i>
                        Limpiar
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Tabla de solicitudes enviadas mejorada -->
    <div class="bg-white rounded-xl shadow-lg border border-gray-100">
        <div class="p-6 border-b border-gray-100">
            <div class="flex justify-between items-center">
                <h2 class="text-xl font-semibold text-gray-800 flex items-center">
                    <i class="fas fa-list-alt text-green-600 mr-2"></i>
                    Solicitudes Enviadas
                </h2>
                <div class="text-sm text-gray-600 bg-gray-100 px-3 py-1 rounded-full">
                    <i class="fas fa-chart-bar mr-1"></i>
                    Mostrando {{ isset($userRequests) ? $userRequests->count() : 0 }} solicitudes
                </div>
                <!-- Botón de prueba para el modal -->
                <button onclick="abrirModalEditarFormulario(1, 1)" 
                        class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-all duration-200 flex items-center text-sm">
                    <i class="fas fa-edit mr-2"></i>
                    Probar Modal
                </button>
            </div>
        </div>
        <div class="p-6">
            @if($userRequests->count() > 0)
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Proyecto</th>
                                <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Formulario</th>
                                <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Empresa</th>
                                <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Estado</th>
                                <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Fecha</th>
                                <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Acciones</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-100">
                            @foreach($userRequests as $request)
                                @php
                                    $formulario = \Modules\FABRICASOFT\Entities\Formulario::find($request->formulario_id);
                                    $formularioNombre = $formulario ? $formulario->nombre : 'Formulario no especificado';
                                @endphp
                                <tr class="hover:bg-green-50 transition-all duration-200">
                                    <td class="px-6 py-4">
                                        <div class="text-sm font-semibold text-gray-900">{{ $request->project_name }}</div>
                                        <div class="text-sm text-gray-600 mt-1">
                                            <i class="fas fa-user mr-1"></i>{{ $request->applicant_name }}
                                        </div>
                                        <div class="text-xs text-gray-500 mt-1">
                                            <i class="fas fa-id-card mr-1"></i>{{ $request->document_type ?? 'No especificado' }}: {{ $request->document_number ?? 'No especificado' }}
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-gray-900 font-medium">
                                            <i class="fas fa-file-alt text-green-600 mr-2"></i>{{ $formularioNombre }}
                                        </div>
                                        <div class="text-xs text-gray-500 mt-1">
                                            <i class="fas fa-calendar mr-1"></i>ID: {{ $request->formulario_id ?? 'N/A' }}
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-gray-900 font-medium">
                                            <i class="fas fa-building mr-1"></i>{{ $request->company_name }}
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        @if($request->status == 'pendiente')
                                            <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-yellow-100 text-yellow-800 border border-yellow-200">
                                                <i class="fas fa-clock mr-1"></i>
                                                Pendiente
                                            </span>
                                        @elseif($request->status == 'aprobada')
                                            <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800 border border-green-200">
                                                <i class="fas fa-check mr-1"></i>
                                                Aprobada
                                            </span>
                                        @elseif($request->status == 'rechazada')
                                            <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-800 border border-red-200">
                                                <i class="fas fa-times mr-1"></i>
                                                Rechazada
                                            </span>
                                        @elseif($request->status == 'en_desarrollo')
                                            <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-200">
                                                <i class="fas fa-code mr-1"></i>
                                                En Desarrollo
                                            </span>
                                        @else
                                            <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-800 border border-gray-200">
                                                <i class="fas fa-question mr-1"></i>
                                                {{ ucfirst($request->status ?? 'Desconocido') }}
                                            </span>
                                        @endif
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-gray-900">
                                            <i class="fas fa-calendar mr-1"></i>{{ \Carbon\Carbon::parse($request->created_at)->format('d/m/Y') }}
                                        </div>
                                        <div class="text-xs text-gray-500">
                                            <i class="fas fa-clock mr-1"></i>{{ \Carbon\Carbon::parse($request->created_at)->format('H:i') }}
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <button onclick="abrirModalEditarFormulario({{ $request->id }}, {{ $request->formulario_id }})"
                                                class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-all duration-200 flex items-center font-semibold shadow-md hover:shadow-lg transform hover:scale-105">
                                            <i class="fas fa-edit mr-2"></i>
                                            Editar
                                        </button>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @else
                <div class="text-center py-12">
                    <div class="bg-gray-100 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-clipboard-check text-green-600 text-3xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-700 mb-3">No hay solicitudes enviadas aún</h3>
                    <p class="text-gray-500 mb-6">Cuando envíes solicitudes de desarrollo de software, aparecerán aquí para que puedas gestionarlas.</p>
                    <a href="{{ route('fabricasoft.usuario.formularios') }}" 
                       class="inline-flex items-center px-6 py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105">
                        <i class="fas fa-plus mr-2"></i>
                        Crear Nueva Solicitud
                    </a>
                </div>
            @endif
        </div>
    </div>
</div>

<!-- Sección de formularios disponibles mejorada -->
<div class="bg-white rounded-xl shadow-lg mt-10 border border-gray-100">
    <div class="p-6 border-b border-gray-100">
        <h2 class="text-xl font-semibold text-gray-800 flex items-center">
            <i class="fas fa-clipboard-check text-green-600 mr-2"></i>
            Formularios Disponibles
        </h2>
    </div>
    <div class="p-6">
        @php
            $formularios = \Modules\FABRICASOFT\Entities\Formulario::orderByDesc('created_at')->get();
        @endphp
        @if($formularios->count() > 0)
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Nombre del Formulario</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Fecha de Creación</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Acciones</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-100">
                        @foreach($formularios as $formulario)
                        <tr class="hover:bg-green-50 transition-all duration-200">
                            <td class="px-6 py-4">
                                <div class="text-sm font-semibold text-gray-900 flex items-center">
                                    <i class="fas fa-file-alt text-green-600 mr-2"></i>
                                    {{ $formulario->nombre }}
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="text-sm text-gray-900">
                                    <i class="fas fa-calendar mr-1"></i>
                                    {{ $formulario->created_at->format('d/m/Y') }}
                                </div>
                                <div class="text-xs text-gray-500">
                                    <i class="fas fa-clock mr-1"></i>
                                    {{ $formulario->created_at->format('H:i') }}
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <button class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-all duration-200 flex items-center font-semibold shadow-md hover:shadow-lg transform hover:scale-105" 
                                        onclick="abrirModalLlenarFormulario(0, {{ $formulario->id }})">
                                    <i class="fas fa-edit mr-2"></i>
                                    Llenar Formulario
                                </button>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <div class="text-center py-12">
                <div class="text-gray-300 mb-4">
                    <i class="fas fa-clipboard-list text-6xl"></i>
                </div>
                <h3 class="text-lg font-semibold text-gray-700 mb-2">No hay formularios disponibles</h3>
                <p class="text-gray-500">Contacte al administrador para crear formularios personalizados.</p>
            </div>
        @endif
    </div>
</div>

<!-- Modal para llenar formulario personalizado -->
<div id="modal-llenar-formulario" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999] hidden p-4">
    <div class="bg-white rounded-xl p-6 w-full max-w-3xl lg:max-w-5xl max-h-[85vh] overflow-y-auto shadow-2xl relative">
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl lg:text-2xl font-semibold text-gray-900 flex items-center">
                <i class="fas fa-edit text-blue-600 mr-2"></i>
                <span id="modal-titulo">Llenar Formulario</span>
            </h3>
            <button onclick="cerrarModalFormulario()" class="text-gray-400 hover:text-gray-600 transition-colors p-2">
                <i class="fas fa-times text-2xl"></i>
            </button>
        </div>
        <form id="form-llenar-formulario" method="POST" action="{{ url('/fabricasoft/usuario/guardar-respuestas') }}">
            @csrf
            <input type="hidden" name="servicio_id" id="input-servicio-id-llenar">
            <input type="hidden" name="formulario_id" id="input-formulario-id-llenar">
            <div id="contenedor-preguntas-llenar" class="grid grid-cols-1 md:grid-cols-2 gap-6"></div>
            <div class="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-4 pt-6 border-t border-gray-200">
                <button type="button" onclick="cerrarModalFormulario()" 
                        class="w-full sm:w-auto px-6 py-3 text-base font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-all duration-200 flex items-center justify-center">
                    <i class="fas fa-times mr-2"></i>
                    Cancelar
                </button>
                <button type="submit" 
                        class="w-full sm:w-auto px-6 py-3 text-base font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-all duration-200 flex items-center justify-center shadow-md hover:shadow-lg transform hover:scale-105">
                    <i class="fas fa-save mr-2"></i>
                    <span id="boton-guardar-texto">Guardar Formulario</span>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal específico para editar formularios enviados -->
<div id="modal-editar-formulario" class="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[9999] hidden p-4 backdrop-blur-sm">
    <div class="bg-white rounded-2xl w-full max-w-5xl lg:max-w-7xl h-[80vh] flex flex-col shadow-2xl relative border border-gray-100">
        <!-- Header mejorado -->
        <div class="flex justify-between items-center p-6 border-b border-gray-200 flex-shrink-0 bg-gradient-to-r from-green-50 to-green-100 rounded-t-2xl">
            <div class="flex-1">
                <h3 class="text-xl lg:text-2xl font-bold text-gray-900 flex items-center">
                    <div class="bg-green-600 text-white p-3 rounded-xl mr-4 shadow-lg">
                        <i class="fas fa-edit text-lg"></i>
                    </div>
                    Editar Formulario Enviado
                </h3>
                <p class="text-sm text-gray-600 mt-2 font-medium ml-16" id="modal-subtitulo">Cargando información...</p>
            </div>
            <button onclick="cerrarModalEditarFormulario()" class="text-gray-400 hover:text-red-500 transition-all duration-300 p-3 hover:bg-red-50 rounded-full group flex-shrink-0">
                <i class="fas fa-times text-xl group-hover:scale-110 transition-transform duration-200"></i>
            </button>
        </div>
        
        <!-- Contenido con scroll mejorado -->
        <div class="flex-1 overflow-y-scroll p-6" style="max-height: calc(80vh - 180px);">
            <!-- Información del proyecto mejorada -->
            <div class="bg-gradient-to-r from-green-50 to-green-100 border border-green-200 rounded-xl p-6 mb-8 shadow-sm">
                <div class="flex items-center mb-4">
                    <div class="bg-green-600 text-white p-3 rounded-xl mr-4">
                        <i class="fas fa-info-circle text-lg"></i>
                    </div>
                    <h4 class="text-lg font-semibold text-gray-800">Información del Proyecto</h4>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div class="bg-white rounded-xl p-4 border border-green-200 shadow-sm hover:shadow-md transition-all duration-200">
                        <label class="block text-xs font-bold text-green-700 uppercase tracking-wide mb-2">Proyecto</label>
                        <p class="text-sm font-semibold text-gray-900" id="info-proyecto">-</p>
                    </div>
                    <div class="bg-white rounded-xl p-4 border border-green-200 shadow-sm hover:shadow-md transition-all duration-200">
                        <label class="block text-xs font-bold text-green-700 uppercase tracking-wide mb-2">Empresa</label>
                        <p class="text-sm font-semibold text-gray-900" id="info-empresa">-</p>
                    </div>
                    <div class="bg-white rounded-xl p-4 border border-green-200 shadow-sm hover:shadow-md transition-all duration-200">
                        <label class="block text-xs font-bold text-green-700 uppercase tracking-wide mb-2">Estado</label>
                        <p class="text-sm font-semibold text-gray-900" id="info-estado">-</p>
                    </div>
                    <div class="bg-white rounded-xl p-4 border border-green-200 shadow-sm hover:shadow-md transition-all duration-200">
                        <label class="block text-xs font-bold text-green-700 uppercase tracking-wide mb-2">Fecha de Envío</label>
                        <p class="text-sm font-semibold text-gray-900" id="info-fecha">-</p>
                    </div>
                </div>
            </div>
            
            <form id="form-editar-formulario" method="POST" action="{{ url('/fabricasoft/usuario/guardar-respuestas') }}">
                @csrf
                <input type="hidden" name="servicio_id" id="input-servicio-id-editar">
                <input type="hidden" name="formulario_id" id="input-formulario-id-editar">
                
                <div id="contenedor-preguntas-editar" class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Las preguntas se cargarán dinámicamente aquí -->
                    <!-- Contenido de prueba para mostrar la barra de scroll -->
                    <div class="bg-white border border-gray-200 rounded-xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 hover:border-green-300 group">
                        <label class="block text-sm font-bold text-gray-800 mb-4 flex items-center">
                            <span class="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs font-bold px-3 py-1 rounded-full mr-3 shadow-sm">1</span>
                            Nombre o título del proyecto
                        </label>
                        <input type="text" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 bg-gray-50 hover:bg-white group-hover:bg-green-50" placeholder="Estanco22">
                    </div>
                    
                    <div class="bg-white border border-gray-200 rounded-xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 hover:border-green-300 group">
                        <label class="block text-sm font-bold text-gray-800 mb-4 flex items-center">
                            <span class="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs font-bold px-3 py-1 rounded-full mr-3 shadow-sm">2</span>
                            Objetivo principal del software
                        </label>
                        <input type="text" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 bg-gray-50 hover:bg-white group-hover:bg-green-50" placeholder="Administrar Las Ventas">
                    </div>
                    
                    <div class="bg-white border border-gray-200 rounded-xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 hover:border-green-300 group lg:col-span-2">
                        <label class="block text-sm font-bold text-gray-800 mb-4 flex items-center">
                            <span class="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs font-bold px-3 py-1 rounded-full mr-3 shadow-sm">3</span>
                            Descripción general del software
                        </label>
                        <textarea class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 bg-gray-50 hover:bg-white resize-vertical group-hover:bg-green-50" rows="4" placeholder="Describe detalladamente el software que necesitas..."></textarea>
                    </div>
                    
                    <div class="bg-white border border-gray-200 rounded-xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 hover:border-green-300 group lg:col-span-2">
                        <label class="block text-sm font-bold text-gray-800 mb-4 flex items-center">
                            <span class="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs font-bold px-3 py-1 rounded-full mr-3 shadow-sm">4</span>
                            Tipo de software
                        </label>
                        <select class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 bg-gray-50 hover:bg-white group-hover:bg-green-50">
                            <option value="">Seleccione el tipo de software...</option>
                            <option value="web">Aplicación Web</option>
                            <option value="desktop">Aplicación de Escritorio</option>
                            <option value="mobile">Aplicación Móvil</option>
                            <option value="api">API/Servicio Web</option>
                            <option value="other">Otro</option>
                        </select>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- Footer mejorado -->
        <div class="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-4 p-6 border-t border-gray-200 flex-shrink-0 bg-gradient-to-r from-gray-50 to-gray-100 rounded-b-2xl">
            <button type="button" onclick="cerrarModalEditarFormulario()" 
                    class="w-full sm:w-auto px-6 py-3 text-sm font-semibold text-gray-700 bg-white border border-gray-300 rounded-xl hover:bg-gray-50 hover:border-gray-400 transition-all duration-200 flex items-center justify-center shadow-sm hover:shadow-md">
                <i class="fas fa-times mr-2"></i>
                Cancelar
            </button>
            <button type="submit" form="form-editar-formulario"
                    class="w-full sm:w-auto px-6 py-3 text-sm font-semibold text-white bg-gradient-to-r from-green-600 to-green-700 rounded-xl hover:from-green-700 hover:to-green-800 transition-all duration-200 flex items-center justify-center shadow-lg hover:shadow-xl transform hover:scale-105">
                <i class="fas fa-save mr-2"></i>
                Actualizar Formulario
            </button>
        </div>
    </div>
</div>

<style>
/* Estilos personalizados para el modal de edición */
#modal-editar-formulario .overflow-y-scroll {
    scrollbar-width: thin;
    scrollbar-color: #10b981 #e5e7eb;
    /* Forzar la aparición de la barra de scroll */
    overflow-y: scroll !important;
}

#modal-editar-formulario .overflow-y-scroll::-webkit-scrollbar {
    width: 12px;
    background-color: #f3f4f6;
}

#modal-editar-formulario .overflow-y-scroll::-webkit-scrollbar-track {
    background: #f3f4f6;
    border-radius: 6px;
    border: 1px solid #e5e7eb;
}

#modal-editar-formulario .overflow-y-scroll::-webkit-scrollbar-thumb {
    background: #10b981;
    border-radius: 6px;
    border: 2px solid #f3f4f6;
}

#modal-editar-formulario .overflow-y-scroll::-webkit-scrollbar-thumb:hover {
    background: #059669;
}

#modal-editar-formulario .overflow-y-scroll::-webkit-scrollbar-corner {
    background: #f3f4f6;
}

/* Animación suave para el scroll */
#modal-editar-formulario .overflow-y-scroll {
    scroll-behavior: smooth;
}

/* Mejorar el espaciado y simetría de las preguntas */
#contenedor-preguntas-editar {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: 1.5rem;
    align-items: start;
}

#contenedor-preguntas-editar > div {
    margin-bottom: 0;
    height: fit-content;
}

/* Efecto hover mejorado para los campos */
#contenedor-preguntas-editar input:focus,
#contenedor-preguntas-editar textarea:focus,
#contenedor-preguntas-editar select:focus {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(16, 185, 129, 0.15);
    border-color: #10b981;
}

/* Estilos para campos que ocupan todo el ancho */
#contenedor-preguntas-editar .lg\\:col-span-2 {
    grid-column: span 2;
}

/* Responsive design para el modal */
@media (max-width: 1024px) {
    #contenedor-preguntas-editar {
        grid-template-columns: 1fr;
    }
    
    #contenedor-preguntas-editar .lg\\:col-span-2 {
        grid-column: span 1;
    }
}

/* Mejorar la simetría del header del modal */
#modal-editar-formulario .flex-1 {
    flex: 1;
    min-width: 0;
}

#modal-editar-formulario .flex-shrink-0 {
    flex-shrink: 0;
}

/* Estilos para la información del proyecto */
#modal-editar-formulario .grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
}

/* Efectos de hover mejorados */
#modal-editar-formulario .hover\\:shadow-md:hover {
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    transform: translateY(-2px);
}

/* Estilos para los botones del footer */
#modal-editar-formulario button[type="submit"] {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    transition: all 0.3s ease;
}

#modal-editar-formulario button[type="submit"]:hover {
    background: linear-gradient(135deg, #059669 0%, #047857 100%);
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(16, 185, 129, 0.3);
}

/* Mejorar la tipografía */
#modal-editar-formulario h3 {
    font-weight: 700;
    letter-spacing: -0.025em;
}

#modal-editar-formulario label {
    font-weight: 600;
    color: #374151;
}

/* Estilos para los campos de entrada */
#modal-editar-formulario input,
#modal-editar-formulario textarea,
#modal-editar-formulario select {
    font-size: 0.95rem;
    line-height: 1.5;
}

/* Efectos de transición suaves */
#modal-editar-formulario * {
    transition: all 0.2s ease-in-out;
}

/* Mejorar el contraste y legibilidad */
#modal-editar-formulario .text-gray-600 {
    color: #4b5563;
}

#modal-editar-formulario .text-gray-800 {
    color: #1f2937;
}

/* Estilos para el backdrop */
#modal-editar-formulario {
    backdrop-filter: blur(8px);
}

/* Animación de entrada del modal */
@keyframes modalFadeIn {
    from {
        opacity: 0;
        transform: scale(0.95) translateY(-20px);
    }
    to {
        opacity: 1;
        transform: scale(1) translateY(0);
    }
}

#modal-editar-formulario > div {
    animation: modalFadeIn 0.3s ease-out;
}

/* Mejorar la simetría de los elementos internos */
#modal-editar-formulario .p-6 {
    padding: 1.5rem;
}

#modal-editar-formulario .mb-4 {
    margin-bottom: 1rem;
}

#modal-editar-formulario .mb-8 {
    margin-bottom: 2rem;
}

/* Estilos para los badges numerados */
#modal-editar-formulario .bg-gradient-to-r {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
}

/* Mejorar el espaciado entre elementos */
#modal-editar-formulario .space-x-4 > * + * {
    margin-left: 1rem;
}

#modal-editar-formulario .space-y-3 > * + * {
    margin-top: 0.75rem;
}

/* Estilos para el estado responsive */
@media (max-width: 768px) {
    #modal-editar-formulario {
        margin: 1rem;
        height: calc(100vh - 2rem);
    }
    
    #modal-editar-formulario .p-6 {
        padding: 1rem;
    }
    
    #modal-editar-formulario .grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
}
</style>

<script>
// Función para cerrar alertas
function closeAlert(alertId) {
    const alert = document.getElementById(alertId);
    if (alert) {
        alert.style.opacity = '0';
        setTimeout(() => {
            alert.remove();
        }, 300);
    }
}

// Auto-cerrar alertas después de 5 segundos
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('[id^="alert-"]');
    alerts.forEach(alert => {
        setTimeout(() => {
            closeAlert(alert.id);
        }, 5000);
    });
});

// Funciones para el modal de formulario
function abrirModalLlenarFormulario(servicioId, formularioId) {
    document.getElementById('modal-llenar-formulario').classList.remove('hidden');
    document.body.style.overflow = 'hidden';
    
    // Ocultar sidebar si existe
    const sidebar = document.querySelector('.sidebar') || 
                   document.querySelector('.nav-sidebar') || 
                   document.querySelector('[class*="sidebar"]') ||
                   document.querySelector('[class*="nav"]');
    if (sidebar) {
        sidebar.style.display = 'none';
    }
    
    // Mostrar loading
    document.getElementById('contenedor-preguntas-llenar').innerHTML = `
        <div class="text-center py-8">
            <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
            <p class="text-gray-600">Cargando formulario...</p>
        </div>
    `;
    
    // Determinar si es edición o nueva solicitud
    const isEditing = servicioId && servicioId > 0;
    const url = isEditing 
        ? `/fabricasoft/usuario/formulario/${servicioId}/respuestas`
        : `/fabricasoft/formularios/${formularioId}/ver-json`;
    
    // Actualizar título del modal
    const modalTitulo = document.getElementById('modal-titulo');
    if (modalTitulo) {
        modalTitulo.textContent = isEditing ? 'Editar Formulario' : 'Llenar Formulario';
    }
    
    // Actualizar texto del botón
    const botonGuardarTexto = document.getElementById('boton-guardar-texto');
    if (botonGuardarTexto) {
        botonGuardarTexto.textContent = isEditing ? 'Actualizar Formulario' : 'Guardar Formulario';
    }
    
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            let html = '';
            let preguntasCliente = 0;
            
            if (isEditing) {
                // Es edición - usar datos con respuestas existentes
                const formulario = data.formulario;
                const respuestas = data.respuestas;
                
                // Agregar campo oculto para servicio_id
                html += `<input type="hidden" name="servicio_id" value="${data.servicio_id}">`;
                html += `<input type="hidden" name="formulario_id" value="${formulario.id}">`;
                
                if (formulario.preguntas && Array.isArray(formulario.preguntas)) {
                    formulario.preguntas.forEach((pregunta, idx) => {
                        // Verificar si es pregunta para cliente (puede ser true, "on", o 1)
                        const esCliente = pregunta.cliente === true || pregunta.cliente === "on" || pregunta.cliente === 1;
                        if (esCliente) {
                            preguntasCliente++;
                            const respuestaExistente = respuestas[pregunta.id] || '';
                            const textoPregunta = pregunta.pregunta || pregunta.texto || 'Pregunta sin texto';
                            
                            html += `<div class="mb-6 p-4 bg-gray-50 rounded-lg border border-gray-200">`;
                            html += `<label class="block text-sm font-semibold text-gray-700 mb-2">${textoPregunta}</label>`;
                            
                            if (pregunta.tipo === 'texto') {
                                html += `<input type='text' name='respuestas[${pregunta.id || idx}]' value='${respuestaExistente}' required class='w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200' placeholder='Ingrese su respuesta'>`;
                            } else if (pregunta.tipo === 'textarea') {
                                html += `<textarea name='respuestas[${pregunta.id || idx}]' required class='w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200' rows='4' placeholder='Ingrese su respuesta'>${respuestaExistente}</textarea>`;
                            } else if (pregunta.tipo === 'numero') {
                                html += `<input type='number' name='respuestas[${pregunta.id || idx}]' value='${respuestaExistente}' required class='w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200' placeholder='Ingrese un número'>`;
                            } else if (pregunta.tipo === 'fecha') {
                                html += `<input type='date' name='respuestas[${pregunta.id || idx}]' value='${respuestaExistente}' required class='w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200'>`;
                            } else if (pregunta.tipo === 'seleccion' && pregunta.opciones) {
                                html += `<select name='respuestas[${pregunta.id || idx}]' required class='w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200'>`;
                                html += `<option value=''>Seleccione una opción...</option>`;
                                pregunta.opciones.forEach(op => {
                                    const selected = op === respuestaExistente ? 'selected' : '';
                                    html += `<option value='${op}' ${selected}>${op}</option>`;
                                });
                                html += `</select>`;
                            }
                            html += `</div>`;
                        }
                    });
                }
            } else {
                // Es nueva solicitud - usar datos del formulario
                const formulario = data;
                
                html += `<input type="hidden" name="formulario_id" value="${formulario.id}">`;
                
                if (formulario.preguntas && Array.isArray(formulario.preguntas)) {
                    formulario.preguntas.forEach((pregunta, idx) => {
                        // Verificar si es pregunta para cliente (puede ser true, "on", o 1)
                        const esCliente = pregunta.cliente === true || pregunta.cliente === "on" || pregunta.cliente === 1;
                        if (esCliente) {
                            preguntasCliente++;
                            const textoPregunta = pregunta.pregunta || pregunta.texto || 'Pregunta sin texto';
                            
                            html += `<div class="mb-6 p-4 bg-gray-50 rounded-lg border border-gray-200">`;
                            html += `<label class="block text-sm font-semibold text-gray-700 mb-2">${textoPregunta}</label>`;
                            
                            if (pregunta.tipo === 'texto') {
                                html += `<input type='text' name='respuestas[${pregunta.id}]' required class='w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200' placeholder='Ingrese su respuesta'>`;
                            } else if (pregunta.tipo === 'textarea') {
                                html += `<textarea name='respuestas[${pregunta.id}]' required class='w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200' rows='4' placeholder='Ingrese su respuesta'></textarea>`;
                            } else if (pregunta.tipo === 'numero') {
                                html += `<input type='number' name='respuestas[${pregunta.id}]' required class='w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200' placeholder='Ingrese un número'>`;
                            } else if (pregunta.tipo === 'fecha') {
                                html += `<input type='date' name='respuestas[${pregunta.id}]' required class='w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200'>`;
                            } else if (pregunta.tipo === 'seleccion' && pregunta.opciones) {
                                html += `<select name='respuestas[${pregunta.id}]' required class='w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200'>`;
                                html += `<option value=''>Seleccione una opción...</option>`;
                                pregunta.opciones.forEach(op => {
                                    html += `<option value='${op}'>${op}</option>`;
                                });
                                html += `</select>`;
                            }
                            html += `</div>`;
                        }
                    });
                }
            }
            
            if (preguntasCliente === 0) {
                html = `
                    <div class="text-center py-8">
                        <i class="fas fa-exclamation-triangle text-yellow-500 text-4xl mb-4"></i>
                        <p class="text-gray-600 font-semibold">Este formulario no tiene preguntas para clientes.</p>
                    </div>
                `;
            }
            
            document.getElementById('contenedor-preguntas-llenar').innerHTML = html;
            
            // Enfocar primer campo
            setTimeout(() => {
                const primerCampo = document.querySelector('#modal-llenar-formulario input, #modal-llenar-formulario select');
                if (primerCampo) {
                    primerCampo.focus();
                }
            }, 100);
        })
        .catch(error => {
            console.error('Error al cargar el formulario:', error);
            let errorMessage = 'Error al cargar el formulario';
            let errorDetails = error.message;
            
            // Si es un error de red, mostrar mensaje más específico
            if (error.message.includes('HTTP error!')) {
                errorMessage = 'Error de conexión';
                errorDetails = 'No se pudo conectar con el servidor. Verifique su conexión a internet.';
            } else if (error.message.includes('Unexpected token')) {
                errorMessage = 'Error en el formato de datos';
                errorDetails = 'El servidor devolvió datos en un formato incorrecto.';
            }
            
            document.getElementById('contenedor-preguntas-llenar').innerHTML = `
                <div class="text-center py-8">
                    <i class="fas fa-exclamation-triangle text-red-500 text-4xl mb-4"></i>
                    <p class="text-red-600 font-semibold mb-2">${errorMessage}</p>
                    <p class="text-sm text-gray-500 mb-4">${errorDetails}</p>
                    <button onclick="abrirModalLlenarFormulario(${servicioId}, ${formularioId})" 
                            class="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all duration-200 flex items-center mx-auto">
                        <i class="fas fa-redo mr-2"></i>
                        Reintentar
                    </button>
                </div>
            `;
        });
}

function cerrarModalFormulario() {
    document.getElementById('modal-llenar-formulario').classList.add('hidden');
    document.body.style.overflow = 'auto';
    
    // Mostrar sidebar si existe
    const sidebar = document.querySelector('.sidebar') || 
                   document.querySelector('.nav-sidebar') || 
                   document.querySelector('[class*="sidebar"]') ||
                   document.querySelector('[class*="nav"]');
    if (sidebar) {
        sidebar.style.display = 'block';
    }
    
    // Resetear formulario
    document.getElementById('form-llenar-formulario').reset();
}

// Cerrar modal con ESC
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        cerrarModalFormulario();
    }
});

// Cerrar modal haciendo clic fuera de él
document.addEventListener('click', function(event) {
    const modal = document.getElementById('modal-llenar-formulario');
    if (modal && !modal.classList.contains('hidden')) {
        if (event.target === modal) {
            cerrarModalFormulario();
        }
    }
});

// Funciones para el modal de edición específico
function abrirModalEditarFormulario(servicioId, formularioId) {
    document.getElementById('modal-editar-formulario').classList.remove('hidden');
    document.body.style.overflow = 'hidden';
    
    // Ocultar sidebar si existe
    const sidebar = document.querySelector('.sidebar') || 
                   document.querySelector('.nav-sidebar') || 
                   document.querySelector('[class*="sidebar"]') ||
                   document.querySelector('[class*="nav"]');
    if (sidebar) {
        sidebar.style.display = 'none';
    }
    
    // Para prueba, mostrar contenido inmediatamente
    if (servicioId === 1 && formularioId === 1) {
        // Mostrar contenido de prueba
        document.getElementById('modal-subtitulo').textContent = 'Modal de prueba - Barra de desplazamiento';
        document.getElementById('info-proyecto').textContent = 'Proyecto de Prueba';
        document.getElementById('info-empresa').textContent = 'Empresa de Prueba';
        document.getElementById('info-estado').textContent = 'Pendiente';
        document.getElementById('info-fecha').textContent = new Date().toLocaleDateString('es-ES');
        
        // El contenido de prueba ya está en el HTML, solo asegurar que sea visible
        document.getElementById('contenedor-preguntas-editar').style.display = 'grid';
        
        // Enfocar primer campo
        setTimeout(() => {
            const primerCampo = document.querySelector('#modal-editar-formulario input, #modal-editar-formulario select');
            if (primerCampo) {
                primerCampo.focus();
            }
        }, 100);
        return;
    }
    
    // Mostrar loading
    document.getElementById('contenedor-preguntas-editar').innerHTML = `
        <div class="text-center py-8 col-span-2">
            <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
            <p class="text-gray-600">Cargando información del formulario...</p>
        </div>
    `;
    
    // Cargar información completa del formulario
    fetch(`/fabricasoft/usuario/formulario/${servicioId}/respuestas`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (!data.success) {
                throw new Error(data.error || 'Error al cargar el formulario');
            }
            
            // Actualizar información del proyecto
            actualizarInformacionProyecto(data);
            
            // Cargar preguntas con respuestas
            cargarPreguntasEdicion(data);
            
            // Enfocar primer campo
            setTimeout(() => {
                const primerCampo = document.querySelector('#modal-editar-formulario input, #modal-editar-formulario select');
                if (primerCampo) {
                    primerCampo.focus();
                }
            }, 100);
        })
        .catch(error => {
            console.error('Error al cargar el formulario:', error);
            document.getElementById('contenedor-preguntas-editar').innerHTML = `
                <div class="text-center py-8 col-span-2">
                    <i class="fas fa-exclamation-triangle text-red-500 text-4xl mb-4"></i>
                    <p class="text-red-600 font-semibold mb-2">Error al cargar el formulario</p>
                    <p class="text-sm text-gray-500 mb-4">${error.message}</p>
                    <button onclick="abrirModalEditarFormulario(${servicioId}, ${formularioId})" 
                            class="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all duration-200 flex items-center mx-auto">
                        <i class="fas fa-redo mr-2"></i>
                        Reintentar
                    </button>
                </div>
            `;
        });
}

function actualizarInformacionProyecto(data) {
    // Obtener información del servicio desde la base de datos
    fetch(`/fabricasoft/solicitudes/${data.servicio_id}/details-json`)
        .then(response => response.json())
        .then(responseData => {
            if (responseData.success) {
                const servicioData = responseData.data;
                document.getElementById('info-proyecto').textContent = servicioData.project_name || 'Solicitud vía formulario';
                document.getElementById('info-empresa').textContent = servicioData.company_name || 'No especificado';
                document.getElementById('info-estado').textContent = obtenerEstadoFormateado(servicioData.status);
                document.getElementById('info-fecha').textContent = new Date(servicioData.created_at).toLocaleDateString('es-ES');
            } else {
                throw new Error(responseData.error || 'Error al cargar información del servicio');
            }
        })
        .catch(error => {
            console.error('Error al cargar información del servicio:', error);
            document.getElementById('info-proyecto').textContent = 'Solicitud vía formulario';
            document.getElementById('info-empresa').textContent = 'No disponible';
            document.getElementById('info-estado').textContent = 'No disponible';
            document.getElementById('info-fecha').textContent = 'No disponible';
        });
    
    // Actualizar subtítulo con nombre del formulario
    document.getElementById('modal-subtitulo').textContent = `Editando formulario: ${data.formulario.nombre}`;
    
    // Actualizar campos ocultos
    document.getElementById('input-servicio-id-editar').value = data.servicio_id;
    document.getElementById('input-formulario-id-editar').value = data.formulario.id;
}

function cargarPreguntasEdicion(data) {
    const formulario = data.formulario;
    const respuestas = data.respuestas;
    let html = '';
    let preguntasCliente = 0;
    
    if (formulario.preguntas && Array.isArray(formulario.preguntas)) {
        formulario.preguntas.forEach((pregunta, idx) => {
            // Verificar si es pregunta para cliente (puede ser true, "on", o 1)
            const esCliente = pregunta.cliente === true || pregunta.cliente === "on" || pregunta.cliente === 1;
            if (esCliente) {
                preguntasCliente++;
                const respuestaExistente = respuestas[pregunta.id || idx] || '';
                const textoPregunta = pregunta.pregunta || pregunta.texto || 'Pregunta sin texto';
                
                html += `<div class="bg-white border border-gray-200 rounded-xl p-5 shadow-sm hover:shadow-lg transition-all duration-300 hover:border-green-300 group">`;
                html += `<label class="block text-sm font-bold text-gray-800 mb-3 flex items-center">`;
                html += `<span class="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs font-bold px-3 py-1 rounded-full mr-3 shadow-sm">${preguntasCliente}</span>`;
                html += `${textoPregunta}`;
                html += `</label>`;
                
                if (pregunta.tipo === 'texto') {
                    html += `<input type='text' name='respuestas[${pregunta.id || idx}]' value='${respuestaExistente}' required class='w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 bg-gray-50 hover:bg-white group-hover:bg-green-50' placeholder='Ingrese su respuesta'>`;
                } else if (pregunta.tipo === 'textarea') {
                    html += `<textarea name='respuestas[${pregunta.id || idx}]' required class='w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 bg-gray-50 hover:bg-white resize-vertical group-hover:bg-green-50' rows='4' placeholder='Ingrese su respuesta'>${respuestaExistente}</textarea>`;
                } else if (pregunta.tipo === 'numero') {
                    html += `<input type='number' name='respuestas[${pregunta.id || idx}]' value='${respuestaExistente}' required class='w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 bg-gray-50 hover:bg-white group-hover:bg-green-50' placeholder='Ingrese un número'>`;
                } else if (pregunta.tipo === 'fecha') {
                    html += `<input type='date' name='respuestas[${pregunta.id || idx}]' value='${respuestaExistente}' required class='w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 bg-gray-50 hover:bg-white group-hover:bg-green-50'>`;
                } else if (pregunta.tipo === 'seleccion' && pregunta.opciones) {
                    html += `<select name='respuestas[${pregunta.id || idx}]' required class='w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 bg-gray-50 hover:bg-white group-hover:bg-green-50'>`;
                    html += `<option value=''>Seleccione una opción...</option>`;
                    pregunta.opciones.forEach(op => {
                        const selected = op === respuestaExistente ? 'selected' : '';
                        html += `<option value='${op}' ${selected}>${op}</option>`;
                    });
                    html += `</select>`;
                }
                html += `</div>`;
            }
        });
    }
    
    if (preguntasCliente === 0) {
        html = `
            <div class="text-center py-12 col-span-2">
                <div class="bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200 rounded-xl p-8 shadow-sm">
                    <div class="bg-yellow-500 text-white p-3 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                        <i class="fas fa-exclamation-triangle text-2xl"></i>
                    </div>
                    <p class="text-gray-700 font-bold text-lg mb-2">Este formulario no tiene preguntas para clientes</p>
                    <p class="text-gray-500">No se encontraron campos editables en este formulario.</p>
                </div>
            </div>
        `;
    }
    
    document.getElementById('contenedor-preguntas-editar').innerHTML = html;
}

function obtenerEstadoFormateado(status) {
    const estados = {
        'pendiente': '⏳ Pendiente',
        'aprobada': '✅ Aprobada',
        'rechazada': '❌ Rechazada',
        'en_desarrollo': '🚀 En Desarrollo',
        'completado': '✅ Completado',
        'testing': '🧪 En Testing',
        'revision': '📋 En Revisión'
    };
    return estados[status] || status;
}

function cerrarModalEditarFormulario() {
    document.getElementById('modal-editar-formulario').classList.add('hidden');
    document.body.style.overflow = 'auto';
    
    // Mostrar sidebar si existe
    const sidebar = document.querySelector('.sidebar') || 
                   document.querySelector('.nav-sidebar') || 
                   document.querySelector('[class*="sidebar"]') ||
                   document.querySelector('[class*="nav"]');
    if (sidebar) {
        sidebar.style.display = 'block';
    }
    
    // Resetear formulario
    document.getElementById('form-editar-formulario').reset();
}

// Cerrar modal de edición con ESC
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        cerrarModalEditarFormulario();
    }
});

// Cerrar modal de edición haciendo clic fuera de él
document.addEventListener('click', function(event) {
    const modal = document.getElementById('modal-editar-formulario');
    if (modal && !modal.classList.contains('hidden')) {
        if (event.target === modal) {
            cerrarModalEditarFormulario();
        }
    }
});
</script>

@endsection
