<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>FABRICASOFT - SENA</title>

        <!-- Font Awesome CDN -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

        <style>
            :root {
                --sena-green: #009739;
                --sena-dark: #1A3C34;
                --accent: #FFFFFF; /* Cambiado de #FFD700 (amarillo) a blanco */
                --text: #0F172A;
                --light-bg: #F0F4F8;
                --secondary-accent: #ffffff;
            }

            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            body {
                overflow-x: hidden;
            }

            .software-factory-container {
                width: 100%;
                font-family: 'Poppins', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
                color: var(--text);
                line-height: 1.9;
                background: var(--light-bg);
                position: relative;
                overflow: hidden;
            }

            .icon {
                width: 4.5rem;
                height: 4.5rem;
                transition: transform 0.5s ease, filter 0.5s ease;
            }

            .button-icon {
                width: 2.2rem;
                height: 2.2rem;
                margin-right: 1rem;
            }

            /* Animated Background */
            .hero-section {
                position: relative;
                min-height: 70vh;
                background: linear-gradient(145deg, var(--sena-green), var(--sena-dark));
                display: flex;
                align-items: center;
                justify-content: center;
                overflow: hidden;
                padding: 1rem;
            }

            .hero-section::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 800"><defs><filter id="glow"><feGaussianBlur stdDeviation="3.5" result="blur"/><feFlood flood-color="%23FFFFFF" flood-opacity="0.3"/><feComposite in2="blur" operator="in" result="glow"/><feMerge><feMergeNode in="glow"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g filter="url(#glow)"><circle cx="200" cy="200" r="50" fill="%23FFFFFF" opacity="0.3"><animate attributeName="cx" values="200;300;200" dur="10s" repeatCount="indefinite"/></circle><circle cx="600" cy="600" r="70" fill="%2300A1D6" opacity="0.3"><animate attributeName="cy" values="600;500;600" dur="12s" repeatCount="indefinite"/></circle><rect x="400" y="400" width="80" height="80" fill="%23FFFFFF" opacity="0.2" transform="rotate(45 440 440)"><animateTransform attributeName="transform" type="rotate" from="45 440 440" to="405 440 440" dur="15s" repeatCount="indefinite"/></rect></g></svg>') center/cover;
                z-index: 1;
                animation: backgroundFlow 20s ease-in-out infinite;
            }

            @keyframes backgroundFlow {
                0%, 100% { transform: scale(1) translate(0, 0); }
                50% { transform: scale(1.1) translate(-20px, -20px); }
            }

            .hero-content {
                text-align: center;
                padding: 1rem;
                max-width: 800px;
                z-index: 2;
                animation: zoomIn 1.5s ease-out;
                margin: 0 auto;
            }

            @keyframes zoomIn {
                from { opacity: 0; transform: scale(0.8) translateY(100px); }
                to { opacity: 1; transform: scale(1) translateY(0); }
            }

            .hero-icon .icon {
                color: var(--accent);
                filter: drop-shadow(0 5px 10px rgba(0, 0, 0, 0.5));
                animation: codePulse 3s ease-in-out infinite;
            }

            @keyframes codePulse {
                0%, 100% { transform: scale(1) rotate(0deg); }
                50% { transform: scale(1.2) rotate(5deg); }
            }

            .hero-title {
                font-size: 4rem;
                font-weight: 900;
                margin: 1rem 0;
                color: #FFFFFF;
                text-shadow: 0 5px 15px rgba(0, 0, 0, 0.8);
                letter-spacing: -2px;
                text-transform: uppercase;
                position: relative;
            }

            .hero-title::after {
                content: '</>';
                position: absolute;
                font-size: 1.2rem;
                color: var(--accent);
                right: -30px;
                top: 20%;
                animation: blink 1.5s infinite;
            }

            @keyframes blink {
                50% { opacity: 0.3; }
            }

            .highlight {
                color: var(--accent);
                font-size: 4.5rem;
                font-weight: 900;
                display: block;
                margin-top: 0.5rem;
                animation: glow 2s ease-in-out infinite;
            }

            @keyframes glow {
                0%, 100% { text-shadow: 0 0 10px var(--accent), 0 0 20px var(--accent), 0 0 30px var(--accent); }
                50% { text-shadow: 0 0 20px var(--accent), 0 0 30px var(--accent), 0 0 40px var(--accent); }
            }

            .hero-subtitle {
                font-size: 1.5rem;
                color: rgba(255, 255, 255, 0.95);
                max-width: 700px;
                margin: 0 auto 2rem;
                font-weight: 300;
                letter-spacing: 1px;
                animation: fadeIn 2s ease-out 0.5s both;
                text-shadow: 0 2px 5px rgba(0, 0, 0, 0.5);
            }

            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }

            .cta-button {
                display: inline-flex;
                align-items: center;
                padding: 1rem 2.5rem;
                font-size: 1.1rem;
                font-weight: 700;
                text-decoration: none;
                border-radius: 10px;
                transition: all 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55);
                margin: 0.5rem;
                text-transform: uppercase;
                letter-spacing: 1px;
                position: relative;
                overflow: hidden;
                z-index: 2;
            }

            .cta-button::before {
                content: '';
                position: absolute;
                top: 0;
                left: -200%;
                width: 300%;
                height: 100%;
                background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
                transition: left 0.6s ease;
                z-index: -1;
            }

            .cta-button:hover::before {
                left: 200%;
            }

            .cta-button.primary {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                background: var(--accent);
                color: var(--sena-dark);
                border-radius: 10px;
                min-width: 160px;
                min-height: 48px;
                font-size: 1.1rem;
                font-weight: 700;
                box-shadow: 0 8px 20px rgba(0, 151, 57, 0.2);
            }
            .cta-button.primary .button-icon {
                margin-right: 0.5rem;
                width: 2rem;
                height: 2rem;
                color: var(--sena-dark);
            }

            .cta-button.secondary {
                background: transparent;
                color: var(--accent);
                border: 3px solid var(--accent);
            }

            .cta-button.login {
                background: var(--sena-dark);
                color: var(--accent);
            }

            .cta-button:hover {
                transform: translateY(-4px) scale(1.05);
                box-shadow: 0 12px 30px rgba(0, 151, 57, 0.7);
            }

            .cta-button.admin {
                color: #fff !important;
            }

            .cta-button.student {
                color: #fff !important;
            }

            .cta-button.customer {
                color: #fff !important;
            }

            .button-container {
                display: flex;
                justify-content: center;
                gap: 1.5rem;
                flex-wrap: wrap;
                max-width: 100%;
                padding: 0 0.5rem;
            }

            .services {
                padding: 4rem 1rem;
                background: linear-gradient(180deg, white, var(--light-bg));
                position: relative;
                z-index: 2;
            }

            .section-title {
                color: var(--sena-dark);
                font-size: 2.5rem;
                font-weight: 800;
                text-align: center;
                margin-bottom: 3rem;
                text-transform: uppercase;
                letter-spacing: 2px;
                position: relative;
            }

            .section-title::before {
                content: '{';
                position: absolute;
                left: -25px;
                top: 10%;
                font-size: 1.8rem;
                color: var(--accent);
                animation: rotate 5s infinite linear;
            }

            .section-title::after {
                content: '}';
                position: absolute;
                right: -25px;
                top: 10%;
                font-size: 1.8rem;
                color: var(--accent);
                animation: rotate 5s infinite linear reverse;
            }

            @keyframes rotate {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }

            .services-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
                gap: 2rem;
                max-width: 1100px;
                margin: 0 auto;
                padding: 0 0.5rem;
            }

            .service-card {
                background: white;
                box-shadow: 0 15px 40px rgba(0, 0, 0, 0.1);
                padding: 2rem 2rem;
                border-radius: 15px;
                text-align: center;
                transition: all 0.6s ease;
                position: relative;
                border: 2px solid transparent;
                overflow: hidden;
            }

            .service-card::before {
                content: '';
                position: absolute;
                top: -100%;
                left: 0;
                width: 100%;
                height: 100%;
                background: linear-gradient(45deg, transparent, rgba(0, 151, 57, 0.2), transparent);
                transition: top 0.4s ease;
            }

            .service-card:hover::before {
                top: 0;
            }

            .service-card:hover {
                transform: translateY(-15px) rotate(2deg);
                border-color: var(--accent);
                box-shadow: 0 20px 50px rgba(0, 151, 57, 0.3);
            }

            .service-icon .icon {
                color: var(--sena-green);
                margin-bottom: 1.5rem;
                transform: scale(1.1);
                transition: transform 0.4s ease;
            }

            .service-card:hover .icon {
                transform: scale(1.3) rotate(8deg);
            }

            .service-card h3 {
                color: var(--sena-dark);
                font-size: 1.6rem;
                margin-bottom: 1rem;
                font-weight: 700;
                text-transform: uppercase;
            }

            .service-card p {
                color: var(--text);
                font-size: 1rem;
                line-height: 1.5;
            }

            .why-choose-us {
                padding: 4rem 1rem;
                background: white;
                position: relative;
                z-index: 2;
            }

            .why-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
                gap: 2rem;
                max-width: 1100px;
                margin: 0 auto;
                padding: 0 0.5rem;
            }

            .why-card {
                display: flex;
                align-items: center;
                gap: 2rem;
                padding: 2rem;
                background: linear-gradient(135deg, var(--light-bg), white);
                border-radius: 15px;
                transition: all 0.5s ease;
                border: 2px solid rgba(0, 151, 57, 0.2);
                position: relative;
                overflow: hidden;
            }

            .why-card::before {
                content: '</>';
                position: absolute;
                top: 10px;
                right: 10px;
                color: var(--accent);
                font-size: 1rem;
                opacity: 0.3;
                animation: floatCode 4s ease-in-out infinite;
            }

            @keyframes floatCode {
                0%, 100% { transform: translateY(0); }
                50% { transform: translateY(-10px); }
            }

            .why-card:hover {
                transform: translateY(-12px) scale(1.03);
                box-shadow: 0 15px 40px rgba(0, 151, 57, 0.2);
                border-color: var(--sena-green);
            }

            .why-icon {
                background: linear-gradient(135deg, var(--sena-green), var(--secondary-accent));
                border-radius: 50%;
                width: 5rem;
                height: 5rem;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
                transition: transform 0.5s ease;
            }

            .why-card:hover .why-icon {
                transform: scale(1.15) rotate(15deg);
            }

            .why-icon .icon {
                color: var(--accent);
                width: 2.5rem;
                height: 2.5rem;
            }

            .why-content h3 {
                color: var(--sena-dark);
                font-size: 1.4rem;
                margin-bottom: 1rem;
                font-weight: 700;
                text-transform: uppercase;
            }

            .why-content p {
                color: var(--text);
                font-size: 1rem;
                line-height: 1.5;
            }

            .contact-section {
                padding: 4rem 1rem;
                background: linear-gradient(160deg, var(--sena-green), var(--sena-dark));
                color: white;
                position: relative;
                overflow: hidden;
                z-index: 2;
            }

            .contact-section::before {
                content: '';
                position: absolute;
                top: -50%;
                left: -50%;
                width: 200%;
                height: 200%;
                background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 800"><g opacity="0.2"><circle cx="400" cy="400" r="200" fill="%23FFD700"><animate attributeName="r" values="200;220;200" dur="8s" repeatCount="indefinite"/></circle><rect x="300" y="300" width="100" height="100" fill="%2300A1D6" transform="rotate(45 350 350)"><animateTransform attributeName="transform" type="rotate" from="45 350 350" to="405 350 350" dur="10s" repeatCount="indefinite"/></rect></g></svg>') center/cover;
                transform: rotate(45deg);
                animation: backgroundFlow 15s ease-in-out infinite;
            }

            .contact-content {
                max-width: 800px;
                margin: 0 auto;
                text-align: center;
                position: relative;
                z-index: 2;
            }

            .form-group {
                margin-bottom: 2rem;
                text-align: left;
                position: relative;
                max-width: 100%;
            }

            .form-group label {
                color: white;
                font-size: 1.1rem;
                font-weight: 600;
                margin-bottom: 0.8rem;
                display: block;
                text-transform: uppercase;
                letter-spacing: 1px;
            }

            .form-group input,
            .form-group textarea {
                width: 100%;
                padding: 1.2rem;
                font-size: 1rem;
                border: 2px solid rgba(255, 255, 255, 0.5);
                border-radius: 10px;
                background: rgba(255, 255, 255, 0.2);
                color: white;
                transition: all 0.4s ease;
                font-family: inherit;
            }

            .form-group input:focus,
            .form-group textarea:focus {
                border-color: var(--accent);
                background: rgba(255, 255, 255, 0.3);
                box-shadow: 0 0 20px rgba(255, 193, 7, 0.4);
                outline: none;
            }

            .form-group input::placeholder,
            .form-group textarea::placeholder {
                color: rgba(255, 255, 255, 0.6);
                font-style: italic;
            }

            @media (max-width: 768px) {
                .hero-title { font-size: 3rem; }
                .highlight { font-size: 3.5rem; }
                .hero-subtitle { font-size: 1.2rem; }
                .section-title { font-size: 2rem; }
                .cta-button { padding: 1rem 2rem; font-size: 1rem; width: 100%; }
                .why-card { flex-direction: column; text-align: center; }
                .why-icon { width: 4.5rem; height: 4.5rem; }
                .button-container { flex-direction: column; }
                .service-card h3 { font-size: 1.4rem; }
                .why-content h3 { font-size: 1.2rem; }
            }

            @keyframes float {
                0%, 100% { transform: translateY(0) rotate(0); }
                50% { transform: translateY(-20px) rotate(8deg); }
            }

            /* Modal Flotante Styles */
            .floating-modal {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: 9999;
                display: none;
                align-items: center;
                justify-content: center;
                animation: fadeIn 0.3s ease-out;
            }

            .floating-modal.show {
                display: flex;
            }

            .modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.7);
                backdrop-filter: blur(5px);
                z-index: 9998;
                display: none;
                animation: fadeIn 0.3s ease-out;
            }

            .modal-overlay.show {
                display: block;
            }

            .floating-modal-content {
                background: white;
                border-radius: 20px;
                box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
                max-width: 800px;
                width: 90%;
                max-height: 90vh;
                overflow-y: auto;
                position: relative;
                animation: slideIn 0.4s ease-out;
                border: 3px solid var(--sena-green);
                color: #333;
            }

            .floating-modal-header {
                background: linear-gradient(135deg, #2ECC71, #27AE60);
                color: white !important;
                padding: 1.5rem 2rem;
                border-radius: 17px 17px 0 0;
                display: flex;
                justify-content: space-between;
                align-items: center;
                position: sticky;
                top: 0;
                z-index: 10;
                text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
            }

            .floating-modal-header * {
                color: white !important;
            }

            .floating-modal-title {
                display: flex;
                align-items: center;
                gap: 0.8rem;
                font-size: 1.4rem;
                font-weight: 600;
                color: white !important;
            }

            .floating-modal-title i {
                font-size: 1.6rem;
                color: white !important;
            }

            .floating-modal-title span {
                color: white !important;
                font-weight: 600;
                text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
            }

            .floating-modal-close {
                background: rgba(0, 0, 0, 0.3);
                border: 2px solid rgba(255, 255, 255, 0.8);
                color: white !important;
                width: 40px;
                height: 40px;
                border-radius: 50%;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: all 0.3s ease;
                font-size: 1.2rem;
                font-weight: bold;
                text-shadow: 0 1px 2px rgba(0, 0, 0, 0.5);
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            }

            .floating-modal-close:hover {
                background: rgba(0, 0, 0, 0.5);
                border-color: white;
                transform: scale(1.1);
                color: white !important;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
            }

            .floating-modal-body {
                padding: 2rem;
                color: #333;
            }

            .floating-modal .form-section {
                margin-bottom: 2rem;
                padding: 1.5rem;
                background: linear-gradient(135deg, #f8f9fa, #e9ecef);
                border-radius: 15px;
                border-left: 4px solid var(--sena-green);
            }

            .floating-modal .form-section h4 {
                color: #2c3e50 !important;
                font-size: 1.2rem;
                margin-bottom: 1.5rem;
                display: flex;
                align-items: center;
                gap: 0.5rem;
                font-weight: 600;
            }

            .floating-modal .form-section h4 i {
                color: var(--sena-green);
                font-size: 1.1rem;
            }

            .floating-modal .form-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 1.5rem;
            }

            .form-group {
                display: flex;
                flex-direction: column;
            }

            .floating-modal .form-group label {
                color: #2c3e50 !important;
                font-weight: 500;
                margin-bottom: 0.5rem;
                font-size: 0.95rem;
            }

            .floating-modal .form-group input,
            .floating-modal .form-group textarea {
                padding: 0.8rem 1rem;
                border: 2px solid #e9ecef;
                border-radius: 10px;
                font-size: 1rem;
                transition: all 0.3s ease;
                background: white;
                color: #333 !important;
                font-family: inherit;
            }

            .floating-modal .form-group input:focus,
            .floating-modal .form-group textarea:focus {
                outline: none;
                border-color: var(--sena-green);
                box-shadow: 0 0 0 3px rgba(0, 151, 57, 0.1);
                transform: translateY(-2px);
            }

            .floating-modal .form-group textarea {
                resize: vertical;
                min-height: 100px;
            }

            .floating-modal .form-group input::placeholder,
            .floating-modal .form-group textarea::placeholder {
                color: #6c757d;
                opacity: 0.7;
            }

            .floating-modal-footer {
                padding: 1.5rem 2rem;
                background: #f8f9fa;
                border-radius: 0 0 17px 17px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 1rem;
            }

            .floating-modal .btn-cancel,
            .floating-modal .btn-submit {
                padding: 0.8rem 1.5rem;
                border: none;
                border-radius: 10px;
                font-size: 1rem;
                font-weight: 500;
                cursor: pointer;
                display: flex;
                align-items: center;
                gap: 0.5rem;
                transition: all 0.3s ease;
                text-decoration: none;
            }

            .floating-modal .btn-cancel {
                background: linear-gradient(135deg, #dc3545, #c82333);
                color: white !important;
                font-weight: 600;
                border: 2px solid #c82333;
            }

            .floating-modal .btn-cancel:hover {
                background: linear-gradient(135deg, #c82333, #bd2130);
                transform: translateY(-2px);
                box-shadow: 0 5px 15px rgba(220, 53, 69, 0.4);
            }

            .floating-modal .btn-submit {
                background: linear-gradient(135deg, #2ECC71, #27AE60);
                color: white !important;
                font-weight: 600;
                border: 2px solid #27AE60;
            }

            .floating-modal .btn-submit:hover {
                transform: translateY(-2px);
                box-shadow: 0 5px 15px rgba(46, 204, 113, 0.4);
                background: linear-gradient(135deg, #27AE60, #229954);
            }

            .floating-modal .btn-submit:disabled {
                opacity: 0.6;
                cursor: not-allowed;
                transform: none;
                background: #6c757d;
                border-color: #6c757d;
            }

            .floating-modal .btn-submit i,
            .floating-modal .btn-cancel i {
                color: white !important;
                font-size: 1rem;
            }

            .floating-modal-close i {
                color: white !important;
                font-size: 1.2rem;
                font-weight: bold;
                text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
            }

            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }

            @keyframes slideIn {
                from {
                    opacity: 0;
                    transform: translateY(-50px) scale(0.9);
                }
                to {
                    opacity: 1;
                    transform: translateY(0) scale(1);
                }
            }

            @media (max-width: 768px) {
                .floating-modal-content {
                    width: 95%;
                    margin: 1rem;
                }

                .floating-modal-header {
                    padding: 1rem 1.5rem;
                }

                .floating-modal-body {
                    padding: 1.5rem;
                }

                .form-grid {
                    grid-template-columns: 1fr;
                }

                .floating-modal-footer {
                    flex-direction: column;
                    gap: 0.5rem;
                }

                .btn-cancel,
                .btn-submit {
                    width: 100%;
                    justify-content: center;
                }
            }

            /* Additional styles to ensure modal visibility */
            .floating-modal[object Object]          position: fixed !important;
                top: 0 !important;
                left: 0 !important;
                width:100t;
                height:100t;
                z-index:9999t;
                display: none !important;
                align-items: center !important;
                justify-content: center !important;
            }

            .floating-modal.show[object Object]           display: flex !important;
            }

            .modal-overlay[object Object]          position: fixed !important;
                top: 0 !important;
                left: 0 !important;
                width:100t;
                height:100t;
                background: rgba(0, 0, 00.7t;
                backdrop-filter: blur(5px) !important;
                z-index:9998t;
                display: none !important;
            }

            .modal-overlay.show[object Object]           display: block !important;
            }

            .floating-modal-content[object Object]        background: white !important;
                border-radius:20t;
                box-shadow: 0 25px 50px rgba(0, 0, 00.3t;
                max-width: 800t;
                width: 90% !important;
                max-height:90t;
                overflow-y: auto !important;
                position: relative !important;
                border:3x solid var(--sena-green) !important;
                color: #333 !important;
            }

            .floating-modal-header[object Object]        background: linear-gradient(135eg, #227AE60) !important;
                color: white !important;
                padding: 1.5rem2t;
                border-radius: 17px 17x 0 0 !important;
                display: flex !important;
                justify-content: space-between !important;
                align-items: center !important;
                position: sticky !important;
                top: 0 !important;
                z-index: 10 !important;
                text-shadow: 0 1px 2px rgba(0, 0, 00.3rtant;
            }

            .floating-modal-header *[object Object]             color: white !important;
                text-shadow: 0 1px 2px rgba(0, 0, 00.3rtant;
            }

            .floating-modal-title[object Object]           display: flex !important;
                align-items: center !important;
                gap:00.8t;
                font-size:10.4t;
                font-weight: 600 !important;
                color: white !important;
                text-shadow: 0 1px 2px rgba(0, 0, 00.3rtant;
            }

            .floating-modal-title i[object Object]              font-size:10.6t;
                color: white !important;
                text-shadow: 0 1px 2px rgba(0, 0, 00.3rtant;
            }

            .floating-modal-title span[object Object]             color: white !important;
                font-weight: 600 !important;
                text-shadow: 0 1px 2px rgba(0, 0, 00.3rtant;
            }

            .floating-modal-close[object Object]        background: rgba(0, 0, 00.3t;
                border: 2px solid rgba(255, 255, 2550.8t;
                color: white !important;
                width:40t;
                height:40t;
                border-radius: 50% !important;
                cursor: pointer !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                transition: all 0.3 ease !important;
                font-size:10.2t;
                font-weight: bold !important;
                text-shadow: 0 1px 2px rgba(0, 0, 00.5t;
                box-shadow: 0 2px 4px rgba(0, 0, 00.2rtant;
            }

            .floating-modal-close:hover[object Object]        background: rgba(0, 0, 00.5t;
                border-color: white !important;
                transform: scale(1.1) !important;
                color: white !important;
                box-shadow: 0 4px 12px rgba(0, 0, 00.4rtant;
            }

            .floating-modal-close i[object Object]             color: white !important;
                font-size:10.2t;
                font-weight: bold !important;
                text-shadow: 0 1px 2px rgba(0, 0, 00.3rtant;
            }
        </style>    </head>
    <body>
        <div class="software-factory-container">
            <!-- Hero Section -->
            <section class="hero-section">
                <div class="hero-content">
                    <div class="hero-icon">
                        <svg class="icon" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                        </svg>
                    </div>
                    <h1 class="hero-title">FÁBRICA DE SOFTWARE<br></h1>
                    <p class="hero-subtitle">Transformamos ideas en soluciones digitales de vanguardia con la excelencia del SENA</p>
                    <div class="button-container">
                        @guest
                            <a href="{{ route('login') }}" class="cta-button secondary">Iniciar Sesión</a>
                            <button type="button" class="cta-button primary" onclick="openFloatingModal()">
                                <svg class="button-icon" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M15 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm-9-2V7H4v3H1v2h3v3h2v-3h3v-2H6zm9 4c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                                </svg>
                                Nuevo Usuario
                            </button>
                        @else
                            @php
                                $userRoles = auth()->user()->roles->pluck('slug')->toArray();
                            @endphp

                            @if(in_array('fabricasoft.admin', $userRoles))
                                <a href="{{ route('fabricasoft.admin.welcome') }}" class="cta-button admin">Panel Administrativo</a>
                            @elseif(in_array('fabricasoft.apprentice', $userRoles))
                                <a href="{{ route('fabricasoft.apprentices.aprendiz') }}" class="cta-button student">Panel del Aprendiz</a>
                            @elseif(in_array('fabricasoft.users', $userRoles))
                                <a href="{{ route('fabricasoft.users') }}" class="cta-button customer">Panel de Usuario</a>
                            @endif
                        @endguest                        <a href="#contact" class="cta-button primary">
                            <svg class="button-icon" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                            </svg>
                            Contáctanos
                        </a>
=======
                        <a href="{{ route('fabricasoft.admin.welcome') }}" class="cta-button secondary">
                            <svg class="button-icon" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                            </svg>
                            Acceso Plataforma
                        </a>
                        @if(Auth::check() && checkRol('fabricasoft.admin'))
                    <li class="nav-item d-none d-sm-inline-block">
                        <a href="{{ route('fabricasoftsoft.admin.welcome') }}" class="nav-link @if (Route::is('fabricasoft.admin.*')) active @endif">Administración</a>
                    </li>
                    @endif
>>>>>>> b2a97326105ad95e73aae81a68a4e5cc652a3566
                    </div>
                </div>
            </section>

            <!-- Services Section -->
            <section class="services">
                <h2 class="section-title">Nuestros Servicios</h2>
                <div class="services-grid">
                    <div class="service-card">
                        <div class="service-icon">
                            <svg class="icon" viewBox="0 0 24 24" fill="currentColor">
<<<<<<< HEAD
                                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                            </svg>
                        </div>
                        <h3>Desarrollo a Medida</h3>
                        <p>Creamos soluciones de software personalizadas que impulsan la innovación y optimizan procesos empresariales con estándares globales.</p>                    </div>

                    <div class="service-card">
                        <div class="service-icon">
                            <svg class="icon" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M19.35 10.04A7.49 7.49 0 0 0 12 4a7.49 7.49 0 0 0-7.35 6.04A5.5 5.5 0 0 0 0 15.5C0 18.54 2.46 21 5.5 21h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM14 13v4h-4v-4H7l5-5 5 5h-3z"/>
                            </svg>
                        </div>
                        <h3>Soluciones Cloud</h3>
                        <p>Implementamos arquitecturas escalables y seguras en AWS, Azure y Google Cloud para potenciar tu transformación digital.</p>                    </div>

                    <div class="service-card">
                        <div class="service-icon">
                            <svg class="icon" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                            </svg>
                        </div>
                        <h3>Ciberseguridad</h3>
                        <p>Protegemos tus activos digitales con soluciones de seguridad avanzadas, garantizando tranquilidad y confianza.</p>                    </div>
                </div>
            </section>

            <!-- Why Choose Us Section -->
            <section class="why-choose-us">
                <h2 class="section-title">Por Qué Elegirnos</h2>                <div class="why-grid">
                    <div class="why-card">
                        <div class="why-icon">
                            <svg class="icon" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>                            </svg>
                        </div>
                        <div class="why-content">
                            <h3>Certificación SENA</h3>
                            <p>Nuestros proyectos están respaldados por la excelencia y prestigio del Servicio Nacional de Aprendizaje.</p>                        </div>
                    </div>

                    <div class="why-card">
                        <div class="why-icon">
                            <svg class="icon" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M16 11c1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3 1.34 3 3 3zm-8 0c1.66 0 3-1.34 3-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/>
                            </svg>
                        </div>
                        <div class="why-content">
                            <h3>Talento de Élite</h3>
                            <p>Contamos con un equipo de profesionales certificados en las tecnologías más innovadoras del mercado.</p>                        </div>
                    </div>

                    <div class="why-card">
                        <div class="why-icon">
                            <svg class="icon" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6l4.5 2.7.75-1.23L14 12.5V7h-3z"/>
                            </svg>
                        </div>
                        <div class="why-content">
                            <h3>Compromiso Temporal</h3>
                            <p>Entregamos proyectos puntuales con calidad excepcional, respetando tus plazos y expectativas.</p>                        </div>
                    </div>
                </div>
            </section>

            <!-- Contact Section -->
            <section class="contact-section" id="contact">
                <div class="contact-content">
                    <h2 class="section-title">¡Conecta con Nosotros!</h2>
                    <p class="hero-subtitle">Convierte tu visión en una realidad digital innovadora con nuestro equipo de expertos.</p>
                    <form>
                        <div class="form-group">
                            <label for="name">Nombre Completo</label>
                            <input type="text" id="name" name="name" placeholder="Tu nombre aquí" required>                        </div>
                        <div class="form-group">
                            <label for="email">Correo Electrónico</label>
                            <input type="email" id="email" name="email" placeholder="tucorreo@ejemplo.com" required>
                        </div>
                        <div class="form-group">
                            <label for="message">Tu Proyecto</label>
                            <textarea id="message" name="message" placeholder="Cuéntanos sobre tu idea o consulta..." rows="6" required></textarea>                        </div>
                        <button type="submit" class="cta-button login">
                            <svg class="button-icon" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
                            </svg>
                            Enviar Mensaje
                        </button>
                    </form>
                </div>
            </section>
        </div>

        <!-- Modal Overlay -->
        <div id="modalOverlay" class="modal-overlay"></div>

        <!-- Modal Nuevo Usuario Flotante -->
        <div id="floatingModal" class="floating-modal">
            <div class="floating-modal-content">
                <div class="floating-modal-header">
                    <div class="floating-modal-title">
                        <i class="fas fa-user-plus"></i>
                        <span>Nuevo Usuario - Pre-registro</span>
                    </div>
                    <button type="button" class="floating-modal-close" onclick="closeFloatingModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <form id="newUserForm" action="{{ route('fabricasoft.preregister.store') }}" method="POST">
                    @csrf
                    <div class="floating-modal-body">
                        <div class="form-section">
                            <h4><i class="fas fa-user"></i> Información Personal</h4>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="full_name">Nombre completo *</label>
                                    <input type="text" id="full_name" name="full_name" placeholder="Ingrese su nombre completo" required>
                                </div>
                                <div class="form-group">
                                    <label for="document_type">Tipo de documento *</label>
                                    <select id="document_type" name="document_type" required>
                                        <option value="">Seleccione tipo de documento</option>
                                        <option value="CC">Cédula de Ciudadanía (CC)</option>
                                        <option value="CE">Cédula de Extranjería (CE)</option>
                                        <option value="TI">Tarjeta de Identidad (TI)</option>
                                        <option value="PP">Pasaporte (PP)</option>
                                        <option value="NIT">NIT</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="document_number">Número de documento *</label>
                                    <input type="text" id="document_number" name="document_number" placeholder="Ej: 12345678" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Correo electrónico *</label>
                                    <input type="email" id="email" name="email" placeholder="usuario@empresa.co" required>
                                </div>
                                <div class="form-group">
                                    <label for="phone">Teléfono *</label>
                                    <input type="tel" id="phone" name="phone" placeholder="+57 123 456 7890" required>
                                </div>
                                <div class="form-group">
                                    <label for="password">Contraseña *</label>
                                    <input type="password" id="password" name="password" placeholder="Crea una contraseña" required>
                                </div>
                            </div>
                        </div>

                        <div class="form-section">
                            <h4><i class="fas fa-building"></i> Información Empresarial</h4>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="company_name">Empresa o institución *</label>
                                    <input type="text" id="company_name" name="company_name" placeholder="Ejemplo: SENA" required>
                                </div>
                                <div class="form-group">
                                    <label for="position">Cargo o rol *</label>
                                    <input type="text" id="position" name="position" placeholder="Gerente de Proyecto" required>
                                </div>
                                <div class="form-group">
                                    <label for="department">Departamento *</label>
                                    <input type="text" id="department" name="department" placeholder="Tecnología" required>
                                </div>
                            </div>
                        </div>

                        <div class="form-section">
                            <h4><i class="fas fa-map-marker-alt"></i> Ubicación</h4>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="country">País *</label>
                                    <input type="text" id="country" name="country" placeholder="Colombia" required>
                                </div>
                                <div class="form-group">
                                    <label for="state">Departamento *</label>
                                    <input type="text" id="state" name="state" placeholder="Antioquia" required>
                                </div>
                                <div class="form-group">
                                    <label for="municipality">Municipio *</label>
                                    <input type="text" id="municipality" name="municipality" placeholder="Medellín" required>
                                </div>
                            </div>
                        </div>

                        <div class="form-section">
                            <h4><i class="fas fa-lightbulb"></i> Descripción del Proyecto</h4>
                            <div class="form-group">
                                <label for="project_description">Describa su proyecto o necesidad *</label>
                                <textarea id="project_description" name="project_description" rows="4" placeholder="Describa brevemente su proyecto o necesidad de software..." required></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="floating-modal-footer">
                        <button type="button" class="btn-cancel" onclick="closeFloatingModal()">
                            <i class="fas fa-times"></i> Cancelar
                        </button>
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-paper-plane"></i> Enviar Solicitud
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <script>
            document.addEventListener('DOMContentLoaded', () => {
                // Smooth scroll                document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                    anchor.addEventListener('click', function (e) {
                        e.preventDefault();
                        document.querySelector(this.getAttribute('href')).scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'                        });
                    });
                });

                // Intersection Observer for animations                const observer = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            entry.target.style.opacity = 1;
                            entry.target.style.transform = 'translateY(0) scale(1) rotate(0deg)';
                            entry.target.style.transition = 'all 1.2s cubic-bezier(0.68, -0.55, 0.265, 1.55)';
                        }
                    });
                }, {
                    threshold: 0.4
                });

                // Animate cards
                document.querySelectorAll('.service-card, .why-card').forEach((card) => {
                    card.style.opacity = 0;
                    card.style.transform = 'translateY(100px) scale(0.9) rotate(-3deg)';
                    observer.observe(card);
                });

                // Parallax effect
                const hero = document.querySelector('.hero-section');
                window.addEventListener('scroll', () => {
                    const scrollPosition = window.pageYOffset;
                    hero.style.backgroundPositionY = `${scrollPosition * 0.5}px`;
                });

                // Form validation with animation
                const form = document.querySelector('form');
                form.addEventListener('submit', (e) => {
                    e.preventDefault();
                    const name = form.querySelector('#name').value;
                    const email = form.querySelector('#email').value;
                    const message = form.querySelector('#message').value;

                    if (name && email && message) {
                        const submitButton = form.querySelector('button[type="submit"]');
                        submitButton.style.transform = 'scale(1.2)';
                        submitButton.style.background = '#ffffff';
                submitButton.style.color = '#000000';
                        setTimeout(() => {
                            alert('¡Mensaje enviado con éxito!');
                            form.reset();
                            submitButton.style.transform = 'scale(1)';
                            submitButton.style.background = '';
                        }, 300);
                    } else {
                        const inputs = form.querySelectorAll('input, textarea');
                        inputs.forEach(input => {
                            if (!input.value) {
                                input.style.animation = 'shake 0.3s ease';
                                setTimeout(() => input.style.animation = '', 300);
                            }
                        });
                        alert('Por favor, completa todos los campos.');
                    }
                });

                // Keyframe for shake animation
                const styleSheet = document.createElement('style');
                styleSheet.textContent = `
                    @keyframes shake {
                        0%, 100% { transform: translateX(0); }
                        25% { transform: translateX(-10px); }
                        75% { transform: translateX(10px); }
                    }
                `;
                document.head.appendChild(styleSheet);

                // Icon hover effects
                document.querySelectorAll('.icon').forEach(icon => {
                    icon.addEventListener('mouseenter', () => {
                        icon.style.transform = 'scale(1.4) rotate(15deg)';
                        icon.style.filter = 'drop-shadow(0 8px 15px rgba(0, 0, 0, 0.6))';
                    });
                    icon.addEventListener('mouseleave', () => {
                        icon.style.transform = 'scale(1.2) rotate(0deg)';
                        icon.style.filter = 'drop-shadow(0 5px 10px rgba(0, 0, 0, 0.5))';
                    });
                });

                // Eliminado el efecto de partículas del mouse
                // (Aquí estaba el código del canvas y las partículas)

                // Typewriter effect for hero subtitle
                const subtitle = document.querySelector('.hero-subtitle');
                const text = subtitle.textContent;
                subtitle.textContent = '';
                let i = 0;

                function typeWriter() {
                    if (i < text.length) {
                        subtitle.textContent += text.charAt(i);
                        i++;
                        setTimeout(typeWriter, 50);
                    }
                }

                setTimeout(typeWriter, 1000);

                // Manejo del formulario de nuevo usuario
                const newUserForm = document.getElementById('newUserForm');
                if (newUserForm) {
                    newUserForm.addEventListener('submit', function(e) {
                        e.preventDefault();
                        
                        const formData = new FormData(this);
                        const submitButton = this.querySelector('button[type="submit"]');
                        const originalText = submitButton.innerHTML;
                        
                        submitButton.disabled = true;
                        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
                        
                        fetch(this.action, {
                            method: 'POST',
                            body: formData,
                            headers: {
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                            }
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                showNotification('Solicitud enviada exitosamente. Recibirá una notificación por correo electrónico cuando su solicitud sea revisada.', 'success');
                                closeFloatingModal();
                                this.reset();
                            } else {
                                showNotification('Error: ' + (data.message || 'No se pudo enviar la solicitud'), 'error');
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            showNotification('Error al enviar la solicitud. Por favor, intente nuevamente.', 'error');
                        })
                        .finally(() => {
                            submitButton.disabled = false;
                            submitButton.innerHTML = originalText;
                        });
                    });
                }
            });

            // Funciones para el modal flotante
            function openFloatingModal() {
                const modal = document.getElementById('floatingModal');
                const overlay = document.getElementById('modalOverlay');
                
                modal.classList.add('show');
                overlay.classList.add('show');
                document.body.style.overflow = 'hidden';
                
                // Focus en el primer campo
                setTimeout(() => {
                    document.getElementById('full_name').focus();
                }, 300);
            }

            function closeFloatingModal() {
                const modal = document.getElementById('floatingModal');
                const overlay = document.getElementById('modalOverlay');
                
                modal.classList.remove('show');
                overlay.classList.remove('show');
                document.body.style.overflow = '';
            }

            // Cerrar modal al hacer clic en el overlay
            document.getElementById('modalOverlay').addEventListener('click', closeFloatingModal);

            // Cerrar modal con la tecla Escape
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    closeFloatingModal();
                }
            });

            // Función para mostrar notificaciones
            function showNotification(message, type = 'info') {
                // Crear elemento de notificación
                const notification = document.createElement('div');
                notification.className = `notification notification-${type}`;
                notification.innerHTML = `
                    <div class="notification-content">
                        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
                        <span>${message}</span>
                        <button onclick="this.parentElement.parentElement.remove()">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                `;
                
                // Agregar estilos
                notification.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: ${type === 'success' ? '#d4edda' : type === 'error' ? '#f8d7da' : '#d1ecf1'};
                    color: ${type === 'success' ? '#155724' : type === 'error' ? '#721c24' : '#0c5460'};
                    border: 1px solid ${type === 'success' ? '#c3e6cb' : type === 'error' ? '#f5c6cb' : '#bee5eb'};
                    border-radius: 10px;
                    padding: 1rem;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
                    z-index: 10000;
                    animation: slideInRight 0.3s ease-out;
                    max-width: 400px;
                `;
                
                // Agregar al DOM
                document.body.appendChild(notification);
                
                // Auto-remover después de 5 segundos
                setTimeout(() => {
                    if (notification.parentElement) {
                        notification.remove();
                    }
                }, 5000);
            }

            // Agregar keyframe para la animación de notificación
            const notificationStyle = document.createElement('style');
            notificationStyle.textContent = `
                @keyframes slideInRight {
                    from {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
            `;
            document.head.appendChild(notificationStyle);
        </script>
    </body>
</html>