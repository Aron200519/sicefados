<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="{{ asset('images/Favicon2.png') }}" type="image/x-icon">
    <title>Panel Usuario</title>
    <!-- Google Font: Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --sena-green: #2ECC71;
            --sena-dark-green: #27AE60;
            --sena-light-green: #ECF9F2;
            --navbar-gradient: linear-gradient(90deg, #2ECC71 0%, #27AE60 100%);
        }
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f9fafb;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        .navbar {
            background: var(--navbar-gradient);
            height: 64px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 24px;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        .navbar .brand {
            color: white;
            font-size: 1.5rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: transform 0.3s ease, opacity 0.3s ease;
        }
        .navbar .brand:hover {
            transform: translateY(-2px);
            opacity: 0.95;
        }
        .navbar .brand i {
            font-size: 1.8rem;
        }
        .navbar .user-menu {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .navbar .user-menu .notification-bell {
            color: white;
            font-size: 1.2rem;
            padding: 8px;
            border-radius: 50%;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .navbar .user-menu .notification-bell:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: scale(1.1);
        }
        /* Notification specific styles */
        .notification-bell-container {
            position: relative;
        }
        .notification-count {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: #e53e3e; /* Red color for count */
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 0.7rem;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 18px; /* Ensure circular shape for single digits */
            height: 18px;
        }
        .notifications-dropdown {
            position: absolute;
            top: 50px; /* Adjust based on navbar height */
            right: 0;
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            width: 250px; /* Adjust width as needed for status only */
            max-height: 300px; /* Max height with scroll */
            overflow-y: auto;
            z-index: 1000;
            display: none; /* Hidden by default */
        }
        .notifications-dropdown.show {
            display: block;
        }
        .notifications-dropdown-header {
            padding: 12px;
            font-weight: 600;
            border-bottom: 1px solid #e2e8f0;
            color: #2d3748;
        }
        .notification-item {
            padding: 12px;
            border-bottom: 1px solid #edf2f7;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }
        .notification-item:hover {
            background-color: #f7fafc;
        }
        .notification-item:last-child {
            border-bottom: none;
        }
        .notification-item strong {
            color: var(--sena-dark-green);
        }
        .notification-item p {
            font-size: 0.85rem;
            color: #4a5568;
        }
        .no-notifications {
            padding: 12px;
            color: #718096;
            text-align: center;
        }
        .navbar .user-menu .user-info {
            display: flex;
            align-items: center;
            gap: 8px;
            color: white;
            font-weight: 500;
            cursor: pointer;
            padding: 8px 14px;
            border-radius: 9999px;
            background-color: rgba(255, 255, 255, 0.1);
            transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
        }
        .navbar .user-menu .user-info:hover {
            background-color: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        .navbar .user-menu .user-avatar {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background-color: white;
            color: var(--sena-dark-green);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 14px;
            border: 2px solid var(--sena-light-green);
        }
        .navbar .mobile-toggle {
            display: none;
        }
        .sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            background-color: #ffffff;
            box-shadow: 2px 0 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
            z-index: 2000;
        }
        .sidebar-hidden {
            transform: translateX(-250px);
        }
        .content-wrapper {
            margin-left: 250px;
            padding: 24px;
            min-height: calc(100vh - 64px);
            transition: margin-left 0.3s ease-in-out;
            margin-top: 64px;
        }
        .content-wrapper-expanded {
            margin-left: 0;
        }
        .sidebar-header {
            padding: 16px;
            border-bottom: 2px solid var(--sena-green);
            background-color: #ffffff;
            color: var(--sena-dark-green);
            font-weight: 600;
            font-size: 1.25rem;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }
        .sidebar-header .mobile-toggle {
            display: block;
            color: var(--sena-dark-green);
            font-size: 1.5rem;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .sidebar-header .mobile-toggle:hover {
            background-color: var(--sena-light-green);
            transform: scale(1.1);
        }
        .sidebar-nav {
            padding: 16px;
        }
        .sidebar-nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar-nav li {
            margin-bottom: 8px;
        }
        .sidebar-nav a {
            display: flex;
            align-items: center;
            padding: 12px;
            border-radius: 8px;
            color: #1e293b;
            font-weight: 500;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }
        .sidebar-nav a:hover, .sidebar-nav a.active {
            background-color: var(--sena-light-green);
            color: var(--sena-dark-green);
            transform: translateX(5px);
        }
        .sidebar-nav .nav-icon {
            margin-right: 12px;
            font-size: 1.1rem;
        }
        .sidebar-nav .nav-treeview {
            padding-left: 24px;
            margin-top: 8px;
        }
        .sidebar-nav .nav-treeview a {
            font-size: 0.95rem;
        }
        .footer {
            background-color: var(--sena-dark-green);
            color: white;
            padding: 12px;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: calc(100% - 250px);
            margin-left: 250px;
            transition: margin-left 0.3s ease-in-out;
        }
        .footer-expanded {
            margin-left: 0;
            width: 100%;
        }
        .dropdown-menu {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(8px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1001;
            transform: translateY(-100%);
            transition: transform 0.3s ease-in-out;
            padding: 16px 24px;
        }
        .dropdown-menu.show {
            transform: translateY(0);
        }
        .dropdown-menu a {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            color: #1e293b;
            font-size: 1rem;
            font-weight: 500;
            border-radius: 6px;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }
        .dropdown-menu a:hover {
            background-color: var(--sena-light-green);
            color: var(--sena-dark-green);
            transform: translateX(4px);
        }
        .card {
            border-top: 4px solid var(--sena-green);
            border-radius: 0.75rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        .btn-success {
            background-color: var(--sena-green);
            border-color: var(--sena-green);
            transition: background-color 0.3s ease, border-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
        }
        .btn-success:hover {
            background-color: var(--sena-dark-green);
            border-color: var(--sena-dark-green);
            transform: scale(1.05);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        .modal-content {
            border-radius: 0.75rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .welcome-card, .options-card {
            background-color: #ffffff;
            border-left: 6px solid var(--sena-green);
            border-radius: 0.75rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 24px;
            margin-bottom: 24px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            animation: slideIn 0.5s ease-out;
        }
        .welcome-card:hover, .options-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
        }
        .welcome-card i, .options-card i {
            color: var(--sena-green);
            font-size: 2rem;
            margin-right: 16px;
        }
        .welcome-card p, .options-card p {
            color: #1e293b;
            font-size: 1.1rem;
            line-height: 1.6;
            margin: 0;
        }
        .options-card h3 {
            color: #1e293b;
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 16px;
        }
        .options-card ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .options-card li {
            display: flex;
            align-items: flex-start;
            margin-bottom: 12px;
        }
        .options-card li i {
            font-size: 1.2rem;
            margin-top: 4px;
        }
        .options-card li p {
            margin-left: 12px;
            font-size: 1rem;
        }
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        @media (max-width: 768px) {
            .navbar .mobile-toggle {
                display: block;
            }
            .navbar .brand {
                font-size: 1.2rem;
            }
            .sidebar {
                transform: translateX(-250px);
                z-index: 2000;
            }
            .sidebar.sidebar-visible {
                transform: translateX(0);
            }
            .content-wrapper {
                margin-left: 0;
            }
            .footer {
                margin-left: 0;
                width: 100%;
            }
            .dropdown-menu {
                padding: 12px 16px;
            }
            .dropdown-menu a {
                font-size: 0.9rem;
            }
            .welcome-card, .options-card {
                padding: 16px;
            }
            .welcome-card p, .options-card p {
                font-size: 1rem;
            }
            .welcome-card i, .options-card i {
                font-size: 1.5rem;
            }
            .options-card h3 {
                font-size: 1.1rem;
            }
            .options-card li p {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper" style="visibility: hidden;">

        <!-- Dropdown Menu -->
        <div class="dropdown-menu hidden" id="dropdown-menu">
            <div class="flex justify-end items-center space-x-4">
                <button type="button" class="text-gray-500 text-2xl h-12 w-12 flex items-center justify-center hover:bg-gray-200 rounded-full" onclick="toggleDropdown()">×</button>
                <a href="#" class="block" onclick="confirmLogout(event, 'logout-form');">
                    <i class="fas fa-sign-out-alt mr-2"></i> Cerrar Sesión
                </a>
            </div>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="hidden">
                @csrf
            </form>
        </div>

        <!-- Navbar -->
        <nav class="navbar">
            <div class="flex items-center">
                <div class="brand">
                    <i class="fas fa-laptop-code"></i>
                    <span></span>
                </div>
            </div>
            <div class="user-menu">
                <div class="notification-bell-container relative">
                    <button class="notification-bell" id="notification-bell-btn">
                        <i class="fas fa-bell"></i>
                        <span class="notification-count" id="notification-count">0</span>
                    </button>
                    <div class="notifications-dropdown" id="notifications-dropdown">
                        <div class="notifications-dropdown-header">Mis Solicitudes Pendientes</div>
                        <div id="notification-list-container">
                            <!-- Notificaciones se cargarán aquí -->
                            <div class="no-notifications">No hay solicitudes pendientes.</div>
                        </div>
                    </div>
                </div>
                <div class="relative">
                    <button class="user-info focus:outline-none" id="navbarDropdown">
                        <div class="user-avatar">U</div>
                        <span>Usuario</span>
                        <i class="fas fa-chevron-down text-xs"></i>
                    </button>
                </div>
            </div>
        </nav>

        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header flex items-center justify-between">
                <div class="flex items-center gap-2">
                    <i class="fas fa-cogs"></i>
                    <span>USUARIO</span>
                </div>
                <button class="mobile-toggle ml-2" id="toggle-sidebar">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            <div class="sidebar-nav">
                <nav>
                    <ul>
                        <li>
                            <a href="{{ route('fabricasoft.cliente.dashboard') }}" class="nav-link">
                                <i class="fas fa-tachometer-alt text-green-500 nav-icon"></i>
                                <span>Inicio</span>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="nav-link">
                                <i class="fas fa-hands-helping text-green-500 nav-icon"></i>
                                <span>Servicios</span>
                                <i class="fas fa-angle-left ml-auto transition-transform duration-200"></i>
                            </a>
                            <ul class="nav-treeview hidden">
                                <li>
                                    <a href="{{ route('fabricasoft.nuevasolicitud') }}" class="nav-link bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg mx-2 mb-2 shadow-lg hover:from-green-600 hover:to-green-700 transition-all duration-300 transform hover:scale-105">
                                        <i class="fas fa-file-signature text-white nav-icon"></i>
                                        <span class="font-semibold text-center">Nueva Solicitud</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="{{ route('fabricasoft.cliente.seguimiento') }}" class="nav-link">
                                        <i class="fas fa-tasks text-green-500 nav-icon"></i>
                                        <span>Seguimiento</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="{{ route('fabricasoft.cliente.soporte') }}" class="nav-link">
                                        <i class="fas fa-headset text-green-500 nav-icon"></i>
                                        <span>Soporte Técnico</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="{{ route('fabricasoft.ajustes') }}" class="nav-link">
                                        <i class="fas fa-cog text-green-500 nav-icon"></i>
                                        <span>Ajustes</span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                    </ul>
                </nav>
            </div>
        </aside>
        <!-- Content Wrapper -->
        <div class="content-wrapper" id="content-wrapper">
            <div class="p-4 border-b bg-white">
                <h1 class="text-2xl font-semibold text-gray-800">Panel de Usuario</h1>
            </div>
            <div class="p-4">
                <div class="welcome-card flex items-center">
                    <i class="fas fa-user-cog"></i>
                    <p>
                        Bienvenido al Panel de usuario. Administre sus proyectos con eficiencia, realice solicitudes de software personalizadas o consulte información relevante según sus necesidades.
                    </p>
                </div>
                <div class="options-card">
                    <div class="flex items-center">
                        <i class="fas fa-list-ul"></i>
                        <h3>¿Listo para empezar? Seleccione una opción del menú</h3>
                    </div>
                    <ul class="mt-4">
                        <li class="bg-gradient-to-r from-green-50 to-green-100 p-4 rounded-lg border-l-4 border-green-500 shadow-sm hover:shadow-md transition-all duration-300 mb-3">
                            <div class="flex items-start">
                                <i class="fas fa-file-signature text-green-600 text-xl mt-1 mr-3"></i>
                                <div>
                                    <p class="font-semibold text-green-800 mb-1">Nueva Solicitud:</p>
                                    <p class="text-gray-700">Complete el formulario para solicitar un software adaptado a sus especificaciones y requisitos.</p>
                                </div>
                            </div>
                        </li>
                        <li class="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500 shadow-sm hover:shadow-md transition-all duration-300 mb-3">
                            <div class="flex items-start">
                                <i class="fas fa-tasks text-blue-600 text-xl mt-1 mr-3"></i>
                                <div>
                                    <p class="font-semibold text-blue-800 mb-1">Seguimiento:</p>
                                    <p class="text-gray-700">Una vez aprobado su software, supervise el avance del proyecto o comuníquese con el equipo de desarrollo.</p>
                                </div>
                            </div>
                        </li>
                        <li class="bg-purple-50 p-4 rounded-lg border-l-4 border-purple-500 shadow-sm hover:shadow-md transition-all duration-300 mb-3">
                            <div class="flex items-start">
                                <i class="fas fa-headset text-purple-600 text-xl mt-1 mr-3"></i>
                                <div>
                                    <p class="font-semibold text-purple-800 mb-1">Soporte Técnico:</p>
                                    <p class="text-gray-700">Solicite asistencia a nuestro equipo de programadores para resolver cualquier inquietud o realizar consultas.</p>
                                </div>
                            </div>
                        </li>
                        <li class="bg-orange-50 p-4 rounded-lg border-l-4 border-orange-500 shadow-sm hover:shadow-md transition-all duration-300 mb-3">
                            <div class="flex items-start">
                                <i class="fas fa-user-cog text-orange-600 text-xl mt-1 mr-3"></i>
                                <div>
                                    <p class="font-semibold text-orange-800 mb-1">Gestión de Perfil:</p>
                                    <p class="text-gray-700">Acceda a su panel de configuración personal para verificar, actualizar o modificar su información de usuario. Mantenga sus datos actualizados para garantizar una comunicación efectiva y un seguimiento óptimo de sus proyectos de desarrollo de software.</p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                @yield('content')
            </div>
        </div>

        <!-- Footer -->
        <footer class="footer" id="footer">
            <strong>Copyright © 2024-2025
                <a href="#" class="text-white hover:underline">Fabrica de software - SENA</a>.
            </strong>
            Todos los derechos reservados.
            <div class="float-right hidden sm:inline-block">
                <b>Versión</b> 1.0.0
            </div>
        </footer>

        <!-- Botón para mostrar el menú lateral cuando está oculto -->
        <button id="show-sidebar-btn" style="display:none; position:fixed; top:32px; left:24px; z-index:3000; background:#2ECC71; color:white; padding:12px 16px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.2); border:none; font-size:1.5rem; cursor:pointer; transform:translateY(-50%);" onclick="toggleSidebar(true)">
            <i class="fas fa-bars"></i>
        </button>
    </div>

    <script>
        // Mostrar contenido inmediatamente
        document.addEventListener('DOMContentLoaded', function () {
            const wrapper = document.querySelector('.wrapper');
            wrapper.style.visibility = 'visible';
            document.body.style.overflow = 'auto';
        });

        // Sidebar Toggle
        function toggleSidebar(forceShow = null) {
            const sidebar = document.getElementById('sidebar');
            const showSidebarBtn = document.getElementById('show-sidebar-btn');
            if (window.innerWidth <= 768) {
                // En móvil
                if (forceShow === true) {
                    sidebar.classList.add('sidebar-visible');
                } else if (forceShow === false) {
                    sidebar.classList.remove('sidebar-visible');
                } else {
                    sidebar.classList.toggle('sidebar-visible');
                }
            } else {
                // En escritorio
                if (forceShow === true) {
                    sidebar.classList.remove('sidebar-hidden');
                    document.getElementById('content-wrapper').classList.remove('content-wrapper-expanded');
                    document.getElementById('footer').classList.remove('footer-expanded');
                } else if (forceShow === false) {
                    sidebar.classList.add('sidebar-hidden');
                    document.getElementById('content-wrapper').classList.add('content-wrapper-expanded');
                    document.getElementById('footer').classList.add('footer-expanded');
                } else {
                    sidebar.classList.toggle('sidebar-hidden');
                    document.getElementById('content-wrapper').classList.toggle('content-wrapper-expanded');
                    document.getElementById('footer').classList.toggle('footer-expanded');
                }
            }
            checkSidebarBtn();
        }

        // Asignar eventos a ambos botones de hamburguesa
        document.addEventListener('DOMContentLoaded', function() {
            const sidebarToggleBtn = document.getElementById('toggle-sidebar');
            const showSidebarBtn = document.getElementById('show-sidebar-btn');
            if (sidebarToggleBtn) {
                sidebarToggleBtn.onclick = function() {
                    toggleSidebar();
                };
            }
            if (showSidebarBtn) {
                showSidebarBtn.onclick = function() {
                    // Siempre mostrar el menú al hacer clic
                    toggleSidebar(true);
                };
            }
            checkSidebarBtn();
        });

        // Mostrar el botón si el sidebar está oculto al cargar o al redimensionar
        function checkSidebarBtn() {
            const sidebar = document.getElementById('sidebar');
            const showSidebarBtn = document.getElementById('show-sidebar-btn');
            // Mostrar el botón si el sidebar está oculto
            if ((window.innerWidth <= 768 && !sidebar.classList.contains('sidebar-visible')) ||
                (window.innerWidth > 768 && sidebar.classList.contains('sidebar-hidden'))) {
                showSidebarBtn.style.display = 'block';
            } else {
                showSidebarBtn.style.display = 'none';
            }
        }
        window.addEventListener('resize', checkSidebarBtn);

        // Dropdown Menu
        function toggleDropdown() {
            const dropdown = document.getElementById('dropdown-menu');
            dropdown.classList.toggle('hidden');
            dropdown.classList.toggle('show');
        }

        document.getElementById('navbarDropdown').addEventListener('click', toggleDropdown);

        // Close Dropdown on Outside Click
        document.addEventListener('click', function (event) {
            const dropdown = document.getElementById('dropdown-menu');
            const toggle = document.getElementById('navbarDropdown');
            if (!toggle.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.add('hidden');
                dropdown.classList.remove('show');
            }
        });

        // Logout Confirmation
        function confirmLogout(event, formId) {
            event.preventDefault();
            Swal.fire({
                title: '¿Estás seguro?',
                text: '¿Deseas cerrar tu sesión?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#2ECC71',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, cerrar sesión',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById(formId).submit();
                }
            });
        }

        // Notifications (Placeholder)
        let pendingRequests = []; // Array para almacenar las solicitudes pendientes

        async function fetchPendingRequests() {
            try {
                const response = await fetch('{{ route('fabricasoft.pending_requests') }}');
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();
                pendingRequests = data; // Almacena las solicitudes obtenidas
                updateNotificationsDisplay();
            } catch (error) {
                console.error("Error al obtener solicitudes pendientes:", error);
                document.getElementById('notification-count').textContent = 'Error';
                document.getElementById('notification-list-container').innerHTML = '<div class="no-notifications">Error al cargar notificaciones.</div>';
            }
        }

        function updateNotificationsDisplay() {
            const countElement = document.getElementById('notification-count');
            const listContainer = document.getElementById('notification-list-container');
            const noNotificationsMessage = document.getElementById('no-notifications-message');

            countElement.textContent = pendingRequests.length;

            if (pendingRequests.length > 0) {
                listContainer.innerHTML = ''; // Limpiar notificaciones previas
                pendingRequests.forEach(request => {
                    const notificationItem = document.createElement('div');
                    notificationItem.className = 'notification-item';
                    // Mostrar Nombre del proyecto, Nombre del cliente, Correo electrónico del cliente
                    notificationItem.innerHTML = `
                        <p><strong>Proyecto:</strong> ${request.project_name ?? 'N/A'}</p>
                        <p><strong>Cliente:</strong> ${request.applicant_name ?? 'N/A'}</p>
                        <p><strong>Tipo de Documento:</strong> ${request.document_type ?? 'N/A'}</p>
                        <p><strong>Número de Documento:</strong> ${request.document_number ?? 'N/A'}</p>
                        <p><strong>Email:</strong> ${request.email ?? 'N/A'}</p>
                        <p><strong>Estado:</strong> ${request.status ? (request.status.charAt(0).toUpperCase() + request.status.slice(1)) : 'N/A'}</p>
                    `;
                    // **NO AÑADIR eventListener para redirección**
                    listContainer.appendChild(notificationItem);
                });
                if (noNotificationsMessage) {
                    noNotificationsMessage.style.display = 'none'; // Oculta el mensaje si hay notificaciones
                    noNotificationsMessage.classList.remove('pulse-effect');
                }
            } else {
                listContainer.innerHTML = ''; // Limpiar notificaciones previas para que solo quede el mensaje
                if (!noNotificationsMessage) {
                    const newNoNotificationsDiv = document.createElement('div');
                    newNoNotificationsDiv.className = 'no-notifications';
                    newNoNotificationsDiv.id = 'no-notifications-message';
                    newNoNotificationsDiv.textContent = 'No hay solicitudes pendientes.';
                    listContainer.appendChild(newNoNotificationsDiv);
                    newNoNotificationsDiv.classList.add('pulse-effect');
                } else {
                    noNotificationsMessage.style.display = 'block';
                    noNotificationsMessage.classList.add('pulse-effect');
                    noNotificationsMessage.textContent = 'No hay solicitudes pendientes.';
                    listContainer.appendChild(noNotificationsMessage);
                }
            }
        }

        // Alternar el desplegable de notificaciones
        document.getElementById('notification-bell-btn').addEventListener('click', function() {
            const dropdown = document.getElementById('notifications-dropdown');
            dropdown.classList.toggle('show');
        });

        // Cerrar el desplegable de notificaciones al hacer clic fuera
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('notifications-dropdown');
            const toggle = document.getElementById('notification-bell-btn');
            if (!toggle.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });

        // Carga inicial y actualización periódica
        document.addEventListener('DOMContentLoaded', () => {
            fetchPendingRequests();
            setInterval(fetchPendingRequests, 30000); // Actualizar cada 30 segundos
        });

        // La función showNotifications original es ahora redundante y puede ser eliminada o modificada para este mensaje.
        function showNotifications() {
            Swal.fire({
                title: 'Notificaciones',
                text: 'Las notificaciones se muestran en el menú desplegable de la campana.',
                icon: 'info',
                confirmButtonColor: '#2ECC71'
            });
        }

        // Treeview Toggle
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', function(e) {
                const treeview = this.nextElementSibling;
                if (treeview && treeview.classList.contains('nav-treeview')) {
                    e.preventDefault();
                    treeview.classList.toggle('hidden');
                    const angle = this.querySelector('.fa-angle-left, .fa-angle-down');
                    if (angle) {
                        angle.classList.toggle('fa-angle-down');
                        angle.classList.toggle('fa-angle-left');
                    }
                }
            });
        });
    </script>
    @stack('scripts')
</body>
</html>