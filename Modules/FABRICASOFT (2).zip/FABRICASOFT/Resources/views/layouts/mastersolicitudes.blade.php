<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="{{ asset('images/Favicon2.png') }}" type="image/x-icon">
    <title>Fabrica de Software</title>
    <!-- Google Font: Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">
    <!-- Google Font: Cinzel for Preloader -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&display=swap">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --sena-green: #2ECC71;
            --sena-dark-green: #27AE60;
            --sena-light-green: #ECF9F2;
            --navbar-gradient: linear-gradient(90deg, #2ECC71 0%, #27AE60 100%);
            --custom-yellow: #FBBF24; /* A yellow that complements the green theme */
        }
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f9fafb;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        .navbar {
            background: var(--navbar-gradient);
            height: 64px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 24px;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        .navbar .brand {
            color: white;
            font-size: 1.5rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: transform 0.3s ease, opacity 0.3s ease;
        }
        .navbar .brand:hover {
            transform: translateY(-2px);
            opacity: 0.95;
        }
        .navbar .brand i {
            font-size: 1.8rem;
        }
        .navbar .user-menu {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .navbar .user-menu .notification-bell {
            color: white;
            font-size: 1.2rem;
            padding: 8px;
            border-radius: 50%;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .navbar .user-menu .notification-bell:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: scale(1.1);
        }
        .navbar .user-menu .user-info {
            display: flex;
            align-items: center;
            gap: 8px;
            color: white;
            font-weight: 500;
            cursor: pointer;
            padding: 8px 14px;
            border-radius: 9999px;
            background-color: rgba(255, 255, 255, 0.1);
            transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
        }
        .navbar .user-menu .user-info:hover {
            background-color: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        .navbar .user-menu .user-avatar {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background-color: white;
            color: var(--sena-dark-green);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 14px;
            border: 2px solid var(--sena-light-green);
        }
        .navbar .mobile-toggle {
            display: none;
        }
        .sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            background-color: #ffffff;
            box-shadow: 2px 0 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
            z-index: 2000;
        }
        .sidebar-hidden {
            transform: translateX(-250px);
        }
        .content-wrapper {
            margin-left: 250px;
            padding: 24px;
            min-height: calc(100vh - 64px);
            transition: margin-left 0.3s ease-in-out;
            margin-top: 64px;
        }
        .content-wrapper-expanded {
            margin-left: 0;
        }
        .sidebar-header {
            padding: 16px;
            border-bottom: 2px solid var(--sena-green);
            background-color: #ffffff;
            color: var(--sena-dark-green);
            font-weight: 600;
            font-size: 1.25rem;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }
        .sidebar-header .mobile-toggle {
            display: block;
            color: var(--sena-dark-green);
            font-size: 1.5rem;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .sidebar-header .mobile-toggle:hover {
            background-color: var(--sena-light-green);
            transform: scale(1.1);
        }
        .sidebar-nav {
            padding: 16px;
        }
        .sidebar-nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar-nav li {
            margin-bottom: 8px;
        }
        .sidebar-nav a {
            display: flex;
            align-items: center;
            padding: 12px;
            border-radius: 8px;
            color: #1e293b;
            font-weight: 500;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }
        .sidebar-nav a:hover, .sidebar-nav a.active {
            background-color: var(--sena-light-green);
            color: var(--sena-dark-green);
            transform: translateX(5px);
        }
        .sidebar-nav .nav-icon {
            margin-right: 12px;
            font-size: 1.1rem;
        }
        .footer {
            background-color: var(--sena-dark-green);
            color: white;
            padding: 12px;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: calc(100% - 250px);
            margin-left: 250px;
            transition: margin-left 0.3s ease-in-out;
        }
        .footer-expanded {
            margin-left: 0;
            width: 100%;
        }
        .dropdown-menu {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(8px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1001;
            transform: translateY(-100%);
            transition: transform 0.3s ease-in-out;
            padding: 16px 24px;
        }
        .dropdown-menu.show {
            transform: translateY(0);
        }
        .dropdown-menu a {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            color: #1e293b;
            font-size: 1rem;
            font-weight: 500;
            border-radius: 6px;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }
        .dropdown-menu a:hover {
            background-color: var(--sena-light-green);
            color: var(--sena-dark-green);
            transform: translateX(4px);
        }
        .card {
            border-top: 4px solid var(--sena-green);
            border-radius: 0.75rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        .preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--navbar-gradient);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 99999;
            visibility: visible;
        }
        .typing-container {
            text-align: center;
            font-family: 'Cinzel', serif;
            color: white;
            text-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .typing-text {
            font-size: 2.5rem;
            font-weight: 700;
            line-height: 1.2;
            animation: fadeInOut 2s infinite;
        }
        @keyframes fadeInOut {
            0% { opacity: 0; }
            50% { opacity: 1; }
            100% { opacity: 0; }
        }
        .bubble {
            position: absolute;
            background: rgba(255, 255, 255, 0.25);
            border-radius: 50%;
            animation: float 5s infinite ease-in-out;
        }
        @keyframes float {
            0% { transform: translateY(0); opacity: 0.8; }
            50% { opacity: 0.4; }
            100% { transform: translateY(-100vh); opacity: 0; }
        }
        @media (max-width: 768px) {
            .navbar .mobile-toggle {
                display: block;
            }
            .navbar .brand {
                font-size: 1.2rem;
            }
            .sidebar {
                transform: translateX(-250px);
                z-index: 2000;
            }
            .sidebar.sidebar-visible {
                transform: translateX(0);
            }
            .content-wrapper {
                margin-left: 0;
            }
            .footer {
                margin-left: 0;
                width: 100%;
            }
            .dropdown-menu {
                padding: 12px 16px;
            }
            .dropdown-menu a {
                font-size: 0.9rem;
            }
        }
        .btn-success {
            background-color: var(--sena-green);
            color: white;
            padding: 8px 16px;
            border-radius: 0.5rem;
            margin-right: 12px; /* Added spacing between buttons */
            transition: background-color 0.3s ease;
        }
        .btn-success:hover {
            background-color: var(--sena-dark-green);
        }
        .btn-info {
            background-color: #3490dc;
            color: white;
            padding: 8px 16px;
            border-radius: 0.5rem;
            margin-right: 12px; /* Added spacing between buttons */
            transition: background-color 0.3s ease;
        }
        .btn-info:hover {
            background-color: #2779bd;
        }
        .btn-danger {
            background-color: #e53e3e;
            color: white;
            padding: 8px 16px;
            border-radius: 0.5rem;
            transition: background-color 0.3s ease;
        }
        .btn-danger:hover {
            background-color: #c53030;
        }
        .status-pendiente {
            background-color: #FBBF24; /* Amarillo */
            color: #744210;
            padding: 4px 8px;
            border-radius: 12px;
            font-weight: 500;
        }
        .status-aprobada {
            background-color: #48bb78; /* Verde */
            color: #2f855a;
            padding: 4px 8px;
            border-radius: 12px;
            font-weight: 500;
        }
        .status-rechazada {
            background-color: #feb2b2; /* Rojo claro */
            color: #742a2a;
            padding: 4px 8px;
            border-radius: 12px;
            font-weight: 500;
        }
        .status-aprobada {
            background-color: #9ae6b4; /* Verde claro */
            color: #22543d;
            padding: 4px 8px;
            border-radius: 12px;
            font-weight: 500;
        }
        .status-rechazado {
            background-color: #feb2b2; /* Rojo claro */
            color: #742a2a;
            padding: 4px 8px;
            border-radius: 12px;
            font-weight: 500;
        }
        .status-pendiente {
            background-color: #fef3c7; /* Amarillo claro */
            color: #92400e;
            padding: 4px 8px;
            border-radius: 12px;
            font-weight: 500;
        }
        .details-row {
            background-color: #f9fafb;
            padding: 16px;
            border-top: 1px solid #e2e8f0;
        }
        .details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 12px;
            font-size: 0.875rem;
        }
        .details-grid div {
            background-color: #ffffff;
            padding: 8px;
            border: 1px solid #e2e8f0;
            border-radius: 4px;
        }
        .details-grid strong {
            color: #2d3748;
        }
        
        /* Grid responsive para detalles */
        .details-grid-responsive {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 8px;
            font-size: 0.875rem;
            padding: 12px;
        }
        
        @media (max-width: 768px) {
            .details-grid-responsive {
                grid-template-columns: 1fr;
                gap: 6px;
                padding: 8px;
            }
        }
        
        @media (max-width: 480px) {
            .details-grid-responsive {
                font-size: 0.8rem;
                padding: 6px;
            }
        }
        
        .details-grid-responsive div {
            background-color: #f8f9fa;
            padding: 8px 12px;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            word-break: break-word;
        }
        
        .details-grid-responsive strong {
            color: #2d3748;
            display: inline-block;
            min-width: 120px;
        }
        
        /* Responsive adicional para la tabla */
        @media (max-width: 640px) {
            .overflow-x-auto {
                -webkit-overflow-scrolling: touch;
            }
            
            table {
                font-size: 0.75rem;
            }
            
            .btn-info, .btn-success, .btn-danger {
                font-size: 0.7rem;
                padding: 4px 8px;
            }
        }
        
        @media (max-width: 480px) {
            .p-4 {
                padding: 0.75rem;
            }
            
            .card {
                margin: 0.5rem;
            }
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        .pulse-effect {
            animation: pulse 1.5s infinite ease-in-out;
        }
        .notification-bell-container {
            position: relative;
        }
        .notification-count {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: #e53e3e; /* Red color for count */
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 0.7rem;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 18px; /* Ensure circular shape for single digits */
            height: 18px;
        }
        .notifications-dropdown {
            position: absolute;
            top: 50px; /* Adjust based on navbar height */
            right: 0;
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            width: 300px; /* Adjust width as needed */
            max-height: 400px; /* Max height with scroll */
            overflow-y: auto;
            z-index: 1000;
            display: none; /* Hidden by default */
        }
        .notifications-dropdown.show {
            display: block;
        }
        .notifications-dropdown-header {
            padding: 12px;
            font-weight: 600;
            border-bottom: 1px solid #e2e8f0;
            color: #2d3748;
        }
        .notification-item {
            padding: 12px;
            border-bottom: 1px solid #edf2f7;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }
        .notification-item:hover {
            background-color: #f7fafc;
        }
        .notification-item:last-child {
            border-bottom: none;
        }
        .notification-item strong {
            color: var(--sena-dark-green);
        }
        .notification-item p {
            font-size: 0.85rem;
            color: #4a5568;
        }
        .no-notifications {
            padding: 12px;
            color: #718096;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="wrapper" style="visibility: hidden;">
        <!-- Preloader -->
        <div class="preloader" id="preloader" style="display: none;">
            <div class="typing-container" id="typing-container">
                <span class="typing-text">Bienvenido</span>
                <span class="typing-text">al panel del administrador</span>
            </div>
        </div>

        <!-- Dropdown Menu -->
        <div class="dropdown-menu hidden" id="dropdown-menu">
            <div class="flex justify-end items-center space-x-4">
                <button type="button" class="text-gray-500 text-2xl h-12 w-12 flex items-center justify-center hover:bg-gray-200 rounded-full" onclick="toggleDropdown()">×</button>
                <a href="#" class="block" onclick="confirmLogout(event, 'logout-form');">
                    <i class="fas fa-sign-out-alt mr-2"></i> Cerrar Sesión
                </a>
            </div>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="hidden">
                @csrf
            </form>
        </div>

        <!-- Navbar -->
         <!-- Navbar -->
         <nav class="navbar">
            <div class="flex items-center">
                <!-- Eliminado el icono de laptop y el span vacío -->
            </div>
            <div class="user-menu">
                <div class="notification-bell-container relative">
                    <button class="notification-bell" id="notification-bell-btn">
                    <i class="fas fa-bell"></i>
                        <span class="notification-count" id="notification-count">0</span>
                </button>
                    <div class="notifications-dropdown" id="notifications-dropdown">
                        <div class="notifications-dropdown-header">Solicitudes Pendientes</div>
                        <div id="notification-list-container">
                            <!-- Notifications will be loaded here -->
                            <div class="no-notifications">No hay solicitudes pendientes.</div>
                        </div>
                    </div>
                </div>
                <div class="relative">
                    <button class="user-info focus:outline-none" id="navbarDropdown">
                        <div class="user-avatar">A</div>
                        <span>Admin</span>
                        <i class="fas fa-chevron-down text-xs"></i>
                    </button>
                </div>
            </div>
        </nav>
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header flex items-center justify-between">
                <div class="flex items-center gap-2">
                    <i class="fas fa-cogs"></i>
                    <span>ADMIN</span>
                </div>
                <button class="mobile-toggle ml-2" id="toggle-sidebar">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            <div class="sidebar-nav">
                <nav>
                    <ul>
                        <li>
                            <a href="{{ route('fabricasoft.admin.welcome') }}" class="nav-link">
                                <i class="fas fa-home text-green-500 nav-icon"></i>
                                <span>Inicio</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.desarrolladores') }}" class="nav-link">
                                <i class="fas fa-users text-green-500 nav-icon"></i>
                                <span>Desarrolladores</span>
                            </a>
                                                   </li>

                        <li>
                            <a href="{{ route('fabricasoft.solicitudes') }}" class="nav-link">
                                <i class="fas fa-headset text-green-500 nav-icon"></i>
                                <span>Solicitudes</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.admin.proyectos') }}" class="nav-link">
                                <i class="fas fa-project-diagram text-green-500 nav-icon"></i>
                                <span>Proyectos</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.admin.avance_proyectos') }}" class="nav-link">
                                <i class="fas fa-chart-line text-green-500 nav-icon"></i>
                                <span>Avance de Proyectos</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.admin.preregistration.index') }}" class="nav-link">
                                <i class="fas fa-user-plus text-green-500 nav-icon"></i>
                                <span>Pre-registros</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.admin.ajustes') }}" class="nav-link">
                                <i class="fas fa-cog text-green-500 nav-icon"></i>
                                <span>Ajustes</span>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="nav-link" id="servicios-menu-link">
                                <i class="fas fa-cogs text-green-500 nav-icon"></i>
                                <span>SERVICIOS</span>
                                <i class="fas fa-angle-left ml-auto transition-transform duration-200"></i>
                            </a>
                            <ul class="nav-treeview hidden" id="servicios-submenu">
                                <li>
                                    <a href="{{ route('fabricasoft.admin.solicitudes_soporte') }}" class="nav-link">
                                        <i class="fas fa-headset text-green-500 nav-icon"></i>
                                        <span>Solicitudes y soporte</span>
                                    </a>
                                </li>

                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>

        <!-- Content Wrapper -->
        <div class="content-wrapper" id="content-wrapper">
            <div class="p-4 border-b bg-white">
                <h1 class="text-2xl font-semibold text-gray-800">Gestión de Solicitudes</h1>
            </div>
                        @yield('content')
        </div>

        <!-- Footer -->
        <footer class="footer" id="footer">
            <strong>Copyright © 2024-2025
                <a href="#" class="text-white hover:underline">ADMIN - SENA</a>.
            </strong>
            Todos los derechos reservados.
            <div class="float-right hidden sm:inline-block">
                <b>Versión</b> 1.0.0
            </div>
        </footer>
    </div>

    <!-- Botón para mostrar el menú lateral cuando está oculto -->
    <button id="show-sidebar-btn" style="display:none; position:fixed; top:32px; left:24px; z-index:3000; background:#2ECC71; color:white; padding:12px 16px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.2); border:none; font-size:1.5rem; cursor:pointer; transform:translateY(-50%);" onclick="toggleSidebar(true)">
        <i class="fas fa-bars"></i>
    </button>

    <script>
        // Preloader Script - DESACTIVADO
        document.addEventListener('DOMContentLoaded', function () {
            const preloader = document.getElementById('preloader');
            const wrapper = document.querySelector('.wrapper');
            
            // DESACTIVAR el preloader completamente
            if (preloader) {
                preloader.style.display = 'none';
            }
            wrapper.style.visibility = 'visible';
            document.body.style.overflow = 'auto';
            
            console.log('Preloader DESACTIVADO en mastersolicitudes');
        });

        // Sidebar Toggle
        function toggleSidebar(forceShow = null) {
            const sidebar = document.getElementById('sidebar');
            const showSidebarBtn = document.getElementById('show-sidebar-btn');
            if (window.innerWidth <= 768) {
                // En móvil
                if (forceShow === true) {
                    sidebar.classList.add('sidebar-visible');
                } else if (forceShow === false) {
                    sidebar.classList.remove('sidebar-visible');
                } else {
                    sidebar.classList.toggle('sidebar-visible');
                }
            } else {
                // En escritorio
                if (forceShow === true) {
                    sidebar.classList.remove('sidebar-hidden');
                    document.getElementById('content-wrapper').classList.remove('content-wrapper-expanded');
                    document.getElementById('footer').classList.remove('footer-expanded');
                } else if (forceShow === false) {
                    sidebar.classList.add('sidebar-hidden');
                    document.getElementById('content-wrapper').classList.add('content-wrapper-expanded');
                    document.getElementById('footer').classList.add('footer-expanded');
                } else {
                    sidebar.classList.toggle('sidebar-hidden');
                    document.getElementById('content-wrapper').classList.toggle('content-wrapper-expanded');
                    document.getElementById('footer').classList.toggle('footer-expanded');
                }
            }
            checkSidebarBtn();
        }

        // Asignar eventos a ambos botones de hamburguesa
        document.addEventListener('DOMContentLoaded', function() {
            const sidebarToggleBtn = document.getElementById('toggle-sidebar');
            const showSidebarBtn = document.getElementById('show-sidebar-btn');
            if (sidebarToggleBtn) {
                sidebarToggleBtn.onclick = function() {
                    toggleSidebar();
                };
            }
            if (showSidebarBtn) {
                showSidebarBtn.onclick = function() {
                    // Siempre mostrar el menú al hacer clic
                    toggleSidebar(true);
                };
            }
            checkSidebarBtn();
        });

        // Mostrar el botón si el sidebar está oculto al cargar o al redimensionar
        function checkSidebarBtn() {
            const sidebar = document.getElementById('sidebar');
            const showSidebarBtn = document.getElementById('show-sidebar-btn');
            // Mostrar el botón si el sidebar está oculto
            if ((window.innerWidth <= 768 && !sidebar.classList.contains('sidebar-visible')) ||
                (window.innerWidth > 768 && sidebar.classList.contains('sidebar-hidden'))) {
                showSidebarBtn.style.display = 'block';
            } else {
                showSidebarBtn.style.display = 'none';
            }
        }
        window.addEventListener('resize', checkSidebarBtn);

        // Dropdown Menu
        function toggleDropdown() {
            const dropdown = document.getElementById('dropdown-menu');
            dropdown.classList.toggle('hidden');
            dropdown.classList.toggle('show');
        }

        document.getElementById('navbarDropdown').addEventListener('click', toggleDropdown);

        // Close Dropdown on Outside Click
        document.addEventListener('click', function (event) {
            const dropdown = document.getElementById('dropdown-menu');
            const toggle = document.getElementById('navbarDropdown');
            if (!toggle.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.add('hidden');
                dropdown.classList.remove('show');
            }
        });

        // Logout Confirmation
        function confirmLogout(event, formId) {
            event.preventDefault();
            Swal.fire({
                title: '¿Estás seguro?',
                text: '¿Deseas cerrar tu sesión?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#2ECC71',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, cerrar sesión',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById(formId).submit();
                }
            });
        }

        // Confirm Status Change for Approve/Reject
        function confirmStatusChange(event, formId, action) {
            event.preventDefault();
            
            // Deshabilitar el botón para prevenir múltiples envíos
            const button = event.target;
            const originalText = button.textContent;
            button.disabled = true;
            button.textContent = 'Procesando...';
            
            Swal.fire({
                title: `¿Estás seguro?`,
                text: `¿Deseas ${action} esta solicitud?`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: action === 'aprobar' ? '#2ECC71' : '#e53e3e',
                cancelButtonColor: '#d33',
                confirmButtonText: `Sí, ${action}`,
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Enviar formulario via AJAX
                    const form = document.getElementById(formId);
                    const formData = new FormData(form);
                    
                    fetch(form.action, {
                        method: 'POST',
                        body: formData,
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: action === 'aprobar' ? '¡Aprobada!' : '¡Rechazada!',
                                text: data.message || `La solicitud ha sido ${action === 'aprobar' ? 'aprobada' : 'rechazada'} exitosamente.`,
                                icon: 'success',
                                confirmButtonColor: '#2ECC71',
                                confirmButtonText: 'OK'
                            }).then(() => {
                                // Recargar la página para mostrar los cambios
                                window.location.reload();
                            });
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: data.message || 'Error al procesar la solicitud',
                                icon: 'error',
                                confirmButtonColor: '#e53e3e',
                                confirmButtonText: 'OK'
                            });
                            // Restaurar el botón
                            button.disabled = false;
                            button.textContent = originalText;
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            title: 'Error',
                            text: 'Error de conexión. Inténtalo de nuevo.',
                            icon: 'error',
                            confirmButtonColor: '#e53e3e',
                            confirmButtonText: 'OK'
                        });
                        // Restaurar el botón
                        button.disabled = false;
                        button.textContent = originalText;
                    });
                } else {
                    // Restaurar el botón si se cancela
                    button.disabled = false;
                    button.textContent = originalText;
                }
            });
        }

        // Modal Toggle
        function toggleModal(modalId) {
            const modal = document.getElementById(modalId);
            modal.classList.toggle('hidden');
        }

        // Notificaciones (Placeholder) -> ACTUALIZADO
        let pendingRequests = []; // Array to store pending requests

        async function fetchPendingRequests() {
            try {
                const response = await fetch(pendingRequestsUrl);
                if (!response.ok) {
                    throw new Error('HTTP error! status: ' + response.status);
                }
                const data = await response.json();
                return data;
            } catch (error) {
                console.error('Error fetching pending requests:', error);
                return [];
            }
        }

        // Function to update notification count and display notifications
        async function updateNotificationCount() {
            const countElement = document.getElementById('notification-count');
            const notificationBellBtn = document.getElementById('notification-bell-btn');
            const notificationsDropdown = document.getElementById('notifications-dropdown');
            const notificationListContainer = document.getElementById('notification-list-container');

            try {
                const pending = await fetchPendingRequests();
                const count = pending.length;
                countElement.textContent = count;
                notificationBellBtn.setAttribute('data-count', count);

                if (count > 0) {
                    notificationsDropdown.classList.add('show');
                    notificationListContainer.innerHTML = ''; // Clear previous notifications
                    pending.forEach(request => {
                        const notificationItem = document.createElement('div');
                        notificationItem.className = 'notification-item';
                        notificationItem.innerHTML = `
                            <strong>${request.project_name ?? 'Solicitud'}</strong>
                            <p>${request.applicant_name ?? 'Solicitante'} - ${request.status ?? 'Pendiente'}</p>
                            <p class="text-sm text-gray-600">Tipo de Documento: ${request.document_type ?? 'No especificado'}</p>
                            <p class="text-sm text-gray-600">Número de Documento: ${request.document_number ?? 'No especificado'}</p>
                        `;
                        notificationItem.onclick = () => {
                            // Redirect to details page for the specific request
                            window.location.href = `/fabricasoft/solicitudes/${request.id}/details`;
                        };
                        notificationListContainer.appendChild(notificationItem);
                    });
                } else {
                    notificationsDropdown.classList.remove('show');
                    notificationListContainer.innerHTML = '<div class="no-notifications">No hay solicitudes pendientes.</div>';
                }
            } catch (error) {
                console.error('Error updating notification count:', error);
                countElement.textContent = '0';
                notificationBellBtn.setAttribute('data-count', '0');
                notificationsDropdown.classList.remove('show');
                notificationListContainer.innerHTML = '<div class="no-notifications">Error al cargar notificaciones.</div>';
            }
        }

        // Initial fetch on page load
        updateNotificationCount();

        // Fetch notifications every 30 seconds
        setInterval(updateNotificationCount, 30000);

        // Toggle details for the main table
        document.addEventListener('click', function(event) {
            const detailsBtn = event.target.closest('.toggle-details');
            if (detailsBtn) {
                const targetId = detailsBtn.dataset.target.split('-')[1]; // Extract the ID
                const detailsRow = document.getElementById(`details-${targetId}`);
                if (detailsRow) {
                    detailsRow.classList.toggle('hidden');
                }
            }
        });

        // Prevenir múltiples envíos de formularios
        document.addEventListener('submit', function(event) {
            const form = event.target;
            if (form.classList.contains('approve-form') || form.classList.contains('reject-form')) {
                const submitBtn = form.querySelector('button[type="button"]');
                if (submitBtn && submitBtn.disabled) {
                    event.preventDefault();
                    return false;
                }
            }
        });

        // Treeview Toggle para submenús del sidebar
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.sidebar .nav-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    const treeview = this.nextElementSibling;
                    if (treeview && treeview.classList.contains('nav-treeview')) {
                        e.preventDefault();
                        treeview.classList.toggle('hidden');
                        // Alternar el icono de flecha
                        const angle = this.querySelector('.fa-angle-left, .fa-angle-down');
                        if (angle) {
                            angle.classList.toggle('fa-angle-left');
                            angle.classList.toggle('fa-angle-down');
                        }
                    }
                });
            });
        });
    </script>
</body>
</html>