<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="{{ asset('images/Favicon2.png') }}" type="image/x-icon">
    <title>Desarrolladores</title>
    <!-- Google Font: Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --sena-green: #2ECC71;
            --sena-dark-green: #27AE60;
            --sena-light-green: #ECF9F2;
            --navbar-gradient: linear-gradient(90deg, #2ECC71 0%, #27AE60 100%);
        }
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f9fafb;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        .navbar {
            background: var(--navbar-gradient);
            height: 64px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 24px;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        .navbar .brand {
            color: white;
            font-size: 1.5rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: transform 0.3s ease, opacity 0.3s ease;
        }
        .navbar .brand:hover {
            transform: translateY(-2px);
            opacity: 0.95;
        }
        .navbar .brand i {
            font-size: 1.8rem;
        }
        .navbar .user-menu {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .navbar .user-menu .notification-bell {
            color: white;
            font-size: 1.2rem;
            padding: 8px;
            border-radius: 50%;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .navbar .user-menu .notification-bell:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: scale(1.1);
        }
        .navbar .user-menu .user-info {
            display: flex;
            align-items: center;
            gap: 8px;
            color: white;
            font-weight: 500;
            cursor: pointer;
            padding: 8px 14px;
            border-radius: 9999px;
            background-color: rgba(255, 255, 255, 0.1);
            transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
        }
        .navbar .user-menu .user-info:hover {
            background-color: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        .navbar .user-menu .user-avatar {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background-color: white;
            color: var(--sena-dark-green);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 14px;
            border: 2px solid var(--sena-light-green);
        }
        .navbar .mobile-toggle {
            display: none;
        }
        .sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            background-color: #ffffff;
            box-shadow: 2px 0 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
            z-index: 2000;
        }
        .sidebar-hidden {
            transform: translateX(-250px);
        }
        .content-wrapper {
            margin-left: 250px;
            padding: 24px;
            min-height: calc(100vh - 64px);
            transition: margin-left 0.3s ease-in-out;
            margin-top: 64px;
        }
        .content-wrapper-expanded {
            margin-left: 0;
        }
        .sidebar-header {
            padding: 16px;
            border-bottom: 2px solid var(--sena-green);
            background-color: #ffffff;
            color: var(--sena-dark-green);
            font-weight: 600;
            font-size: 1.25rem;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }
        .sidebar-header .mobile-toggle {
            display: block;
            color: var(--sena-dark-green);
            font-size: 1.5rem;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .sidebar-header .mobile-toggle:hover {
            background-color: var(--sena-light-green);
            transform: scale(1.1);
        }
        .sidebar-nav {
            padding: 16px;
        }
        .sidebar-nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar-nav li {
            margin-bottom: 8px;
        }
        .sidebar-nav a {
            display: flex;
            align-items: center;
            padding: 12px;
            border-radius: 8px;
            color: #1e293b;
            font-weight: 500;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }
        .sidebar-nav a:hover, .sidebar-nav a.active {
            background-color: var(--sena-light-green);
            color: var(--sena-dark-green);
            transform: translateX(5px);
        }
        .sidebar-nav .nav-icon {
            margin-right: 12px;
            font-size: 1.1rem;
        }
        .sidebar-nav .nav-treeview {
            padding-left: 24px;
            margin-top: 8px;
        }
        .sidebar-nav .nav-treeview a {
            font-size: 0.95rem;
        }
        .footer {
            background-color: var(--sena-dark-green);
            color: white;
            padding: 12px;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: calc(100% - 250px);
            margin-left: 250px;
            transition: margin-left 0.3s ease-in-out;
        }
        .footer-expanded {
            margin-left: 0;
            width: 100%;
        }
        .dropdown-menu {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(8px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1001;
            transform: translateY(-100%);
            transition: transform 0.3s ease-in-out;
            padding: 16px 24px;
        }
        .dropdown-menu.show {
            transform: translateY(0);
        }
        .dropdown-menu a {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            color: #1e293b;
            font-size: 1rem;
            font-weight: 500;
            border-radius: 6px;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }
        .dropdown-menu a:hover {
            background-color: var(--sena-light-green);
            color: var(--sena-dark-green);
            transform: translateX(4px);
        }
        .card {
            border-top: 4px solid var(--sena-green);
            border-radius: 0.75rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        @media (max-width: 768px) {
            .navbar .mobile-toggle {
                display: block;
            }
            .navbar .brand {
                font-size: 1.2rem;
            }
            .navbar .user-menu {
                gap: 8px;
            }
            .navbar .user-menu .notification-bell {
                font-size: 1rem;
                padding: 6px;
            }
            .navbar .user-info {
                font-size: 0.9rem;
            }
            .navbar .user-avatar {
                width: 28px;
                height: 28px;
                font-size: 0.8rem;
            }
            .sidebar {
                transform: translateX(-250px);
                z-index: 2000;
                width: 250px;
            }
            .sidebar.sidebar-visible {
                transform: translateX(0);
            }
            .content-wrapper {
                margin-left: 0;
                padding-top: 64px;
            }
            .footer {
                margin-left: 0;
                width: 100%;
                padding: 8px 12px;
                font-size: 0.8rem;
            }
            .dropdown-menu {
                padding: 12px 16px;
            }
            .dropdown-menu a {
                font-size: 0.9rem;
                padding: 10px 12px;
            }
            .notifications-dropdown {
                width: 280px;
                right: -10px;
            }
            .notification-item {
                padding: 8px;
                font-size: 0.85rem;
            }
        }

        @media (max-width: 480px) {
            .navbar {
                padding: 0 12px;
                height: 56px;
            }
            .navbar .brand {
                font-size: 1rem;
            }
            .navbar .user-menu {
                gap: 6px;
            }
            .navbar .user-info {
                font-size: 0.8rem;
            }
            .navbar .user-avatar {
                width: 24px;
                height: 24px;
                font-size: 0.7rem;
            }
            .sidebar {
                width: 100%;
                transform: translateX(-100%);
            }
            .content-wrapper {
                padding-top: 56px;
            }
            .footer {
                padding: 6px 8px;
                font-size: 0.75rem;
            }
            .notifications-dropdown {
                width: 260px;
                right: -20px;
            }
            .notification-item {
                padding: 6px;
                font-size: 0.8rem;
            }
            #show-sidebar-btn {
                top: 28px;
                left: 12px;
                padding: 8px 12px;
                font-size: 1.2rem;
            }
        }

        @media (max-width: 640px) {
            .card {
                margin: 8px;
                border-radius: 0.5rem;
            }
            .btn-success {
                padding: 8px 16px;
                font-size: 0.9rem;
            }
            .modal-content {
                margin: 8px;
                border-radius: 0.5rem;
            }
            
            /* Responsive para tablas */
            .overflow-x-auto {
                -webkit-overflow-scrolling: touch;
            }
            
            table {
                font-size: 0.75rem;
            }
            
            .btn-info, .btn-success, .btn-danger {
                font-size: 0.7rem;
                padding: 4px 8px;
            }
        }
        
        @media (max-width: 480px) {
            .p-4 {
                padding: 0.75rem;
            }
            
            .card {
                margin: 0.5rem;
            }
        }
        .notifications-dropdown {
            position: absolute;
            top: 40px; /* justo debajo de la campana */
            right: 0;
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            width: 320px; /* ancho suficiente para el contenido */
            max-width: 90vw;
            max-height: 400px;
            overflow-y: auto;
            z-index: 2000;
            display: none;
            word-break: break-word;
        }
        .notifications-dropdown.show {
            display: block;
        }
        .notifications-dropdown-header {
            padding: 12px;
            font-weight: 600;
            border-bottom: 1px solid #e2e8f0;
            color: #2d3748;
        }
        .notification-item {
            padding: 12px;
            border-bottom: 1px solid #edf2f7;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }
        .notification-item:hover {
            background-color: #f7fafc;
        }
        .notification-item:last-child {
            border-bottom: none;
        }
        .notification-item strong {
            color: var(--sena-dark-green);
        }
        .notification-item p {
            font-size: 0.85rem;
            color: #4a5568;
            margin-bottom: 2px;
            word-break: break-word;
        }
        .no-notifications {
            padding: 12px;
            color: #718096;
            text-align: center;
        }
        .notification-count {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: #e53e3e;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 0.7rem;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 18px;
            height: 18px;
            z-index: 10;
        }
    </style>
</head>
<body>
    <div class="wrapper" style="visibility: hidden;">

        <!-- Dropdown Menu -->
        <div class="dropdown-menu hidden" id="dropdown-menu">
            <div class="flex justify-end items-center space-x-4">
                <button type="button" class="text-gray-500 text-2xl h-12 w-12 flex items-center justify-center hover:bg-gray-200 rounded-full" onclick="toggleDropdown()">×</button>
                <a href="#" class="block" onclick="confirmLogout(event, 'logout-form');">
                    <i class="fas fa-sign-out-alt mr-2"></i> Cerrar Sesión
                </a>
            </div>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="hidden">
                @csrf
            </form>
        </div>

        <!-- Navbar -->
        <nav class="navbar">
            <div class="flex items-center">
                <!-- Eliminado el icono de laptop y el span vacío -->
            </div>
            <div class="user-menu">
                <div class="notification-bell-container relative">
                    <button class="notification-bell" id="notification-bell-btn">
                    <i class="fas fa-bell"></i>
                        <span class="notification-count" id="notification-count">0</span>
                </button>
                    <div class="notifications-dropdown" id="notifications-dropdown">
                        <div class="notifications-dropdown-header">Solicitudes Pendientes</div>
                        <div id="notification-list-container">
                            <!-- Notifications will be loaded here -->
                            <div class="no-notifications">No hay solicitudes pendientes.</div>
                        </div>
                    </div>
                </div>
                <div class="relative">
                    <button class="user-info focus:outline-none" id="navbarDropdown">
                        <div class="user-avatar">A</div>
                        <span>Admin</span>
                        <i class="fas fa-chevron-down text-xs"></i>
                    </button>
                </div>
            </div>
        </nav>

        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header flex items-center justify-between">
                <div class="flex items-center gap-2">
                    <i class="fas fa-cogs"></i>
                    <span>ADMIN</span>
                </div>
                <button class="mobile-toggle ml-2" id="toggle-sidebar">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            <div class="sidebar-nav">
                <nav>
                    <ul>
                        <li>
                            <a href="{{ route('fabricasoft.admin.welcome') }}" class="nav-link">
                                <i class="fas fa-home text-green-500 nav-icon"></i>
                                <span>Inicio</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.desarrolladores') }}" class="nav-link">
                                <i class="fas fa-users text-green-500 nav-icon"></i>
                                <span>Desarrolladores</span>
                            </a>
                                                   </li>

                        <li>
                            <a href="{{ route('fabricasoft.solicitudes') }}" class="nav-link">
                                <i class="fas fa-headset text-green-500 nav-icon"></i>
                                <span>Solicitudes</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.admin.proyectos') }}" class="nav-link">
                                <i class="fas fa-project-diagram text-green-500 nav-icon"></i>
                                <span>Proyectos</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.admin.avance_proyectos') }}" class="nav-link">
                                <i class="fas fa-chart-line text-green-500 nav-icon"></i>
                                <span>Avance de Proyectos</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.admin.preregistration.index') }}" class="nav-link">
                                <i class="fas fa-user-plus text-green-500 nav-icon"></i>
                                <span>Pre-registros</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.admin.ajustes') }}" class="nav-link">
                                <i class="fas fa-cog text-green-500 nav-icon"></i>
                                <span>Ajustes</span>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="nav-link" id="servicios-menu-link">
                                <i class="fas fa-cogs text-green-500 nav-icon"></i>
                                <span>SERVICIOS</span>
                                <i class="fas fa-angle-left ml-auto transition-transform duration-200"></i>
                            </a>
                            <ul class="nav-treeview hidden" id="servicios-submenu">
                                <li>
                                    <a href="{{ route('fabricasoft.admin.solicitudes_soporte') }}" class="nav-link">
                                        <i class="fas fa-headset text-green-500 nav-icon"></i>
                                        <span>Solicitudes y soporte</span>
                                    </a>
                                </li>

                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>

        <!-- Content Wrapper -->
        <div class="content-wrapper" id="content-wrapper">
            <div class="p-4 border-b bg-white">
                <h1 class="text-2xl font-semibold text-gray-800">Gestión de Desarrolladores</h1>
            </div>
            <div class="p-4">
                @yield('content')
            </div>
        </div>

        <!-- Footer -->
        <footer class="footer" id="footer">
            <strong>Copyright © 2024-2025
                <a href="#" class="text-white hover:underline">ADMIN - SENA</a>.
            </strong>
            Todos los derechos reservados.
            <div class="float-right hidden sm:inline-block">
                <b>Versión</b> 1.0.0
            </div>
        </footer>
    </div>

    <!-- Botón para mostrar el menú lateral cuando está oculto -->
    <button id="show-sidebar-btn" style="display:none; position:fixed; top:32px; left:24px; z-index:3000; background:#2ECC71; color:white; padding:12px 16px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.2); border:none; font-size:1.5rem; cursor:pointer; transform:translateY(-50%);" onclick="toggleSidebar(true)">
        <i class="fas fa-bars"></i>
    </button>

    <script>
        // Mostrar contenido inmediatamente
        document.addEventListener('DOMContentLoaded', function () {
            const wrapper = document.querySelector('.wrapper');
            wrapper.style.visibility = 'visible';
            document.body.style.overflow = 'auto';
        });

        // Sidebar Toggle
        function toggleSidebar(forceShow = null) {
            const sidebar = document.getElementById('sidebar');
            const showSidebarBtn = document.getElementById('show-sidebar-btn');
            if (window.innerWidth <= 768) {
                if (forceShow === true) {
                    sidebar.classList.add('sidebar-visible');
                } else if (forceShow === false) {
                    sidebar.classList.remove('sidebar-visible');
                } else {
                    sidebar.classList.toggle('sidebar-visible');
                }
            } else {
                if (forceShow === true) {
                    sidebar.classList.remove('sidebar-hidden');
                    document.getElementById('content-wrapper').classList.remove('content-wrapper-expanded');
                    document.getElementById('footer').classList.remove('footer-expanded');
                } else if (forceShow === false) {
                    sidebar.classList.add('sidebar-hidden');
                    document.getElementById('content-wrapper').classList.add('content-wrapper-expanded');
                    document.getElementById('footer').classList.add('footer-expanded');
                } else {
                    sidebar.classList.toggle('sidebar-hidden');
                    document.getElementById('content-wrapper').classList.toggle('content-wrapper-expanded');
                    document.getElementById('footer').classList.toggle('footer-expanded');
                }
            }
            checkSidebarBtn();
        }

        document.addEventListener('DOMContentLoaded', function() {
            const sidebarToggleBtn = document.getElementById('toggle-sidebar');
            const showSidebarBtn = document.getElementById('show-sidebar-btn');
            if (sidebarToggleBtn) {
                sidebarToggleBtn.onclick = function() {
                    toggleSidebar();
                };
            }
            if (showSidebarBtn) {
                showSidebarBtn.onclick = function() {
                    toggleSidebar(true);
                };
            }
            checkSidebarBtn();
        });

        function checkSidebarBtn() {
            const sidebar = document.getElementById('sidebar');
            const showSidebarBtn = document.getElementById('show-sidebar-btn');
            if ((window.innerWidth <= 768 && !sidebar.classList.contains('sidebar-visible')) ||
                (window.innerWidth > 768 && sidebar.classList.contains('sidebar-hidden'))) {
                showSidebarBtn.style.display = 'block';
            } else {
                showSidebarBtn.style.display = 'none';
            }
        }
        window.addEventListener('resize', checkSidebarBtn);

        // Dropdown Menu
        function toggleDropdown() {
            const dropdown = document.getElementById('dropdown-menu');
            dropdown.classList.toggle('hidden');
            dropdown.classList.toggle('show');
        }

        document.getElementById('navbarDropdown').addEventListener('click', toggleDropdown);

        document.addEventListener('click', function (event) {
            const dropdown = document.getElementById('dropdown-menu');
            const toggle = document.getElementById('navbarDropdown');
            if (!toggle.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.add('hidden');
                dropdown.classList.remove('show');
            }
        });

        // Notifications
        function showNotifications() {
            Swal.fire({
                icon: 'info',
                title: 'Notificaciones',
                text: 'No hay nuevas notificaciones.',
            });
        }

        let pendingRequests = [];
        // Sistema de Notificaciones Global
        let notifications = []; // Array to store all notifications

        async function fetchNotifications() {
            try {
                const response = await fetch('/fabricasoft/admin/notifications');
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();
                notifications = data; // Store the fetched notifications
                updateNotificationsDisplay();
            } catch (error) {
                console.error("Error fetching notifications:", error);
                document.getElementById('notification-count').textContent = 'Error';
                document.getElementById('notification-list-container').innerHTML = '<div class="no-notifications">Error al cargar notificaciones.</div>';
            }
        }

        function updateNotificationsDisplay() {
            const countElement = document.getElementById('notification-count');
            const listContainer = document.getElementById('notification-list-container');
            
            // Contar solo notificaciones no leídas
            const unreadCount = notifications.filter(n => !n.read_at).length;
            countElement.textContent = unreadCount;

            if (notifications.length > 0) {
                listContainer.innerHTML = ''; // Clear previous notifications
                notifications.forEach(notification => {
                    const notificationItem = document.createElement('div');
                    notificationItem.className = `notification-item ${notification.read_at ? 'read' : 'unread'}`;
                    
                    // Determinar el icono según el tipo
                    let icon = 'fas fa-bell';
                    let iconColor = 'text-blue-500';
                    
                    if (notification.notification_type === 'success') {
                        icon = 'fas fa-check-circle';
                        iconColor = 'text-green-500';
                    } else if (notification.notification_type === 'warning') {
                        icon = 'fas fa-exclamation-triangle';
                        iconColor = 'text-yellow-500';
                    } else if (notification.notification_type === 'error') {
                        icon = 'fas fa-times-circle';
                        iconColor = 'text-red-500';
                    }

                    notificationItem.innerHTML = `
                        <div class="flex items-start space-x-3">
                            <i class="${icon} ${iconColor} mt-1"></i>
                            <div class="flex-1">
                                <h4 class="font-semibold text-sm">${notification.title}</h4>
                                <p class="text-xs text-gray-600">${notification.message}</p>
                                <div class="flex justify-between items-center mt-2">
                                    <span class="text-xs text-gray-500">${formatDate(notification.created_at)}</span>
                                    ${notification.module ? `<span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">${notification.module}</span>` : ''}
                                </div>
                            </div>
                        </div>
                    `;
                    
                    notificationItem.addEventListener('click', () => {
                        // Marcar como leída si no está leída
                        if (!notification.read_at) {
                            markAsRead(notification.id);
                        }
                        
                        // Navegar según el tipo
                        if (notification.type === 'request') {
                            window.location.href = `{{ url('fabricasoft/solicitudes') }}?id=${notification.id}`;
                        } else if (notification.type === 'notification') {
                            // Para notificaciones globales, ir a la página de notificaciones
                            window.location.href = "{{ route('notifications.index') }}";
                        }
                    });
                    
                    listContainer.appendChild(notificationItem);
                });
            } else {
                listContainer.innerHTML = '<div class="no-notifications">No hay notificaciones.</div>';
            }
        }

        async function markAsRead(notificationId) {
            try {
                const response = await fetch(`/notifications/${notificationId}/read`, {
                    method: 'PATCH',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                        'Content-Type': 'application/json'
                    }
                });
                
                if (response.ok) {
                    // Actualizar la notificación localmente
                    const notification = notifications.find(n => n.id === notificationId);
                    if (notification) {
                        notification.read_at = new Date().toISOString();
                        updateNotificationsDisplay();
                    }
                }
            } catch (error) {
                console.error('Error marking notification as read:', error);
            }
        }

        function formatDate(dateString) {
            const date = new Date(dateString);
            const now = new Date();
            const diffInHours = (now - date) / (1000 * 60 * 60);
            
            if (diffInHours < 1) {
                return 'Hace unos minutos';
            } else if (diffInHours < 24) {
                return `Hace ${Math.floor(diffInHours)} horas`;
            } else {
                return date.toLocaleDateString('es-ES');
            }
        }
        document.getElementById('notification-bell-btn').addEventListener('click', function() {
            const dropdown = document.getElementById('notifications-dropdown');
            dropdown.classList.toggle('show');
        });
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('notifications-dropdown');
            const toggle = document.getElementById('notification-bell-btn');
            if (!toggle.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });
        document.addEventListener('DOMContentLoaded', () => {
            fetchNotifications();
            setInterval(fetchNotifications, 30000);
        });

        // Treeview Toggle para submenús del sidebar
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.sidebar .nav-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    const treeview = this.nextElementSibling;
                    if (treeview && treeview.classList.contains('nav-treeview')) {
                        e.preventDefault();
                        treeview.classList.toggle('hidden');
                        // Alternar el icono de flecha
                        const angle = this.querySelector('.fa-angle-left, .fa-angle-down');
                        if (angle) {
                            angle.classList.toggle('fa-angle-left');
                            angle.classList.toggle('fa-angle-down');
                        }
                    }
                });
            });
        });

        // Logout Confirmation
        function confirmLogout(event, formId) {
            event.preventDefault();
            Swal.fire({
                title: '¿Estás seguro?',
                text: '¿Deseas cerrar tu sesión?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#2ECC71',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, cerrar sesión',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById(formId).submit();
                }
            });
        }
    </script>
</body>
</html>