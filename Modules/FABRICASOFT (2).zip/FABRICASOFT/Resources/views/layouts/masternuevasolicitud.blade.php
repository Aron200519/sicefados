<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="{{ asset('images/Favicon2.png') }}" type="image/x-icon">
    <title>Solicitud de Software</title>
    <!-- Google Font: Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">
    <!-- Google Font: Cinzel for Preloader -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&display=swap">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --sena-green: #2ECC71;
            --sena-dark-green: #27AE60;
            --sena-light-green: #ECF9F2;
            --navbar-gradient: linear-gradient(90deg, #2ECC71 0%, #27AE60 100%);
        }
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f9fafb;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        .navbar {
            background: var(--navbar-gradient);
            height: 64px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 24px;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        .navbar .brand {
            color: white;
            font-size: 1.5rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: transform 0.3s ease, opacity 0.3s ease;
        }
        .navbar .brand:hover {
            transform: translateY(-2px);
            opacity: 0.95;
        }
        .navbar .brand i {
            font-size: 1.8rem;
        }
        .navbar .user-menu {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .navbar .user-menu .notification-bell {
            color: white;
            font-size: 1.2rem;
            padding: 8px;
            border-radius: 50%;
            transition: background-color 0.3s ease, transform 0.3s ease;
            position: relative;
        }
        .navbar .user-menu .notification-bell:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: scale(1.1);
        }
        .notification-bell-container {
            position: relative;
        }
        .notification-count {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: #ef4444;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: bold;
        }
        .notifications-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            width: 350px;
            max-height: 400px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            display: none;
            overflow: hidden;
        }
        .notifications-dropdown.show {
            display: block;
        }
        .notifications-dropdown-header {
            padding: 12px 16px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
            font-weight: 600;
            color: #495057;
        }
        .notification-item {
            padding: 12px 16px;
            border-bottom: 1px solid #f1f3f4;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }
        .notification-item:hover {
            background-color: #f8f9fa;
        }
        .notification-item.unread {
            background-color: #f0f9ff;
            border-left: 3px solid #3b82f6;
        }
        .notification-item.read {
            opacity: 0.7;
        }
        .no-notifications {
            padding: 20px;
            text-align: center;
            color: #6c757d;
            font-style: italic;
        }
        .navbar .user-menu .user-info {
            display: flex;
            align-items: center;
            gap: 8px;
            color: white;
            font-weight: 500;
            cursor: pointer;
            padding: 8px 14px;
            border-radius: 9999px;
            background-color: rgba(255, 255, 255, 0.1);
            transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
        }
        .navbar .user-menu .user-info:hover {
            background-color: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        .navbar .user-menu .user-avatar {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background-color: white;
            color: var(--sena-dark-green);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 14px;
            border: 2px solid var(--sena-light-green);
        }
        .navbar .mobile-toggle {
            display: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }
        .sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            background-color: #ffffff;
            box-shadow: 2px 0 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
            z-index: 2000;
        }
        .sidebar-hidden {
            transform: translateX(-250px);
        }
        .content-wrapper {
            margin-left: 250px;
            padding: 24px;
            min-height: calc(100vh - 64px);
            transition: margin-left 0.3s ease-in-out;
            margin-top: 64px;
        }
        .content-wrapper-expanded {
            margin-left: 0;
        }
        .sidebar-header {
            padding: 16px;
            border-bottom: 2px solid var(--sena-green);
            background-color: #ffffff;
            color: var(--sena-dark-green);
            font-weight: 600;
            font-size: 1.25rem;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }
        .sidebar-header .mobile-toggle {
            display: block;
            color: var(--sena-dark-green);
            font-size: 1.5rem;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .sidebar-header .mobile-toggle:hover {
            background-color: var(--sena-light-green);
            transform: scale(1.1);
        }
        .sidebar-nav {
            padding: 16px;
        }
        .sidebar-nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar-nav li {
            margin-bottom: 8px;
        }
        .sidebar-nav a {
            display: flex;
            align-items: center;
            padding: 12px;
            border-radius: 8px;
            color: #1e293b;
            font-weight: 500;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }
        .sidebar-nav a:hover, .sidebar-nav a.active {
            background-color: var(--sena-light-green);
            color: var(--sena-dark-green);
            transform: translateX(5px);
        }
        .sidebar-nav .nav-icon {
            margin-right: 12px;
            font-size: 1.1rem;
        }
        .sidebar-nav .nav-treeview {
            padding-left: 24px;
            margin-top: 8px;
        }
        .sidebar-nav .nav-treeview a {
            font-size: 0.95rem;
        }
        .footer {
            background-color: var(--sena-dark-green);
            color: white;
            padding: 12px;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: calc(100% - 250px);
            margin-left: 250px;
            transition: margin-left 0.3s ease-in-out;
        }
        .footer-expanded {
            margin-left: 0;
            width: 100%;
        }
        .dropdown-menu {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(8px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1001;
            transform: translateY(-100%);
            transition: transform 0.3s ease-in-out;
            padding: 16px 24px;
        }
        .dropdown-menu.show {
            transform: translateY(0);
        }
        .dropdown-menu a {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            color: #1e293b;
            font-size: 1rem;
            font-weight: 500;
            border-radius: 6px;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }
        .dropdown-menu a:hover {
            background-color: var(--sena-light-green);
            color: var(--sena-dark-green);
            transform: translateX(4px);
        }
        .card {
            border-top: 4px solid var(--sena-green);
            border-radius: 0.75rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            padding: 24px;
            background-color: #ffffff;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            animation: slideIn 0.5s ease-out;
        }
        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
        }
        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--sena-dark-green);
            margin-bottom: 16px;
            border-bottom: 2px solid var(--sena-light-green);
            padding-bottom: 8px;
        }
        .form-label {
            color: #1e293b;
            font-size: 0.95rem;
            font-weight: 500;
            margin-bottom: 8px;
            display: block;
        }
        .form-input, .form-textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #d1d5db;
            border-radius: 0.5rem;
            font-size: 1rem;
            color: #1e293b;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .form-input:focus, .form-textarea:focus {
            outline: none;
            border-color: var(--sena-green);
            box-shadow: 0 0 0 3px rgba(46, 204, 113, 0.2);
        }
        .form-checkbox, .form-radio {
            margin-right: 8px;
        }
        .checkbox-label, .radio-label {
            display: flex;
            align-items: center;
            font-size: 0.95rem;
            color: #1e293b;
            margin-bottom: 8px;
        }
        .btn-submit {
            background-color: var(--sena-green);
            color: white;
            padding: 12px 24px;
            border-radius: 0.5rem;
            font-weight: 500;
            transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
        }
        .btn-submit:hover {
            background-color: var(--sena-dark-green);
            transform: scale(1.05);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        .preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: var(--sena-dark-green);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.9s ease;
        }
        .preloader.fade-out {
            opacity: 0;
        }
        .typing-container {
            text-align: center;
        }
        .typing-text {
            display: block;
            color: white;
            font-size: 2rem;
            font-family: 'Cinzel', serif;
            margin: 10px 0;
        }
        .conditional-field {
            display: none;
            margin-top: 8px;
            transition: opacity 0.3s ease;
        }
        .conditional-field.active {
            display: block;
            opacity: 1;
        }
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        @media (max-width: 768px) {
            .navbar .mobile-toggle {
                display: block;
            }
            .navbar .brand {
                font-size: 1.2rem;
            }
            .sidebar {
                transform: translateX(-250px);
            }
            .sidebar.sidebar-visible {
                transform: translateX(0);
            }
            .content-wrapper {
                margin-left: 0;
            }
            .footer {
                margin-left: 0;
                width: 100%;
            }
            .dropdown-menu {
                padding: 12px 16px;
            }
            .dropdown-menu a {
                font-size: 0.9rem;
            }
            .card {
                padding: 16px;
            }
            .form-label {
                font-size: 0.9rem;
            }
            .form-input, .form-textarea {
                font-size: 0.9rem;
            }
            .section-title {
                font-size: 1.1rem;
            }
            .grid-cols-2 {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper" style="visibility: {{ session('success') || session('error') ? 'visible' : 'hidden' }};">
        <!-- Preloader -->
        <div class="preloader" id="preloader" style="display: none;">
            <div class="typing-container" id="typing-container">
                <span class="typing-text">Bienvenido</span>
                <span class="typing-text">al panel del usuario</span>
            </div>
        </div>

        <!-- Dropdown Menu -->
        <div class="dropdown-menu hidden" id="dropdown-menu">
            <div class="flex justify-end items-center space-x-4">
                <button type="button" class="text-gray-500 text-2xl h-12 w-12 flex items-center justify-center hover:bg-gray-200 rounded-full" onclick="toggleDropdown()">×</button>
                <a href="#" class="block" onclick="confirmLogout(event, 'logout-form');">
                    <i class="fas fa-sign-out-alt mr-2"></i> Cerrar Sesión
                </a>
            </div>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="hidden">
                @csrf
            </form>
        </div>

        <!-- Navbar -->
        <nav class="navbar">
            <div class="flex items-center">
                <button class="mobile-toggle" id="toggle-sidebar-mobile">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="brand">
                    <i class="fas fa-laptop-code"></i>
                    
                </div>
            </div>
            <div class="user-menu">
                <div class="notification-bell-container relative">
                    <button class="notification-bell" id="notification-bell-btn">
                        <i class="fas fa-bell"></i>
                        <span class="notification-count" id="notification-count">0</span>
                    </button>
                    <div class="notifications-dropdown" id="notifications-dropdown">
                        <div class="notifications-dropdown-header">Notificaciones</div>
                        <div id="notification-list-container">
                            <!-- Notifications will be loaded here -->
                            <div class="no-notifications">No hay notificaciones.</div>
                        </div>
                    </div>
                </div>
                <div class="relative">
                    <button type="button" class="user-info focus:outline-none" id="navbarDropdown">
                        <div class="user-avatar">U</div>
                        <span>Usuario</span>
                        <i class="fas fa-chevron-down text-xs"></i>
                    </button>
                </div>
            </div>
        </nav>

        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header flex items-center justify-between">
                <div class="flex items-center gap-2">
                    <i class="fas fa-cogs"></i>
                    <span>USUARIO</span>
                </div>
                <button class="mobile-toggle ml-2" id="toggle-sidebar">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            <div class="sidebar-nav">
                <nav>
                    <ul>
                        <li>
                            <a href="{{ route('fabricasoft.cliente.dashboard') }}" class="nav-link">
                                <i class="fas fa-tachometer-alt text-green-500 nav-icon"></i>
                                <span>Inicio</span>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="nav-link">
                                <i class="fas fa-hands-helping text-green-500 nav-icon"></i>
                                <span>Servicios</span>
                                <i class="fas fa-angle-left ml-auto transition-transform duration-200"></i>
                            </a>
                            <ul class="nav-treeview hidden">
                                <li>
                                    <a href="{{ route('fabricasoft.nuevasolicitud') }}" class="nav-link">
                                        <i class="fas fa-file-signature text-green-500 nav-icon"></i>
                                        <span>Nueva Solicitud</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="nav-link">
                                        <i class="fas fa-tasks text-green-500 nav-icon"></i>
                                        <span>Seguimiento</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="nav-link">
                                        <i class="fas fa-headset text-green-500 nav-icon"></i>
                                        <span>Soporte Técnico</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="{{ route('fabricasoft.ajustes') }}" class="nav-link">
                                        <i class="fas fa-cog text-green-500 nav-icon"></i>
                                        <span>Ajustes</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>

        <!-- Content Wrapper -->
        <div class="content-wrapper" id="content-wrapper">
            @yield('content')
        </div>

        <!-- Footer -->
        <footer class="footer" id="footer">
            <p>© 2025 SENA - Todos los derechos reservados</p>
        </footer>

        <!-- Show Sidebar Button -->
        <button id="show-sidebar-btn" style="display:none; position:fixed; top:32px; left:24px; z-index:3000; background:#2ECC71; color:white; padding:12px 16px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.2); border:none; font-size:1.5rem; cursor:pointer; transform:translateY(-50%);">
            <i class="fas fa-bars"></i>
        </button>
    </div>

    <script>
        // Preloader - DESACTIVADO
        document.addEventListener('DOMContentLoaded', () => {
            const preloader = document.getElementById('preloader');
            const wrapper = document.querySelector('.wrapper');
            
            // DESACTIVAR el preloader completamente
            if (preloader) {
                preloader.style.display = 'none';
            }
            wrapper.style.visibility = 'visible';
            
            console.log('Preloader DESACTIVADO en masternuevasolicitud');
            checkSidebarBtn();
        });

        // Sidebar Toggle
        function toggleSidebar(forceShow = null) {
            const sidebar = document.getElementById('sidebar');
            const contentWrapper = document.getElementById('content-wrapper');
            const footer = document.getElementById('footer');
            if (window.innerWidth <= 768) {
                // Mobile view
                if (forceShow === true) {
                    sidebar.classList.add('sidebar-visible');
                    sidebar.classList.remove('sidebar-hidden');
                } else if (forceShow === false) {
                    sidebar.classList.remove('sidebar-visible');
                    sidebar.classList.add('sidebar-hidden');
                } else {
                    sidebar.classList.toggle('sidebar-visible');
                    sidebar.classList.toggle('sidebar-hidden');
                }
                contentWrapper.classList.toggle('content-wrapper-expanded', !sidebar.classList.contains('sidebar-visible'));
                footer.classList.toggle('footer-expanded', !sidebar.classList.contains('sidebar-visible'));
            } else {
                // Desktop view
                if (forceShow === true) {
                    sidebar.classList.remove('sidebar-hidden');
                } else if (forceShow === false) {
                    sidebar.classList.add('sidebar-hidden');
                } else {
                    sidebar.classList.toggle('sidebar-hidden');
                }
                contentWrapper.classList.toggle('content-wrapper-expanded', sidebar.classList.contains('sidebar-hidden'));
                footer.classList.toggle('footer-expanded', sidebar.classList.contains('sidebar-hidden'));
            }
            checkSidebarBtn();
        }

        // Assign events to both hamburger buttons
        document.addEventListener('DOMContentLoaded', function() {
            const sidebarToggleBtn = document.getElementById('toggle-sidebar');
            const sidebarToggleMobileBtn = document.getElementById('toggle-sidebar-mobile');
            const showSidebarBtn = document.getElementById('show-sidebar-btn');
            if (sidebarToggleBtn) {
                sidebarToggleBtn.onclick = function() {
                    toggleSidebar();
                };
            }
            if (sidebarToggleMobileBtn) {
                sidebarToggleMobileBtn.onclick = function() {
                    toggleSidebar();
                };
            }
            if (showSidebarBtn) {
                showSidebarBtn.onclick = function() {
                    toggleSidebar(true);
                };
            }
        });

        // Show/hide sidebar button based on sidebar state
        function checkSidebarBtn() {
            const sidebar = document.getElementById('sidebar');
            const showSidebarBtn = document.getElementById('show-sidebar-btn');
            if ((window.innerWidth <= 768 && !sidebar.classList.contains('sidebar-visible')) ||
                (window.innerWidth > 768 && sidebar.classList.contains('sidebar-hidden'))) {
                showSidebarBtn.style.display = 'block';
            } else {
                showSidebarBtn.style.display = 'none';
            }
        }
        window.addEventListener('resize', checkSidebarBtn);

        // Dropdown Menu
        function toggleDropdown() {
            const dropdown = document.getElementById('dropdown-menu');
            dropdown.classList.toggle('show');
            dropdown.classList.toggle('hidden');
        }

        document.getElementById('navbarDropdown').addEventListener('click', function(e) {
            e.preventDefault();
            toggleDropdown();
        });

        // Close Dropdown on Outside Click
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('dropdown-menu');
            const toggle = document.getElementById('navbarDropdown');
            if (!toggle.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.add('hidden');
                dropdown.classList.remove('show');
            }
        });

        // Logout Confirmation
        function confirmLogout(event, formId) {
            event.preventDefault();
            Swal.fire({
                title: '¿Estás seguro?',
                text: '¿Deseas cerrar tu sesión?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#2ECC71',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, cerrar sesión',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById(formId).submit();
                }
            });
        }

        // Sistema de Notificaciones Global
        let notifications = []; // Array to store all notifications

        async function fetchNotifications() {
            try {
                const response = await fetch('/fabricasoft/admin/notifications');
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();
                notifications = data; // Store the fetched notifications
                updateNotificationsDisplay();
            } catch (error) {
                console.error("Error fetching notifications:", error);
                document.getElementById('notification-count').textContent = 'Error';
                document.getElementById('notification-list-container').innerHTML = '<div class="no-notifications">Error al cargar notificaciones.</div>';
            }
        }

        function updateNotificationsDisplay() {
            const countElement = document.getElementById('notification-count');
            const listContainer = document.getElementById('notification-list-container');
            
            // Contar solo notificaciones no leídas
            const unreadCount = notifications.filter(n => !n.read_at).length;
            countElement.textContent = unreadCount;

            if (notifications.length > 0) {
                listContainer.innerHTML = ''; // Clear previous notifications
                notifications.forEach(notification => {
                    const notificationItem = document.createElement('div');
                    notificationItem.className = `notification-item ${notification.read_at ? 'read' : 'unread'}`;
                    
                    // Determinar el icono según el tipo
                    let icon = 'fas fa-bell';
                    let iconColor = 'text-blue-500';
                    
                    if (notification.notification_type === 'success') {
                        icon = 'fas fa-check-circle';
                        iconColor = 'text-green-500';
                    } else if (notification.notification_type === 'warning') {
                        icon = 'fas fa-exclamation-triangle';
                        iconColor = 'text-yellow-500';
                    } else if (notification.notification_type === 'error') {
                        icon = 'fas fa-times-circle';
                        iconColor = 'text-red-500';
                    }

                    notificationItem.innerHTML = `
                        <div class="flex items-start space-x-3">
                            <i class="${icon} ${iconColor} mt-1"></i>
                            <div class="flex-1">
                                <h4 class="font-semibold text-sm">${notification.title}</h4>
                                <p class="text-xs text-gray-600">${notification.message}</p>
                                <div class="flex justify-between items-center mt-2">
                                    <span class="text-xs text-gray-500">${formatDate(notification.created_at)}</span>
                                    ${notification.module ? `<span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">${notification.module}</span>` : ''}
                                </div>
                            </div>
                        </div>
                    `;
                    
                    notificationItem.addEventListener('click', () => {
                        // Marcar como leída si no está leída
                        if (!notification.read_at) {
                            markAsRead(notification.id);
                        }
                        
                        // Navegar según el tipo
                        if (notification.type === 'request') {
                            window.location.href = `{{ url('fabricasoft/solicitudes') }}?id=${notification.id}`;
                        } else if (notification.type === 'notification') {
                            // Para notificaciones globales, ir a la página de notificaciones
                            window.location.href = "{{ route('notifications.index') }}";
                        }
                    });
                    
                    listContainer.appendChild(notificationItem);
                });
            } else {
                listContainer.innerHTML = '<div class="no-notifications">No hay notificaciones.</div>';
            }
        }

        async function markAsRead(notificationId) {
            try {
                const response = await fetch(`/notifications/${notificationId}/read`, {
                    method: 'PATCH',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                        'Content-Type': 'application/json'
                    }
                });
                
                if (response.ok) {
                    // Actualizar la notificación localmente
                    const notification = notifications.find(n => n.id === notificationId);
                    if (notification) {
                        notification.read_at = new Date().toISOString();
                        updateNotificationsDisplay();
                    }
                }
            } catch (error) {
                console.error('Error marking notification as read:', error);
            }
        }

        function formatDate(dateString) {
            const date = new Date(dateString);
            const now = new Date();
            const diffInHours = (now - date) / (1000 * 60 * 60);
            
            if (diffInHours < 1) {
                return 'Hace unos minutos';
            } else if (diffInHours < 24) {
                return `Hace ${Math.floor(diffInHours)} horas`;
            } else {
                return date.toLocaleDateString('es-ES');
            }
        }

        // Toggle notification dropdown
        document.getElementById('notification-bell-btn').addEventListener('click', function() {
            const dropdown = document.getElementById('notifications-dropdown');
            dropdown.classList.toggle('show');
        });

        // Close notification dropdown on outside click
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('notifications-dropdown');
            const toggle = document.getElementById('notification-bell-btn');
            if (!toggle.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });

        // Initial fetch and periodic refresh
        document.addEventListener('DOMContentLoaded', () => {
            fetchNotifications();
            setInterval(fetchNotifications, 30000); // Refresh every 30 seconds
        });

        // Treeview Toggle
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', function(e) {
                const treeview = this.nextElementSibling;
                if (treeview && treeview.classList.contains('nav-treeview')) {
                    e.preventDefault();
                    treeview.classList.toggle('hidden');
                    const angle = this.querySelector('.fa-angle-left, .fa-angle-down');
                    if (angle) {
                        angle.classList.toggle('fa-angle-down');
                        angle.classList.toggle('fa-angle-left');
                    }
                }
            });
        });

        // Toggle Conditional Fields
        function toggleField(fieldId, show) {
            const field = document.getElementById(fieldId);
            if (show) {
                field.classList.add('active');
                const inputs = field.querySelectorAll('input, textarea');
                inputs.forEach(input => input.required = true);
            } else {
                field.classList.remove('active');
                const inputs = field.querySelectorAll('input, textarea');
                inputs.forEach(input => {
                    input.required = false;
                    input.value = '';
                });
            }
        }

        // Form Validation
        function handleFormSubmission(event) {
            event.preventDefault();
            const form = document.getElementById('software-request-form');
            let errors = [];

            // Validate required fields
            const requiredFields = form.querySelectorAll('[required]');
            requiredFields.forEach(field => {
                if (!field.value && field.type !== 'radio' && field.type !== 'checkbox') {
                    errors.push(`El campo "${field.previousElementSibling.textContent}" es obligatorio.`);
                }
            });

            // Validate radio groups
            const radioGroups = [
                'project_code_exists', 'document_version', 'has_documents', 'system_type',
                'reference_system', 'user_restrictions', 'offline', 'integration',
                'database', 'backups', 'security_level', 'availability', 'load_time',
                'phased_delivery', 'documentation_support', 'training_needed',
                'budget_defined', 'budget_includes_support', 'has_process_documents'
            ];
            radioGroups.forEach(group => {
                if (!form.querySelector(`input[name="${group}"]:checked`)) {
                    errors.push(`Debe seleccionar una opción para "${form.querySelector(`input[name="${group}"]`).closest('div').previousElementSibling.textContent}".`);
                }
            });

            // Validate checkbox groups
            const checkboxGroups = ['system_goals', 'functionalities', 'platform', 'devices', 'documentation', 'training_type'];
            checkboxGroups.forEach(group => {
                const checkboxes = form.querySelectorAll(`input[name="${group}"]`);
                let checked = false;
                checkboxes.forEach(cb => {
                    if (cb.checked) {
                        checked = true;
                    }
                });
                if (!checked) {
                    errors.push(`Debe seleccionar al menos una opción para "${form.querySelector(`input[name="${group}"]`).closest('div').previousElementSibling.textContent}".`);
                }
            });

            // Validate conditional fields
            if (form.querySelector('input[name="project_code_exists"]:checked')?.value === 'yes' && !form.querySelector('#project_code').value) {
                errors.push('Debe especificar el código del proyecto.');
            }
            if (form.querySelector('input[name="document_version"]:checked')?.value === 'update' && !form.querySelector('#version_number').value) {
                errors.push('Debe especificar la versión del documento.');
            }
            if (form.querySelector('input[name="has_documents"]:checked')?.value === 'yes' && !form.querySelector('#documents').files.length) {
                errors.push('Debe adjuntar al menos un documento.');
            }
            if (form.querySelector('input[name="system_type"]:checked')?.value === 'other' && !form.querySelector('#system_type_other').value) {
                errors.push('Debe especificar el tipo de sistema.');
            }
            if (form.querySelector('input[name="reference_system"]:checked')?.value === 'yes' && !form.querySelector('#reference_system_details').value) {
                errors.push('Debe especificar el sistema de referencia.');
            }
            if (form.querySelector('input[name="system_goals"][value="other"]:checked') && !form.querySelector('#system_goals_other').value.trim()) {
                errors.push('Debe especificar el otro objetivo.');
            }
            if (form.querySelector('input[name="functionalities"][value="other"]:checked') && !form.querySelector('#functionalities_other').value.trim()) {
                errors.push('Debe especificar la otra funcionalidad.');
            }
            if (form.querySelector('input[name="devices"][value="other"]:checked') && !form.querySelector('#devices_other').value.trim()) {
                errors.push('Debe especificar el otro dispositivo.');
            }
            if (form.querySelector('input[name="integration"]:checked')?.value === 'yes' && !form.querySelector('#integration_details').value) {
                errors.push('Debe especificar los sistemas a conectar.');
            }
            if (form.querySelector('input[name="availability"]:checked')?.value === 'other' && !form.querySelector('#availability_other').value) {
                errors.push('Debe especificar el horario de disponibilidad.');
            }
            if (form.querySelector('input[name="phased_delivery"]:checked')?.value === 'yes' && !form.querySelector('#phase_1').value) {
                errors.push('Debe especificar al menos la fase 1.');
            }
            if (form.querySelector('input[name="documentation"][value="other"]:checked') && !form.querySelector('#documentation_other').value.trim()) {
                errors.push('Debe especificar la otra documentación.');
            }
            if (form.querySelector('input[name="training_needed"]:checked')?.value === 'yes' && !form.querySelector('#training_details').value) {
                errors.push('Debe especificar los detalles de la capacitación.');
            }
            if (form.querySelector('input[name="training_type"][value="other"]:checked') && !form.querySelector('#training_type_other').value.trim()) {
                errors.push('Debe especificar el otro tipo de capacitación.');
            }
            if (form.querySelector('input[name="budget_defined"]:checked')?.value === 'yes' && !form.querySelector('#budget_details').value) {
                errors.push('Debe especificar los detalles del presupuesto.');
            }
            if (form.querySelector('input[name="has_process_documents"]:checked')?.value === 'yes' && !form.querySelector('#process_documents').files.length) {
                errors.push('Debe adjuntar al menos un documento del proceso.');
            }

            // Validate user types
            if (!form.querySelector('#user_type_1').value || !form.querySelector('#user_functions_1').value) {
                errors.push('Debe especificar el tipo y funciones del usuario 1.');
            }
            if (!form.querySelector('#user_type_2').value || !form.querySelector('#user_functions_2').value) {
                errors.push('Debe especificar el tipo y funciones del usuario 2.');
            }

            // Validate dates
            const startDate = form.querySelector('#start_date').value;
            const endDate = form.querySelector('#end_date').value;
            if (startDate && endDate && new Date(startDate) > new Date(endDate)) {
                errors.push('La fecha de inicio no puede ser posterior a la fecha de finalización.');
            }

            // Display errors or submit
            if (errors.length > 0) {
                Swal.fire({
                    icon: 'error',
                    title: 'Errores en el formulario',
                    html: `<ul>${errors.map(error => `<li>${error}</li>`).join('')}</ul>`,
                    confirmButtonColor: '#2ECC71'
                });
            } else {
                form.submit();
            }
        }

        // Añadir estilos para los estados de la solicitud si no existen
        const styleElement = document.createElement('style');
        styleElement.innerHTML = `
            .status-pendiente {
                background-color: #FBBF24; /* Amarillo */
                color: #744210;
                padding: 4px 8px;
                border-radius: 12px;
                font-weight: 500;
            }
            .status-aprobada {
                background-color: #48bb78; /* Verde */
                color: #2f855a;
                padding: 4px 8px;
                border-radius: 12px;
                font-weight: 500;
            }
            .status-rechazada {
                background-color: #feb2b2; /* Rojo claro */
                color: #742a2a;
                padding: 4px 8px;
                border-radius: 12px;
                font-weight: 500;
            }
        `;
        document.head.appendChild(styleElement);
    </script>
</body>
</html>