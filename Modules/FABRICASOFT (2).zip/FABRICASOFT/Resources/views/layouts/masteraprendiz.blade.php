<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="icon" href="{{ asset('images/Favicon2.png') }}" type="image/x-icon">
    <title>Panel Aprendiz</title>
    <!-- Google Font: Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --sena-green: #2ECC71;
            --sena-dark-green: #27AE60;
            --sena-light-green: #ECF9F2;
            --navbar-gradient: linear-gradient(90deg, #2ECC71 0%, #27AE60 100%);
        }
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f9fafb;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        .navbar {
            background: var(--navbar-gradient);
            height: 64px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 24px;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1002;
        }
        .navbar .brand {
            color: white;
            font-size: 1.5rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: transform 0.3s ease, opacity 0.3s ease;
        }
        .navbar .brand:hover {
            transform: translateY(-2px);
            opacity: 0.95;
        }
        .navbar .brand i {
            font-size: 1.8rem;
        }
        .navbar .user-menu {
            display: flex;
            align-items: center;
            gap: 14px;
            position: relative;
        }
        .navbar .user-menu .notification-bell {
            color: white;
            font-size: 1.2rem;
            padding: 8px;
            border-radius: 50%;
            transition: background-color 0.3s ease, transform 0.3s ease;
            position: relative;
        }
        .navbar .user-menu .notification-bell:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: scale(1.1);
        }
        .notification-bell-container {
            position: relative;
        }
        .notification-count {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: #ef4444;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: bold;
        }
        .notifications-dropdown {
            position: absolute;
            top: 50px;
        }
        
        /* Estilos para el botón de cerrar sesión */
        .logout-button {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white !important;
            border-radius: 9999px;
            margin: 0;
            padding: 6px 12px !important;
            transition: all 0.3s ease;
            font-weight: 600;
            font-size: 0.5rem;
            display: inline-block;
            text-align: center;
            min-width: auto;
            border: 1px solid rgba(255, 255, 255, 0.3);
            transform: scale(0.65);
        }
        
        .logout-button:hover {
            background: linear-gradient(135deg, #dc2626, #b91c1c) !important;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }
        
        .logout-button i {
            color: white !important;
        }
        
        /* Estilos para el botón de configuración */
        .config-button {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: white !important;
            border-radius: 9999px;
            margin: 0;
            padding: 6px 12px !important;
            transition: all 0.3s ease;
            font-weight: 600;
            font-size: 0.5rem;
            display: inline-block;
            text-align: center;
            min-width: auto;
            border: 1px solid rgba(255, 255, 255, 0.3);
            transform: scale(0.65);
        }
        
        .config-button:hover {
            background: linear-gradient(135deg, #2563eb, #1d4ed8) !important;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }
        
        .config-button i {
            color: white !important;
        }
            right: 0;
            width: 350px;
            max-height: 400px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            display: none;
            overflow: hidden;
        }
        .notifications-dropdown.show {
            display: block;
        }
        .notifications-dropdown-header {
            padding: 12px 16px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
            font-weight: 600;
            color: #495057;
        }
        .notification-item {
            padding: 12px 16px;
            border-bottom: 1px solid #f1f3f4;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }
        .notification-item:hover {
            background-color: #f8f9fa;
        }
        .notification-item.unread {
            background-color: #f0f9ff;
            border-left: 3px solid #3b82f6;
        }
        .notification-item.read {
            opacity: 0.7;
        }
        .no-notifications {
            padding: 20px;
            text-align: center;
            color: #6c757d;
            font-style: italic;
        }
        .dropdown-menu {
            display: none;
        }
        .dropdown-menu.show {
            display: block;
        }
        .navbar .user-menu .user-info {
            display: flex;
            align-items: center;
            gap: 6px;
            color: #000000 !important;
            font-weight: 600;
            cursor: pointer;
            padding: 4px 10px;
            border-radius: 9999px;
            background-color: #ffffff;
            border: 1px solid rgba(255, 255, 255, 0.3);
            transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
            font-size: 0.85rem;
            transform: scale(0.9);
        }
        .navbar .user-menu .user-info:hover {
            background-color: #f8f9fa;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            border-color: rgba(255, 255, 255, 0.5);
        }
        .navbar .user-menu .user-avatar {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: linear-gradient(135deg, #ffffff, #f8f9fa);
            color: var(--sena-dark-green);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 14px;
            border: 1px solid rgba(255, 255, 255, 0.8);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        .navbar .mobile-toggle {
            display: block;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            padding: 10px 12px;
            border-radius: 8px;
            background-color: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
        }
        .navbar .mobile-toggle:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: scale(1.05);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }

        .sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            background-color: #ffffff;
            box-shadow: 2px 0 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
            z-index: 2000;
        }
        .sidebar-hidden {
            transform: translateX(-250px);
        }
        .content-wrapper {
            margin-left: 250px;
            padding: 24px;
            min-height: calc(100vh - 64px);
            transition: margin-left 0.3s ease-in-out;
            margin-top: 64px;
        }
        .content-wrapper-expanded {
            margin-left: 0;
        }
        .sidebar-header {
            padding: 16px;
            border-bottom: 2px solid var(--sena-green);
            background-color: #ffffff;
            color: var(--sena-dark-green);
            font-weight: 600;
            font-size: 1.25rem;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }
        .sidebar-header .mobile-toggle {
            display: block;
            color: var(--sena-dark-green);
            font-size: 1.5rem;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .sidebar-header .mobile-toggle:hover {
            background-color: var(--sena-light-green);
            transform: scale(1.1);
        }
        .sidebar-nav {
            padding: 16px;
        }
        .sidebar-nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar-nav li {
            margin-bottom: 8px;
        }
        .sidebar-nav a {
            display: flex;
            align-items: center;
            padding: 12px;
            border-radius: 8px;
            color: #1e293b;
            font-weight: 500;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }
        .sidebar-nav a:hover, .sidebar-nav a.active {
            background-color: var(--sena-light-green);
            color: var(--sena-dark-green);
            transform: translateX(5px);
        }
        .sidebar-nav .nav-icon {
            margin-right: 12px;
            font-size: 1.1rem;
        }
        .sidebar-nav .nav-treeview {
            padding-left: 24px;
            margin-top: 8px;
        }
        .sidebar-nav .nav-treeview a {
            font-size: 0.95rem;
        }
        .footer {
            background-color: var(--sena-dark-green);
            color: white;
            padding: 16px 24px;
            position: fixed;
            bottom: 0;
            left: 250px;
            right: 0;
            transition: left 0.3s ease-in-out;
            box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.1);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            z-index: 1000;
        }
        
        .footer-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .footer-left {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }
        
        .footer-right {
            display: flex;
            align-items: center;
        }
        
        .footer-text {
            font-weight: 600;
            font-size: 14px;
            line-height: 1.4;
        }
        
        .footer-left .footer-text:first-child {
            margin-bottom: 4px;
        }
        .footer-expanded {
            left: 0;
        }
        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            width: 250px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(8px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1001;
            transform: translateY(-10px);
            opacity: 0;
            visibility: hidden;
            transition: transform 0.3s ease-in-out, opacity 0.3s ease-in-out, visibility 0.3s ease-in-out;
            padding: 8px 0;
            border-radius: 8px;
            margin-top: 8px;
        }
        .dropdown-menu.show {
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }
        .dropdown-menu a {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            color: #1e293b;
            font-size: 1rem;
            font-weight: 500;
            border-radius: 6px;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }
        .dropdown-menu a:hover {
            background-color: var(--sena-light-green);
            color: var(--sena-dark-green);
            transform: translateX(4px);
        }
        .dropdown-menu button {
            color: #6b7280 !important;
            transition: all 0.3s ease;
        }
        .dropdown-menu button:hover {
            background-color: #f3f4f6 !important;
            color: #374151 !important;
        }
        .card {
            border-top: 4px solid var(--sena-green);
            border-radius: 0.75rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        .btn-success {
            background-color: var(--sena-green);
            border-color: var(--sena-green);
            transition: background-color 0.3s ease, border-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
        }
        .btn-success:hover {
            background-color: var(--sena-dark-green);
            border-color: var(--sena-dark-green);
            transform: scale(1.05);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        .modal-content {
            border-radius: 0.75rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        /* Mobile Overlay */
        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1500;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease, visibility 0.3s ease;
        }
        .sidebar-overlay.show {
            opacity: 1;
            visibility: visible;
        }
        
        @media (max-width: 768px) {
            .navbar .mobile-toggle {
                display: block;
                margin-right: 12px;
            }
            .navbar .brand {
                font-size: 1.2rem;
            }
            .sidebar {
                transform: translateX(-100%);
                z-index: 2000;
            }
            .sidebar.sidebar-visible {
                transform: translateX(0);
            }
            .content-wrapper {
                margin-left: 0;
                padding: 16px;
            }
            .footer {
                left: 0;
                padding: 12px 16px;
            }
            .footer-content {
                flex-direction: column;
                text-align: center;
                gap: 8px;
            }
            .footer-left {
                align-items: center;
            }
            .footer-right {
                justify-content: center;
            }
            .footer-text {
                font-size: 13px;
            }
            .dropdown-menu {
                padding: 12px 16px;
            }
            .dropdown-menu a {
                font-size: 0.9rem;
            }
        }
        
        @media (min-width: 769px) {
            .sidebar-overlay {
                display: none;
            }
        }
        
        /* Preloader para Aprendiz */

        .typing-container-aprendiz {
            text-align: center;
            font-family: 'Roboto', sans-serif;
            color: white;
            text-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        
        .typing-text-aprendiz {
            font-size: 2.5rem;
            font-weight: 700;
            line-height: 1.2;
            display: block;
            margin: 10px 0;
        }
    </style>
</head>
<body>

    <div class="wrapper">

        <!-- Dropdown Menu del Usuario -->
        <div class="dropdown-menu hidden" id="dropdown-menu" style="position: absolute; top: 70px; right: 20px; background: white; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 1000; min-width: 200px; padding: 8px 0;">
            <div class="px-4 py-2 border-b border-gray-200">
                <p class="text-sm font-medium text-gray-800">Aprendiz</p>
                <p class="text-xs text-gray-500">{{ Auth::user()->email ?? 'aprendiz@sena.edu.co' }}</p>
            </div>
            <div class="px-1 py-1 text-right">
                <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 4px;">
                    <a href="{{ route('fabricasoft.aprendiz.ajustes') }}" class="config-button">
                        <i class="fas fa-cog mr-1"></i> Config
                    </a>
                    <a href="#" class="logout-button" onclick="confirmLogout(event, 'logout-form-aprendiz');">
                        <i class="fas fa-sign-out-alt mr-1"></i> Salir
                    </a>
                </div>
            </div>
            <form id="logout-form-aprendiz" action="{{ route('logout') }}" method="POST" class="hidden">
                @csrf
            </form>
        </div>

        <!-- Navbar -->
        <nav class="navbar">
            <div class="flex items-center">
                <button class="mobile-toggle mr-4" id="navbar-mobile-toggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="brand">
                    <span class="text-lg font-semibold text-white">Panel de Aprendiz</span>
                </div>
            </div>
            <div class="user-menu">
                <div class="relative" style="margin-left: auto;">
                    <button class="user-info focus:outline-none" id="navbarDropdown">
                        <div class="user-avatar">A</div>
                        <span>Aprendiz</span>
                        <i class="fas fa-chevron-down text-xs"></i>
                    </button>
                </div>
            </div>
        </nav>

        <!-- Sidebar Overlay for Mobile -->
        <div class="sidebar-overlay" id="sidebar-overlay" onclick="closeSidebar()"></div>

        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header flex items-center justify-between">
                <div class="flex items-center gap-2">
                    <i class="fas fa-cogs"></i>
                    <span>APRENDIZ</span>
                </div>
                <button class="mobile-toggle ml-2" id="toggle-sidebar">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            <div class="sidebar-nav">
                <nav>
                    <ul>
                        <li>
                            <a href="{{ route('fabricasoft.apprentices.aprendiz') }}" class="nav-link">
                                <i class="fas fa-home text-green-500 nav-icon"></i>
                                <span>Inicio</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.aprendiz.proyectos') }}" class="nav-link">
                                <i class="fas fa-project-diagram text-green-500 nav-icon"></i>
                                <span>Proyectos</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.desarrollador.mis-proyectos') }}" class="nav-link">
                                <i class="fas fa-folder-open text-green-500 nav-icon"></i>
                                <span>Mis Proyectos</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.aprendiz.requerimientos') }}" class="nav-link">
                                <i class="fas fa-clipboard-list text-green-500 nav-icon"></i>
                                <span>Requerimientos</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.aprendiz.tareas') }}" class="nav-link">
                                <i class="fas fa-tasks text-green-500 nav-icon"></i>
                                <span>Tareas</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.aprendiz.reportes') }}" class="nav-link">
                                <i class="fas fa-chart-bar text-green-500 nav-icon"></i>
                                <span>Reportes</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.aprendiz.ajustes') }}" class="nav-link">
                                <i class="fas fa-cog text-green-500 nav-icon"></i>
                                <span>Ajustes</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>

        <!-- Content Wrapper -->
        <div class="content-wrapper" id="content-wrapper">
            <div class="p-4 border-b bg-white">
                <h1 class="text-2xl font-semibold text-gray-800">Panel de Aprendiz</h1>
            </div>
            <div class="p-4">
                @yield('content')
            </div>
        </div>

        <!-- Footer -->
        <footer class="footer" id="footer">
            <div class="footer-content">
                <div class="footer-left">
                    <span class="footer-text">Copyright © 2024-2025 APRENDIZ - SENA.</span>
                    <span class="footer-text">Todos los derechos reservados.</span>
                </div>
                <div class="footer-right">
                    <span class="footer-text">Versión 1.0.0</span>
                </div>
            </div>
        </footer>
    </div>

    <!-- Botón para mostrar el menú lateral cuando está oculto -->
    <button id="show-sidebar-btn" style="display:none; position:fixed; top:32px; left:24px; z-index:3000; background:#2ECC71; color:white; padding:12px 16px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.2); border:none; font-size:1.5rem; cursor:pointer; transform:translateY(-50%);" onclick="toggleSidebar(true)">
        <i class="fas fa-bars"></i>
    </button>

    <script>
        // Mostrar contenido inmediatamente
        document.addEventListener('DOMContentLoaded', function () {
            const wrapper = document.querySelector('.wrapper');
            
            // Mostrar contenido principal
            if (wrapper) {
                wrapper.style.visibility = 'visible';
            }
            
            document.body.style.overflow = 'auto';
        });

        // Sidebar Toggle Functions
        function toggleSidebar(forceShow = null) {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebar-overlay');
            const contentWrapper = document.getElementById('content-wrapper');
            const footer = document.getElementById('footer');
            
            if (window.innerWidth <= 768) {
                // Mobile behavior
                if (forceShow === true || (forceShow === null && !sidebar.classList.contains('sidebar-visible'))) {
                    sidebar.classList.add('sidebar-visible');
                    overlay.classList.add('show');
                    document.body.style.overflow = 'hidden';
                } else {
                    closeSidebar();
                }
            } else {
                // Desktop behavior
                if (forceShow === true) {
                    sidebar.classList.remove('sidebar-hidden');
                    contentWrapper.classList.remove('content-wrapper-expanded');
                    footer.classList.remove('footer-expanded');
                } else if (forceShow === false) {
                    sidebar.classList.add('sidebar-hidden');
                    contentWrapper.classList.add('content-wrapper-expanded');
                    footer.classList.add('footer-expanded');
                } else {
                    sidebar.classList.toggle('sidebar-hidden');
                    contentWrapper.classList.toggle('content-wrapper-expanded');
                    footer.classList.toggle('footer-expanded');
                }
            }
        }

        function closeSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebar-overlay');
            
            sidebar.classList.remove('sidebar-visible');
            overlay.classList.remove('show');
            document.body.style.overflow = 'auto';
        }

        // Event Listeners
        document.addEventListener('DOMContentLoaded', function() {
            const navbarToggleBtn = document.getElementById('navbar-mobile-toggle');
            const sidebarToggleBtn = document.getElementById('toggle-sidebar');
            
            if (navbarToggleBtn) {
                navbarToggleBtn.addEventListener('click', function() {
                    toggleSidebar();
                });
            }
            
            if (sidebarToggleBtn) {
                sidebarToggleBtn.addEventListener('click', function() {
                    toggleSidebar();
                });
            }
            
            // Close sidebar when clicking on nav links on mobile
            const navLinks = document.querySelectorAll('.sidebar-nav a');
            navLinks.forEach(link => {
                link.addEventListener('click', function() {
                    if (window.innerWidth <= 768) {
                        closeSidebar();
                    }
                });
            });
            
            // Initialize floating button state
            const sidebar = document.getElementById('sidebar');
            const showSidebarBtn = document.getElementById('show-sidebar-btn');
            
            if (window.innerWidth > 768 && sidebar && showSidebarBtn) {
                if (sidebar.classList.contains('sidebar-hidden')) {
                    showSidebarBtn.style.display = 'block';
                } else {
                    showSidebarBtn.style.display = 'none';
                }
            }
        });

        // Handle window resize
        window.addEventListener('resize', function() {
            if (window.innerWidth > 768) {
                // Reset mobile state when switching to desktop
                const sidebar = document.getElementById('sidebar');
                const overlay = document.getElementById('sidebar-overlay');
                const showSidebarBtn = document.getElementById('show-sidebar-btn');
                
                sidebar.classList.remove('sidebar-visible');
                overlay.classList.remove('show');
                document.body.style.overflow = 'auto';
                
                // Show/hide floating button based on sidebar state
                if (showSidebarBtn) {
                    if (sidebar.classList.contains('sidebar-hidden')) {
                        showSidebarBtn.style.display = 'block';
                    } else {
                        showSidebarBtn.style.display = 'none';
                    }
                }
            } else {
                // Hide floating button on mobile
                const showSidebarBtn = document.getElementById('show-sidebar-btn');
                if (showSidebarBtn) {
                    showSidebarBtn.style.display = 'none';
                }
            }
        });

        // Dropdown Menu
        function toggleDropdown() {
            const dropdown = document.getElementById('dropdown-menu');
            dropdown.classList.toggle('hidden');
            dropdown.classList.toggle('show');
        }

        document.getElementById('navbarDropdown').addEventListener('click', toggleDropdown);

        // Close Dropdown on Outside Click
        document.addEventListener('click', function (event) {
            const dropdown = document.getElementById('dropdown-menu');
            const toggle = document.getElementById('navbarDropdown');
            if (!toggle.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.add('hidden');
                dropdown.classList.remove('show');
            }
        });

        // Logout Confirmation
        function confirmLogout(event, formId) {
            event.preventDefault();
            Swal.fire({
                title: '¿Estás seguro?',
                text: '¿Deseas cerrar tu sesión?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#2ECC71',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, cerrar sesión',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById(formId).submit();
                }
            });
        }

        // Función para forzar mostrar el preloader (solo para pruebas)
        function forceShowAprendizPreloader() {
            window.location.reload();
        }
        window.forceShowAprendizPreloader = forceShowAprendizPreloader;
        
        // Función para forzar ocultar el preloader (emergencia)
        function forceHideAprendizPreloader() {
            const preloader = document.getElementById('preloader-aprendiz');
            const wrapper = document.querySelector('.wrapper');
            preloader.style.display = 'none';
            wrapper.style.visibility = 'visible';
            document.body.style.overflow = 'auto';
            console.log('Preloader de aprendiz forzado a ocultar');
        }
        window.forceHideAprendizPreloader = forceHideAprendizPreloader;
        
        // Función de prueba para mostrar el preloader manualmente
        function testAprendizPreloader() {
            const preloader = document.getElementById('preloader-aprendiz');
            const wrapper = document.querySelector('.wrapper');
            
            console.log('Probando preloader de aprendiz...');
            console.log('Preloader:', preloader);
            console.log('Wrapper:', wrapper);
            
            if (preloader) {
                preloader.style.display = 'flex';
                wrapper.style.visibility = 'hidden';
                document.body.style.overflow = 'hidden';
                
                setTimeout(function() {
                    preloader.style.display = 'none';
                    wrapper.style.visibility = 'visible';
                    document.body.style.overflow = 'auto';
                    console.log('Test completado');
                }, 2000);
            } else {
                console.log('ERROR: No se encontró el elemento preloader');
            }
        }
        window.testAprendizPreloader = testAprendizPreloader;
        
        // Función para forzar mostrar el preloader
        function forceShowAprendizPreloader() {
            const preloader = document.getElementById('preloader-aprendiz');
            const wrapper = document.querySelector('.wrapper');
            
            wrapper.style.visibility = 'hidden';
            document.body.style.overflow = 'hidden';
            
            setTimeout(function() {
                preloader.style.display = 'none';
                wrapper.style.visibility = 'visible';
                document.body.style.overflow = 'auto';
            }, 2000);
        }
        window.forceShowAprendizPreloader = forceShowAprendizPreloader;

        // Sistema de Notificaciones Global
        let notifications = []; // Array to store all notifications

        async function fetchNotifications() {
            try {
                const response = await fetch('{{ route("fabricasoft.aprendiz.notifications") }}');
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();
                notifications = data; // Store the fetched notifications
                updateNotificationsDisplay();
            } catch (error) {
                console.error("Error fetching notifications:", error);
                document.getElementById('notification-count').textContent = '0';
                document.getElementById('notification-list-container').innerHTML = '<div class="no-notifications">Error al cargar notificaciones.</div>';
            }
        }

        function updateNotificationsDisplay() {
            const countElement = document.getElementById('notification-count');
            const listContainer = document.getElementById('notification-list-container');
            
            // Contar solo notificaciones no leídas
            const unreadCount = notifications.filter(n => !n.read_at).length;
            countElement.textContent = unreadCount;

            if (notifications.length > 0) {
                listContainer.innerHTML = ''; // Clear previous notifications
                notifications.forEach(notification => {
                    const notificationItem = document.createElement('div');
                    notificationItem.className = `notification-item ${notification.read_at ? 'read' : 'unread'}`;
                    
                    // Determinar el icono según el tipo
                    let icon = 'fas fa-bell';
                    let iconColor = 'text-blue-500';
                    
                    if (notification.notification_type === 'success') {
                        icon = 'fas fa-check-circle';
                        iconColor = 'text-green-500';
                    } else if (notification.notification_type === 'warning') {
                        icon = 'fas fa-exclamation-triangle';
                        iconColor = 'text-yellow-500';
                    } else if (notification.notification_type === 'error') {
                        icon = 'fas fa-times-circle';
                        iconColor = 'text-red-500';
                    }

                    notificationItem.innerHTML = `
                        <div class="flex items-start space-x-3">
                            <i class="${icon} ${iconColor} mt-1"></i>
                            <div class="flex-1">
                                <h4 class="font-semibold text-sm">${notification.title}</h4>
                                <p class="text-xs text-gray-600">${notification.message}</p>
                                <div class="flex justify-between items-center mt-2">
                                    <span class="text-xs text-gray-500">${formatDate(notification.created_at)}</span>
                                    ${notification.module ? `<span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">${notification.module}</span>` : ''}
                                </div>
                            </div>
                        </div>
                    `;
                    
                    notificationItem.addEventListener('click', () => {
                        // Marcar como leída si no está leída
                        if (!notification.read_at) {
                            markAsRead(notification.id);
                        }
                        
                        // Navegar según el tipo
                        if (notification.type === 'request') {
                            window.location.href = `{{ url('fabricasoft/solicitudes') }}?id=${notification.id}`;
                        } else if (notification.type === 'notification') {
                            // Para notificaciones globales, ir a la página de notificaciones
                            window.location.href = "{{ route('notifications.index') }}";
                        }
                    });
                    
                    listContainer.appendChild(notificationItem);
                });
            } else {
                listContainer.innerHTML = '<div class="no-notifications">No hay notificaciones.</div>';
            }
        }

        async function markAsRead(notificationId) {
            try {
                const response = await fetch(`/notifications/${notificationId}/read`, {
                    method: 'PATCH',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                        'Content-Type': 'application/json'
                    }
                });
                
                if (response.ok) {
                    // Actualizar la notificación localmente
                    const notification = notifications.find(n => n.id === notificationId);
                    if (notification) {
                        notification.read_at = new Date().toISOString();
                        updateNotificationsDisplay();
                    }
                }
            } catch (error) {
                console.error('Error marking notification as read:', error);
            }
        }

        function formatDate(dateString) {
            const date = new Date(dateString);
            const now = new Date();
            const diffInHours = (now - date) / (1000 * 60 * 60);
            
            if (diffInHours < 1) {
                return 'Hace unos minutos';
            } else if (diffInHours < 24) {
                return `Hace ${Math.floor(diffInHours)} horas`;
            } else {
                return date.toLocaleDateString('es-ES');
            }
        }

        // Toggle notification dropdown
        document.getElementById('notification-bell-btn').addEventListener('click', function() {
            const dropdown = document.getElementById('notifications-dropdown');
            dropdown.classList.toggle('show');
        });

        // Close notification dropdown on outside click
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('notifications-dropdown');
            const toggle = document.getElementById('notification-bell-btn');
            if (!toggle.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });

        // Initial fetch and periodic refresh
        document.addEventListener('DOMContentLoaded', () => {
            fetchNotifications();
            setInterval(fetchNotifications, 30000); // Refresh every 30 seconds

        });

        // Treeview Toggle
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', function(e) {
                const treeview = this.nextElementSibling;
                if (treeview && treeview.classList.contains('nav-treeview')) {
                    e.preventDefault();
                    treeview.classList.toggle('hidden');
                    const angle = this.querySelector('.fa-angle-left, .fa-angle-down');
                    if (angle) {
                        angle.classList.toggle('fa-angle-down');
                        angle.classList.toggle('fa-angle-left');
                    }
                }
            });
        });

    </script>
</body>
</html>