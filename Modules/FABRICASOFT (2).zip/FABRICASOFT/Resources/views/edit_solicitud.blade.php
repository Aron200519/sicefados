@extends('fabricasoft::layouts.masternuevasolicitud')
@section('content')
<div class="max-w-4xl mx-auto mt-10 bg-white p-8 rounded shadow">
    <h2 class="text-2xl font-bold mb-6">Editar Solicitud</h2>
    <form action="{{ route('fabricasoft.solicitudes.update', $solicitud->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <!-- Ejemplo de campos, agrega los que necesites -->
        <div class="mb-4">
            <label for="project_name" class="block font-semibold mb-1">Nombre del Proyecto</label>
            <input type="text" name="project_name" id="project_name" class="form-input w-full" value="{{ old('project_name', $solicitud->project_name) }}" required>
        </div>
        <div class="mb-4">
            <label for="company_name" class="block font-semibold mb-1">Empresa</label>
            <input type="text" name="company_name" id="company_name" class="form-input w-full" value="{{ old('company_name', $solicitud->company_name) }}" required>
        </div>
        <div class="mb-4">
            <label for="email" class="block font-semibold mb-1">Correo</label>
            <input type="email" name="email" id="email" class="form-input w-full" value="{{ old('email', $solicitud->email) }}" required>
        </div>
        <div class="mb-4">
            <label for="status" class="block font-semibold mb-1">Estado</label>
            <select name="status" id="status" class="form-select w-full">
                <option value="pendiente" {{ $solicitud->status == 'pendiente' ? 'selected' : '' }}>Pendiente</option>
                <option value="aprobada" {{ $solicitud->status == 'aprobada' ? 'selected' : '' }}>Aprobada</option>
                <option value="rechazada" {{ $solicitud->status == 'rechazada' ? 'selected' : '' }}>Rechazada</option>
            </select>
        </div>
        <!-- Agrega aquí el resto de campos necesarios -->
        <div class="flex justify-end">
            <button type="submit" class="btn btn-success">Guardar Cambios</button>
            <a href="{{ route('fabricasoft.nuevasolicitud') }}" class="btn btn-danger ml-2">Cancelar</a>
        </div>
    </form>
</div>
@endsection 