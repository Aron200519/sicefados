@extends($isAdmin ? 'fabricasoft::layouts.masteradmin' : ($isDesarrollador ? 'fabricasoft::layouts.masteraprendiz' : 'fabricasoft::layouts.masterusers'))
@section('content')
<div class="max-w-4xl mx-auto mt-10 bg-white p-8 rounded shadow">
    <!-- Botón Volver -->
    <div class="mb-6">
        @if($isAdmin)
            <a href="{{ route('fabricasoft.admin.dashboard') }}" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors duration-200">
                <i class="fas fa-arrow-left mr-2"></i>
                Volver al Inicio
            </a>
        @elseif($isDesarrollador)
            <a href="{{ route('fabricasoft.aprendiz.tareas') }}" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors duration-200">
                <i class="fas fa-arrow-left mr-2"></i>
                Volver a Tareas
            </a>
        @else
            <a href="{{ route('fabricasoft.cliente.dashboard') }}" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors duration-200">
                <i class="fas fa-arrow-left mr-2"></i>
                Volver al Inicio
            </a>
        @endif
    </div>
    
    <h2 class="text-2xl font-bold mb-6 flex items-center gap-2">
        <i class="fas fa-cog text-green-600"></i> Ajustes de Perfil
        @if($isAdmin)
            <span class="text-sm bg-red-100 text-red-800 px-2 py-1 rounded">Administrador</span>
        @elseif($isDesarrollador)
            <span class="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">Desarrollador</span>
        @else
            <span class="text-sm bg-green-100 text-green-800 px-2 py-1 rounded">Cliente</span>
        @endif
    </h2>
    
    @if(session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4 shadow-md">
            <div class="flex items-center">
                <i class="fas fa-check-circle mr-2 text-green-600"></i>
                <span>{{ session('success') }}</span>
            </div>
        </div>
    @endif
    
    @if($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 shadow-md">
            <div class="flex items-center mb-2">
                <i class="fas fa-exclamation-triangle mr-2 text-red-600"></i>
                <span class="font-semibold">Error de validación:</span>
            </div>
            <ul class="list-disc pl-5">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    
    @if(session('error'))
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 shadow-md">
            <div class="flex items-center">
                <i class="fas fa-times-circle mr-2 text-red-600"></i>
                <span>{{ session('error') }}</span>
            </div>
        </div>
    @endif
    
    <form action="{{ $isAdmin ? route('fabricasoft.admin.ajustes.update') : ($isDesarrollador ? route('fabricasoft.aprendiz.ajustes.update') : route('fabricasoft.ajustes.update')) }}" method="POST">
        @csrf
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="mb-4">
                <label class="block font-semibold mb-2 text-gray-700">Usuario</label>
                <input type="text" name="nickname" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200" value="{{ old('nickname', $user->nickname) }}">
            </div>
            
            <div class="mb-4">
                <label class="block font-semibold mb-2 text-gray-700">Correo electrónico</label>
                <input type="email" name="email" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200" value="{{ old('email', $user->email) }}" required>
            </div>
            
            <div class="mb-4">
                <label class="block font-semibold mb-2 text-gray-700">Nombre completo</label>
                <input type="text" name="applicant_name" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200" value="{{ old('applicant_name', $solicitud->applicant_name ?? '') }}">
            </div>
            
            <div class="mb-4">
                <label class="block font-semibold mb-2 text-gray-700">Tipo de documento</label>
                <select name="document_type" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200">
                    <option value="">Seleccione tipo de documento</option>
                    <option value="CC" {{ old('document_type', $solicitud->document_type ?? '') == 'CC' ? 'selected' : '' }}>Cédula de Ciudadanía (CC)</option>
                    <option value="CE" {{ old('document_type', $solicitud->document_type ?? '') == 'CE' ? 'selected' : '' }}>Cédula de Extranjería (CE)</option>
                    <option value="TI" {{ old('document_type', $solicitud->document_type ?? '') == 'TI' ? 'selected' : '' }}>Tarjeta de Identidad (TI)</option>
                    <option value="PP" {{ old('document_type', $solicitud->document_type ?? '') == 'PP' ? 'selected' : '' }}>Pasaporte (PP)</option>
                    <option value="NIT" {{ old('document_type', $solicitud->document_type ?? '') == 'NIT' ? 'selected' : '' }}>NIT</option>
                </select>
            </div>
            
            <div class="mb-4">
                <label class="block font-semibold mb-2 text-gray-700">Número de documento</label>
                <input type="number" name="document_number" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200" value="{{ old('document_number', $solicitud->document_number ?? '') }}" placeholder="Ej: 12345678" min="100000" max="9999999999999">
                <small class="text-gray-600 text-sm mt-1 block">
                    <i class="fas fa-info-circle mr-1"></i>
                    Solo números, entre 6 y 15 dígitos. Debe ser único en el sistema.
                </small>
            </div>
            
            @if($isCliente)
                <div class="mb-4">
                    <label class="block font-semibold mb-2 text-gray-700">Empresa</label>
                    <input type="text" name="company_name" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200" value="{{ old('company_name', $solicitud->company_name ?? '') }}">
                </div>
                
                <div class="mb-4">
                    <label class="block font-semibold mb-2 text-gray-700">Teléfono</label>
                    <input type="tel" name="phone" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200" value="{{ old('phone', $solicitud->phone ?? '') }}">
                </div>
                
                <div class="mb-4">
                    <label class="block font-semibold mb-2 text-gray-700">Cargo</label>
                    <input type="text" name="applicant_role" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200" value="{{ old('applicant_role', $solicitud->applicant_role ?? '') }}">
                </div>
                
                <div class="mb-4">
                    <label class="block font-semibold mb-2 text-gray-700">País</label>
                    <input type="text" name="country" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200" value="{{ old('country', $solicitud->country ?? '') }}">
                </div>
                
                <div class="mb-4">
                    <label class="block font-semibold mb-2 text-gray-700">Departamento (Empresa)</label>
                    <input type="text" name="department" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200" value="{{ old('department', $solicitud->department ?? '') }}">
                </div>
                
                <div class="mb-4">
                    <label class="block font-semibold mb-2 text-gray-700">Departamento (Ubicación)</label>
                    <input type="text" name="department_location" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200" value="{{ old('department_location', $solicitud->department_location ?? '') }}">
                </div>
                
                <div class="mb-4">
                    <label class="block font-semibold mb-2 text-gray-700">Municipio</label>
                    <input type="text" name="municipality" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200" value="{{ old('municipality', $solicitud->municipality ?? '') }}">
                </div>
            @endif
        </div>
        
        <div class="mt-8 flex justify-end">
            <button type="submit" class="bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-8 rounded-lg transition-colors duration-200 flex items-center">
                <i class="fas fa-save mr-2"></i>
                Guardar Cambios
            </button>
        </div>
    </form>
</div>

@section('scripts')
<script>
    // Mostrar notificación de éxito con SweetAlert2 si existe
    @if(session('success'))
        Swal.fire({
            icon: 'success',
            title: '¡Datos Actualizados!',
            text: '{{ session('success') }}',
            showConfirmButton: false,
            timer: 3000,
            toast: true,
            position: 'top-end'
        });
    @endif
    
    // Agregar confirmación al enviar el formulario
    document.querySelector('form').addEventListener('submit', function(e) {
        const submitBtn = document.querySelector('button[type="submit"]');
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Guardando...';
        submitBtn.disabled = true;
    });
</script>
@endsection

@endsection 