@extends('fabricasoft::layouts.masterusers')
@section('content')
<script>
    // Redirigir al nuevo dashboard del cliente
    window.location.href = "{{ route('fabricasoft.cliente.dashboard') }}";
</script>
<div class="container mx-auto px-4 py-8">
    <!-- Header -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-2">Redirigiendo...</h1>
        <p class="text-gray-600">Redirigiendo al nuevo panel de cliente</p>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                    <i class="fas fa-file-alt text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Total Solicitudes</p>
                    <p class="text-2xl font-semibold text-gray-800">{{ $userRequests->count() }}</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-yellow-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-yellow-100 text-yellow-600">
                    <i class="fas fa-clock text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Pendientes</p>
                    <p class="text-2xl font-semibold text-gray-800">{{ $userRequests->where('status', 'pendiente')->count() }}</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-green-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-green-100 text-green-600">
                    <i class="fas fa-check-circle text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Aprobadas</p>
                    <p class="text-2xl font-semibold text-gray-800">{{ $userRequests->where('status', 'aprobada')->count() }}</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Action Buttons -->
    <div class="mb-8">
        <div class="flex flex-col sm:flex-row gap-4">
            <a href="{{ route('fabricasoft.nuevasolicitud') }}" class="inline-flex items-center px-6 py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition duration-200">
                <i class="fas fa-plus mr-2"></i>
                Nueva Solicitud
            </a>
            <a href="#my-requests" class="inline-flex items-center px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition duration-200">
                <i class="fas fa-list mr-2"></i>
                Ver Mis Solicitudes
            </a>
        </div>
    </div>

    <!-- My Requests Section -->
    <div id="my-requests" class="bg-white rounded-lg shadow-md">
        <div class="p-6 border-b border-gray-200">
            <h2 class="text-xl font-semibold text-gray-800">Mis Solicitudes</h2>
        </div>
        
        <div class="p-6">
            @if($userRequests->count() > 0)
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Proyecto</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Empresa</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            @foreach($userRequests as $request)
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900">{{ $request->project_name }}</div>
                                        <div class="text-sm text-gray-500">{{ $request->applicant_name }}</div>
                <div class="text-sm text-gray-500">Tipo de Documento: {{ $request->document_type ?? 'No especificado' }}</div>
                <div class="text-sm text-gray-500">Número de Documento: {{ $request->document_number ?? 'No especificado' }}</div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        {{ $request->company_name }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        @if($request->status == 'pendiente')
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                                <i class="fas fa-clock mr-1"></i>
                                                Pendiente
                                            </span>
                                        @elseif($request->status == 'aprobada')
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                <i class="fas fa-check mr-1"></i>
                                                Aprobada
                                            </span>
                                        @elseif($request->status == 'rechazada')
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                                <i class="fas fa-times mr-1"></i>
                                                Rechazada
                                            </span>
                                        @else
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                                {{ ucfirst($request->status) }}
                                            </span>
                                        @endif
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {{ \Carbon\Carbon::parse($request->created_at)->format('d/m/Y H:i') }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <div class="flex space-x-2">
                                            @if($request->formulario_id)
                                                <button onclick="abrirModalEditarFormulario({{ $request->id }})" class="text-green-600 hover:text-green-900" title="Editar formulario llenado">
                                                    <i class="fas fa-pen"></i>
                                                </button>
                                                <button onclick="confirmarEliminarFormulario({{ $request->id }})" class="text-red-500 hover:text-red-700" title="Eliminar formulario llenado">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            @else
                                                <a href="{{ route('fabricasoft.solicitudes.edit', $request->id) }}" class="text-blue-600 hover:text-blue-900">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form action="{{ route('fabricasoft.solicitudes.destroy', $request->id) }}" method="POST" class="inline" onsubmit="return confirm('¿Estás seguro de eliminar esta solicitud?')">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="text-red-600 hover:text-red-900">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            @endif
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @else
                <div class="text-center py-12">
                    <div class="text-gray-400 mb-4">
                        <i class="fas fa-file-alt text-6xl"></i>
                    </div>
                    <h3 class="text-lg font-medium text-gray-900 mb-2">No tienes solicitudes aún</h3>
                    <p class="text-gray-500 mb-6">Comienza creando tu primera solicitud de desarrollo de software</p>
                    <a href="{{ route('fabricasoft.nuevasolicitud') }}" class="inline-flex items-center px-4 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition duration-200">
                        <i class="fas fa-plus mr-2"></i>
                        Crear Primera Solicitud
                    </a>
                </div>
            @endif
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="mt-8 bg-white rounded-lg shadow-md">
        <div class="p-6 border-b border-gray-200">
            <h2 class="text-xl font-semibold text-gray-800">Actividad Reciente</h2>
        </div>
        <div class="p-6">
            @if($userRequests->count() > 0)
                <div class="space-y-4">
                    @foreach($userRequests->take(5) as $request)
                        <div class="flex items-center space-x-4">
                            <div class="flex-shrink-0">
                                @if($request->status == 'aprobada')
                                    <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                                        <i class="fas fa-check text-green-600"></i>
                                    </div>
                                @elseif($request->status == 'pendiente')
                                    <div class="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                                        <i class="fas fa-clock text-yellow-600"></i>
                                    </div>
                                @else
                                    <div class="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                                        <i class="fas fa-file text-gray-600"></i>
                                    </div>
                                @endif
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="text-sm font-medium text-gray-900 truncate">
                                    {{ $request->project_name }}
                                </p>
                                <p class="text-sm text-gray-500">
                                    {{ \Carbon\Carbon::parse($request->created_at)->diffForHumans() }}
                                </p>
                            </div>
                            <div class="flex-shrink-0">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                                    @if($request->status == 'aprobada') bg-green-100 text-green-800
                                    @elseif($request->status == 'pendiente') bg-yellow-100 text-yellow-800
                                    @else bg-gray-100 text-gray-800 @endif">
                                    {{ ucfirst($request->status) }}
                                </span>
                            </div>
                        </div>
                    @endforeach
                </div>
            @else
                <div class="text-center py-8 text-gray-500">
                    <i class="fas fa-info-circle text-2xl mb-2"></i>
                    <p>No hay actividad reciente</p>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function abrirModalEditarFormulario(servicioId) {
    fetch(`/fabricasoft/usuario/formulario/${servicioId}/editar`, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(res => res.text())
    .then(html => {
        document.getElementById('modal-editar-formulario-content').innerHTML = html;
        document.getElementById('modal-editar-formulario').classList.remove('hidden');
        
        // Ocultar sidebar si existe
        const sidebar = document.querySelector('.sidebar') || 
                       document.querySelector('.nav-sidebar') || 
                       document.querySelector('[class*="sidebar"]') ||
                       document.querySelector('[class*="nav"]');
        if (sidebar) {
            sidebar.style.display = 'none';
        }
        
        // Prevenir scroll del body
        document.body.style.overflow = 'hidden';
        
        // Enfocar primer campo
        setTimeout(() => {
            const primerCampo = document.querySelector('#modal-editar-formulario input, #modal-editar-formulario select, #modal-editar-formulario textarea');
            if (primerCampo) {
                primerCampo.focus();
            }
        }, 100);
    });
}

function cerrarModalEditarFormulario() {
    document.getElementById('modal-editar-formulario').classList.add('hidden');
    document.body.style.overflow = 'auto';
    
    // Mostrar sidebar si existe
    const sidebar = document.querySelector('.sidebar') || 
                   document.querySelector('.nav-sidebar') || 
                   document.querySelector('[class*="sidebar"]') ||
                   document.querySelector('[class*="nav"]');
    if (sidebar) {
        sidebar.style.display = 'block';
    }
}
function enviarFormularioEditar(e, servicioId) {
    e.preventDefault();
    const form = document.getElementById('form-editar-formulario-ajax');
    const formData = new FormData(form);
    fetch(`/fabricasoft/usuario/formulario/${servicioId}/actualizar`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        },
        body: formData
    })
    .then(res => res.ok ? res.text() : Promise.reject(res))
    .then(() => {
        location.reload();
    });
}
function confirmarEliminarFormulario(servicioId) {
    Swal.fire({
        title: '¿Estás seguro?',
        text: 'Esta acción eliminará el formulario llenado y no se puede deshacer.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#e53e3e',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch(`/fabricasoft/usuario/formulario/${servicioId}/eliminar`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                }
            }).then(() => {
                location.reload();
            });
        }
    });
}
</script>
@endpush

<!-- Modal flotante para editar formulario llenado -->
<div id="modal-editar-formulario" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999] hidden p-4">
    <div class="bg-white rounded-lg p-6 w-full max-w-3xl lg:max-w-5xl max-h-[85vh] overflow-y-auto shadow-2xl relative">
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl lg:text-2xl font-semibold text-gray-900">Editar Formulario</h3>
            <button onclick="cerrarModalEditarFormulario()" class="text-gray-400 hover:text-gray-600 transition-colors p-2">
                <i class="fas fa-times text-2xl"></i>
            </button>
        </div>
        <div id="modal-editar-formulario-content"></div>
    </div>
</div>
