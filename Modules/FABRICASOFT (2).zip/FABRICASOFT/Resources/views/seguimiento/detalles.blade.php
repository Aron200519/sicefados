@extends('fabricasoft::layouts.app')

@section('title', 'Detalles del Seguimiento')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-eye"></i> Detalles del Seguimiento
                    </h3>
                    <div class="card-tools">
                        <a href="javascript:history.back()" class="btn btn-secondary btn-sm">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Información del formulario -->
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Información del Formulario</h5>
                            <table class="table table-borderless">
                                <tr>
                                    <td><strong>Formulario:</strong></td>
                                    <td>{{ $seguimiento->formulario->nombre ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Usuario:</strong></td>
                                    <td>{{ $seguimiento->user->name ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Email:</strong></td>
                                    <td>{{ $seguimiento->user->email ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Desarrollador:</strong></td>
                                    <td>
                                        @if($seguimiento->assignedUser)
                                            <span class="badge badge-info">{{ $seguimiento->assignedUser->name }}</span>
                                        @else
                                            <span class="text-muted">Sin asignar</span>
                                        @endif
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h5>Estado y Prioridad</h5>
                            <table class="table table-borderless">
                                <tr>
                                    <td><strong>Estado:</strong></td>
                                    <td>
                                        <span class="badge {{ $seguimiento->estado_class }}">
                                            {{ $seguimiento->estado_legible }}
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td><strong>Prioridad:</strong></td>
                                    <td>
                                        <span class="badge {{ $seguimiento->prioridad_class }}">
                                            {{ $seguimiento->prioridad_legible }}
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td><strong>Fecha Envío:</strong></td>
                                    <td>{{ $seguimiento->fecha_envio->format('d/m/Y H:i:s') }}</td>
                                </tr>
                                @if($seguimiento->fecha_revision)
                                <tr>
                                    <td><strong>Fecha Revisión:</strong></td>
                                    <td>{{ $seguimiento->fecha_revision->format('d/m/Y H:i:s') }}</td>
                                </tr>
                                @endif
                                @if($seguimiento->fecha_desarrollo)
                                <tr>
                                    <td><strong>Fecha Desarrollo:</strong></td>
                                    <td>{{ $seguimiento->fecha_desarrollo->format('d/m/Y H:i:s') }}</td>
                                </tr>
                                @endif
                                @if($seguimiento->fecha_completado)
                                <tr>
                                    <td><strong>Fecha Completado:</strong></td>
                                    <td>{{ $seguimiento->fecha_completado->format('d/m/Y H:i:s') }}</td>
                                </tr>
                                @endif
                            </table>
                        </div>
                    </div>

                    <!-- Comentarios -->
                    @if($seguimiento->comentarios || $seguimiento->respuesta_admin || $seguimiento->respuesta_desarrollador)
                    <div class="row mt-4">
                        <div class="col-12">
                            <h5>Comentarios y Respuestas</h5>
                            
                            @if($seguimiento->comentarios)
                            <div class="alert alert-info">
                                <h6><i class="fas fa-comment"></i> Comentarios del Usuario</h6>
                                <p>{{ $seguimiento->comentarios }}</p>
                            </div>
                            @endif

                            @if($seguimiento->respuesta_admin)
                            <div class="alert alert-warning">
                                <h6><i class="fas fa-user-shield"></i> Respuesta del Administrador</h6>
                                <p>{{ $seguimiento->respuesta_admin }}</p>
                            </div>
                            @endif

                            @if($seguimiento->respuesta_desarrollador)
                            <div class="alert alert-primary">
                                <h6><i class="fas fa-code"></i> Respuesta del Desarrollador</h6>
                                <p>{{ $seguimiento->respuesta_desarrollador }}</p>
                            </div>
                            @endif
                        </div>
                    </div>
                    @endif

                    <!-- Respuestas del formulario -->
                    @if($respuestas->count() > 0)
                    <div class="row mt-4">
                        <div class="col-12">
                            <h5>Respuestas del Formulario</h5>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Pregunta</th>
                                            <th>Respuesta</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($respuestas as $respuesta)
                                        <tr>
                                            <td><strong>{{ $respuesta->pregunta_id }}</strong></td>
                                            <td>{{ $respuesta->respuesta }}</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    @endif

                    <!-- Timeline del seguimiento -->
                    <div class="row mt-4">
                        <div class="col-12">
                            <h5>Timeline del Seguimiento</h5>
                            <div class="timeline">
                                <div class="time-label">
                                    <span class="bg-green">{{ $seguimiento->fecha_envio->format('d/m/Y') }}</span>
                                </div>
                                <div>
                                    <i class="fas fa-envelope bg-blue"></i>
                                    <div class="timeline-item">
                                        <span class="time"><i class="fas fa-clock"></i> {{ $seguimiento->fecha_envio->format('H:i') }}</span>
                                        <h3 class="timeline-header">Formulario Enviado</h3>
                                        <div class="timeline-body">
                                            El usuario {{ $seguimiento->user->name }} envió el formulario "{{ $seguimiento->formulario->nombre }}"
                                        </div>
                                    </div>
                                </div>

                                @if($seguimiento->fecha_revision)
                                <div>
                                    <i class="fas fa-search bg-yellow"></i>
                                    <div class="timeline-item">
                                        <span class="time"><i class="fas fa-clock"></i> {{ $seguimiento->fecha_revision->format('H:i') }}</span>
                                        <h3 class="timeline-header">En Revisión</h3>
                                        <div class="timeline-body">
                                            El formulario fue puesto en revisión
                                        </div>
                                    </div>
                                </div>
                                @endif

                                @if($seguimiento->fecha_desarrollo)
                                <div>
                                    <i class="fas fa-code bg-purple"></i>
                                    <div class="timeline-item">
                                        <span class="time"><i class="fas fa-clock"></i> {{ $seguimiento->fecha_desarrollo->format('H:i') }}</span>
                                        <h3 class="timeline-header">En Desarrollo</h3>
                                        <div class="timeline-body">
                                            El formulario comenzó a ser desarrollado
                                        </div>
                                    </div>
                                </div>
                                @endif

                                @if($seguimiento->fecha_completado)
                                <div>
                                    <i class="fas fa-check bg-green"></i>
                                    <div class="timeline-item">
                                        <span class="time"><i class="fas fa-clock"></i> {{ $seguimiento->fecha_completado->format('H:i') }}</span>
                                        <h3 class="timeline-header">Completado</h3>
                                        <div class="timeline-body">
                                            El formulario fue completado exitosamente
                                        </div>
                                    </div>
                                </div>
                                @endif

                                <div>
                                    <i class="fas fa-clock bg-gray"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.timeline {
    position: relative;
    margin: 0 0 30px 0;
    padding: 0;
    list-style: none;
}

.timeline:before {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    width: 4px;
    background: #ddd;
    left: 31px;
    margin: 0;
    border-radius: 2px;
}

.timeline > div {
    position: relative;
    margin-right: 10px;
    margin-bottom: 15px;
}

.timeline > div > .timeline-item {
    box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
    border-radius: 0.25rem;
    background-color: #fff;
    color: #495057;
    margin-left: 60px;
    margin-top: 0;
    margin-bottom: 0;
    margin-right: 0;
    position: relative;
}

.timeline > div > .timeline-item > .time {
    color: #999;
    float: right;
    padding: 10px;
    font-size: 12px;
}

.timeline > div > .timeline-item > .timeline-header {
    color: #495057;
    font-size: 16px;
    line-height: 1.1;
    margin: 0;
    padding: 10px;
    border-bottom: 0 solid rgba(0,0,0,.125);
    background-color: rgba(0,0,0,.03);
    color: #495057;
}

.timeline > div > .timeline-item > .timeline-body,
.timeline > div > .timeline-item > .timeline-footer {
    padding: 10px;
}

.timeline > div > i,
.timeline > div > .fa,
.timeline > div > .fas,
.timeline > div > .far,
.timeline > div > .fab {
    width: 30px;
    height: 30px;
    font-size: 15px;
    line-height: 30px;
    position: absolute;
    color: #666;
    background: #dadada;
    border-radius: 50%;
    text-align: center;
    left: 18px;
    top: 0;
}

.timeline > .time-label > span {
    font-weight: 600;
    padding: 5px 10px;
    display: inline-block;
    background-color: #fff;
    color: #666;
    border-radius: 4px;
    border: 1px solid #ddd;
}
</style>
@endsection

