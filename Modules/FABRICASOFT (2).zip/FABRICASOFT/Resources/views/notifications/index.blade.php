@extends('fabricasoft::layouts.masteradmin')

@section('title', 'Notificaciones - FABRICASOFT')

@section('content')
<div class="min-h-screen bg-gray-50 py-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Header -->
        <div class="mb-8">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">Notificaciones</h1>
                    <p class="mt-2 text-gray-600">Mantente al día con las últimas actualizaciones del sistema</p>
                </div>
                <div class="flex items-center space-x-3">
                    <button onclick="markAllAsRead()" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                        <i class="fas fa-check-double mr-2"></i>
                        Marcar todas como leídas
                    </button>
                    <button onclick="refreshNotifications()" class="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                        <i class="fas fa-sync-alt mr-2"></i>
                        Actualizar
                    </button>
                </div>
            </div>
        </div>

        <!-- Filtros -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
            <div class="flex flex-wrap items-center gap-4">
                <div class="flex items-center space-x-4">
                    <label class="text-sm font-medium text-gray-700">Filtrar por:</label>
                    <select id="filter-type" class="border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500">
                        <option value="">Todas</option>
                        <option value="request">Solicitudes</option>
                        <option value="notification">Notificaciones</option>
                        <option value="system">Sistema</option>
                    </select>
                </div>
                <div class="flex items-center space-x-4">
                    <label class="text-sm font-medium text-gray-700">Estado:</label>
                    <select id="filter-status" class="border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500">
                        <option value="">Todos</option>
                        <option value="unread">No leídas</option>
                        <option value="read">Leídas</option>
                    </select>
                </div>
                <div class="flex items-center space-x-4">
                    <label class="text-sm font-medium text-gray-700">Ordenar por:</label>
                    <select id="filter-sort" class="border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500">
                        <option value="newest">Más recientes</option>
                        <option value="oldest">Más antiguas</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Lista de Notificaciones -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-medium text-gray-900">
                    Notificaciones 
                    <span id="notifications-count" class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        {{ $notifications->count() }}
                    </span>
                </h3>
            </div>
            
            <div id="notifications-list" class="divide-y divide-gray-200">
                @forelse($notifications as $notification)
                <div class="notification-item p-6 hover:bg-gray-50 transition-colors duration-200 {{ $notification['read_at'] ? 'opacity-75' : '' }}" data-id="{{ $notification['id'] }}" data-type="{{ $notification['type'] }}" data-read="{{ $notification['read_at'] ? 'true' : 'false' }}">
                    <div class="flex items-start space-x-4">
                        <!-- Icono de notificación -->
                        <div class="flex-shrink-0">
                            @if($notification['type'] === 'request')
                                <div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                                    <i class="fas fa-file-alt text-blue-600"></i>
                                </div>
                            @elseif($notification['type'] === 'notification')
                                <div class="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                                    <i class="fas fa-bell text-green-600"></i>
                                </div>
                            @else
                                <div class="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
                                    <i class="fas fa-info-circle text-gray-600"></i>
                                </div>
                            @endif
                        </div>
                        
                        <!-- Contenido de la notificación -->
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between">
                                <h4 class="text-sm font-medium text-gray-900 {{ $notification['read_at'] ? '' : 'font-semibold' }}">
                                    {{ $notification['title'] }}
                                </h4>
                                <div class="flex items-center space-x-2">
                                    @if(!$notification['read_at'])
                                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                            Nueva
                                        </span>
                                    @endif
                                    <span class="text-xs text-gray-500">
                                        {{ \Carbon\Carbon::parse($notification['created_at'])->diffForHumans() }}
                                    </span>
                                </div>
                            </div>
                            <p class="mt-1 text-sm text-gray-600">
                                {{ $notification['message'] }}
                            </p>
                        </div>
                        
                        <!-- Acciones -->
                        <div class="flex-shrink-0 flex items-center space-x-2">
                            @if(!$notification['read_at'])
                                <button onclick="markAsRead({{ $notification['id'] }})" class="text-green-600 hover:text-green-800 text-sm font-medium">
                                    Marcar como leída
                                </button>
                            @endif
                            <button onclick="deleteNotification({{ $notification['id'] }})" class="text-red-600 hover:text-red-800 text-sm font-medium">
                                Eliminar
                            </button>
                        </div>
                    </div>
                </div>
                @empty
                <div class="p-12 text-center">
                    <div class="w-16 h-16 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center">
                        <i class="fas fa-bell text-gray-400 text-xl"></i>
                    </div>
                    <h3 class="text-lg font-medium text-gray-900 mb-2">No hay notificaciones</h3>
                    <p class="text-gray-500">Cuando recibas notificaciones, aparecerán aquí.</p>
                </div>
                @endforelse
            </div>
        </div>

        <!-- Paginación -->
        @if($notifications->hasPages())
        <div class="mt-6 flex items-center justify-between">
            <div class="flex-1 flex justify-between sm:hidden">
                @if($notifications->onFirstPage())
                    <span class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-400 bg-white cursor-default">
                        Anterior
                    </span>
                @else
                    <a href="{{ $notifications->previousPageUrl() }}" class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                        Anterior
                    </a>
                @endif
                
                @if($notifications->hasMorePages())
                    <a href="{{ $notifications->nextPageUrl() }}" class="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                        Siguiente
                    </a>
                @else
                    <span class="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-400 bg-white cursor-default">
                        Siguiente
                    </span>
                @endif
            </div>
            
            <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                <div>
                    <p class="text-sm text-gray-700">
                        Mostrando 
                        <span class="font-medium">{{ $notifications->firstItem() }}</span>
                        a 
                        <span class="font-medium">{{ $notifications->lastItem() }}</span>
                        de 
                        <span class="font-medium">{{ $notifications->total() }}</span>
                        resultados
                    </p>
                </div>
                <div>
                    <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                        {{ $notifications->links() }}
                    </nav>
                </div>
            </div>
        </div>
        @endif
    </div>
</div>

<!-- Scripts -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Aplicar filtros
    document.getElementById('filter-type').addEventListener('change', applyFilters);
    document.getElementById('filter-status').addEventListener('change', applyFilters);
    document.getElementById('filter-sort').addEventListener('change', applyFilters);
});

function applyFilters() {
    const typeFilter = document.getElementById('filter-type').value;
    const statusFilter = document.getElementById('filter-status').value;
    const sortFilter = document.getElementById('filter-sort').value;
    
    const notifications = document.querySelectorAll('.notification-item');
    
    notifications.forEach(notification => {
        const type = notification.dataset.type;
        const read = notification.dataset.read;
        
        let show = true;
        
        // Filtro por tipo
        if (typeFilter && type !== typeFilter) {
            show = false;
        }
        
        // Filtro por estado
        if (statusFilter === 'read' && read === 'false') {
            show = false;
        } else if (statusFilter === 'unread' && read === 'true') {
            show = false;
        }
        
        notification.style.display = show ? 'block' : 'none';
    });
    
    // Actualizar contador
    updateNotificationsCount();
}

function updateNotificationsCount() {
    const visibleNotifications = document.querySelectorAll('.notification-item[style="display: block"], .notification-item:not([style])');
    const countElement = document.getElementById('notifications-count');
    if (countElement) {
        countElement.textContent = visibleNotifications.length;
    }
}

function markAsRead(notificationId) {
    fetch(`/fabricasoft/notifications/${notificationId}/read`, {
        method: 'GET',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const notification = document.querySelector(`[data-id="${notificationId}"]`);
            if (notification) {
                notification.dataset.read = 'true';
                notification.classList.add('opacity-75');
                
                // Remover el botón "Marcar como leída"
                const markAsReadBtn = notification.querySelector('button[onclick*="markAsRead"]');
                if (markAsReadBtn) {
                    markAsReadBtn.remove();
                }
                
                // Remover la etiqueta "Nueva"
                const newLabel = notification.querySelector('.bg-red-100');
                if (newLabel) {
                    newLabel.remove();
                }
            }
            
            // Mostrar mensaje de éxito
            Swal.fire({
                title: 'Éxito',
                text: 'Notificación marcada como leída',
                icon: 'success',
                confirmButtonColor: '#2ECC71'
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Swal.fire({
            title: 'Error',
            text: 'No se pudo marcar la notificación como leída',
            icon: 'error',
            confirmButtonColor: '#e53e3e'
        });
    });
}

function markAllAsRead() {
    Swal.fire({
        title: '¿Estás seguro?',
        text: '¿Deseas marcar todas las notificaciones como leídas?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#2ECC71',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Sí, marcar todas',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            // Marcar todas como leídas
            const unreadNotifications = document.querySelectorAll('.notification-item[data-read="false"]');
            unreadNotifications.forEach(notification => {
                const notificationId = notification.dataset.id;
                markAsRead(notificationId);
            });
            
            Swal.fire({
                title: 'Completado',
                text: 'Todas las notificaciones han sido marcadas como leídas',
                icon: 'success',
                confirmButtonColor: '#2ECC71'
            });
        }
    });
}

function deleteNotification(notificationId) {
    Swal.fire({
        title: '¿Estás seguro?',
        text: '¿Deseas eliminar esta notificación? Esta acción no se puede deshacer.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#e53e3e',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            const notification = document.querySelector(`[data-id="${notificationId}"]`);
            if (notification) {
                notification.remove();
                updateNotificationsCount();
                
                Swal.fire({
                    title: 'Eliminada',
                    text: 'La notificación ha sido eliminada',
                    icon: 'success',
                    confirmButtonColor: '#2ECC71'
                });
            }
        }
    });
}

function refreshNotifications() {
    // Recargar la página para obtener notificaciones actualizadas
    window.location.reload();
}
</script>
@endsection
