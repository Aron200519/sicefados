@extends('fabricasoft::layouts.masterusers')

@section('content')
<!-- Contenido específico de soporte irá aquí -->
@endsection