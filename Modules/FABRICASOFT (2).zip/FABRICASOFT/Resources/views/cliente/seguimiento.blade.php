@extends('fabricasoft::layouts.masternuevasolicitud')

@section('content')
<div class="p-6">
    <!-- Header -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-2">Seguimiento de Mis Solicitudes</h1>
        <p class="text-gray-600">Monitoree el estado de sus solicitudes y comuníquese con el equipo de desarrollo</p>
    </div>

    @if($userRequests->count() > 0)
        <!-- Lista de solicitudes -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="px-8 py-6 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-indigo-50">
                <h2 class="text-xl font-semibold text-gray-800">Mis Solicitudes</h2>
                <p class="text-gray-600 text-sm mt-1">Mostrando {{ $userRequests->count() }} solicitudes</p>
            </div>
            
            <div class="divide-y divide-gray-100">
                @foreach($userRequests as $index => $request)
                    @php
                        $progreso = $progresos[$request->id] ?? 0;
                        $formularioNombre = $formularios[$request->formulario_id] ?? 'Formulario no especificado';
                    @endphp
                    
                    <div class="p-6 hover:bg-gray-50 transition-colors duration-200">
                        <div class="flex items-center justify-between">
                            <!-- Información principal -->
                            <div class="flex-1">
                                <div class="flex items-center space-x-4">
                                    <!-- Estado con color -->
                                    <div class="flex-shrink-0">
                                        @if($request->estado == 'aprobado' || $request->estado == 'en_desarrollo')
                                            <div class="w-3 h-3 bg-green-500 rounded-full"></div>
                                        @elseif($request->estado == 'rechazado')
                                            <div class="w-3 h-3 bg-red-500 rounded-full"></div>
                                        @else
                                            <div class="w-3 h-3 bg-yellow-500 rounded-full"></div>
                                        @endif
                                    </div>
                                    
                                    <!-- Información del proyecto -->
                                    <div class="flex-1">
                                        <div class="flex items-center space-x-3 mb-2">
                                            <h3 class="text-lg font-semibold text-gray-800">{{ $request->nombre_proyecto }}</h3>
                                            <span class="px-3 py-1 text-xs font-medium rounded-full 
                                                @if($request->estado == 'aprobado' || $request->estado == 'en_desarrollo') bg-green-100 text-green-800
                                                @elseif($request->estado == 'rechazado') bg-red-100 text-red-800
                                                @else bg-yellow-100 text-yellow-800 @endif">
                                                {{ ucfirst(str_replace('_', ' ', $request->estado)) }}
                                            </span>
                                        </div>
                                        
                                        <div class="flex items-center space-x-6 text-sm text-gray-600">
                                            <span><i class="fas fa-file-alt mr-2"></i>{{ $formularioNombre }}</span>
                                            <span><i class="fas fa-calendar mr-2"></i>{{ $request->created_at->format('d/m/Y') }}</span>
                                            @if($request->assignedUser)
                                                <span><i class="fas fa-user mr-2"></i>{{ $request->assignedUser->name }}</span>
                                            @endif
                                        </div>
                                        
                                        <p class="text-gray-700 mt-2 line-clamp-2">{{ Str::limit($request->descripcion, 150) }}</p>
                                    </div>
                                </div>
                                
                                <!-- Barra de progreso solo para aprobados/en desarrollo -->
                                @if($request->estado == 'aprobado' || $request->estado == 'en_desarrollo')
                                    <div class="mt-4">
                                        <div class="flex items-center justify-between text-sm text-gray-600 mb-1">
                                            <span>Progreso del proyecto</span>
                                            <span>{{ number_format($progreso, 1) }}%</span>
                                        </div>
                                        <div class="w-full bg-gray-200 rounded-full h-2">
                                            <div class="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-300" 
                                                 style="width: {{ $progreso }}%"></div>
                                        </div>
                                    </div>
                                @endif
                            </div>
                            
                            <!-- Acciones -->
                            <div class="flex items-center space-x-3 ml-6">
                                <!-- Ver detalles -->
                                <button onclick="verDetalles({{ $request->id }})" 
                                        class="p-3 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors duration-200"
                                        title="Ver detalles">
                                    <i class="fas fa-eye text-lg"></i>
                                </button>
                                
                                <!-- Contactar desarrollador solo si está asignado -->
                                @if($request->assignedUser && ($request->estado == 'aprobado' || $request->estado == 'en_desarrollo'))
                                    <button onclick="contactarDesarrollador('{{ $request->assignedUser->name }}', '{{ $request->assignedUser->phone ?? '' }}')" 
                                            class="p-3 text-green-600 hover:bg-green-50 rounded-lg transition-colors duration-200"
                                            title="Contactar desarrollador">
                                        <i class="fab fa-whatsapp text-lg"></i>
                                    </button>
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    @else
        <!-- Estado vacío -->
        <div class="bg-white rounded-xl shadow-lg p-12 text-center">
            <div class="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i class="fas fa-file-alt text-3xl text-gray-400"></i>
            </div>
            <h3 class="text-xl font-semibold text-gray-800 mb-2">No tienes solicitudes</h3>
            <p class="text-gray-600 mb-6">Aún no has enviado ninguna solicitud de desarrollo de software.</p>
            <a href="{{ route('fabricasoft.cliente.dashboard') }}" 
               class="inline-flex items-center px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors duration-200">
                <i class="fas fa-plus mr-2"></i>
                Crear nueva solicitud
            </a>
        </div>
    @endif
</div>

<!-- Modal de detalles -->
<div id="detallesModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
    <div class="flex items-center justify-center min-h-screen p-4">
        <div class="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div class="sticky top-0 bg-white border-b border-gray-200 px-8 py-6">
                <div class="flex items-center justify-between">
                    <h2 class="text-2xl font-bold text-gray-800">Detalles de la Solicitud</h2>
                    <button onclick="cerrarModal()" class="text-gray-400 hover:text-gray-600 transition-colors duration-200">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
            </div>
            
            <div class="p-8" id="detallesContenido">
                <!-- El contenido se cargará dinámicamente -->
            </div>
        </div>
    </div>
</div>

<!-- Centro de Comunicación -->
<div id="comunicacionModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
    <div class="flex items-center justify-center min-h-screen p-4">
        <div class="bg-white rounded-xl shadow-2xl max-w-md w-full">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800">Centro de Comunicación</h3>
            </div>
            
            <div class="p-6">
                <div class="space-y-4">
                    <!-- WhatsApp Desarrollador -->
                    <div class="bg-green-50 rounded-lg p-4">
                        <div class="flex items-center space-x-3">
                            <div class="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                                <i class="fab fa-whatsapp text-white text-xl"></i>
                            </div>
                            <div class="flex-1">
                                <h4 class="font-semibold text-gray-800">WhatsApp Desarrollador</h4>
                                <p class="text-sm text-gray-600">Comunicación directa con el desarrollador asignado</p>
                            </div>
                        </div>
                        <button id="whatsappBtn" class="w-full mt-3 bg-green-500 text-white py-2 px-4 rounded-lg hover:bg-green-600 transition-colors duration-200">
                            <i class="fab fa-whatsapp mr-2"></i>Contactar por WhatsApp
                        </button>
                    </div>
                    
                    <!-- Email Desarrollador -->
                    <div class="bg-blue-50 rounded-lg p-4">
                        <div class="flex items-center space-x-3">
                            <div class="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
                                <i class="fas fa-envelope text-white text-xl"></i>
                            </div>
                            <div class="flex-1">
                                <h4 class="font-semibold text-gray-800">Email Desarrollador</h4>
                                <p class="text-sm text-gray-600">Enviar correo electrónico al desarrollador</p>
                            </div>
                        </div>
                        <button id="emailBtn" class="w-full mt-3 bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors duration-200">
                            <i class="fas fa-envelope mr-2"></i>Enviar Email
                        </button>
                    </div>
                </div>
                
                <div class="mt-6 pt-4 border-t border-gray-200">
                    <button onclick="cerrarComunicacionModal()" class="w-full bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors duration-200">
                        Cerrar
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let desarrolladorActual = null;

function verDetalles(requestId) {
    // Mostrar loading
    document.getElementById('detallesContenido').innerHTML = `
        <div class="flex items-center justify-center py-12">
            <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <span class="ml-3 text-gray-600">Cargando detalles...</span>
        </div>
    `;
    
    document.getElementById('detallesModal').classList.remove('hidden');
    
    // Cargar detalles
    fetch(`/fabricasoft/cliente/proyecto/${requestId}/detalle`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                mostrarDetalles(data);
            } else {
                document.getElementById('detallesContenido').innerHTML = `
                    <div class="text-center py-12">
                        <i class="fas fa-exclamation-triangle text-4xl text-red-500 mb-4"></i>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">Error al cargar detalles</h3>
                        <p class="text-gray-600">No se pudieron cargar los detalles de la solicitud.</p>
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('detallesContenido').innerHTML = `
                <div class="text-center py-12">
                    <i class="fas fa-exclamation-triangle text-4xl text-red-500 mb-4"></i>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">Error de conexión</h3>
                    <p class="text-gray-600">No se pudo conectar con el servidor.</p>
                </div>
            `;
        });
}

function mostrarDetalles(data) {
    const request = data.request;
    const formularioNombre = data.formularioNombre || 'Formulario no especificado';
    
    let estadoMensaje = '';
    if (request.estado === 'rechazado') {
        estadoMensaje = '<div class="bg-red-50 border border-red-200 rounded-lg p-4 mb-6"><div class="flex items-center"><i class="fas fa-times-circle text-red-500 mr-3"></i><span class="text-red-800 font-medium">Tu solicitud ha sido rechazada</span></div></div>';
    } else if (request.estado === 'pendiente') {
        estadoMensaje = '<div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6"><div class="flex items-center"><i class="fas fa-clock text-yellow-500 mr-3"></i><span class="text-yellow-800 font-medium">Aún no han dado respuesta a tu solicitud</span></div></div>';
    }
    
    document.getElementById('detallesContenido').innerHTML = `
        ${estadoMensaje}
        
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Información del proyecto -->
            <div class="space-y-6">
                <div class="bg-gray-50 rounded-lg p-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">Información del Proyecto</h3>
                    <div class="space-y-3">
                        <div>
                            <label class="text-sm font-medium text-gray-600">Nombre del proyecto:</label>
                            <p class="text-gray-800 font-medium">${request.nombre_proyecto}</p>
                        </div>
                        <div>
                            <label class="text-sm font-medium text-gray-600">Formulario enviado:</label>
                            <p class="text-gray-800 font-medium">${formularioNombre}</p>
                        </div>
                        <div>
                            <label class="text-sm font-medium text-gray-600">Fecha de solicitud:</label>
                            <p class="text-gray-800">${new Date(request.created_at).toLocaleDateString('es-ES')}</p>
                        </div>
                        <div>
                            <label class="text-sm font-medium text-gray-600">Estado:</label>
                            <span class="px-3 py-1 text-xs font-medium rounded-full 
                                ${request.estado === 'aprobado' || request.estado === 'en_desarrollo' ? 'bg-green-100 text-green-800' : 
                                  request.estado === 'rechazado' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}">
                                ${request.estado.replace('_', ' ').charAt(0).toUpperCase() + request.estado.replace('_', ' ').slice(1)}
                            </span>
                        </div>
                    </div>
                </div>
                
                <div class="bg-gray-50 rounded-lg p-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">Descripción del Proyecto</h3>
                    <p class="text-gray-700 leading-relaxed">${request.descripcion || 'No se proporcionó descripción'}</p>
                </div>
            </div>
            
            <!-- Información del desarrollador y comunicación -->
            <div class="space-y-6">
                ${request.assigned_user ? `
                <div class="bg-blue-50 rounded-lg p-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">Desarrollador Asignado</h3>
                    <div class="flex items-center space-x-4 mb-4">
                        <div class="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
                            <i class="fas fa-user text-white"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-800">${request.assigned_user.name}</p>
                            <p class="text-sm text-gray-600">${request.assigned_user.email}</p>
                        </div>
                    </div>
                    <button onclick="contactarDesarrollador('${request.assigned_user.name}', '${request.assigned_user.phone || ''}')" 
                            class="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200">
                        <i class="fab fa-whatsapp mr-2"></i>Contactar Desarrollador
                    </button>
                </div>
                ` : `
                <div class="bg-gray-50 rounded-lg p-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">Desarrollador</h3>
                    <p class="text-gray-600">Aún no se ha asignado un desarrollador a este proyecto.</p>
                </div>
                `}
                
                <!-- Progreso del proyecto -->
                ${request.estado === 'aprobado' || request.estado === 'en_desarrollo' ? `
                <div class="bg-green-50 rounded-lg p-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">Progreso del Proyecto</h3>
                    <div class="mb-3">
                        <div class="flex items-center justify-between text-sm text-gray-600 mb-1">
                            <span>Progreso general</span>
                            <span>${data.progreso || 0}%</span>
                        </div>
                        <div class="w-full bg-gray-200 rounded-full h-3">
                            <div class="bg-gradient-to-r from-green-500 to-blue-500 h-3 rounded-full transition-all duration-300" 
                                 style="width: ${data.progreso || 0}%"></div>
                        </div>
                    </div>
                </div>
                ` : ''}
            </div>
        </div>
    `;
}

function contactarDesarrollador(nombre, telefono) {
    desarrolladorActual = { nombre, telefono };
    document.getElementById('comunicacionModal').classList.remove('hidden');
}

function cerrarModal() {
    document.getElementById('detallesModal').classList.add('hidden');
}

function cerrarComunicacionModal() {
    document.getElementById('comunicacionModal').classList.add('hidden');
    desarrolladorActual = null;
}

// Event listeners para WhatsApp y Email
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('whatsappBtn').addEventListener('click', function() {
        if (desarrolladorActual) {
            const mensaje = encodeURIComponent(`Hola ${desarrolladorActual.nombre}, necesito información sobre mi proyecto.`);
            const telefono = desarrolladorActual.telefono || '573001234567'; // Número por defecto
            window.open(`https://wa.me/${telefono}?text=${mensaje}`, '_blank');
        }
    });
    
    document.getElementById('emailBtn').addEventListener('click', function() {
        if (desarrolladorActual) {
            const asunto = encodeURIComponent('Consulta sobre proyecto');
            const mensaje = encodeURIComponent(`Hola ${desarrolladorActual.nombre},\n\nNecesito información sobre mi proyecto.\n\nSaludos.`);
            window.open(`mailto:desarrollo@fabricasoft.com?subject=${asunto}&body=${mensaje}`, '_blank');
        }
    });
});

// Cerrar modales al hacer clic fuera
document.getElementById('detallesModal').addEventListener('click', function(e) {
    if (e.target === this) {
        cerrarModal();
    }
});

document.getElementById('comunicacionModal').addEventListener('click', function(e) {
    if (e.target === this) {
        cerrarComunicacionModal();
    }
});
</script>

<style>
.line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
</style>
@endsection