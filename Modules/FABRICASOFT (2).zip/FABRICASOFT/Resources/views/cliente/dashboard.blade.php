@extends('fabricasoft::layouts.masterusers')

@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- Header -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-2">Panel de Cliente</h1>
        <p class="text-gray-600">Gestiona y monitorea el avance de tus proyectos de desarrollo de software</p>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                    <i class="fas fa-file-alt text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Total Proyectos</p>
                    <p class="text-2xl font-semibold text-gray-800">{{ $userRequests->count() }}</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-yellow-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-yellow-100 text-yellow-600">
                    <i class="fas fa-clock text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">En Desarrollo</p>
                    <p class="text-2xl font-semibold text-gray-800">{{ $userRequests->whereIn('status', ['en_desarrollo', 'revision', 'testing'])->count() }}</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-green-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-green-100 text-green-600">
                    <i class="fas fa-check-circle text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Completados</p>
                    <p class="text-2xl font-semibold text-gray-800">{{ $userRequests->where('status', 'completado')->count() }}</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-purple-100 text-purple-600">
                    <i class="fas fa-percentage text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">Progreso Promedio</p>
                    <p class="text-2xl font-semibold text-gray-800">{{ number_format($progresoPromedio ?? 0, 1) }}%</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Sección de Ajustes de Perfil -->
    <div class="bg-gradient-to-r from-green-50 to-green-100 rounded-lg shadow-md p-6 mb-8 border border-green-200">
        <div class="flex items-center justify-between">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-green-500 text-white mr-4">
                    <i class="fas fa-user-cog text-xl"></i>
                </div>
                <div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-1">Gestión de Perfil</h3>
                    <p class="text-gray-600">Verifique y actualice su información personal para mantener sus datos actualizados en el sistema. Esto garantiza una comunicación eficiente y un seguimiento preciso de sus proyectos.</p>
                </div>
            </div>
            <a href="{{ route('fabricasoft.ajustes') }}" class="bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 flex items-center shadow-lg hover:shadow-xl transform hover:scale-105">
                <i class="fas fa-edit mr-2"></i>
                Gestionar Perfil
            </a>
        </div>
    </div>

    <!-- Información del Equipo de Desarrollo -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-8">
        <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <i class="fas fa-users text-indigo-500 mr-3"></i>
            Equipo de Desarrollo Asignado
        </h3>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            @foreach($userRequests->where('assigned_user_id', '!=', null) as $proyecto)
                @if($proyecto->assignedUser)
                    <div class="border border-gray-200 rounded-lg p-4">
                        <div class="flex items-center mb-3">
                            <div class="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-user text-indigo-600"></i>
                            </div>
                            <div class="ml-3">
                                <h4 class="font-medium text-gray-800">{{ $proyecto->assignedUser->nickname ?? 'Desarrollador' }}</h4>
                                @php
                        $formularioNombre = null;
                        if ($proyecto->formulario_id) {
                            $formulario = \DB::table('formularios')->where('id', $proyecto->formulario_id)->first();
                            $formularioNombre = $formulario ? $formulario->nombre : null;
                        }
                    @endphp
                    <p class="text-sm text-gray-600">
                        {{ $proyecto->project_name }}
                        @if($formularioNombre)
                            <span class="text-sm text-blue-600">({{ $formularioNombre }})</span>
                        @endif
                    </p>
                            </div>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-xs px-2 py-1 rounded-full {{ $proyecto->estado_clase_css }}">
                                {{ $proyecto->estado_legible }}
                            </span>
                            <button onclick="contactarDesarrollador('{{ $proyecto->assignedUser->email ?? '' }}')" 
                                    class="text-indigo-600 hover:text-indigo-800 text-sm">
                                <i class="fas fa-envelope mr-1"></i>Contactar
                            </button>
                        </div>
                    </div>
                @endif
            @endforeach
            
            @if($userRequests->where('assigned_user_id', '!=', null)->count() === 0)
                <div class="col-span-full text-center py-8">
                    <i class="fas fa-users text-gray-400 text-4xl mb-4"></i>
                    <p class="text-gray-600">Aún no se han asignado desarrolladores a tus proyectos</p>
                </div>
            @endif
        </div>
    </div>

    <!-- Gráfico de Progreso -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <i class="fas fa-chart-line text-blue-500 mr-3"></i>
                Progreso de Proyectos
            </h3>
            <canvas id="progresoChart" width="400" height="200"></canvas>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <i class="fas fa-chart-pie text-green-500 mr-3"></i>
                Estado de Proyectos
            </h3>
            <canvas id="estadoChart" width="400" height="200"></canvas>
        </div>
    </div>

    <!-- Lista de Proyectos con Avance -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex justify-between items-center">
                <h2 class="text-xl font-semibold text-gray-800">Mis Proyectos</h2>
                <div class="flex space-x-2">
                    <button onclick="exportarProyectos()" class="bg-blue-600 text-white px-4 py-2 rounded-md text-sm hover:bg-blue-700 transition-colors">
                        <i class="fas fa-download mr-2"></i>Exportar
                    </button>
                    <button onclick="refrescarProyectos()" class="bg-gray-600 text-white px-4 py-2 rounded-md text-sm hover:bg-gray-700 transition-colors">
                        <i class="fas fa-sync-alt mr-2"></i>Refrescar
                    </button>
                </div>
            </div>
        </div>
        
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Proyecto
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Estado
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Progreso
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Desarrollador
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Fecha Inicio
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Acciones
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @foreach($userRequests as $proyecto)
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <div class="flex-shrink-0 h-10 w-10">
                                    <div class="h-10 w-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-semibold">
                                        <i class="fas fa-project-diagram"></i>
                                    </div>
                                </div>
                                <div class="ml-4">
                                    @php
                            $formularioNombre = null;
                            if ($proyecto->formulario_id) {
                                $formulario = \DB::table('formularios')->where('id', $proyecto->formulario_id)->first();
                                $formularioNombre = $formulario ? $formulario->nombre : null;
                            }
                        @endphp
                        <div class="text-sm font-medium text-gray-900">
                            {{ $proyecto->project_name }}
                            @if($formularioNombre)
                                <span class="text-sm text-blue-600">({{ $formularioNombre }})</span>
                            @endif
                        </div>
                                    <div class="text-sm text-gray-500">{{ $proyecto->company_name }}</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full {{ $proyecto->estado_clase_css }}">
                                {{ $proyecto->estado_legible }}
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <div class="w-16 bg-gray-200 rounded-full h-2 mr-2">
                                    <div class="bg-green-600 h-2 rounded-full" style="width: {{ $progresos[$proyecto->id] ?? 0 }}%"></div>
                                </div>
                                <span class="text-sm text-gray-900">{{ $progresos[$proyecto->id] ?? 0 }}%</span>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            @if($proyecto->assignedUser)
                                <div class="flex items-center">
                                    <div class="h-8 w-8 rounded-full bg-green-500 flex items-center justify-center text-white text-xs font-semibold mr-2">
                                        {{ substr($proyecto->assignedUser->name, 0, 1) }}
                                    </div>
                                    {{ $proyecto->assignedUser->name }}
                                </div>
                            @else
                                <span class="text-gray-500">Sin asignar</span>
                            @endif
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {{ \Carbon\Carbon::parse($proyecto->created_at)->format('d/m/Y') }}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button onclick="verDetalleProyecto({{ $proyecto->id }})" class="text-blue-600 hover:text-blue-900 mr-3">
                                <i class="fas fa-eye"></i> Ver
                            </button>
                            @if($proyecto->status != 'completado')
                            <button onclick="contactarDesarrollador({{ $proyecto->id }})" class="text-green-600 hover:text-green-900">
                                <i class="fas fa-comments"></i> Contactar
                            </button>
                            @endif
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <!-- Sección de Actividad del Desarrollador -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden mb-8">
        <div class="px-6 py-4 border-b border-gray-200">
            <h2 class="text-xl font-semibold text-gray-800">Actividad del Desarrollador</h2>
            <p class="text-sm text-gray-600 mt-1">Últimas tareas, requerimientos y avances registrados</p>
        </div>
        
        <div class="p-6">
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Tareas Recientes -->
                <div class="bg-blue-50 rounded-lg p-4">
                    <h3 class="text-lg font-semibold text-blue-800 mb-3 flex items-center">
                        <i class="fas fa-tasks mr-2"></i>Tareas Recientes
                    </h3>
                    <div class="space-y-3">
                        @php
                            $todasTareas = collect();
                            foreach($tareasPorProyecto as $proyectoId => $tareas) {
                                foreach($tareas as $tarea) {
                                    $tarea->proyecto_id = $proyectoId;
                                    $todasTareas->push($tarea);
                                }
                            }
                            $tareasRecientes = $todasTareas->sortByDesc('created_at')->take(5);
                        @endphp
                        
                        @if($tareasRecientes->count() > 0)
                            @foreach($tareasRecientes as $tarea)
                            <div class="bg-white rounded p-3 border-l-4 border-blue-500">
                                <div class="flex justify-between items-start">
                                    <div class="flex-1">
                                        <h4 class="text-sm font-medium text-gray-800">{{ $tarea->titulo }}</h4>
                                        <p class="text-xs text-gray-600 mt-1">{{ Str::limit($tarea->descripcion, 50) }}</p>
                                        <div class="flex items-center mt-2">
                                            <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full
                                                @if($tarea->estado == 'pendiente') bg-yellow-100 text-yellow-800
                                                @elseif($tarea->estado == 'en_progreso') bg-blue-100 text-blue-800
                                                @elseif($tarea->estado == 'completada') bg-green-100 text-green-800
                                                @else bg-gray-100 text-gray-800 @endif">
                                                {{ ucfirst(str_replace('_', ' ', $tarea->estado)) }}
                                            </span>
                                        </div>
                                    </div>
                                    <span class="text-xs text-gray-500">{{ \Carbon\Carbon::parse($tarea->created_at)->format('d/m') }}</span>
                                </div>
                            </div>
                            @endforeach
                        @else
                            <div class="text-center py-4 text-gray-500">
                                <i class="fas fa-tasks text-2xl mb-2"></i>
                                <p class="text-sm">No hay tareas registradas</p>
                            </div>
                        @endif
                    </div>
                </div>

                <!-- Requerimientos Recientes -->
                <div class="bg-purple-50 rounded-lg p-4">
                    <h3 class="text-lg font-semibold text-purple-800 mb-3 flex items-center">
                        <i class="fas fa-clipboard-list mr-2"></i>Requerimientos
                    </h3>
                    <div class="space-y-3">
                        @php
                            $todosRequerimientos = collect();
                            foreach($requerimientosPorProyecto as $proyectoId => $requerimientos) {
                                foreach($requerimientos as $req) {
                                    $req->proyecto_id = $proyectoId;
                                    $todosRequerimientos->push($req);
                                }
                            }
                            $requerimientosRecientes = $todosRequerimientos->sortByDesc('created_at')->take(5);
                        @endphp
                        
                        @if($requerimientosRecientes->count() > 0)
                            @foreach($requerimientosRecientes as $req)
                            <div class="bg-white rounded p-3 border-l-4 border-purple-500">
                                <div class="flex justify-between items-start">
                                    <div class="flex-1">
                                        <h4 class="text-sm font-medium text-gray-800">{{ $req->titulo }}</h4>
                                        <p class="text-xs text-gray-600 mt-1">{{ Str::limit($req->descripcion, 50) }}</p>
                                        <div class="flex items-center mt-2">
                                            <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full
                                                @if($req->estado == 'pendiente') bg-yellow-100 text-yellow-800
                                                @elseif($req->estado == 'en_revision') bg-blue-100 text-blue-800
                                                @elseif($req->estado == 'aprobado') bg-green-100 text-green-800
                                                @else bg-gray-100 text-gray-800 @endif">
                                                {{ ucfirst(str_replace('_', ' ', $req->estado)) }}
                                            </span>
                                            @if($req->tipo)
                                            <span class="ml-2 inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800">
                                                {{ ucfirst($req->tipo) }}
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                    <span class="text-xs text-gray-500">{{ \Carbon\Carbon::parse($req->created_at)->format('d/m') }}</span>
                                </div>
                            </div>
                            @endforeach
                        @else
                            <div class="text-center py-4 text-gray-500">
                                <i class="fas fa-clipboard-list text-2xl mb-2"></i>
                                <p class="text-sm">No hay requerimientos registrados</p>
                            </div>
                        @endif
                    </div>
                </div>

                <!-- Avances Recientes -->
                <div class="bg-green-50 rounded-lg p-4">
                    <h3 class="text-lg font-semibold text-green-800 mb-3 flex items-center">
                        <i class="fas fa-chart-line mr-2"></i>Últimos Avances
                    </h3>
                    <div class="space-y-3">
                        @php
                            $todosAvances = collect();
                            foreach($avancesPorProyecto as $proyectoId => $avances) {
                                foreach($avances as $avance) {
                                    $avance->proyecto_id = $proyectoId;
                                    $todosAvances->push($avance);
                                }
                            }
                            $avancesRecientes = $todosAvances->sortByDesc('created_at')->take(5);
                        @endphp
                        
                        @if($avancesRecientes->count() > 0)
                            @foreach($avancesRecientes as $avance)
                            <div class="bg-white rounded p-3 border-l-4 border-green-500">
                                <div class="flex justify-between items-start">
                                    <div class="flex-1">
                                        <h4 class="text-sm font-medium text-gray-800">{{ $avance->titulo }}</h4>
                                        <p class="text-xs text-gray-600 mt-1">{{ Str::limit($avance->descripcion, 50) }}</p>
                                        <div class="flex items-center mt-2">
                                            <div class="flex items-center">
                                                <div class="w-12 bg-gray-200 rounded-full h-2 mr-2">
                                                    <div class="bg-green-600 h-2 rounded-full" style="width: {{ $avance->porcentaje_avance }}%"></div>
                                                </div>
                                                <span class="text-xs text-gray-600">{{ $avance->porcentaje_avance }}%</span>
                                            </div>
                                            @if($avance->tipo)
                                            <span class="ml-2 inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                                                {{ ucfirst($avance->tipo) }}
                                            </span>
                                            @endif
                                        </div>
                                    </div>
                                    <span class="text-xs text-gray-500">{{ \Carbon\Carbon::parse($avance->created_at)->format('d/m') }}</span>
                                </div>
                            </div>
                            @endforeach
                        @else
                            <div class="text-center py-4 text-gray-500">
                                <i class="fas fa-chart-line text-2xl mb-2"></i>
                                <p class="text-sm">No hay avances registrados</p>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal para ver detalles del proyecto -->
<div id="modalDetalleProyecto" class="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[9999] hidden p-4 backdrop-blur-sm">
    <div class="bg-gradient-to-br from-white to-gray-50 rounded-2xl shadow-2xl w-full max-w-7xl mx-auto h-[90vh] flex flex-col relative border border-gray-200">
        <!-- Header del modal -->
        <div class="p-6 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50 flex-shrink-0 rounded-t-2xl">
            <div class="flex justify-between items-center">
                <div class="flex items-center">
                    <div class="p-2 bg-blue-100 rounded-lg mr-3">
                        <i class="fas fa-project-diagram text-blue-600 text-xl"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-800">Detalles del Proyecto</h3>
                </div>
                <button onclick="cerrarModalDetalle()" class="text-white bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-2xl font-bold p-4 hover:scale-110 rounded-full transition-all duration-300 shadow-xl border-2 border-red-400 hover:border-red-500 z-[10000] relative min-w-[55px] min-h-[55px] flex items-center justify-center transform hover:rotate-90">
                    &times;
                </button>
            </div>
        </div>
        
        <!-- Contenido del modal con scrollbar -->
        <div class="flex-1 overflow-hidden">
            <div id="contenidoDetalleProyecto" class="h-full overflow-y-auto">
                <!-- Contenido dinámico -->
            </div>
        </div>
    </div>
</div>

<style>
/* Scrollbar para el modal principal */
#contenidoDetalleProyecto {
    overflow-y: auto;
    scrollbar-width: thin;
    scrollbar-color: #6b7280 #f3f4f6;
    -webkit-overflow-scrolling: touch;
    height: calc(90vh - 100px);
    padding: 32px;
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
}

#contenidoDetalleProyecto::-webkit-scrollbar {
    width: 14px;
}

#contenidoDetalleProyecto::-webkit-scrollbar-track {
    background: linear-gradient(180deg, #e2e8f0 0%, #cbd5e1 100%);
    border-radius: 8px;
    border: 1px solid #cbd5e1;
}

#contenidoDetalleProyecto::-webkit-scrollbar-thumb {
    background: linear-gradient(180deg, #64748b 0%, #475569 100%);
    border-radius: 8px;
    border: 2px solid #cbd5e1;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.2);
}

#contenidoDetalleProyecto::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(180deg, #475569 0%, #334155 100%);
    transform: scale(1.05);
}

/* Scrollbar para las secciones internas */
.custom-scrollbar {
    overflow-y: auto;
    scrollbar-width: thin;
    scrollbar-color: #9ca3af #f3f4f6;
}

.custom-scrollbar::-webkit-scrollbar {
    width: 8px;
}

.custom-scrollbar::-webkit-scrollbar-track {
    background: #f3f4f6;
    border-radius: 4px;
}

.custom-scrollbar::-webkit-scrollbar-thumb {
    background: #9ca3af;
    border-radius: 4px;
    border: 1px solid #f3f4f6;
}

.custom-scrollbar::-webkit-scrollbar-thumb:hover {
    background: #6b7280;
}

/* Responsive para el modal */
@media (max-width: 768px) {
    #modalDetalleProyecto {
        padding: 8px;
    }
    
    #modalDetalleProyecto > div {
        height: 95vh;
        max-width: 100%;
    }
    
    #contenidoDetalleProyecto {
        padding: 16px;
    }
}

@media (max-width: 480px) {
    #modalDetalleProyecto {
        padding: 4px;
    }
    
    #modalDetalleProyecto > div {
        height: 98vh;
    }
    
    #contenidoDetalleProyecto {
        padding: 12px;
    }
}
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Datos para los gráficos
const progresoData = {
    labels: ['Pendiente', 'En Desarrollo', 'Revisión', 'Testing', 'Completado'],
    datasets: [{
        label: 'Proyectos',
        data: [
            {{ $userRequests->where('status', 'pendiente')->count() }},
            {{ $userRequests->where('status', 'en_desarrollo')->count() }},
            {{ $userRequests->where('status', 'revision')->count() }},
            {{ $userRequests->where('status', 'testing')->count() }},
            {{ $userRequests->where('status', 'completado')->count() }}
        ],
        backgroundColor: [
            '#FCD34D',
            '#3B82F6',
            '#8B5CF6',
            '#F97316',
            '#10B981'
        ],
        borderWidth: 0
    }]
};

const estadoData = {
    labels: ['Pendiente', 'En Desarrollo', 'Revisión', 'Testing', 'Completado'],
    datasets: [{
        data: [
            {{ $userRequests->where('status', 'pendiente')->count() }},
            {{ $userRequests->where('status', 'en_desarrollo')->count() }},
            {{ $userRequests->where('status', 'revision')->count() }},
            {{ $userRequests->where('status', 'testing')->count() }},
            {{ $userRequests->where('status', 'completado')->count() }}
        ],
        backgroundColor: [
            '#FCD34D',
            '#3B82F6',
            '#8B5CF6',
            '#F97316',
            '#10B981'
        ]
    }]
};

// Crear gráficos
const progresoChart = new Chart(document.getElementById('progresoChart'), {
    type: 'bar',
    data: progresoData,
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 1
                }
            }
        }
    }
});

const estadoChart = new Chart(document.getElementById('estadoChart'), {
    type: 'doughnut',
    data: estadoData,
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});

function verDetalleProyecto(proyectoId) {
    // Mostrar modal con loading
    document.getElementById('modalDetalleProyecto').classList.remove('hidden');
    document.getElementById('contenidoDetalleProyecto').innerHTML = `
        <div class="text-center py-8">
            <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p class="mt-4 text-gray-600">Cargando detalles del proyecto...</p>
        </div>
    `;
    
    // Cargar datos reales del proyecto via AJAX
    fetch(`/fabricasoft/cliente/proyecto/${proyectoId}/detalle`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const proyecto = data.proyecto;
                const tareas = data.tareas || [];
                const requerimientos = data.requerimientos || [];
                const avances = data.avances || [];
                
                let contenido = `
                    <div class="space-y-8">
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <div class="bg-gradient-to-br from-blue-50 to-indigo-50 p-8 rounded-2xl shadow-lg border border-blue-100 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                                <h4 class="font-bold text-gray-800 mb-6 text-xl flex items-center">
                                    <div class="p-3 bg-blue-100 rounded-xl mr-4">
                                        <i class="fas fa-info-circle text-blue-600 text-lg"></i>
                                    </div>Información del Proyecto
                                </h4>
                                <div class="space-y-3 text-sm">
                                    <div class="flex justify-between items-center">
                                        <span class="font-medium text-gray-700">Nombre:</span>
                                        <span class="text-gray-900">${proyecto.project_name || 'No especificado'}</span>
                                    </div>
                                    <div class="flex justify-between items-center">
                                        <span class="font-medium text-gray-700">Empresa:</span>
                                        <span class="text-gray-900">${proyecto.company_name || 'No especificado'}</span>
                                    </div>
                                    <div class="flex justify-between items-center">
                                        <span class="font-medium text-gray-700">Estado:</span>
                                        <span class="px-3 py-1 text-xs font-semibold rounded-full 
                                            ${proyecto.status === 'pendiente' ? 'bg-yellow-100 text-yellow-800' : 
                                              proyecto.status === 'en_desarrollo' ? 'bg-blue-100 text-blue-800' : 
                                              proyecto.status === 'revision' ? 'bg-purple-100 text-purple-800' : 
                                              proyecto.status === 'testing' ? 'bg-orange-100 text-orange-800' : 
                                              proyecto.status === 'completado' ? 'bg-green-100 text-green-800' : 
                                              'bg-gray-100 text-gray-800'}">${proyecto.status ? proyecto.status.replace('_', ' ').charAt(0).toUpperCase() + proyecto.status.replace('_', ' ').slice(1) : 'No especificado'}</span>
                                    </div>
                                    <div class="flex justify-between items-center">
                                        <span class="font-medium text-gray-700">Progreso:</span>
                                        <div class="flex items-center">
                                            <div class="w-20 bg-gray-200 rounded-full h-2 mr-2">
                                                <div class="bg-green-600 h-2 rounded-full" style="width: ${data.progreso || 0}%"></div>
                                            </div>
                                            <span class="text-sm font-medium text-gray-900">${data.progreso || 0}%</span>
                                        </div>
                                    </div>
                                    <div class="flex justify-between items-center">
                                        <span class="font-medium text-gray-700">Fecha de Creación:</span>
                                        <span class="text-gray-900">${new Date(proyecto.created_at).toLocaleDateString('es-ES')}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="bg-gradient-to-br from-green-50 to-emerald-50 p-8 rounded-2xl shadow-lg border border-green-100 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                                <h4 class="font-bold text-gray-800 mb-6 text-xl flex items-center">
                                    <div class="p-3 bg-green-100 rounded-xl mr-4">
                                        <i class="fas fa-user-tie text-green-600 text-lg"></i>
                                    </div>Desarrollador Asignado
                                </h4>
                                <div class="space-y-3 text-sm">
                                    ${proyecto.assigned_user ? `
                                        <div class="flex justify-between items-center">
                                            <span class="font-medium text-gray-700">Nombre:</span>
                                            <span class="text-gray-900">${proyecto.assigned_user.name}</span>
                                        </div>
                                        <div class="flex justify-between items-center">
                                            <span class="font-medium text-gray-700">Email:</span>
                                            <span class="text-gray-900">${proyecto.assigned_user.email}</span>
                                        </div>
                                        <div class="flex justify-between items-center">
                                            <span class="font-medium text-gray-700">Teléfono:</span>
                                            <span class="text-gray-900">${proyecto.assigned_user.phone || 'No especificado'}</span>
                                        </div>
                                    ` : '<p class="text-gray-500 text-center py-4">Sin desarrollador asignado</p>'}
                                </div>
                            </div>
                        </div>
                        
                        <!-- Tareas del Proyecto -->
                        <div class="bg-gradient-to-br from-white to-blue-50 p-8 rounded-2xl shadow-lg border border-blue-100 hover:shadow-xl transition-all duration-300">
                            <h4 class="font-bold text-gray-800 mb-6 text-xl flex items-center">
                                <div class="p-3 bg-blue-100 rounded-xl mr-4">
                                    <i class="fas fa-tasks text-blue-600 text-lg"></i>
                                </div>Tareas del Proyecto 
                                <span class="ml-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white text-sm font-bold px-4 py-2 rounded-full shadow-md">${tareas.length}</span>
                            </h4>
                            ${tareas.length > 0 ? `
                                <div class="space-y-4 max-h-64 overflow-y-auto custom-scrollbar">
                                    ${tareas.map(tarea => `
                                        <div class="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-xl border-l-4 border-blue-500 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                                            <div class="flex justify-between items-start">
                                                <div class="flex-1">
                                                    <h5 class="text-sm font-semibold text-gray-800 mb-2">${tarea.titulo}</h5>
                                                    <p class="text-sm text-gray-600 mb-3">${tarea.descripcion ? tarea.descripcion.substring(0, 120) + (tarea.descripcion.length > 120 ? '...' : '') : 'Sin descripción'}</p>
                                                    <div class="flex items-center justify-between">
                                                        <div class="flex items-center space-x-2">
                                                            <span class="inline-flex px-3 py-1 text-xs font-semibold rounded-full
                                                                ${tarea.estado === 'pendiente' ? 'bg-yellow-100 text-yellow-800' : 
                                                                  tarea.estado === 'en_progreso' ? 'bg-blue-100 text-blue-800' : 
                                                                  tarea.estado === 'completada' ? 'bg-green-100 text-green-800' : 
                                                                  'bg-gray-100 text-gray-800'}">${tarea.estado ? tarea.estado.replace('_', ' ').charAt(0).toUpperCase() + tarea.estado.replace('_', ' ').slice(1) : 'Sin estado'}</span>
                                                            ${tarea.prioridad ? `<span class="inline-flex px-3 py-1 text-xs font-semibold rounded-full
                                                                ${tarea.prioridad === 'alta' ? 'bg-red-100 text-red-800' : 
                                                                  tarea.prioridad === 'media' ? 'bg-yellow-100 text-yellow-800' : 
                                                                  'bg-green-100 text-green-800'}">${tarea.prioridad.charAt(0).toUpperCase() + tarea.prioridad.slice(1)}</span>` : ''}
                                                        </div>
                                                        <span class="text-xs text-gray-500 bg-white px-2 py-1 rounded">${new Date(tarea.created_at).toLocaleDateString('es-ES')}</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    `).join('')}
                                </div>
                                                         ` : '<div class="text-center py-12 text-gray-500"><div class="p-6 bg-blue-100 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center"><i class="fas fa-tasks text-3xl text-blue-600"></i></div><p class="text-lg font-medium">No hay tareas registradas para este proyecto</p></div>'}
                        </div>
                        
                        <!-- Requerimientos del Proyecto -->
                        <div class="bg-gradient-to-br from-white to-purple-50 p-8 rounded-2xl shadow-lg border border-purple-100 hover:shadow-xl transition-all duration-300">
                            <h4 class="font-bold text-gray-800 mb-6 text-xl flex items-center">
                                <div class="p-3 bg-purple-100 rounded-xl mr-4">
                                    <i class="fas fa-clipboard-list text-purple-600 text-lg"></i>
                                </div>Requerimientos del Proyecto
                                <span class="ml-3 bg-gradient-to-r from-purple-500 to-purple-600 text-white text-sm font-bold px-4 py-2 rounded-full shadow-md">${requerimientos.length}</span>
                            </h4>
                            ${requerimientos.length > 0 ? `
                                <div class="space-y-4 max-h-64 overflow-y-auto custom-scrollbar">
                                    ${requerimientos.map(req => `
                                        <div class="bg-gradient-to-r from-purple-50 to-violet-50 p-6 rounded-xl border-l-4 border-purple-500 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                                            <div class="flex justify-between items-start">
                                                <div class="flex-1">
                                                    <h5 class="text-sm font-semibold text-gray-800 mb-2">${req.titulo}</h5>
                                                    <p class="text-sm text-gray-600 mb-3">${req.descripcion ? req.descripcion.substring(0, 120) + (req.descripcion.length > 120 ? '...' : '') : 'Sin descripción'}</p>
                                                    <div class="flex items-center justify-between">
                                                        <div class="flex items-center space-x-2">
                                                            <span class="inline-flex px-3 py-1 text-xs font-semibold rounded-full
                                                                ${req.estado === 'pendiente' ? 'bg-yellow-100 text-yellow-800' : 
                                                                  req.estado === 'en_revision' ? 'bg-blue-100 text-blue-800' : 
                                                                  req.estado === 'aprobado' ? 'bg-green-100 text-green-800' : 
                                                                  'bg-gray-100 text-gray-800'}">${req.estado ? req.estado.replace('_', ' ').charAt(0).toUpperCase() + req.estado.replace('_', ' ').slice(1) : 'Sin estado'}</span>
                                                            ${req.tipo ? `<span class="inline-flex px-3 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800">${req.tipo.charAt(0).toUpperCase() + req.tipo.slice(1)}</span>` : ''}
                                                        </div>
                                                        <span class="text-xs text-gray-500 bg-white px-2 py-1 rounded">${new Date(req.created_at).toLocaleDateString('es-ES')}</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    `).join('')}
                                </div>
                                                         ` : '<div class="text-center py-12 text-gray-500"><div class="p-6 bg-purple-100 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center"><i class="fas fa-clipboard-list text-3xl text-purple-600"></i></div><p class="text-lg font-medium">No hay requerimientos registrados para este proyecto</p></div>'}
                        </div>
                        
                        <!-- Avances del Proyecto -->
                        <div class="bg-gradient-to-br from-white to-green-50 p-8 rounded-2xl shadow-lg border border-green-100 hover:shadow-xl transition-all duration-300">
                            <h4 class="font-bold text-gray-800 mb-6 text-xl flex items-center">
                                <div class="p-3 bg-green-100 rounded-xl mr-4">
                                    <i class="fas fa-chart-line text-green-600 text-lg"></i>
                                </div>Avances del Proyecto
                                <span class="ml-3 bg-gradient-to-r from-green-500 to-green-600 text-white text-sm font-bold px-4 py-2 rounded-full shadow-md">${avances.length}</span>
                            </h4>
                            ${avances.length > 0 ? `
                                <div class="space-y-4 max-h-64 overflow-y-auto custom-scrollbar">
                                    ${avances.map(avance => `
                                        <div class="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-xl border-l-4 border-green-500 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                                            <div class="flex justify-between items-start">
                                                <div class="flex-1">
                                                    <h5 class="text-sm font-semibold text-gray-800 mb-2">${avance.titulo}</h5>
                                                    <p class="text-sm text-gray-600 mb-3">${avance.descripcion ? avance.descripcion.substring(0, 120) + (avance.descripcion.length > 120 ? '...' : '') : 'Sin descripción'}</p>
                                                    <div class="flex items-center justify-between">
                                                        <div class="flex items-center space-x-2">
                                                            <div class="flex items-center">
                                                                <div class="w-20 bg-gray-200 rounded-full h-2 mr-2">
                                                                    <div class="bg-green-600 h-2 rounded-full" style="width: ${avance.porcentaje_avance}%"></div>
                                                                </div>
                                                                <span class="text-sm font-medium text-gray-700">${avance.porcentaje_avance}%</span>
                                                            </div>
                                                            ${avance.tipo ? `<span class="inline-flex px-3 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">${avance.tipo.charAt(0).toUpperCase() + avance.tipo.slice(1)}</span>` : ''}
                                                        </div>
                                                        <span class="text-xs text-gray-500 bg-white px-2 py-1 rounded">${new Date(avance.created_at).toLocaleDateString('es-ES')}</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    `).join('')}
                                </div>
                                                         ` : '<div class="text-center py-12 text-gray-500"><div class="p-6 bg-green-100 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center"><i class="fas fa-chart-line text-3xl text-green-600"></i></div><p class="text-lg font-medium">No hay avances registrados para este proyecto</p></div>'}
                        </div>
                    </div>
                `;
                
                document.getElementById('contenidoDetalleProyecto').innerHTML = contenido;
            } else {
                document.getElementById('contenidoDetalleProyecto').innerHTML = `
                    <div class="text-center py-8">
                        <i class="fas fa-exclamation-triangle text-red-500 text-4xl mb-4"></i>
                        <p class="text-gray-600">Error al cargar los detalles del proyecto</p>
                        <p class="text-sm text-gray-500 mt-2">${data.message || 'Intente nuevamente'}</p>
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('contenidoDetalleProyecto').innerHTML = `
                <div class="text-center py-8">
                    <i class="fas fa-exclamation-triangle text-red-500 text-4xl mb-4"></i>
                    <p class="text-gray-600">Error al cargar los detalles del proyecto</p>
                    <p class="text-sm text-gray-500 mt-2">Verifique su conexión e intente nuevamente</p>
                </div>
            `;
        });
}

function cerrarModalDetalle() {
    const modal = document.getElementById('modalDetalleProyecto');
    if (modal) {
        modal.classList.add('hidden');
        // Limpiar el contenido del modal
        const contenido = document.getElementById('contenidoDetalleProyecto');
        if (contenido) {
            contenido.innerHTML = '';
        }
    }
}

// Función adicional para cerrar con ESC
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        cerrarModalDetalle();
    }
});

// Función para cerrar haciendo clic fuera del modal
document.addEventListener('click', function(event) {
    const modal = document.getElementById('modalDetalleProyecto');
    if (modal && !modal.classList.contains('hidden')) {
        if (event.target === modal) {
            cerrarModalDetalle();
        }
    }
});

function contactarDesarrollador(email) {
    if (!email) {
        Swal.fire({
            icon: 'warning',
            title: 'Información no disponible',
            text: 'No se encontró información de contacto del desarrollador.',
            confirmButtonText: 'Entendido'
        });
        return;
    }
    
    Swal.fire({
        title: 'Contactar Desarrollador',
        html: `
            <div class="text-left">
                <p class="mb-4 text-gray-600">Selecciona el método de contacto:</p>
                <div class="space-y-3">
                    <button onclick="enviarEmail('${email}')" class="w-full bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
                        <i class="fas fa-envelope mr-2"></i>Enviar Email
                    </button>
                    <button onclick="copiarEmail('${email}')" class="w-full bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors">
                        <i class="fas fa-copy mr-2"></i>Copiar Email
                    </button>
                </div>
            </div>
        `,
        showConfirmButton: false,
        showCloseButton: true
    });
}

function enviarEmail(email) {
    window.open(`mailto:${email}?subject=Consulta sobre proyecto FABRICASOFT`, '_blank');
    Swal.close();
}

function copiarEmail(email) {
    navigator.clipboard.writeText(email).then(() => {
        Swal.fire({
            icon: 'success',
            title: 'Email copiado',
            text: 'El email del desarrollador ha sido copiado al portapapeles.',
            timer: 2000,
            showConfirmButton: false
        });
    }).catch(() => {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'No se pudo copiar el email. Inténtalo manualmente.',
            confirmButtonText: 'Entendido'
        });
    });
}

function exportarProyectos() {
    // Implementar exportación
    alert('Funcionalidad de exportación en desarrollo');
}

function refrescarProyectos() {
    location.reload();
}
</script>
@endsection 