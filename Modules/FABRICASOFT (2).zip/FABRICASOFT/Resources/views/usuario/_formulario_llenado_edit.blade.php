<form id="form-editar-formulario-ajax" method="POST" action="{{ route('fabricasoft.usuario.formulario.actualizar', $servicio->id) }}" onsubmit="enviarFormularioEditar(event, {{ $servicio->id }})">
    @csrf
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        @foreach($formulario->preguntas as $idx => $pregunta)
            @if(!empty($pregunta['cliente']))
                @php
                    $respuesta = $respuestas->where('pregunta', $pregunta['texto'])->first();
                    // Identificador único: si existe id, úsalo; si no, usa 'nuevo_' + idx + '_' + hash
                    $hash = substr(md5($pregunta['texto']), 0, 8);
                    $inputId = $respuesta && $respuesta->id ? $respuesta->id : 'nuevo_'.$idx.'_'.$hash;
                @endphp
                <div class="mb-4">
                    <label class="block font-semibold mb-1">{{ $pregunta['texto'] }}</label>
                    <input type="hidden" name="pregunta_texto[{{ $inputId }}]" value="{{ $pregunta['texto'] }}">
                    <input type="hidden" name="pregunta_key[{{ $inputId }}]" value="{{ $inputId }}">
                    @if($pregunta['tipo'] === 'texto')
                        <input type="text" name="respuestas[{{ $inputId }}]" value="{{ $respuesta->respuesta ?? '' }}" class="form-input w-full rounded border border-gray-300" required>
                    @elseif($pregunta['tipo'] === 'numero')
                        <input type="number" name="respuestas[{{ $inputId }}]" value="{{ $respuesta->respuesta ?? '' }}" class="form-input w-full rounded border border-gray-300" required>
                    @elseif($pregunta['tipo'] === 'fecha')
                        <input type="date" name="respuestas[{{ $inputId }}]" value="{{ $respuesta->respuesta ?? '' }}" class="form-input w-full rounded border border-gray-300" required>
                    @elseif($pregunta['tipo'] === 'seleccion' && !empty($pregunta['opciones']))
                        <select name="respuestas[{{ $inputId }}]" class="form-select w-full rounded border border-gray-300" required>
                            <option value="">Seleccione...</option>
                            @foreach($pregunta['opciones'] as $op)
                                <option value="{{ $op }}" @if(($respuesta->respuesta ?? '') == $op) selected @endif>{{ $op }}</option>
                            @endforeach
                        </select>
                    @endif
                </div>
            @endif
        @endforeach
    </div>
    <div class="flex justify-end gap-4 mt-6">
        <button type="button" onclick="cerrarModalEditarFormulario()" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg font-semibold hover:bg-gray-300 transition">Cancelar</button>
        <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition">Guardar Cambios</button>
    </div>
</form> 