@extends('fabricasoft::layouts.masterusers')
@section('content')
<div class="container mx-auto px-4 py-8">
    <div class="mb-8">
        <h1 class="text-2xl font-bold text-gray-800 mb-2">Editar Formulario Llenado</h1>
        <p class="text-gray-600">Modifica tus respuestas y guarda los cambios.</p>
    </div>
    <div class="bg-white rounded-lg shadow-md p-8 max-w-2xl mx-auto">
        <h2 class="text-xl font-semibold text-blue-700 mb-6">{{ $formulario->nombre ?? 'Formulario' }}</h2>
        <form id="form-editar-formulario-ajax" method="POST" action="{{ route('fabricasoft.usuario.formulario.actualizar', $servicio->id) }}" onsubmit="enviarFormularioEditar(event, {{ $servicio->id }})">
            @csrf
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                @foreach($formulario->preguntas as $idx => $pregunta)
                    @if(!empty($pregunta['cliente']))
                        @php
                            $respuesta = $respuestas->where('pregunta', $pregunta['texto'])->first();
                        @endphp
                        <div class="mb-4">
                            <label class="block font-semibold mb-1">{{ $pregunta['texto'] }}</label>
                            @if($pregunta['tipo'] === 'texto')
                                <input type="text" name="respuestas[{{ $respuesta->id ?? '' }}]" value="{{ $respuesta->respuesta ?? '' }}" class="form-input w-full rounded border border-gray-300" required>
                            @elseif($pregunta['tipo'] === 'numero')
                                <input type="number" name="respuestas[{{ $respuesta->id ?? '' }}]" value="{{ $respuesta->respuesta ?? '' }}" class="form-input w-full rounded border border-gray-300" required>
                            @elseif($pregunta['tipo'] === 'fecha')
                                <input type="date" name="respuestas[{{ $respuesta->id ?? '' }}]" value="{{ $respuesta->respuesta ?? '' }}" class="form-input w-full rounded border border-gray-300" required>
                            @elseif($pregunta['tipo'] === 'seleccion' && !empty($pregunta['opciones']))
                                <select name="respuestas[{{ $respuesta->id ?? '' }}]" class="form-select w-full rounded border border-gray-300" required>
                                    <option value="">Seleccione...</option>
                                    @foreach($pregunta['opciones'] as $op)
                                        <option value="{{ $op }}" @if(($respuesta->respuesta ?? '') == $op) selected @endif>{{ $op }}</option>
                                    @endforeach
                                </select>
                            @endif
                        </div>
                    @endif
                @endforeach
            </div>
            <div class="flex justify-end gap-4 mt-6">
                <button type="button" onclick="cerrarModalEditarFormulario()" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg font-semibold hover:bg-gray-300 transition">Cancelar</button>
                <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition">Guardar Cambios</button>
            </div>
        </form>
    </div>
</div>
@endsection 