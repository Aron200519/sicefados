@extends('fabricasoft::layouts.app')

@section('title', 'Mis Formularios - Seguimiento')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-clipboard-list"></i> Mis Formularios - Seguimiento
                    </h3>
                </div>
                <div class="card-body">
                    <!-- Estadísticas del usuario -->
                    <div class="row mb-4">
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-info">
                                <div class="inner">
                                    <h3>{{ $stats->total ?? 0 }}</h3>
                                    <p>Total Formularios</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-clipboard-list"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-warning">
                                <div class="inner">
                                    <h3>{{ $stats->pendientes ?? 0 }}</h3>
                                    <p>Pendientes</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-clock"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-primary">
                                <div class="inner">
                                    <h3>{{ $stats->en_desarrollo ?? 0 }}</h3>
                                    <p>En Desarrollo</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-code"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-success">
                                <div class="inner">
                                    <h3>{{ $stats->completados ?? 0 }}</h3>
                                    <p>Completados</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Filtros -->
                    <div class="row mb-3">
                        <div class="col-12">
                            <form method="GET" action="{{ route('fabricasoft.usuario.seguimiento.formularios') }}" class="form-inline">
                                <div class="form-group mr-2">
                                    <select name="estado" class="form-control form-control-sm">
                                        <option value="">Todos los estados</option>
                                        <option value="pendiente" {{ request('estado') == 'pendiente' ? 'selected' : '' }}>Pendiente</option>
                                        <option value="en_revision" {{ request('estado') == 'en_revision' ? 'selected' : '' }}>En Revisión</option>
                                        <option value="en_desarrollo" {{ request('estado') == 'en_desarrollo' ? 'selected' : '' }}>En Desarrollo</option>
                                        <option value="testing" {{ request('estado') == 'testing' ? 'selected' : '' }}>Testing</option>
                                        <option value="completado" {{ request('estado') == 'completado' ? 'selected' : '' }}>Completado</option>
                                        <option value="rechazado" {{ request('estado') == 'rechazado' ? 'selected' : '' }}>Rechazado</option>
                                        <option value="pausado" {{ request('estado') == 'pausado' ? 'selected' : '' }}>Pausado</option>
                                    </select>
                                </div>
                                <div class="form-group mr-2">
                                    <select name="formulario_id" class="form-control form-control-sm">
                                        <option value="">Todos los formularios</option>
                                        @foreach($formularios as $formulario)
                                            <option value="{{ $formulario->id }}" {{ request('formulario_id') == $formulario->id ? 'selected' : '' }}>
                                                {{ $formulario->nombre }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary btn-sm">
                                    <i class="fas fa-search"></i> Filtrar
                                </button>
                                <a href="{{ route('fabricasoft.usuario.seguimiento.formularios') }}" class="btn btn-secondary btn-sm ml-1">
                                    <i class="fas fa-times"></i> Limpiar
                                </a>
                            </form>
                        </div>
                    </div>

                    <!-- Tabla de seguimientos -->
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Formulario</th>
                                    <th>Desarrollador</th>
                                    <th>Estado</th>
                                    <th>Prioridad</th>
                                    <th>Fecha Envío</th>
                                    <th>Última Actualización</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($seguimientos as $seguimiento)
                                    <tr>
                                        <td>
                                            <strong>{{ $seguimiento->formulario->nombre ?? 'N/A' }}</strong>
                                            @if($seguimiento->comentarios)
                                                <br><small class="text-muted">{{ Str::limit($seguimiento->comentarios, 50) }}</small>
                                            @endif
                                        </td>
                                        <td>
                                            @if($seguimiento->assignedUser)
                                                <span class="badge badge-info">{{ $seguimiento->assignedUser->name }}</span>
                                            @else
                                                <span class="text-muted">Sin asignar</span>
                                            @endif
                                        </td>
                                        <td>
                                            <span class="badge {{ $seguimiento->estado_class }}">
                                                {{ $seguimiento->estado_legible }}
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge {{ $seguimiento->prioridad_class }}">
                                                {{ $seguimiento->prioridad_legible }}
                                            </span>
                                        </td>
                                        <td>{{ $seguimiento->fecha_envio->format('d/m/Y H:i') }}</td>
                                        <td>
                                            @if($seguimiento->updated_at)
                                                {{ $seguimiento->updated_at->format('d/m/Y H:i') }}
                                            @else
                                                <span class="text-muted">-</span>
                                            @endif
                                        </td>
                                        <td>
                                            <a href="{{ route('fabricasoft.usuario.seguimiento.detalles', $seguimiento->id) }}" 
                                               class="btn btn-info btn-sm" title="Ver detalles">
                                                <i class="fas fa-eye"></i> Ver
                                            </a>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="7" class="text-center">
                                            <div class="text-muted">
                                                <i class="fas fa-inbox fa-3x mb-3"></i>
                                                <p>No tienes formularios enviados</p>
                                                <a href="{{ route('cefa.fabricasoft.index') }}" class="btn btn-primary">
                                                    <i class="fas fa-plus"></i> Crear nuevo formulario
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    <!-- Paginación -->
                    <div class="d-flex justify-content-center">
                        {{ $seguimientos->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Timeline de estados -->
@if($seguimientos->count() > 0)
<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-chart-line"></i> Progreso de Formularios
                    </h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        @foreach($seguimientos->take(4) as $seguimiento)
                            <div class="col-md-6 col-lg-3 mb-3">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <h6 class="card-title">{{ $seguimiento->formulario->nombre ?? 'N/A' }}</h6>
                                        <div class="progress mb-2">
                                            @php
                                                $progreso = 0;
                                                switch($seguimiento->estado) {
                                                    case 'pendiente': $progreso = 10; break;
                                                    case 'en_revision': $progreso = 30; break;
                                                    case 'en_desarrollo': $progreso = 60; break;
                                                    case 'testing': $progreso = 80; break;
                                                    case 'completado': $progreso = 100; break;
                                                    case 'rechazado': $progreso = 0; break;
                                                    case 'pausado': $progreso = 40; break;
                                                }
                                            @endphp
                                            <div class="progress-bar bg-{{ $seguimiento->estado == 'completado' ? 'success' : ($seguimiento->estado == 'rechazado' ? 'danger' : 'primary') }}" 
                                                 style="width: {{ $progreso }}%">
                                                {{ $progreso }}%
                                            </div>
                                        </div>
                                        <small class="text-muted">
                                            {{ $seguimiento->estado_legible }}
                                        </small>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endif

@endsection

@push('scripts')
<script>
// Auto-refresh cada 30 segundos para mantener actualizado el estado
setInterval(function() {
    // Solo refrescar si no hay modales abiertos
    if ($('.modal').hasClass('show')) return;
    
    // Refrescar la página
    location.reload();
}, 30000);

// Mostrar notificación cuando se actualiza el estado
@if(session('success'))
    Swal.fire({
        icon: 'success',
        title: '¡Éxito!',
        text: '{{ session('success') }}',
        timer: 3000,
        showConfirmButton: false
    });
@endif

@if(session('error'))
    Swal.fire({
        icon: 'error',
        title: 'Error',
        text: '{{ session('error') }}'
    });
@endif
</script>
@endpush

