<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="{{ asset('images/Favicon2.png') }}" type="image/x-icon">
    <title>ADMIN</title>
    <!-- Google Font: Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --sena-green: #2ECC71;
            --sena-dark-green: #27AE60;
            --sena-light-green: #ECF9F2;
            --navbar-gradient: linear-gradient(90deg, #2ECC71 0%, #27AE60 100%);
        }
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f9fafb;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        .navbar {
            background: var(--navbar-gradient);
            height: 64px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 24px;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        .navbar .brand {
            color: white;
            font-size: 1.5rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: transform 0.3s ease, opacity 0.3s ease;
        }
        .navbar .brand:hover {
            transform: translateY(-2px);
            opacity: 0.95;
        }
        .navbar .brand i {
            font-size: 1.8rem;
        }
        .navbar .user-menu {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .navbar .user-menu .notification-bell {
            color: white;
            font-size: 1.2rem;
            padding: 8px;
            border-radius: 50%;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .navbar .user-menu .notification-bell:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: scale(1.1);
        }
        /* Notification specific styles */
        .notification-bell-container {
            position: relative;
        }
        .notification-count {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: #e53e3e; /* Red color for count */
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 0.7rem;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 18px; /* Ensure circular shape for single digits */
            height: 18px;
        }
        .notifications-dropdown {
            position: absolute;
            top: 50px; /* Adjust based on navbar height */
            right: 0;
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            width: 300px; /* Adjust width as needed */
            max-height: 400px; /* Max height with scroll */
            overflow-y: auto;
            z-index: 1000;
            display: none; /* Hidden by default */
        }
        .notifications-dropdown.show {
            display: block;
        }
        .notifications-dropdown-header {
            padding: 12px;
            font-weight: 600;
            border-bottom: 1px solid #e2e8f0;
            color: #2d3748;
        }
        .notification-item {
            padding: 12px;
            border-bottom: 1px solid #edf2f7;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }
        .notification-item:hover {
            background-color: #f7fafc;
        }
        .notification-item:last-child {
            border-bottom: none;
        }
        .notification-item strong {
            color: var(--sena-dark-green);
        }
        .notification-item p {
            font-size: 0.85rem;
            color: #4a5568;
        }
        .no-notifications {
            padding: 12px;
            color: #718096;
            text-align: center;
        }
        .navbar .user-menu .user-info {
            display: flex;
            align-items: center;
            gap: 8px;
            color: white;
            font-weight: 500;
            cursor: pointer;
            padding: 8px 14px;
            border-radius: 9999px;
            background-color: rgba(255, 255, 255, 0.1);
            transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
        }
        .navbar .user-menu .user-info:hover {
            background-color: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        .navbar .user-menu .user-avatar {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background-color: white;
            color: var(--sena-dark-green);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 14px;
            border: 2px solid var(--sena-light-green);
        }
        .navbar .mobile-toggle {
            display: none;
        }
        .sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            background-color: #ffffff;
            box-shadow: 2px 0 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
            z-index: 2000;
        }
        .sidebar-hidden {
            transform: translateX(-250px);
        }
        .content-wrapper {
            margin-left: 250px;
            padding: 24px;
            min-height: calc(100vh - 64px);
            transition: margin-left 0.3s ease-in-out;
            margin-top: 64px;
        }
        .content-wrapper-expanded {
            margin-left: 0;
        }
        .sidebar-header {
            padding: 16px;
            border-bottom: 2px solid var(--sena-green);
            background-color: #ffffff;
            color: var(--sena-dark-green);
            font-weight: 600;
            font-size: 1.25rem;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }
        .sidebar-header .mobile-toggle {
            display: block;
            color: var(--sena-dark-green);
            font-size: 1.5rem;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .sidebar-header .mobile-toggle:hover {
            background-color: var(--sena-light-green);
            transform: scale(1.1);
        }
        .sidebar-nav {
            padding: 16px;
        }
        .sidebar-nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar-nav li {
            margin-bottom: 8px;
        }
        .sidebar-nav a {
            display: flex;
            align-items: center;
            padding: 12px;
            border-radius: 8px;
            color: #1e293b;
            font-weight: 500;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }
        .sidebar-nav a:hover, .sidebar-nav a.active {
            background-color: var(--sena-light-green);
            color: var(--sena-dark-green);
            transform: translateX(5px);
        }
        .sidebar-nav .nav-icon {
            margin-right: 12px;
            font-size: 1.1rem;
        }
        .sidebar-nav .nav-treeview {
            padding-left: 24px;
            margin-top: 8px;
        }
        .sidebar-nav .nav-treeview a {
            font-size: 0.95rem;
        }
        .footer {
            background-color: var(--sena-dark-green);
            color: white;
            padding: 12px;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: calc(100% - 250px);
            margin-left: 250px;
            transition: margin-left 0.3s ease-in-out;
        }
        .footer-expanded {
            margin-left: 0;
            width: 100%;
        }
        .dropdown-menu {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(8px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1001;
            transform: translateY(-100%);
            transition: transform 0.3s ease-in-out;
            padding: 16px 24px;
        }
        .dropdown-menu.show {
            transform: translateY(0);
        }
        .dropdown-menu a {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            color: #1e293b;
            font-size: 1rem;
            font-weight: 500;
            border-radius: 6px;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }
        .dropdown-menu a:hover {
            background-color: var(--sena-light-green);
            color: var(--sena-dark-green);
            transform: translateX(4px);
        }
        .card {
            border-top: 4px solid var(--sena-green);
            border-radius: 0.75rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        .btn-success {
            background-color: var(--sena-green);
            border-color: var(--sena-green);
            transition: background-color 0.3s ease, border-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
        }
        .btn-success:hover {
            background-color: var(--sena-dark-green);
            border-color: var(--sena-dark-green);
            transform: scale(1.05);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        .modal-content {
            border-radius: 0.75rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        @media (max-width: 768px) {
            .navbar .mobile-toggle {
                display: block;
            }
            .navbar .brand {
                font-size: 1.2rem;
            }
            .sidebar {
                transform: translateX(-250px);
                z-index: 2000;
            }
            .sidebar.sidebar-visible {
                transform: translateX(0);
            }
            .content-wrapper {
                margin-left: 0;
            }
            .footer {
                margin-left: 0;
                width: 100%;
            }
            .dropdown-menu {
                padding: 12px 16px;
            }
            .dropdown-menu a {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper" style="visibility: hidden;">

        <!-- Dropdown Menu -->
        <div class="dropdown-menu hidden" id="dropdown-menu">
            <div class="flex justify-end items-center space-x-4">
                <button type="button" class="text-gray-500 text-2xl h-12 w-12 flex items-center justify-center hover:bg-gray-200 rounded-full" onclick="toggleDropdown()">×</button>
                <a href="#" class="block" onclick="confirmLogout(event, 'logout-form');">
                    <i class="fas fa-sign-out-alt mr-2"></i> Cerrar Sesión
                </a>
            </div>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="hidden">
                @csrf
            </form>
        </div>

        <!-- Navbar -->
        <nav class="navbar">
            <div class="flex items-center">
                <!-- Eliminado el icono de laptop y el span vacío -->
            </div>
            <div class="user-menu">
                <div class="notification-bell-container relative">
                    <button class="notification-bell" id="notification-bell-btn">
                        <i class="fas fa-bell"></i>
                        <span class="notification-count" id="notification-count">0</span>
                    </button>
                    <div class="notifications-dropdown" id="notifications-dropdown">
                        <div class="notifications-dropdown-header">Solicitudes Pendientes</div>
                        <div id="notification-list-container">
                            <!-- Notifications will be loaded here -->
                            <div class="no-notifications">No hay solicitudes pendientes.</div>
                        </div>
                    </div>
                </div>
                <div class="relative">
                    <button class="user-info focus:outline-none" id="navbarDropdown">
                        <div class="user-avatar">A</div>
                        <span>Admin</span>
                        <i class="fas fa-chevron-down text-xs"></i>
                    </button>
                </div>
            </div>
        </nav>

        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header flex items-center justify-between">
                <div class="flex items-center gap-2">
                    <i class="fas fa-cogs"></i>
                    <span>ADMIN</span>
                </div>
                <button class="mobile-toggle ml-2" id="toggle-sidebar">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            <div class="sidebar-nav">
                <nav>
                    <ul>
                        <li>
                            <a href="{{ route('fabricasoft.admin.welcome') }}" class="nav-link">
                                <i class="fas fa-home text-green-500 nav-icon"></i>
                                <span>Inicio</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.desarrolladores') }}" class="nav-link">
                                <i class="fas fa-users text-green-500 nav-icon"></i>
                                <span>Desarrolladores</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.solicitudes') }}" class="nav-link">
                                <i class="fas fa-headset text-green-500 nav-icon"></i>
                                <span>Solicitudes</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('fabricasoft.admin.preregistration.index') }}" class="nav-link">
                                <i class="fas fa-user-plus text-green-500 nav-icon"></i>
                                <span>Pre-registros</span>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="nav-link" id="servicios-menu-link">
                                <i class="fas fa-cogs text-green-500 nav-icon"></i>
                                <span>SERVICIOS</span>
                                <i class="fas fa-angle-left ml-auto transition-transform duration-200"></i>
                            </a>
                            <ul class="nav-treeview hidden" id="servicios-submenu">
                                <li>
                                    <a href="{{ route('fabricasoft.admin.solicitudes_soporte') }}" class="nav-link">
                                        <i class="fas fa-headset text-green-500 nav-icon"></i>
                                        <span>Solicitudes y soporte</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>

        <!-- Content Wrapper -->
        <div class="content-wrapper" id="content-wrapper">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
                <!-- Card para la Gestión de Proyectos -->
                <div class="card bg-white p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-2xl font-semibold text-gray-800">Gestión de Proyectos</h2>
                        <button onclick="toggleModal('add-project-modal')" class="btn-success text-white font-medium py-2 px-4 rounded-lg flex items-center gap-2">
                            <i class="fas fa-plus"></i> Agregar Proyecto
                        </button>
                    </div>

                    <!-- Tabla de Proyectos -->
                    <div class="overflow-x-auto">
                        <table class="w-full table-auto border-collapse">
                            <thead>
                                <tr class="bg-gray-100 text-gray-700">
                                    <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-xs sm:text-sm">ID</th>
                                    <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-xs sm:text-sm">Nombre del Proyecto</th>
                                    <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-xs sm:text-sm hidden md:table-cell">Descripción</th>
                                    <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-xs sm:text-sm">Estado</th>
                                    <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-xs sm:text-sm">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Ejemplo de fila (Placeholder) -->
                                <tr class="border-b hover:bg-sena-light-green transition-colors duration-200">
                                    <td class="px-2 sm:px-4 py-2 sm:py-3 text-gray-600 text-xs sm:text-sm">1</td>
                                    <td class="px-2 sm:px-4 py-2 sm:py-3 text-gray-800 text-xs sm:text-sm break-words">Sistema de Inventarios</td>
                                    <td class="px-2 sm:px-4 py-2 sm:py-3 text-gray-600 text-xs sm:text-sm hidden md:table-cell break-words">Plataforma para gestionar inventarios en tiempo real</td>
                                    <td class="px-2 sm:px-4 py-2 sm:py-3">
                                        <span class="inline-block bg-sena-green text-white text-xs font-semibold px-2 py-1 rounded">Activo</span>
                                    </td>
                                    <td class="px-2 sm:px-4 py-2 sm:py-3 flex gap-1 sm:gap-2">
                                        <button class="text-sena-dark-green hover:text-sena-green transition-colors p-1">
                                            <i class="fas fa-edit text-xs sm:text-sm"></i>
                                        </button>
                                        <button class="text-red-500 hover:text-red-600 transition-colors p-1">
                                            <i class="fas fa-trash text-xs sm:text-sm"></i>
                                        </button>
                                    </td>
                                </tr>
                                <tr class="border-b hover:bg-sena-light-green transition-colors duration-200">
                                    <td class="px-2 sm:px-4 py-2 sm:py-3 text-gray-600 text-xs sm:text-sm">2</td>
                                    <td class="px-2 sm:px-4 py-2 sm:py-3 text-gray-800 text-xs sm:text-sm break-words">Aplicación Móvil SENA</td>
                                    <td class="px-2 sm:px-4 py-2 sm:py-3 text-gray-600 text-xs sm:text-sm hidden md:table-cell break-words">App para estudiantes y administradores</td>
                                    <td class="px-2 sm:px-4 py-2 sm:py-3">
                                        <span class="inline-block bg-yellow-400 text-white text-xs font-semibold px-2 py-1 rounded">En Progreso</span>
                                    </td>
                                    <td class="px-2 sm:px-4 py-2 sm:py-3 flex gap-1 sm:gap-2">
                                        <button class="text-sena-dark-green hover:text-sena-green transition-colors p-1">
                                            <i class="fas fa-edit text-xs sm:text-sm"></i>
                                        </button>
                                        <button class="text-red-500 hover:text-red-600 transition-colors p-1">
                                            <i class="fas fa-trash text-xs sm:text-sm"></i>
                                        </button>
                                    </td>
                                </tr>
                                <!-- Más filas pueden ser añadidas dinámicamente -->
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Modal para Agregar Proyecto -->
                <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999] hidden p-4" id="add-project-modal">
                    <div class="bg-white rounded-lg p-6 w-full max-w-3xl lg:max-w-5xl max-h-[85vh] overflow-y-auto shadow-2xl relative">
                        <div class="flex justify-between items-center mb-6">
                            <h3 class="text-xl lg:text-2xl font-semibold text-gray-900">Agregar Nuevo Proyecto</h3>
                            <button onclick="toggleModal('add-project-modal')" class="text-gray-400 hover:text-gray-600 transition-colors p-2">
                                <i class="fas fa-times text-2xl"></i>
                            </button>
                        </div>
                        <form class="space-y-6">
                            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                <div>
                                    <label for="project-name" class="block text-sm font-medium text-gray-700 mb-2">Nombre del Proyecto *</label>
                                    <input type="text" id="project-name" required 
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                           placeholder="Ej. Sistema de Gestión">
                                </div>
                                <div>
                                    <label for="project-status" class="block text-sm font-medium text-gray-700 mb-2">Estado *</label>
                                    <select id="project-status" required 
                                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                        <option value="activo">Activo</option>
                                        <option value="en_progreso">En Progreso</option>
                                        <option value="completado">Completado</option>
                                    </select>
                                </div>
                            </div>
                            <div>
                                <label for="project-description" class="block text-sm font-medium text-gray-700 mb-2">Descripción *</label>
                                <textarea id="project-description" rows="4" required 
                                          class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                                          placeholder="Describe el proyecto..."></textarea>
                            </div>
                            <div class="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-4 pt-6 border-t border-gray-200">
                                <button type="button" onclick="toggleModal('add-project-modal')" 
                                        class="w-full sm:w-auto px-6 py-3 text-base font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors">
                                    Cancelar
                                </button>
                                <button type="submit" 
                                        class="w-full sm:w-auto px-6 py-3 text-base font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors">
                                    <i class="fas fa-plus mr-2"></i>Guardar Proyecto
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <footer class="footer" id="footer">
            <strong>Copyright © 2024-2025
                <a href="#" class="text-white hover:underline">ADMIN - SENA</a>.
            </strong>
            Todos los derechos reservados.
            <div class="float-right hidden sm:inline-block">
                <b>Versión</b> 1.0.0
            </div>
        </footer>
    </div>

    <!-- Botón para mostrar el menú lateral cuando está oculto -->
    <button id="show-sidebar-btn" style="display:none; position:fixed; top:32px; left:24px; z-index:3000; background:#2ECC71; color:white; padding:12px 16px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.2); border:none; font-size:1.5rem; cursor:pointer; transform:translateY(-50%);" onclick="toggleSidebar(true)">
        <i class="fas fa-bars"></i>
    </button>

    <script>
        // Mostrar contenido inmediatamente
        document.addEventListener('DOMContentLoaded', function () {
            const wrapper = document.querySelector('.wrapper');
            wrapper.style.visibility = 'visible';
            document.body.style.overflow = 'auto';
        });

        // Sidebar Toggle
        function toggleSidebar(forceShow = null) {
            const sidebar = document.getElementById('sidebar');
            const showSidebarBtn = document.getElementById('show-sidebar-btn');
            if (window.innerWidth <= 768) {
                // En móvil
                if (forceShow === true) {
                    sidebar.classList.add('sidebar-visible');
                } else if (forceShow === false) {
                    sidebar.classList.remove('sidebar-visible');
                } else {
                    sidebar.classList.toggle('sidebar-visible');
                }
            } else {
                // En escritorio
                if (forceShow === true) {
                    sidebar.classList.remove('sidebar-hidden');
                    document.getElementById('content-wrapper').classList.remove('content-wrapper-expanded');
                    document.getElementById('footer').classList.remove('footer-expanded');
                } else if (forceShow === false) {
                    sidebar.classList.add('sidebar-hidden');
                    document.getElementById('content-wrapper').classList.add('content-wrapper-expanded');
                    document.getElementById('footer').classList.add('footer-expanded');
                } else {
                    sidebar.classList.toggle('sidebar-hidden');
                    document.getElementById('content-wrapper').classList.toggle('content-wrapper-expanded');
                    document.getElementById('footer').classList.toggle('footer-expanded');
                }
            }
            checkSidebarBtn();
        }

        // Asignar eventos a ambos botones de hamburguesa
        document.addEventListener('DOMContentLoaded', function() {
            const sidebarToggleBtn = document.getElementById('toggle-sidebar');
            const showSidebarBtn = document.getElementById('show-sidebar-btn');
            if (sidebarToggleBtn) {
                sidebarToggleBtn.onclick = function() {
                    toggleSidebar();
                };
            }
            if (showSidebarBtn) {
                showSidebarBtn.onclick = function() {
                    // Siempre mostrar el menú al hacer clic
                    toggleSidebar(true);
                };
            }
            checkSidebarBtn();
        });

        // Mostrar el botón si el sidebar está oculto al cargar o al redimensionar
        function checkSidebarBtn() {
            const sidebar = document.getElementById('sidebar');
            const showSidebarBtn = document.getElementById('show-sidebar-btn');
            // Mostrar el botón si el sidebar está oculto
            if ((window.innerWidth <= 768 && !sidebar.classList.contains('sidebar-visible')) ||
                (window.innerWidth > 768 && sidebar.classList.contains('sidebar-hidden'))) {
                showSidebarBtn.style.display = 'block';
            } else {
                showSidebarBtn.style.display = 'none';
            }
        }
        window.addEventListener('resize', checkSidebarBtn);

        // Dropdown Menu
        function toggleDropdown() {
            const dropdown = document.getElementById('dropdown-menu');
            dropdown.classList.toggle('hidden');
            dropdown.classList.toggle('show');
        }

        document.getElementById('navbarDropdown').addEventListener('click', toggleDropdown);

        // Close Dropdown on Outside Click
        document.addEventListener('click', function (event) {
            const dropdown = document.getElementById('dropdown-menu');
            const toggle = document.getElementById('navbarDropdown');
            if (!toggle.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.add('hidden');
                dropdown.classList.remove('show');
            }
        });

        // Logout Confirmation
        function confirmLogout(event, formId) {
            event.preventDefault();
            Swal.fire({
                title: '¿Estás seguro?',
                text: '¿Deseas cerrar tu sesión?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#2ECC71',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, cerrar sesión',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById(formId).submit();
                }
            });
        }

            // Modal Toggle
    function toggleModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal.classList.contains('hidden')) {
            // Abrir modal
            modal.classList.remove('hidden');
            modal.classList.add('flex');
            document.body.style.overflow = 'hidden';
            
            // Ocultar sidebar si existe
            const sidebar = document.querySelector('.sidebar') || 
                           document.querySelector('.nav-sidebar') || 
                           document.querySelector('[class*="sidebar"]') ||
                           document.querySelector('[class*="nav"]');
            if (sidebar) {
                sidebar.style.display = 'none';
            }
            
            // Enfocar primer campo
            setTimeout(() => {
                const primerCampo = modal.querySelector('input, textarea, select');
                if (primerCampo) {
                    primerCampo.focus();
                }
            }, 100);
        } else {
            // Cerrar modal
            modal.classList.add('hidden');
            modal.classList.remove('flex');
            document.body.style.overflow = 'auto';
            
            // Mostrar sidebar si existe
            const sidebar = document.querySelector('.sidebar') || 
                           document.querySelector('.nav-sidebar') || 
                           document.querySelector('[class*="sidebar"]') ||
                           document.querySelector('[class*="nav"]');
            if (sidebar) {
                sidebar.style.display = 'block';
            }
            
            // Resetear formulario
            const form = modal.querySelector('form');
            if (form) {
                form.reset();
            }
        }
    }

        // Notifications (Placeholder)
        let pendingRequests = []; // Array to store pending requests

        async function fetchPendingRequests() {
            try {
                const response = await fetch('/fabricasoft/admin/notifications');
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();
                pendingRequests = data; // Store the fetched requests
                updateNotificationsDisplay();
            } catch (error) {
                console.error("Error fetching pending requests:", error);
                document.getElementById('notification-count').textContent = 'Error';
                document.getElementById('notification-list-container').innerHTML = '<div class="no-notifications">Error al cargar notificaciones.</div>';
            }
        }

        function updateNotificationsDisplay() {
            const countElement = document.getElementById('notification-count');
            const listContainer = document.getElementById('notification-list-container');
            countElement.textContent = pendingRequests.length;

            if (pendingRequests.length > 0) {
                listContainer.innerHTML = ''; // Clear previous notifications
                pendingRequests.forEach(request => {
                    const notificationItem = document.createElement('div');
                    notificationItem.className = 'notification-item';
                    notificationItem.innerHTML = `
                        <p><strong>Proyecto:</strong> ${request.project_name ?? 'N/A'}</p>
                        <p><strong>Cliente:</strong> ${request.applicant_name ?? 'N/A'}</p>
                        <p><strong>Tipo de Documento:</strong> ${request.document_type ?? 'N/A'}</p>
                        <p><strong>Número de Documento:</strong> ${request.document_number ?? 'N/A'}</p>
                        <p><strong>Email:</strong> ${request.email ?? 'N/A'}</p>
                        <p><strong>Estado:</strong> ${request.status ? (request.status.charAt(0).toUpperCase() + request.status.slice(1)) : 'N/A'}</p>
                    `;
                    notificationItem.addEventListener('click', () => {
                        if (request.type === 'preregistration') {
                            window.location.href = "{{ route('fabricasoft.admin.preregistration.index') }}";
                        } else {
                            window.location.href = `{{ url('fabricasoft/solicitudes') }}?id=${request.id}`;
                        }
                    });
                    listContainer.appendChild(notificationItem);
                });
            } else {
                listContainer.innerHTML = '<div class="no-notifications">No hay solicitudes pendientes.</div>';
            }
        }

        // Toggle notification dropdown
        document.getElementById('notification-bell-btn').addEventListener('click', function() {
            const dropdown = document.getElementById('notifications-dropdown');
            dropdown.classList.toggle('show');
        });

        // Close notification dropdown on outside click
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('notifications-dropdown');
            const toggle = document.getElementById('notification-bell-btn');
            if (!toggle.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });

        // Initial fetch and periodic refresh
        document.addEventListener('DOMContentLoaded', () => {
            fetchPendingRequests();
            setInterval(fetchPendingRequests, 30000); // Refresh every 30 seconds
        });

        // Original showNotifications (now deprecated for the new dropdown)
        function showNotifications() {
            Swal.fire({
                title: 'Notificaciones',
                text: 'Las notificaciones se muestran en el menú desplegable de la campana.',
                icon: 'info',
                confirmButtonColor: '#2ECC71'
            });
        }

        // Alerts Auto-Hide
        window.onload = function() {
            const successAlert = document.getElementById('alert-success');
            const errorAlert = document.getElementById('alert-error');
            if (successAlert) {
                setTimeout(() => successAlert.style.display = 'none', 3000);
            }
            if (errorAlert) {
                setTimeout(() => errorAlert.style.display = 'none', 4000);
            }
        };
    </script>
</body>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var serviciosLink = document.getElementById('servicios-menu-link');
    var serviciosSubmenu = document.getElementById('servicios-submenu');
    if (serviciosLink && serviciosSubmenu) {
        serviciosLink.addEventListener('click', function(e) {
            e.preventDefault();
            serviciosSubmenu.classList.toggle('hidden');
            var angle = this.querySelector('.fa-angle-left, .fa-angle-down');
            if (angle) {
                angle.classList.toggle('fa-angle-left');
                angle.classList.toggle('fa-angle-down');
            }
        });
        console.log('Script de menú de servicios enlazado');
    } else {
        console.log('No se encontró el enlace o submenú de servicios');
    }
});
</script>
</html>