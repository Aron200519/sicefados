@extends('fabricasoft::layouts.app')

@section('title', 'Formularios Asignados - Desarrollador')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-code"></i> Formularios Asignados
                    </h3>
                </div>
                <div class="card-body">
                    <!-- Estadísticas del desarrollador -->
                    <div class="row mb-4">
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-info">
                                <div class="inner">
                                    <h3>{{ $stats->total ?? 0 }}</h3>
                                    <p>Total Asignados</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-tasks"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-warning">
                                <div class="inner">
                                    <h3>{{ $stats->pendientes ?? 0 }}</h3>
                                    <p>Pendientes</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-clock"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-primary">
                                <div class="inner">
                                    <h3>{{ $stats->en_desarrollo ?? 0 }}</h3>
                                    <p>En Desarrollo</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-code"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-success">
                                <div class="inner">
                                    <h3>{{ $stats->completados ?? 0 }}</h3>
                                    <p>Completados</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Filtros -->
                    <div class="row mb-3">
                        <div class="col-12">
                            <form method="GET" action="{{ route('fabricasoft.desarrollador.seguimiento.formularios') }}" class="form-inline">
                                <div class="form-group mr-2">
                                    <select name="estado" class="form-control form-control-sm">
                                        <option value="">Todos los estados</option>
                                        <option value="pendiente" {{ request('estado') == 'pendiente' ? 'selected' : '' }}>Pendiente</option>
                                        <option value="en_revision" {{ request('estado') == 'en_revision' ? 'selected' : '' }}>En Revisión</option>
                                        <option value="en_desarrollo" {{ request('estado') == 'en_desarrollo' ? 'selected' : '' }}>En Desarrollo</option>
                                        <option value="testing" {{ request('estado') == 'testing' ? 'selected' : '' }}>Testing</option>
                                        <option value="completado" {{ request('estado') == 'completado' ? 'selected' : '' }}>Completado</option>
                                        <option value="rechazado" {{ request('estado') == 'rechazado' ? 'selected' : '' }}>Rechazado</option>
                                        <option value="pausado" {{ request('estado') == 'pausado' ? 'selected' : '' }}>Pausado</option>
                                    </select>
                                </div>
                                <div class="form-group mr-2">
                                    <select name="prioridad" class="form-control form-control-sm">
                                        <option value="">Todas las prioridades</option>
                                        <option value="1" {{ request('prioridad') == '1' ? 'selected' : '' }}>Baja</option>
                                        <option value="2" {{ request('prioridad') == '2' ? 'selected' : '' }}>Media</option>
                                        <option value="3" {{ request('prioridad') == '3' ? 'selected' : '' }}>Alta</option>
                                        <option value="4" {{ request('prioridad') == '4' ? 'selected' : '' }}>Urgente</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary btn-sm">
                                    <i class="fas fa-search"></i> Filtrar
                                </button>
                                <a href="{{ route('fabricasoft.desarrollador.seguimiento.formularios') }}" class="btn btn-secondary btn-sm ml-1">
                                    <i class="fas fa-times"></i> Limpiar
                                </a>
                            </form>
                        </div>
                    </div>

                    <!-- Tabla de seguimientos -->
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Formulario</th>
                                    <th>Usuario</th>
                                    <th>Estado</th>
                                    <th>Prioridad</th>
                                    <th>Fecha Asignación</th>
                                    <th>Tiempo Transcurrido</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($seguimientos as $seguimiento)
                                    <tr>
                                        <td>
                                            <strong>{{ $seguimiento->formulario->nombre ?? 'N/A' }}</strong>
                                            @if($seguimiento->comentarios)
                                                <br><small class="text-muted">{{ Str::limit($seguimiento->comentarios, 50) }}</small>
                                            @endif
                                        </td>
                                        <td>
                                            <span class="badge badge-secondary">{{ $seguimiento->user->name ?? 'N/A' }}</span>
                                            <br><small class="text-muted">{{ $seguimiento->user->email ?? 'N/A' }}</small>
                                        </td>
                                        <td>
                                            <span class="badge {{ $seguimiento->estado_class }}">
                                                {{ $seguimiento->estado_legible }}
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge {{ $seguimiento->prioridad_class }}">
                                                {{ $seguimiento->prioridad_legible }}
                                            </span>
                                        </td>
                                        <td>{{ $seguimiento->fecha_envio->format('d/m/Y H:i') }}</td>
                                        <td>
                                            @php
                                                $dias = $seguimiento->fecha_envio->diffInDays(now());
                                                $horas = $seguimiento->fecha_envio->diffInHours(now());
                                            @endphp
                                            @if($dias > 0)
                                                <span class="text-warning">{{ $dias }} día(s)</span>
                                            @else
                                                <span class="text-info">{{ $horas }} hora(s)</span>
                                            @endif
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="{{ route('fabricasoft.desarrollador.seguimiento.detalles', $seguimiento->id) }}" 
                                                   class="btn btn-info btn-sm" title="Ver detalles">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <button type="button" class="btn btn-warning btn-sm" 
                                                        onclick="actualizarEstado({{ $seguimiento->id }})" title="Actualizar estado">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="7" class="text-center">
                                            <div class="text-muted">
                                                <i class="fas fa-inbox fa-3x mb-3"></i>
                                                <p>No tienes formularios asignados</p>
                                            </div>
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    <!-- Paginación -->
                    <div class="d-flex justify-content-center">
                        {{ $seguimientos->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal para actualizar estado -->
<div class="modal fade" id="modalActualizarEstado" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Actualizar Estado del Formulario</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="formActualizarEstado">
                    <input type="hidden" id="seguimiento_id" name="seguimiento_id">
                    
                    <div class="form-group">
                        <label for="estado">Estado</label>
                        <select id="estado" name="estado" class="form-control" required>
                            <option value="pendiente">Pendiente</option>
                            <option value="en_revision">En Revisión</option>
                            <option value="en_desarrollo">En Desarrollo</option>
                            <option value="testing">Testing</option>
                            <option value="completado">Completado</option>
                            <option value="rechazado">Rechazado</option>
                            <option value="pausado">Pausado</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="comentarios">Comentarios del Desarrollador</label>
                        <textarea id="comentarios" name="comentarios" class="form-control" rows="4" 
                                  placeholder="Describe el progreso, problemas encontrados, o cualquier información relevante..."></textarea>
                    </div>

                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i>
                        <strong>Consejo:</strong> Mantén informado al usuario sobre el progreso de su solicitud.
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" onclick="guardarEstado()">Actualizar Estado</button>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
function actualizarEstado(id) {
    // Cargar datos del seguimiento
    fetch(`/fabricasoft/desarrollador/seguimiento-formularios/${id}/detalles`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('seguimiento_id').value = id;
            document.getElementById('estado').value = data.seguimiento.estado;
            document.getElementById('comentarios').value = data.seguimiento.respuesta_desarrollador || '';
            $('#modalActualizarEstado').modal('show');
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al cargar los datos del seguimiento');
        });
}

function guardarEstado() {
    const id = document.getElementById('seguimiento_id').value;
    const formData = new FormData(document.getElementById('formActualizarEstado'));
    
    fetch(`/fabricasoft/desarrollador/seguimiento-formularios/${id}/estado`, {
        method: 'PUT',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            estado: formData.get('estado'),
            comentarios: formData.get('comentarios')
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            $('#modalActualizarEstado').modal('hide');
            Swal.fire({
                icon: 'success',
                title: '¡Estado actualizado!',
                text: 'El estado del formulario ha sido actualizado correctamente.',
                timer: 2000,
                showConfirmButton: false
            }).then(() => {
                location.reload();
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: data.error || 'Error al actualizar el estado'
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Error al actualizar el estado del formulario'
        });
    });
}

// Auto-refresh cada 60 segundos para mantener actualizado el estado
setInterval(function() {
    // Solo refrescar si no hay modales abiertos
    if ($('.modal').hasClass('show')) return;
    
    // Refrescar la página
    location.reload();
}, 60000);

// Mostrar notificación cuando se actualiza el estado
@if(session('success'))
    Swal.fire({
        icon: 'success',
        title: '¡Éxito!',
        text: '{{ session('success') }}',
        timer: 3000,
        showConfirmButton: false
    });
@endif

@if(session('error'))
    Swal.fire({
        icon: 'error',
        title: 'Error',
        text: '{{ session('error') }}'
    });
@endif
</script>
@endpush

