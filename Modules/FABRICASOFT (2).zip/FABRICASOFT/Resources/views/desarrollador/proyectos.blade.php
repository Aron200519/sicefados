@extends('fabricasoft::layouts.masteraprendiz')

@section('title', 'Mis Proyectos')

@section('content')
<div class="container mx-auto px-4 py-8">
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-2">Mis Proyectos</h1>
        <p class="text-gray-600">Gestiona y visualiza todos tus proyectos asignados</p>
    </div>

    @if(session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
            {{ session('success') }}
        </div>
    @endif

    @if(session('error'))
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            {{ session('error') }}
        </div>
    @endif

    @if($proyectos->count() > 0)
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @foreach($proyectos as $proyecto)
                <div class="bg-white rounded-lg shadow-md border border-gray-200 overflow-hidden">
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="text-xl font-semibold text-gray-800">{{ $proyecto->project_name }}</h3>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                {{ ucfirst($proyecto->status) }}
                            </span>
                        </div>
                        
                        <div class="space-y-3 mb-4">
                            <div>
                                <p class="text-sm text-gray-600"><strong>Cliente:</strong> {{ $proyecto->applicant_name }}</p>
                                <p class="text-sm text-gray-600"><strong>Empresa:</strong> {{ $proyecto->company_name }}</p>
                                <p class="text-sm text-gray-600"><strong>Grupo:</strong> {{ $proyecto->grupo_nombre }}</p>
                            </div>
                        </div>

                        <div class="flex justify-between items-center">
                            <a href="{{ route('fabricasoft.desarrollador.proyecto.detalle', $proyecto->id) }}" 
                               class="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700 transition-colors">
                                <i class="fas fa-eye mr-2"></i>
                                Ver Detalles
                            </a>
                            
                            <div class="text-xs text-gray-500">
                                Creado: {{ \Carbon\Carbon::parse($proyecto->created_at)->format('d/m/Y') }}
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    @else
        <div class="text-center py-12">
            <div class="mb-4">
                <i class="fas fa-folder-open text-6xl text-gray-300"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-900 mb-2">No tienes proyectos asignados</h3>
            <p class="text-gray-500">Cuando te asignen a un proyecto, aparecerá aquí.</p>
        </div>
    @endif
</div>
@endsection 