@extends('fabricasoft::layouts.masteraprendiz')

@section('title', 'Detalle del Proyecto')

@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- Header del proyecto -->
    <div class="mb-8">
        <div class="flex items-center justify-between mb-4">
            <div>
                <h1 class="text-3xl font-bold text-gray-800">{{ $proyecto->project_name }}</h1>
                <p class="text-gray-600">{{ $proyecto->applicant_name }} - {{ $proyecto->company_name }}</p>
            </div>
            <a href="{{ route('fabricasoft.desarrollador.mis-proyectos') }}" 
               class="inline-flex items-center px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded-md hover:bg-gray-700 transition-colors">
                <i class="fas fa-arrow-left mr-2"></i>
                Volver
            </a>
        </div>

        <!-- Estadísticas del proyecto -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div class="bg-white p-4 rounded-lg shadow border">
                <div class="flex items-center">
                    <div class="p-2 bg-blue-100 rounded-lg">
                        <i class="fas fa-tasks text-blue-600"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-600">Total Tareas</p>
                        <p class="text-2xl font-bold text-gray-900">{{ $stats['total_tareas'] }}</p>
                    </div>
                </div>
            </div>

            <div class="bg-white p-4 rounded-lg shadow border">
                <div class="flex items-center">
                    <div class="p-2 bg-green-100 rounded-lg">
                        <i class="fas fa-check text-green-600"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-600">Tareas Completadas</p>
                        <p class="text-2xl font-bold text-gray-900">{{ $stats['tareas_completadas'] }}</p>
                    </div>
                </div>
            </div>

            <div class="bg-white p-4 rounded-lg shadow border">
                <div class="flex items-center">
                    <div class="p-2 bg-yellow-100 rounded-lg">
                        <i class="fas fa-file-alt text-yellow-600"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-600">Requerimientos</p>
                        <p class="text-2xl font-bold text-gray-900">{{ $stats['total_requerimientos'] }}</p>
                    </div>
                </div>
            </div>

            <div class="bg-white p-4 rounded-lg shadow border">
                <div class="flex items-center">
                    <div class="p-2 bg-purple-100 rounded-lg">
                        <i class="fas fa-chart-line text-purple-600"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-600">Avance General</p>
                        <p class="text-2xl font-bold text-gray-900">{{ round($stats['avance_general']) }}%</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @if(session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
            {{ session('success') }}
        </div>
    @endif

    <!-- Pestañas de contenido -->
    <div class="bg-white rounded-lg shadow border">
        <div class="border-b border-gray-200">
            <nav class="flex space-x-8 px-6" aria-label="Tabs">
                <button onclick="mostrarTab('tareas')" id="tab-tareas" class="tab-button active py-4 px-1 border-b-2 border-blue-500 font-medium text-sm text-blue-600">
                    <i class="fas fa-tasks mr-2"></i>Tareas
                </button>
                <button onclick="mostrarTab('requerimientos')" id="tab-requerimientos" class="tab-button py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700">
                    <i class="fas fa-file-alt mr-2"></i>Requerimientos
                </button>
                <button onclick="mostrarTab('avances')" id="tab-avances" class="tab-button py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700">
                    <i class="fas fa-chart-line mr-2"></i>Avances
                </button>
            </nav>
        </div>

        <!-- Contenido de Tareas -->
        <div id="contenido-tareas" class="tab-content p-6">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-lg font-medium text-gray-900">Tareas del Proyecto</h3>
                <button onclick="abrirModalTarea()" class="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700 transition-colors">
                    <i class="fas fa-plus mr-2"></i>Nueva Tarea
                </button>
            </div>

            @if($tareas->count() > 0)
                <div class="space-y-4">
                    @foreach($tareas as $tarea)
                        <div class="border border-gray-200 rounded-lg p-4">
                            <div class="flex items-center justify-between mb-2">
                                <h4 class="text-lg font-medium text-gray-900">{{ $tarea->titulo }}</h4>
                                <div class="flex items-center space-x-2">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-{{ $tarea->prioridad_color }}-100 text-{{ $tarea->prioridad_color }}-800">
                                        {{ ucfirst($tarea->prioridad) }}
                                    </span>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-{{ $tarea->estado_color }}-100 text-{{ $tarea->estado_color }}-800">
                                        {{ ucfirst(str_replace('_', ' ', $tarea->estado)) }}
                                    </span>
                                </div>
                            </div>
                            <p class="text-gray-600 mb-3">{{ $tarea->descripcion }}</p>
                            <div class="flex items-center justify-between text-sm text-gray-500">
                                <div>
                                    @if($tarea->asignadoA)
                                        <span><strong>Asignado a:</strong> {{ $tarea->asignadoA->nickname }}</span>
                                    @endif
                                    @if($tarea->fecha_limite)
                                        <span class="ml-4"><strong>Fecha límite:</strong> {{ $tarea->fecha_limite->format('d/m/Y') }}</span>
                                    @endif
                                </div>
                                <button onclick="editarTarea({{ $tarea->id }})" class="text-blue-600 hover:text-blue-800">
                                    <i class="fas fa-edit"></i> Editar
                                </button>
                            </div>
                        </div>
                    @endforeach
                </div>
            @else
                <div class="text-center py-8">
                    <i class="fas fa-tasks text-4xl text-gray-300 mb-4"></i>
                    <p class="text-gray-500">No hay tareas creadas para este proyecto</p>
                </div>
            @endif
        </div>

        <!-- Contenido de Requerimientos -->
        <div id="contenido-requerimientos" class="tab-content p-6 hidden">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-lg font-medium text-gray-900">Requerimientos del Proyecto</h3>
                <button onclick="abrirModalRequerimiento()" class="inline-flex items-center px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-md hover:bg-green-700 transition-colors">
                    <i class="fas fa-plus mr-2"></i>Nuevo Requerimiento
                </button>
            </div>

            @if($requerimientos->count() > 0)
                <div class="space-y-4">
                    @foreach($requerimientos as $req)
                        <div class="border border-gray-200 rounded-lg p-4">
                            <div class="flex items-center justify-between mb-2">
                                <h4 class="text-lg font-medium text-gray-900">{{ $req->titulo }}</h4>
                                <div class="flex items-center space-x-2">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-{{ $req->tipo_color }}-100 text-{{ $req->tipo_color }}-800">
                                        {{ ucfirst($req->tipo) }}
                                    </span>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-{{ $req->prioridad_color }}-100 text-{{ $req->prioridad_color }}-800">
                                        {{ ucfirst($req->prioridad) }}
                                    </span>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-{{ $req->estado_color }}-100 text-{{ $req->estado_color }}-800">
                                        {{ ucfirst(str_replace('_', ' ', $req->estado)) }}
                                    </span>
                                </div>
                            </div>
                            <p class="text-gray-600 mb-3">{{ $req->descripcion }}</p>
                            @if($req->criterios_aceptacion)
                                <div class="mb-3">
                                    <strong class="text-sm text-gray-700">Criterios de Aceptación:</strong>
                                    <p class="text-sm text-gray-600">{{ $req->criterios_aceptacion }}</p>
                                </div>
                            @endif
                            <div class="text-sm text-gray-500">
                                <span><strong>Creado por:</strong> {{ $req->creadoPor->nickname ?? 'N/A' }}</span>
                                <span class="ml-4"><strong>Fecha:</strong> {{ $req->created_at->format('d/m/Y') }}</span>
                            </div>
                        </div>
                    @endforeach
                </div>
            @else
                <div class="text-center py-8">
                    <i class="fas fa-file-alt text-4xl text-gray-300 mb-4"></i>
                    <p class="text-gray-500">No hay requerimientos creados para este proyecto</p>
                </div>
            @endif
        </div>

        <!-- Contenido de Avances -->
        <div id="contenido-avances" class="tab-content p-6 hidden">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-lg font-medium text-gray-900">Avances del Proyecto</h3>
                <button onclick="abrirModalAvance()" class="inline-flex items-center px-4 py-2 bg-purple-600 text-white text-sm font-medium rounded-md hover:bg-purple-700 transition-colors">
                    <i class="fas fa-plus mr-2"></i>Registrar Avance
                </button>
            </div>

            @if($avances->count() > 0)
                <div class="space-y-4">
                    @foreach($avances as $avance)
                        <div class="border border-gray-200 rounded-lg p-4">
                            <div class="flex items-center justify-between mb-2">
                                <h4 class="text-lg font-medium text-gray-900">{{ $avance->titulo }}</h4>
                                <div class="flex items-center space-x-2">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-{{ $avance->tipo_color }}-100 text-{{ $avance->tipo_color }}-800">
                                        <i class="{{ $avance->tipo_icon }} mr-1"></i>{{ ucfirst($avance->tipo) }}
                                    </span>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                        {{ $avance->porcentaje_avance }}%
                                    </span>
                                </div>
                            </div>
                            <p class="text-gray-600 mb-3">{{ $avance->descripcion }}</p>
                            @if($avance->comentarios)
                                <div class="mb-3 p-3 bg-gray-50 rounded">
                                    <strong class="text-sm text-gray-700">Comentarios:</strong>
                                    <p class="text-sm text-gray-600">{{ $avance->comentarios }}</p>
                                </div>
                            @endif
                            <div class="text-sm text-gray-500">
                                <span><strong>Registrado por:</strong> {{ $avance->usuario->nickname }}</span>
                                <span class="ml-4"><strong>Fecha:</strong> {{ $avance->created_at->format('d/m/Y H:i') }}</span>
                            </div>
                        </div>
                    @endforeach
                </div>
            @else
                <div class="text-center py-8">
                    <i class="fas fa-chart-line text-4xl text-gray-300 mb-4"></i>
                    <p class="text-gray-500">No hay avances registrados para este proyecto</p>
                </div>
            @endif
        </div>
    </div>
</div>

<!-- Modal para crear/editar tarea -->
<div id="modalTarea" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999] hidden p-4">
    <div class="bg-white rounded-lg p-6 w-full max-w-3xl lg:max-w-5xl max-h-[90vh] overflow-y-auto shadow-2xl relative">
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl lg:text-2xl font-semibold text-gray-900">Nueva Tarea</h3>
            <button onclick="cerrarModalTarea()" class="text-gray-400 hover:text-gray-600 transition-colors p-2">
                <i class="fas fa-times text-2xl"></i>
            </button>
        </div>
        
        <form id="formTarea" action="{{ route('fabricasoft.desarrollador.tareas.crear') }}" method="POST" class="space-y-6">
            @csrf
            <input type="hidden" name="proyecto_id" value="{{ $proyecto->id }}">
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Título *</label>
                    <input type="text" name="titulo" required 
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                           placeholder="Ingrese el título de la tarea">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Prioridad *</label>
                    <select name="prioridad" required 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="baja">Baja</option>
                        <option value="media" selected>Media</option>
                        <option value="alta">Alta</option>
                        <option value="urgente">Urgente</option>
                    </select>
                </div>
                </div>
                
                <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Descripción *</label>
                <textarea name="descripcion" rows="4" required 
                          class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                          placeholder="Describa los detalles de la tarea"></textarea>
                </div>
                
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Fecha Límite</label>
                    <input type="date" name="fecha_limite" 
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Asignado a</label>
                    <select name="asignado_a" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="">Sin asignar</option>
                        @foreach($proyecto->equipo ?? [] as $miembro)
                            <option value="{{ $miembro->id }}">{{ $miembro->nickname }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            
            <div class="space-y-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-3">
                        Tiempo Estimado: <span id="tiempo-valor" class="font-semibold text-blue-600 text-lg">8</span> horas
                    </label>
                    <div class="relative">
                        <input type="range" id="tiempo-slider" name="tiempo_estimado" 
                               min="1" max="40" value="8" step="1"
                               class="w-full h-4 bg-gray-200 rounded-lg appearance-none cursor-pointer slider">
                        <div class="flex justify-between text-sm text-gray-500 mt-3">
                            <span>1h</span>
                            <span>10h</span>
                            <span>20h</span>
                            <span>30h</span>
                            <span>40h</span>
                        </div>
                    </div>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-3">
                        Progreso Inicial: <span id="progreso-valor" class="font-semibold text-green-600 text-lg">0</span>%
                    </label>
                    <div class="relative">
                        <input type="range" id="progreso-slider" name="progreso_inicial" 
                               min="0" max="100" value="0" step="5"
                               class="w-full h-4 bg-gray-200 rounded-lg appearance-none cursor-pointer slider">
                        <div class="flex justify-between text-sm text-gray-500 mt-3">
                            <span>0%</span>
                            <span>25%</span>
                            <span>50%</span>
                            <span>75%</span>
                            <span>100%</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-4 pt-6 border-t border-gray-200">
                <button type="button" onclick="cerrarModalTarea()" 
                        class="w-full sm:w-auto px-6 py-3 text-base font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors">
                    Cancelar
                </button>
                <button type="submit" 
                        class="w-full sm:w-auto px-6 py-3 text-base font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors">
                    <i class="fas fa-plus mr-2"></i>Crear Tarea
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal para crear requerimiento -->
<div id="modalRequerimiento" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999] hidden p-4">
    <div class="bg-white rounded-lg p-6 w-full max-w-3xl lg:max-w-5xl max-h-[90vh] overflow-y-auto shadow-2xl relative">
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl lg:text-2xl font-semibold text-gray-900">Nuevo Requerimiento</h3>
            <button onclick="cerrarModalRequerimiento()" class="text-gray-400 hover:text-gray-600 transition-colors p-2">
                <i class="fas fa-times text-2xl"></i>
            </button>
        </div>
        
        <form id="formRequerimiento" action="{{ route('fabricasoft.desarrollador.requerimientos.crear') }}" method="POST" class="space-y-6">
            @csrf
            <input type="hidden" name="proyecto_id" value="{{ $proyecto->id }}">
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Título *</label>
                    <input type="text" name="titulo" required 
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
                           placeholder="Ingrese el título del requerimiento">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Tipo *</label>
                    <select name="tipo" required 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500">
                        <option value="funcional" selected>Funcional</option>
                        <option value="no_funcional">No Funcional</option>
                        <option value="técnico">Técnico</option>
                        <option value="usuario">Usuario</option>
                    </select>
                </div>
                </div>
                
                <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Descripción *</label>
                <textarea name="descripcion" rows="4" required 
                          class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 resize-none"
                          placeholder="Describa detalladamente el requerimiento"></textarea>
            </div>
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Prioridad *</label>
                    <select name="prioridad" required 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500">
                        <option value="baja">Baja</option>
                        <option value="media" selected>Media</option>
                        <option value="alta">Alta</option>
                        <option value="crítica">Crítica</option>
                    </select>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Complejidad</label>
                    <div class="relative">
                        <input type="range" id="complejidad-slider" name="complejidad" 
                               min="1" max="10" value="5" step="1"
                               class="w-full h-4 bg-gray-200 rounded-lg appearance-none cursor-pointer slider">
                        <div class="flex justify-between text-sm text-gray-500 mt-3">
                            <span>Baja</span>
                            <span>Media</span>
                            <span>Alta</span>
                        </div>
                        <div class="text-center text-sm text-gray-600 mt-2">
                            Nivel: <span id="complejidad-valor" class="font-semibold text-green-600">5</span>/10
                        </div>
                    </div>
                </div>
            </div>
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Criterios de Aceptación</label>
                <textarea name="criterios_aceptacion" rows="3" 
                          class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 resize-none"
                          placeholder="Defina los criterios para considerar el requerimiento como completado"></textarea>
            </div>
            
            <div class="space-y-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-3">
                        Tiempo Estimado: <span id="tiempo-req-valor" class="font-semibold text-green-600 text-lg">16</span> horas
                    </label>
                    <div class="relative">
                        <input type="range" id="tiempo-req-slider" name="tiempo_estimado" 
                               min="1" max="80" value="16" step="1"
                               class="w-full h-4 bg-gray-200 rounded-lg appearance-none cursor-pointer slider">
                        <div class="flex justify-between text-sm text-gray-500 mt-3">
                            <span>1h</span>
                            <span>20h</span>
                            <span>40h</span>
                            <span>60h</span>
                            <span>80h</span>
                        </div>
                    </div>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-3">
                        Urgencia: <span id="urgencia-valor" class="font-semibold text-orange-600 text-lg">Media</span>
                    </label>
                    <div class="relative">
                        <input type="range" id="urgencia-slider" name="urgencia" 
                               min="1" max="5" value="3" step="1"
                               class="w-full h-4 bg-gray-200 rounded-lg appearance-none cursor-pointer slider">
                        <div class="flex justify-between text-sm text-gray-500 mt-3">
                            <span>Muy Baja</span>
                            <span>Baja</span>
                            <span>Media</span>
                            <span>Alta</span>
                            <span>Crítica</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-4 pt-6 border-t border-gray-200">
                <button type="button" onclick="cerrarModalRequerimiento()" 
                        class="w-full sm:w-auto px-6 py-3 text-base font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors">
                    Cancelar
                </button>
                <button type="submit" 
                        class="w-full sm:w-auto px-6 py-3 text-base font-medium text-white bg-green-600 rounded-lg hover:bg-green-700 transition-colors">
                    <i class="fas fa-plus mr-2"></i>Crear Requerimiento
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal para registrar avance -->
<div id="modalAvance" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999] hidden p-4">
    <div class="bg-white rounded-lg p-6 w-full max-w-3xl lg:max-w-5xl max-h-[90vh] overflow-y-auto shadow-2xl relative">
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl lg:text-2xl font-semibold text-gray-900">Registrar Avance</h3>
            <button onclick="cerrarModalAvance()" class="text-gray-400 hover:text-gray-600 transition-colors p-2">
                <i class="fas fa-times text-2xl"></i>
            </button>
        </div>
        
        <form id="formAvance" action="{{ route('fabricasoft.desarrollador.avances.registrar') }}" method="POST" class="space-y-6">
            @csrf
            <input type="hidden" name="proyecto_id" value="{{ $proyecto->id }}">
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Título *</label>
                    <input type="text" name="titulo" required 
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                           placeholder="Ingrese el título del avance">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Tipo *</label>
                    <select name="tipo" required 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
                        <option value="desarrollo" selected>Desarrollo</option>
                        <option value="diseño">Diseño</option>
                        <option value="testing">Testing</option>
                        <option value="documentacion">Documentación</option>
                        <option value="reunion">Reunión</option>
                        <option value="otro">Otro</option>
                    </select>
                </div>
                </div>
                
                <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Descripción *</label>
                <textarea name="descripcion" rows="4" required 
                          class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500 resize-none"
                          placeholder="Describa detalladamente el avance realizado"></textarea>
            </div>
            
            <div class="space-y-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-3">
                        Porcentaje de Avance: <span id="avance-valor" class="font-semibold text-purple-600 text-lg">0</span>%
                    </label>
                    <div class="relative">
                        <input type="range" id="avance-slider" name="porcentaje_avance" 
                               min="0" max="100" value="0" step="5"
                               class="w-full h-4 bg-gray-200 rounded-lg appearance-none cursor-pointer slider">
                        <div class="flex justify-between text-sm text-gray-500 mt-3">
                            <span>0%</span>
                            <span>25%</span>
                            <span>50%</span>
                            <span>75%</span>
                            <span>100%</span>
                        </div>
                </div>
            </div>
            
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Comentarios</label>
                    <textarea name="comentarios" rows="3" 
                              class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500 resize-none"
                              placeholder="Agregue comentarios adicionales sobre el avance"></textarea>
                </div>
            </div>
            
            <div class="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-4 pt-6 border-t border-gray-200">
                <button type="button" onclick="cerrarModalAvance()" 
                        class="w-full sm:w-auto px-6 py-3 text-base font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors">
                    Cancelar
                </button>
                <button type="submit" 
                        class="w-full sm:w-auto px-6 py-3 text-base font-medium text-white bg-purple-600 rounded-lg hover:bg-purple-700 transition-colors">
                    <i class="fas fa-plus mr-2"></i>Registrar Avance
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Funciones para manejo de pestañas
function mostrarTab(tab) {
    // Ocultar todos los contenidos
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.add('hidden');
    });
    
    // Remover clase active de todos los botones
    document.querySelectorAll('.tab-button').forEach(button => {
        button.classList.remove('active', 'border-blue-500', 'text-blue-600');
        button.classList.add('border-transparent', 'text-gray-500');
    });
    
    // Mostrar contenido seleccionado
    document.getElementById('contenido-' + tab).classList.remove('hidden');
    
    // Activar botón seleccionado
    document.getElementById('tab-' + tab).classList.add('active', 'border-blue-500', 'text-blue-600');
    document.getElementById('tab-' + tab).classList.remove('border-transparent', 'text-gray-500');
}

// Funciones para modales
function abrirModalTarea() {
    document.getElementById('modalTarea').classList.remove('hidden');
    document.body.style.overflow = 'hidden';
    // Ocultar el sidebar usando la función global
    if (typeof toggleSidebar === 'function') {
        toggleSidebar(false);
    } else {
        const sidebar = document.querySelector('.sidebar') || 
                       document.querySelector('.nav-sidebar') || 
                       document.querySelector('[class*="sidebar"]') ||
                       document.querySelector('[class*="nav"]');
        if (sidebar) {
            sidebar.style.display = 'none';
        }
    }
    inicializarSlidersTarea();
                // Forzar scroll visible
            setTimeout(() => {
                const modalContent = document.querySelector('#modalTarea .bg-white');
                if (modalContent) {
                    modalContent.style.overflowY = 'scroll';
                    modalContent.style.maxHeight = '85vh';
                }
        // Enfocar el primer campo
        const primerCampo = document.querySelector('#modalTarea input[name="titulo"]');
        if (primerCampo) {
            primerCampo.focus();
        }
    }, 100);
}

function cerrarModalTarea() {
    document.getElementById('modalTarea').classList.add('hidden');
    document.body.style.overflow = 'auto';
    // Mostrar el sidebar usando la función global
    if (typeof toggleSidebar === 'function') {
        toggleSidebar(true);
    } else {
        const sidebar = document.querySelector('.sidebar') || 
                       document.querySelector('.nav-sidebar') || 
                       document.querySelector('[class*="sidebar"]') ||
                       document.querySelector('[class*="nav"]');
        if (sidebar) {
            sidebar.style.display = 'block';
        }
    }
    document.getElementById('formTarea').reset();
    resetearSlidersTarea();
}

function abrirModalRequerimiento() {
    document.getElementById('modalRequerimiento').classList.remove('hidden');
    document.body.style.overflow = 'hidden';
    // Ocultar el sidebar usando la función global
    if (typeof toggleSidebar === 'function') {
        toggleSidebar(false);
    } else {
        const sidebar = document.querySelector('.sidebar') || 
                       document.querySelector('.nav-sidebar') || 
                       document.querySelector('[class*="sidebar"]') ||
                       document.querySelector('[class*="nav"]');
        if (sidebar) {
            sidebar.style.display = 'none';
        }
    }
    inicializarSlidersRequerimiento();
                // Forzar scroll visible
            setTimeout(() => {
                const modalContent = document.querySelector('#modalRequerimiento .bg-white');
                if (modalContent) {
                    modalContent.style.overflowY = 'scroll';
                    modalContent.style.maxHeight = '85vh';
                }
        // Enfocar el primer campo
        const primerCampo = document.querySelector('#modalRequerimiento input[name="titulo"]');
        if (primerCampo) {
            primerCampo.focus();
        }
    }, 100);
}

function cerrarModalRequerimiento() {
    document.getElementById('modalRequerimiento').classList.add('hidden');
    document.body.style.overflow = 'auto';
    // Mostrar el sidebar usando la función global
    if (typeof toggleSidebar === 'function') {
        toggleSidebar(true);
    } else {
        const sidebar = document.querySelector('.sidebar') || 
                       document.querySelector('.nav-sidebar') || 
                       document.querySelector('[class*="sidebar"]') ||
                       document.querySelector('[class*="nav"]');
        if (sidebar) {
            sidebar.style.display = 'block';
        }
    }
    document.getElementById('formRequerimiento').reset();
    resetearSlidersRequerimiento();
}

function abrirModalAvance() {
    document.getElementById('modalAvance').classList.remove('hidden');
    document.body.style.overflow = 'hidden';
    // Ocultar el sidebar usando la función global
    if (typeof toggleSidebar === 'function') {
        toggleSidebar(false);
    } else {
        const sidebar = document.querySelector('.sidebar') || 
                       document.querySelector('.nav-sidebar') || 
                       document.querySelector('[class*="sidebar"]') ||
                       document.querySelector('[class*="nav"]');
        if (sidebar) {
            sidebar.style.display = 'none';
        }
    }
    inicializarSlidersAvance();
                // Forzar scroll visible
            setTimeout(() => {
                const modalContent = document.querySelector('#modalAvance .bg-white');
                if (modalContent) {
                    modalContent.style.overflowY = 'scroll';
                    modalContent.style.maxHeight = '85vh';
                }
        // Enfocar el primer campo
        const primerCampo = document.querySelector('#modalAvance input[name="titulo"]');
        if (primerCampo) {
            primerCampo.focus();
        }
    }, 100);
}

function cerrarModalAvance() {
    document.getElementById('modalAvance').classList.add('hidden');
    document.body.style.overflow = 'auto';
    // Mostrar el sidebar usando la función global
    if (typeof toggleSidebar === 'function') {
        toggleSidebar(true);
    } else {
        const sidebar = document.querySelector('.sidebar') || 
                       document.querySelector('.nav-sidebar') || 
                       document.querySelector('[class*="sidebar"]') ||
                       document.querySelector('[class*="nav"]');
        if (sidebar) {
            sidebar.style.display = 'block';
        }
    }
    document.getElementById('formAvance').reset();
    resetearSlidersAvance();
}

// Funciones para inicializar sliders
function inicializarSlidersTarea() {
    const tiempoSlider = document.getElementById('tiempo-slider');
    const tiempoValor = document.getElementById('tiempo-valor');
    const progresoSlider = document.getElementById('progreso-slider');
    const progresoValor = document.getElementById('progreso-valor');
    
    if (tiempoSlider && tiempoValor) {
        tiempoSlider.addEventListener('input', function() {
            tiempoValor.textContent = this.value;
        });
    }
    
    if (progresoSlider && progresoValor) {
        progresoSlider.addEventListener('input', function() {
            progresoValor.textContent = this.value;
        });
    }
}

function inicializarSlidersRequerimiento() {
    const complejidadSlider = document.getElementById('complejidad-slider');
    const complejidadValor = document.getElementById('complejidad-valor');
    const tiempoReqSlider = document.getElementById('tiempo-req-slider');
    const tiempoReqValor = document.getElementById('tiempo-req-valor');
    const urgenciaSlider = document.getElementById('urgencia-slider');
    const urgenciaValor = document.getElementById('urgencia-valor');
    
    if (complejidadSlider && complejidadValor) {
        complejidadSlider.addEventListener('input', function() {
            complejidadValor.textContent = this.value;
        });
    }
    
    if (tiempoReqSlider && tiempoReqValor) {
        tiempoReqSlider.addEventListener('input', function() {
            tiempoReqValor.textContent = this.value;
        });
    }
    
    if (urgenciaSlider && urgenciaValor) {
        urgenciaSlider.addEventListener('input', function() {
            const urgencias = ['Muy Baja', 'Baja', 'Media', 'Alta', 'Crítica'];
            urgenciaValor.textContent = urgencias[this.value - 1];
        });
    }
}

function inicializarSlidersAvance() {
    const avanceSlider = document.getElementById('avance-slider');
    const avanceValor = document.getElementById('avance-valor');
    
    if (avanceSlider && avanceValor) {
        avanceSlider.addEventListener('input', function() {
            avanceValor.textContent = this.value;
        });
    }
}

// Funciones para resetear sliders
function resetearSlidersTarea() {
    const tiempoSlider = document.getElementById('tiempo-slider');
    const tiempoValor = document.getElementById('tiempo-valor');
    const progresoSlider = document.getElementById('progreso-slider');
    const progresoValor = document.getElementById('progreso-valor');
    
    if (tiempoSlider && tiempoValor) {
        tiempoSlider.value = 8;
        tiempoValor.textContent = '8';
    }
    
    if (progresoSlider && progresoValor) {
        progresoSlider.value = 0;
        progresoValor.textContent = '0';
    }
}

function resetearSlidersRequerimiento() {
    const complejidadSlider = document.getElementById('complejidad-slider');
    const complejidadValor = document.getElementById('complejidad-valor');
    const tiempoReqSlider = document.getElementById('tiempo-req-slider');
    const tiempoReqValor = document.getElementById('tiempo-req-valor');
    const urgenciaSlider = document.getElementById('urgencia-slider');
    const urgenciaValor = document.getElementById('urgencia-valor');
    
    if (complejidadSlider && complejidadValor) {
        complejidadSlider.value = 5;
        complejidadValor.textContent = '5';
    }
    
    if (tiempoReqSlider && tiempoReqValor) {
        tiempoReqSlider.value = 16;
        tiempoReqValor.textContent = '16';
    }
    
    if (urgenciaSlider && urgenciaValor) {
        urgenciaSlider.value = 3;
        urgenciaValor.textContent = 'Media';
    }
}

function resetearSlidersAvance() {
    const avanceSlider = document.getElementById('avance-slider');
    const avanceValor = document.getElementById('avance-valor');
    
    if (avanceSlider && avanceValor) {
        avanceSlider.value = 0;
        avanceValor.textContent = '0';
    }
}

function editarTarea(tareaId) {
    // Implementar edición de tarea
    Swal.fire({
        title: 'Función en desarrollo',
        text: 'La edición de tareas estará disponible próximamente',
        icon: 'info',
        confirmButtonColor: '#3b82f6',
        confirmButtonText: 'Entendido'
    });
}

// Función global para ocultar/mostrar sidebar
function toggleSidebar(show) {
    const sidebar = document.querySelector('.sidebar') || 
                   document.querySelector('.nav-sidebar') || 
                   document.querySelector('[class*="sidebar"]') ||
                   document.querySelector('[class*="nav"]');
    if (sidebar) {
        sidebar.style.display = show ? 'block' : 'none';
    }
}

// Cerrar modales al hacer clic fuera
document.addEventListener('DOMContentLoaded', function() {
    
    // Cerrar modal de tareas al hacer clic fuera
    document.getElementById('modalTarea').addEventListener('click', function(e) {
        if (e.target === this) {
            cerrarModalTarea();
        }
    });
    
    // Cerrar modal de requerimientos al hacer clic fuera
    document.getElementById('modalRequerimiento').addEventListener('click', function(e) {
        if (e.target === this) {
            cerrarModalRequerimiento();
        }
    });
    
    // Cerrar modal de avances al hacer clic fuera
    document.getElementById('modalAvance').addEventListener('click', function(e) {
        if (e.target === this) {
            cerrarModalAvance();
        }
    });
    
    // Mejorar la funcionalidad de scroll en los modales
    function setupModalScroll(modalId) {
        const modal = document.getElementById(modalId);
        const modalContent = modal.querySelector('.bg-white');
        
        if (modalContent) {
            // Forzar scroll visible
            modalContent.style.overflowY = 'scroll';
            modalContent.style.maxHeight = '80vh';
            modalContent.classList.add('modal-scrollable');
            
            // Agregar indicador de scroll
            const scrollIndicator = document.createElement('div');
            scrollIndicator.className = 'modal-scroll-indicator';
            modalContent.appendChild(scrollIndicator);
            
            // Forzar que aparezca la barra de scroll
            setTimeout(() => {
                modalContent.style.overflowY = 'scroll';
                modalContent.style.maxHeight = '80vh';
                
                // Si el contenido es más alto que el contenedor, forzar scroll
                if (modalContent.scrollHeight > modalContent.clientHeight) {
                    modalContent.style.overflowY = 'scroll';
                }
            }, 100);
            
            // Mostrar/ocultar indicador de scroll
            modalContent.addEventListener('scroll', function() {
                const isScrollable = this.scrollHeight > this.clientHeight;
                const isAtBottom = this.scrollTop + this.clientHeight >= this.scrollHeight - 10;
                
                if (isScrollable && !isAtBottom) {
                    scrollIndicator.classList.add('visible');
                } else {
                    scrollIndicator.classList.remove('visible');
                }
            });
            
            // Scroll suave al hacer clic en el indicador
            scrollIndicator.addEventListener('click', function() {
                modalContent.scrollTo({
                    top: modalContent.scrollHeight,
                    behavior: 'smooth'
                });
            });
            
            // Asegurar que el scroll funcione en diferentes navegadores
            modalContent.addEventListener('wheel', function(e) {
                e.stopPropagation();
            });
        }
    }
    
    // Configurar scroll para todos los modales
    setupModalScroll('modalTarea');
    setupModalScroll('modalRequerimiento');
    setupModalScroll('modalAvance');
    
    // Mejorar la accesibilidad de los campos
    function enhanceFormFields(modalId) {
        const modal = document.getElementById(modalId);
        const inputs = modal.querySelectorAll('input, textarea, select');
        
        inputs.forEach(input => {
            // Asegurar que los campos sean interactivos
            input.style.pointerEvents = 'auto';
            input.style.position = 'relative';
            input.style.zIndex = '10';
            
            // Agregar indicador visual de campo requerido
            if (input.hasAttribute('required')) {
                const label = input.previousElementSibling;
                if (label && label.tagName === 'LABEL') {
                    if (!label.querySelector('.required-indicator')) {
                        const indicator = document.createElement('span');
                        indicator.className = 'required-indicator text-red-500 ml-1';
                        indicator.textContent = '*';
                        label.appendChild(indicator);
                    }
                }
            }
        });
    }
    
    // Mejorar campos en todos los modales
    enhanceFormFields('modalTarea');
    enhanceFormFields('modalRequerimiento');
    enhanceFormFields('modalAvance');
    
    // Cerrar modales con Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            if (!document.getElementById('modalTarea').classList.contains('hidden')) {
                cerrarModalTarea();
            } else if (!document.getElementById('modalRequerimiento').classList.contains('hidden')) {
                cerrarModalRequerimiento();
            } else if (!document.getElementById('modalAvance').classList.contains('hidden')) {
                cerrarModalAvance();
            }
        }
    });
    
    // Manejo de formularios con SweetAlert2
    document.getElementById('formTarea').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        
        fetch(this.action, {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                Swal.fire({
                    title: '¡Éxito!',
                    text: data.message || 'Tarea creada correctamente',
                    icon: 'success',
                    confirmButtonColor: '#3b82f6'
                }).then(() => {
                    window.location.reload();
                });
            } else {
                Swal.fire({
                    title: 'Error',
                    text: data.message || 'Error al crear la tarea',
                    icon: 'error',
                    confirmButtonColor: '#ef4444'
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            Swal.fire({
                title: 'Error',
                text: 'Error de conexión. Inténtalo de nuevo.',
                icon: 'error',
                confirmButtonColor: '#ef4444'
            });
        });
    });
    
    document.getElementById('formRequerimiento').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        
        fetch(this.action, {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                Swal.fire({
                    title: '¡Éxito!',
                    text: data.message || 'Requerimiento creado correctamente',
                    icon: 'success',
                    confirmButtonColor: '#10b981'
                }).then(() => {
                    window.location.reload();
                });
            } else {
                Swal.fire({
                    title: 'Error',
                    text: data.message || 'Error al crear el requerimiento',
                    icon: 'error',
                    confirmButtonColor: '#ef4444'
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            Swal.fire({
                title: 'Error',
                text: 'Error de conexión. Inténtalo de nuevo.',
                icon: 'error',
                confirmButtonColor: '#ef4444'
            });
        });
    });
    
    document.getElementById('formAvance').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        
        fetch(this.action, {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                Swal.fire({
                    title: '¡Éxito!',
                    text: data.message || 'Avance registrado correctamente',
                    icon: 'success',
                    confirmButtonColor: '#8b5cf6'
                }).then(() => {
                    window.location.reload();
                });
            } else {
                Swal.fire({
                    title: 'Error',
                    text: data.message || 'Error al registrar el avance',
                    icon: 'error',
                    confirmButtonColor: '#ef4444'
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            Swal.fire({
                title: 'Error',
                text: 'Error de conexión. Inténtalo de nuevo.',
                icon: 'error',
                confirmButtonColor: '#ef4444'
            });
        });
    });
});
</script>
<style>
/* Estilos para los sliders */
.slider {
    -webkit-appearance: none;
    appearance: none;
    height: 8px;
    border-radius: 4px;
    background: #e5e7eb;
    outline: none;
    transition: all 0.3s ease;
}

.slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #3b82f6;
    cursor: pointer;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    transition: all 0.3s ease;
}

.slider::-webkit-slider-thumb:hover {
    background: #2563eb;
    transform: scale(1.1);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
}

.slider::-moz-range-thumb {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #3b82f6;
    cursor: pointer;
    border: none;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    transition: all 0.3s ease;
}

.slider::-moz-range-thumb:hover {
    background: #2563eb;
    transform: scale(1.1);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
}

/* Estilos específicos para sliders de requerimientos */
#complejidad-slider::-webkit-slider-thumb,
#tiempo-req-slider::-webkit-slider-thumb,
#urgencia-slider::-webkit-slider-thumb {
    background: #10b981;
}

#complejidad-slider::-webkit-slider-thumb:hover,
#tiempo-req-slider::-webkit-slider-thumb:hover,
#urgencia-slider::-webkit-slider-thumb:hover {
    background: #059669;
}

#complejidad-slider::-moz-range-thumb,
#tiempo-req-slider::-moz-range-thumb,
#urgencia-slider::-moz-range-thumb {
    background: #10b981;
}

#complejidad-slider::-moz-range-thumb:hover,
#tiempo-req-slider::-moz-range-thumb:hover,
#urgencia-slider::-moz-range-thumb:hover {
    background: #059669;
}

/* Estilos específicos para sliders de avances */
#avance-slider::-webkit-slider-thumb {
    background: #8b5cf6;
}

#avance-slider::-webkit-slider-thumb:hover {
    background: #7c3aed;
}

#avance-slider::-moz-range-thumb {
    background: #8b5cf6;
}

#avance-slider::-moz-range-thumb:hover {
    background: #7c3aed;
}

/* Estilos para el modal responsive */
@media (max-width: 768px) {
    #modalTarea,
    #modalRequerimiento,
    #modalAvance {
        padding: 0.5rem;
        align-items: flex-start;
        padding-top: 1rem;
    }
    
    #modalTarea .bg-white,
    #modalRequerimiento .bg-white,
    #modalAvance .bg-white {
        margin: 0;
        max-height: calc(100vh - 1rem);
        width: calc(100vw - 1rem);
        border-radius: 0.5rem;
        padding: 1rem;
    }
    
    .slider::-webkit-slider-thumb {
        height: 24px;
        width: 24px;
    }
    
    .slider::-moz-range-thumb {
        height: 24px;
        width: 24px;
    }
}

@media (max-width: 640px) {
    #modalTarea,
    #modalRequerimiento,
    #modalAvance {
        padding: 0.25rem;
        padding-top: 0.5rem;
    }
    
    #modalTarea .bg-white,
    #modalRequerimiento .bg-white,
    #modalAvance .bg-white {
        padding: 1rem;
        max-height: calc(100vh - 0.5rem);
        width: calc(100vw - 0.5rem);
    }
    
    .grid-cols-1.lg\\:grid-cols-2 {
        grid-template-columns: 1fr;
    }
    
    .slider::-webkit-slider-thumb {
        height: 20px;
        width: 20px;
    }
    
    .slider::-moz-range-thumb {
        height: 20px;
        width: 20px;
    }
    
    /* Reducir espaciado en móviles */
    .space-y-6 > * + * {
        margin-top: 1rem;
    }
    
    .space-y-4 > * + * {
        margin-top: 0.75rem;
    }
    
    /* Botones más compactos en móviles */
    .flex.flex-col.sm\\:flex-row.justify-end.space-y-3.sm\\:space-y-0.sm\\:space-x-4 {
        gap: 0.5rem;
    }
    
    .px-6.py-3 {
        padding: 0.75rem 1rem;
    }
}

/* Animaciones para el modal */
@keyframes modalFadeIn {
    from {
        opacity: 0;
        transform: scale(0.95);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

#modalTarea:not(.hidden) .bg-white,
#modalRequerimiento:not(.hidden) .bg-white,
#modalAvance:not(.hidden) .bg-white {
    animation: modalFadeIn 0.3s ease-out;
}

/* Transiciones suaves */
.transition-colors {
    transition: all 0.2s ease-in-out;
}

/* Estilos para valores de sliders */
#tiempo-valor,
#progreso-valor,
#complejidad-valor,
#tiempo-req-valor,
#urgencia-valor,
#avance-valor {
    transition: color 0.2s ease;
}

/* Hover effects para botones */
button:hover {
    transform: translateY(-1px);
    transition: all 0.2s ease;
}

button:active {
    transform: translateY(0);
}

/* Estilos para los botones de pestañas */
.tab-button.active {
    border-bottom-color: #3b82f6;
    color: #3b82f6;
}

.tab-button:hover {
    color: #374151;
}

/* Estilos para el scroll de modales */
.overflow-y-auto {
    scrollbar-width: thin;
    scrollbar-color: #3b82f6 #f3f4f6;
    scroll-behavior: smooth;
    overflow-y: scroll !important;
    max-height: 80vh;
}

.overflow-y-auto::-webkit-scrollbar {
    width: 12px;
    display: block !important;
}

.overflow-y-auto::-webkit-scrollbar-track {
    background: #f3f4f6;
    border-radius: 6px;
    margin: 4px;
}

.overflow-y-auto::-webkit-scrollbar-thumb {
    background: #3b82f6;
    border-radius: 6px;
    border: 2px solid #f3f4f6;
}

.overflow-y-auto::-webkit-scrollbar-thumb:hover {
    background: #2563eb;
}

/* Forzar scroll en todos los modales */
#modalTarea .bg-white,
#modalRequerimiento .bg-white,
#modalAvance .bg-white {
    overflow-y: scroll !important;
    max-height: 85vh !important;
    scrollbar-width: thin;
    scrollbar-color: #3b82f6 #f3f4f6;
}

/* Estilos específicos para Firefox */
#modalTarea .bg-white,
#modalRequerimiento .bg-white,
#modalAvance .bg-white {
    scrollbar-width: thin;
    scrollbar-color: #3b82f6 #f3f4f6;
}

/* Asegurar que el scroll sea visible */
.modal-scrollable {
    overflow-y: scroll !important;
    max-height: 85vh !important;
}

/* Forzar scroll visible en todos los navegadores */
#modalTarea .bg-white,
#modalRequerimiento .bg-white,
#modalAvance .bg-white {
    overflow-y: scroll !important;
    max-height: 85vh !important;
    scrollbar-width: thin !important;
    scrollbar-color: #3b82f6 #f3f4f6 !important;
}

/* Estilos específicos para Chrome/Safari */
#modalTarea .bg-white::-webkit-scrollbar,
#modalRequerimiento .bg-white::-webkit-scrollbar,
#modalAvance .bg-white::-webkit-scrollbar {
    width: 12px !important;
    display: block !important;
}

#modalTarea .bg-white::-webkit-scrollbar-track,
#modalRequerimiento .bg-white::-webkit-scrollbar-track,
#modalAvance .bg-white::-webkit-scrollbar-track {
    background: #f3f4f6 !important;
    border-radius: 6px !important;
    margin: 4px !important;
}

#modalTarea .bg-white::-webkit-scrollbar-thumb,
#modalRequerimiento .bg-white::-webkit-scrollbar-thumb,
#modalAvance .bg-white::-webkit-scrollbar-thumb {
    background: #3b82f6 !important;
    border-radius: 6px !important;
    border: 2px solid #f3f4f6 !important;
}

#modalTarea .bg-white::-webkit-scrollbar-thumb:hover,
#modalRequerimiento .bg-white::-webkit-scrollbar-thumb:hover,
#modalAvance .bg-white::-webkit-scrollbar-thumb:hover {
    background: #2563eb !important;
}

/* Asegurar que el contenido del modal tenga altura suficiente para scroll */
#modalTarea .bg-white form,
#modalRequerimiento .bg-white form,
#modalAvance .bg-white form {
    min-height: 600px;
    padding-bottom: 2rem;
}

/* Mejorar la interactividad de los campos */
#modalTarea input,
#modalTarea textarea,
#modalTarea select,
#modalRequerimiento input,
#modalRequerimiento textarea,
#modalRequerimiento select,
#modalAvance input,
#modalAvance textarea,
#modalAvance select {
    position: relative;
    z-index: 10;
    pointer-events: auto;
}

/* Asegurar que los modales estén por encima de todo */
#modalTarea,
#modalRequerimiento,
#modalAvance {
    z-index: 9999 !important;
}

/* Mejorar el contraste del overlay */
#modalTarea::before,
#modalRequerimiento::before,
#modalAvance::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    z-index: -1;
}

/* Asegurar que el contenido del modal sea interactivo */
#modalTarea .bg-white,
#modalRequerimiento .bg-white,
#modalAvance .bg-white {
    position: relative;
    z-index: 10000;
    pointer-events: auto;
}

/* Mejorar la accesibilidad de los campos */
input:focus,
textarea:focus,
select:focus {
    outline: 2px solid #3b82f6;
    outline-offset: 2px;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

/* Indicador visual de scroll */
.modal-scroll-indicator {
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 40px;
    height: 4px;
    background: rgba(59, 130, 246, 0.3);
    border-radius: 2px;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.modal-scroll-indicator.visible {
    opacity: 1;
}
</style>
@endsection 