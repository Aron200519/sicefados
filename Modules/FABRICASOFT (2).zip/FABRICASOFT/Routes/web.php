<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;
use Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController;
use Modules\FABRICASOFT\Http\Controllers\NewRequestController;
use Modules\FABRICASOFT\Http\Controllers\GrupoController;
use Modules\FABRICASOFT\Http\Controllers\PreregistrationController;
use Modules\FABRICASOFT\Http\Controllers\DesarrolladorProyectoController;
use Modules\FABRICASOFT\Http\Controllers\AjustesController;
use Modules\FABRICASOFT\Http\Middleware\FabricasoftAuthMiddleware;
use Modules\FABRICASOFT\Http\Middleware\FabricasoftAdminMiddleware;

Route::prefix('fabricasoft')->group(function() {
    // Rutas públicas (no requieren autenticación)
    Route::get('/index', 'FABRICASOFTController@index')->name('cefa.fabricasoft.index');
    
    // Rutas públicas para ver formularios JSON (no requieren autenticación)
    Route::get('/formularios/{id}/ver-json', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'verFormularioJson'])->name('fabricasoft.formularios.ver-json');
    Route::get('/admin/formularios/{id}/ver-json', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'verFormularioJson'])->name('fabricasoft.admin.formularios.ver-json');
    
    // Rutas que requieren autenticación y roles de FABRICASOFT
    Route::middleware([\Modules\FABRICASOFT\Http\Middleware\FabricasoftSessionSecurityMiddleware::class, FabricasoftAuthMiddleware::class])->group(function() {
        Route::get('/apprentices/aprendiz', 'FABRICASOFTController@apprentices')->name('fabricasoft.apprentices.aprendiz');
        
        // Rutas específicas del aprendiz
        Route::get('/aprendiz/dashboard', 'FABRICASOFTController@aprendizDashboard')->name('fabricasoft.aprendiz.dashboard');
        Route::get('/aprendiz/proyectos', 'FABRICASOFTController@aprendizProyectos')->name('fabricasoft.aprendiz.proyectos');
        Route::get('/aprendiz/tareas', 'FABRICASOFTController@aprendizTareas')->name('fabricasoft.aprendiz.tareas');
        Route::get('/aprendiz/proyecto/{id}/tareas', 'FABRICASOFTController@getProyectoTareas')->name('fabricasoft.aprendiz.proyecto.tareas');
        Route::post('/aprendiz/proyecto/{id}/tareas', 'FABRICASOFTController@guardarTareaProyecto')->name('fabricasoft.aprendiz.proyecto.tareas.guardar');
        Route::put('/aprendiz/proyecto/{id}/tareas/{tareaId}', 'FABRICASOFTController@actualizarTareaProyecto')->name('fabricasoft.aprendiz.proyecto.tareas.actualizar');
        Route::delete('/aprendiz/proyecto/{id}/tareas/{tareaId}', 'FABRICASOFTController@eliminarTareaProyecto')->name('fabricasoft.aprendiz.proyecto.tareas.eliminar');
        Route::get('/aprendiz/requerimientos', 'FABRICASOFTController@aprendizRequerimientos')->name('fabricasoft.aprendiz.requerimientos');
        
        Route::post('/aprendiz/requerimientos/guardar', 'FABRICASOFTController@aprendizRequerimientosGuardar')->name('fabricasoft.aprendiz.requerimientos.guardar');
Route::delete('/aprendiz/requerimientos/{id}/eliminar', 'FABRICASOFTController@aprendizRequerimientosEliminar')->name('fabricasoft.aprendiz.requerimientos.eliminar');
        Route::get('/aprendiz/reportes', 'FABRICASOFTController@aprendizReportes')->name('fabricasoft.aprendiz.reportes');
        Route::get('/aprendiz/proyecto/{id}', 'FABRICASOFTController@aprendizProyectoDetalle')->name('fabricasoft.aprendiz.proyecto.detalle');
        Route::get('/aprendiz/proyecto/{id}/editar', 'FABRICASOFTController@aprendizProyectoEditar')->name('fabricasoft.aprendiz.proyecto.editar');
        Route::put('/aprendiz/proyecto/{id}/actualizar', 'FABRICASOFTController@aprendizProyectoActualizar')->name('fabricasoft.aprendiz.proyecto.actualizar');
        
        // Rutas para ajustes
        Route::get('/aprendiz/ajustes', [AjustesController::class, 'show'])->name('fabricasoft.aprendiz.ajustes');
        Route::post('/aprendiz/ajustes', [AjustesController::class, 'update'])->name('fabricasoft.aprendiz.ajustes.update');
        
        // Ruta para notificaciones del aprendiz
        Route::get('/aprendiz/notifications', 'FABRICASOFTController@notifications')->name('fabricasoft.aprendiz.notifications');
        
        // Rutas para notificaciones generales
        Route::get('/notifications', 'FABRICASOFTController@notificationsIndex')->name('notifications.index');
        Route::get('/notifications/{id}/read', 'FABRICASOFTController@markNotificationAsRead')->name('notifications.read');
        
        // Rutas para ajustes de cliente
        Route::get('/ajustes', [AjustesController::class, 'show'])->name('fabricasoft.ajustes');
        Route::post('/ajustes', [AjustesController::class, 'update'])->name('fabricasoft.ajustes.update');
        
        // Rutas para desarrolladores (alias de aprendiz)
        Route::get('/desarrollador/dashboard', 'FABRICASOFTController@aprendizDashboard')->name('fabricasoft.desarrollador.dashboard');
        Route::get('/desarrollador/proyectos', 'FABRICASOFTController@aprendizProyectos')->name('fabricasoft.desarrollador.proyectos');
        Route::get('/desarrollador/tareas', 'FABRICASOFTController@aprendizTareas')->name('fabricasoft.desarrollador.tareas');
        Route::get('/desarrollador/requerimientos', 'FABRICASOFTController@aprendizRequerimientos')->name('fabricasoft.desarrollador.requerimientos');
        Route::get('/desarrollador/reportes', 'FABRICASOFTController@aprendizReportes')->name('fabricasoft.desarrollador.reportes');
        
        // Nuevas rutas para gestión de proyectos del desarrollador
        Route::get('/desarrollador/mis-proyectos', [DesarrolladorProyectoController::class, 'misProyectos'])->name('fabricasoft.desarrollador.mis-proyectos');
        Route::get('/desarrollador/proyecto/{id}/detalle', [DesarrolladorProyectoController::class, 'proyectoDetalle'])->name('fabricasoft.desarrollador.proyecto.detalle');
        Route::post('/desarrollador/tareas/crear', [DesarrolladorProyectoController::class, 'crearTarea'])->name('fabricasoft.desarrollador.tareas.crear');
        Route::put('/desarrollador/tareas/{id}/actualizar', [DesarrolladorProyectoController::class, 'actualizarTarea'])->name('fabricasoft.desarrollador.tareas.actualizar');
        Route::post('/desarrollador/requerimientos/crear', [DesarrolladorProyectoController::class, 'crearRequerimiento'])->name('fabricasoft.desarrollador.requerimientos.crear');
        Route::post('/desarrollador/avances/registrar', [DesarrolladorProyectoController::class, 'registrarAvance'])->name('fabricasoft.desarrollador.avances.registrar');

        // Rutas para seguimiento de formularios (Desarrollador)
        Route::get('/desarrollador/seguimiento-formularios', [\Modules\FABRICASOFT\Http\Controllers\FormularioSeguimientoController::class, 'desarrolladorSeguimiento'])->name('fabricasoft.desarrollador.seguimiento.formularios');
        Route::get('/desarrollador/seguimiento-formularios/{id}/detalles', [\Modules\FABRICASOFT\Http\Controllers\FormularioSeguimientoController::class, 'detalles'])->name('fabricasoft.desarrollador.seguimiento.detalles');
        Route::put('/desarrollador/seguimiento-formularios/{id}/estado', [\Modules\FABRICASOFT\Http\Controllers\FormularioSeguimientoController::class, 'actualizarEstado'])->name('fabricasoft.desarrollador.seguimiento.actualizar-estado');
        
        Route::get('/users/users', 'FABRICASOFTController@users')->name('fabricasoft.users');
        Route::get('/cliente/dashboard', 'FABRICASOFTController@clienteDashboard')->name('fabricasoft.cliente.dashboard');
        Route::get('/cliente/proyecto/{id}/detalle', 'FABRICASOFTController@getDetalleProyectoCliente')->name('fabricasoft.cliente.proyecto.detalle');
        Route::get('/cliente/seguimiento', 'FABRICASOFTController@clienteSeguimiento')->name('fabricasoft.cliente.seguimiento');
        Route::get('/cliente/soporte', 'FABRICASOFTController@clienteSoporte')->name('fabricasoft.cliente.soporte');
        Route::get('/desarrolladores', 'FABRICASOFTController@desarrolladores')->name('fabricasoft.desarrolladores');
        Route::get('/solicitudes', 'FABRICASOFTController@solicitudes')->name('fabricasoft.solicitudes');
        Route::get('/solicitudes/filtrar-email', [FABRICASOFTController::class, 'filtrarSolicitudesPorEmail'])->name('fabricasoft.solicitudes.filtrar-email');
        Route::get('/solicitudes/{id}/details', [FABRICASOFTController::class, 'getRequestDetails'])->name('fabricasoft.solicitudes.details');
        Route::get('/solicitudes/{id}/details-json', [FABRICASOFTController::class, 'getRequestDetailsJson'])->name('fabricasoft.solicitudes.details.json');
        Route::get('/nuevasolicitud', 'FABRICASOFTController@nuevasolicitud')->name('fabricasoft.nuevasolicitud');
        Route::post('/nueva-solicitud', [FABRICASOFTController::class, 'storeNewRequest'])->name('fabricasoft.nueva-solicitud.store');
        Route::put('/solicitudes/{id}/update-status', [FABRICASOFTController::class, 'updateStatus'])->name('fabricasoft.solicitudes.update_status');
        Route::get('/pending-requests', [FABRICASOFTController::class, 'getPendingRequests'])->name('fabricasoft.pending_requests');
        
        // Rutas para editar, actualizar y eliminar solicitudes de usuario
        Route::get('/solicitudes/{id}/edit', [NewRequestController::class, 'edit'])->name('fabricasoft.solicitudes.edit');
        Route::put('/solicitudes/{id}', [NewRequestController::class, 'update'])->name('fabricasoft.solicitudes.update');
        Route::delete('/solicitudes/{id}', [NewRequestController::class, 'destroy'])->name('fabricasoft.solicitudes.destroy');
        
        // Rutas para grupos
        Route::post('/grupos/store', [GrupoController::class, 'store'])->name('fabricasoft.grupos.store');
Route::put('/grupos/{id}/update', [GrupoController::class, 'update'])->name('fabricasoft.grupos.update');
Route::delete('/grupos/{id}/destroy', [GrupoController::class, 'destroy'])->name('fabricasoft.grupos.destroy');
Route::get('/grupos/{id}/equipo', [GrupoController::class, 'getEquipo'])->name('fabricasoft.grupos.equipo');
        Route::get('/grupos/{id}/ver', [FABRICASOFTController::class, 'verGrupo'])->name('fabricasoft.grupos.ver');
        Route::get('/grupos/{id}/ver-json', [FABRICASOFTController::class, 'verGrupoJson'])->name('fabricasoft.grupos.ver.json');
        
        // Rutas para formularios de usuario
        Route::post('/usuario/guardar-respuestas', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'guardarRespuestasFormulario']);
        Route::get('/usuario/formulario/{servicio_id}/respuestas', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'obtenerRespuestasFormulario'])->name('fabricasoft.usuario.formulario.respuestas');
        Route::get('/usuario/formulario/{servicio_id}/editar', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'editarFormularioLlenado'])->name('fabricasoft.usuario.formulario.editar');
        Route::post('/usuario/formulario/{servicio_id}/actualizar', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'actualizarFormularioLlenado'])->name('fabricasoft.usuario.formulario.actualizar');
        Route::post('/usuario/formulario/{servicio_id}/eliminar', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'eliminarFormularioLlenado'])->name('fabricasoft.usuario.formulario.eliminar');

        // Rutas para seguimiento de formularios (Usuario)
        Route::get('/usuario/seguimiento-formularios', [\Modules\FABRICASOFT\Http\Controllers\FormularioSeguimientoController::class, 'usuarioSeguimiento'])->name('fabricasoft.usuario.seguimiento.formularios');
        Route::get('/usuario/seguimiento-formularios/{id}/detalles', [\Modules\FABRICASOFT\Http\Controllers\FormularioSeguimientoController::class, 'detalles'])->name('fabricasoft.usuario.seguimiento.detalles');
    });
    
    // Rutas que requieren autenticación y rol de administrador
    Route::middleware([\Modules\FABRICASOFT\Http\Middleware\FabricasoftSessionSecurityMiddleware::class, FabricasoftAdminMiddleware::class])->group(function() {
        Route::get('/admin/welcome', 'FABRICASOFTController@admin')->name('fabricasoft.admin.welcome');
        Route::get('/admin/dashboard', 'FABRICASOFTController@admin')->name('fabricasoft.admin.dashboard');
        
        // Rutas para gestión de usuarios
        Route::get('/admin/users', 'FABRICASOFTController@admin')->name('fabricasoft.admin.users.index');
        Route::get('/admin/users/create', 'FABRICASOFTController@createUser')->name('fabricasoft.admin.users.create');
        Route::post('/admin/users/store', 'FABRICASOFTController@storeUser')->name('fabricasoft.admin.users.store');
        Route::get('/admin/users/{id}/edit', 'FABRICASOFTController@editUser')->name('fabricasoft.admin.users.edit');
        Route::put('/admin/users/update/{id}', 'FABRICASOFTController@updateUser')->name('fabricasoft.admin.users.update');
        Route::delete('/admin/users/destroy/{id}', 'FABRICASOFTController@destroyUser')->name('fabricasoft.admin.users.destroy');
        
        // Rutas para pre-registro
        Route::post('/preregister/store', [PreregistrationController::class, 'store'])->name('fabricasoft.preregister.store');
        Route::get('/admin/preregistration', [PreregistrationController::class, 'index'])->name('fabricasoft.admin.preregistration.index');
        Route::post('/admin/preregistration/{id}/approve', [PreregistrationController::class, 'approve'])->name('fabricasoft.admin.preregistration.approve');
        Route::post('/admin/preregistration/{id}/reject', [PreregistrationController::class, 'reject'])->name('fabricasoft.admin.preregistration.reject');
        
        // Rutas administrativas adicionales
        Route::get('/admin/solicitudes-soporte', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'solicitudesSoporte'])->name('fabricasoft.admin.solicitudes_soporte');
        Route::get('/admin/proyectos', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'proyectos'])->name('fabricasoft.admin.proyectos');
        Route::get('/admin/avance-proyectos', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'avanceProyectos'])->name('fabricasoft.admin.avance_proyectos');
        Route::get('/admin/seguimiento', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'seguimiento'])->name('fabricasoft.admin.seguimiento');
        Route::get('/admin/notifications', 'FABRICASOFTController@notifications')->name('fabricasoft.admin.notifications');
        Route::get('/admin/gestion-roles', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'getGestionRoles'])->name('fabricasoft.admin.gestion-roles');
        Route::post('/admin/asignar-desarrollador', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'asignarDesarrollador'])->name('fabricasoft.admin.asignar-desarrollador');
        Route::get('/admin/proyecto/{id}/equipo', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'getEquipoProyecto'])->name('fabricasoft.admin.proyecto.equipo');
        Route::post('/admin/actualizar-progreso', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'actualizarProgresoGeneral'])->name('fabricasoft.admin.actualizar-progreso');
        
        // Rutas para seguimiento de avance
        Route::get('/admin/proyecto/{id}/detalle-avance', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'getDetalleAvance'])->name('fabricasoft.admin.proyecto.detalle_avance');
        Route::put('/admin/proyecto/{id}/actualizar-progreso', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'actualizarProgreso'])->name('fabricasoft.admin.proyecto.actualizar_progreso');
        Route::get('/admin/proyecto/{id}/generar-reporte', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'generarReporteAvance'])->name('fabricasoft.admin.proyecto.generar_reporte');
        Route::get('/admin/proyecto/{id}/historial', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'getHistorialProyecto'])->name('fabricasoft.admin.proyecto.historial');
        
        // Rutas para gestión de tareas del avance de proyectos
        Route::post('/admin/avance-proyectos/tareas/crear', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'crearTareaAvance'])->name('fabricasoft.admin.avance_proyectos.tareas.crear');
        Route::put('/admin/avance-proyectos/tareas/{id}/actualizar', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'actualizarTareaAvance'])->name('fabricasoft.admin.avance_proyectos.tareas.actualizar');
        Route::delete('/admin/avance-proyectos/tareas/{id}/eliminar', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'eliminarTareaAvance'])->name('fabricasoft.admin.avance_proyectos.tareas.eliminar');
        
        // Rutas para ajustes de admin
        Route::get('/admin/ajustes', [AjustesController::class, 'show'])->name('fabricasoft.admin.ajustes');
        Route::post('/admin/ajustes', [AjustesController::class, 'update'])->name('fabricasoft.admin.ajustes.update');
        
        // Rutas para notificaciones
        Route::get('/notifications', 'FABRICASOFTController@notificationsIndex')->name('notifications.index');
        Route::get('/notifications/{id}/read', 'FABRICASOFTController@markNotificationAsRead')->name('notifications.read');

        // Rutas para formularios administrativos
        Route::get('/admin/formularios/crear', function() {
            return view('fabricasoft::admin.formularios_crear');
        })->name('fabricasoft.admin.formularios.crear');
        Route::post('/admin/formularios/store', 'FABRICASOFTController@storeFormularioPersonalizado')->name('fabricasoft.admin.formularios.store');
        Route::get('/admin/formularios', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'listarFormularios'])->name('fabricasoft.admin.formularios.listado');
        Route::get('/admin/formularios/{id}/ver', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'verFormulario'])->name('fabricasoft.admin.formularios.ver');
        Route::get('/admin/formularios/{id}/editar', 'FABRICASOFTController@editarFormulario')->name('fabricasoft.admin.formularios.editar');
        Route::delete('/admin/formularios/{id}/eliminar', 'FABRICASOFTController@eliminarFormulario')->name('fabricasoft.admin.formularios.eliminar');
        // Esta ruta se movió fuera del middleware de admin para ser accesible desde la vista de usuario
        Route::put('/admin/formularios/{id}/update', 'FABRICASOFTController@updateFormulario')->name('fabricasoft.admin.formularios.update');
        Route::post('/admin/servicios/asociar-formulario', [\Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController::class, 'asociarFormularioServicio']);
        Route::post('/admin/asignar-aprendiz', 'FABRICASOFTController@asignarAprendiz')->name('fabricasoft.admin.asignar-aprendiz');

        // Rutas para seguimiento de formularios (Admin)
        Route::get('/admin/seguimiento-formularios', [\Modules\FABRICASOFT\Http\Controllers\FormularioSeguimientoController::class, 'adminSeguimiento'])->name('fabricasoft.admin.seguimiento.formularios');
        Route::get('/admin/seguimiento-formularios/exportar', [\Modules\FABRICASOFT\Http\Controllers\FormularioSeguimientoController::class, 'exportar'])->name('fabricasoft.admin.seguimiento.exportar');
        Route::get('/admin/seguimiento-formularios/{id}/detalles', [\Modules\FABRICASOFT\Http\Controllers\FormularioSeguimientoController::class, 'detalles'])->name('fabricasoft.admin.seguimiento.detalles');
        Route::put('/admin/seguimiento-formularios/{id}/estado', [\Modules\FABRICASOFT\Http\Controllers\FormularioSeguimientoController::class, 'actualizarEstado'])->name('fabricasoft.admin.seguimiento.actualizar-estado');
        Route::post('/admin/seguimiento-formularios/{id}/asignar-desarrollador', [\Modules\FABRICASOFT\Http\Controllers\FormularioSeguimientoController::class, 'asignarDesarrollador'])->name('fabricasoft.admin.seguimiento.asignar-desarrollador');
    });
});
