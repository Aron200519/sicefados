<?php

namespace Modules\FABRICASOFT\Emails;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use App\Models\PreregistrationRequest;

class PreregistrationNotification extends Mailable
{
    use Queueable, SerializesModels;

    public $preregistration;
    public $type; // 'admin', 'approval', 'rejection'

    public function __construct(PreregistrationRequest $preregistration, $type = 'admin')
    {
        $this->preregistration = $preregistration;
        $this->type = $type;
    }

    public function build()
    {
        $subject = '';
        $view = '';

        switch ($this->type) {
            case 'admin':
                $subject = 'Nueva solicitud de pre-registro - FABRICASOFT';
                $view = 'fabricasoft::emails.admin-notification';
                break;
            case 'approval':
                $subject = 'Solicitud aprobada - FABRICASOFT';
                $view = 'fabricasoft::emails.approval-notification';
                break;
            case 'rejection':
                $subject = 'Solicitud rechazada - FABRICASOFT';
                $view = 'fabricasoft::emails.rejection-notification';
                break;
        }

        return $this->subject($subject)
                    ->view($view);
    }
} 