<?php

namespace Modules\FABRICASOFT\Emails;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class NotificacionEliminacionPreregistro extends Mailable
{
    use Queueable, SerializesModels;

    public $preregistro;

    public function __construct($preregistro)
    {
        $this->preregistro = $preregistro;
    }

    public function build()
    {
        return $this->subject('Eliminación de preregistro rechazado - FABRICASOFT')
            ->view('fabricasoft::emails.eliminacion-preregistro');
    }
} 