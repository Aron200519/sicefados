<?php

namespace Modules\FABRICASOFT\Emails;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class NotificacionEliminacionSolicitud extends Mailable
{
    use Queueable, SerializesModels;

    public $solicitud;

    public function __construct($solicitud)
    {
        $this->solicitud = $solicitud;
    }

    public function build()
    {
        return $this->subject('Eliminación de solicitud rechazada - FABRICASOFT')
            ->view('fabricasoft::emails.eliminacion-solicitud');
    }
} 