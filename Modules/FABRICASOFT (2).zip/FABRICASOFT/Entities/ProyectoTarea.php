<?php

namespace Modules\FABRICASOFT\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProyectoTarea extends Model
{
    protected $table = 'proyecto_tareas';
    
    protected $fillable = [
        'proyecto_id',
        'asignado_por',
        'asignado_a',
        'titulo',
        'descripcion',
        'prioridad',
        'fecha_limite',
        'tiempo_estimado',
        'progreso',
        'estado',
        'comentarios',
        'fecha_inicio',
        'fecha_completado'
    ];

    protected $casts = [
        'fecha_limite' => 'date',
        'fecha_inicio' => 'datetime',
        'fecha_completado' => 'datetime',
        'tiempo_estimado' => 'integer',
        'progreso' => 'integer'
    ];

    /**
     * Relación con el proyecto
     */
    public function proyecto(): BelongsTo
    {
        return $this->belongsTo(NewRequest::class, 'proyecto_id');
    }

    /**
     * Relación con el usuario asignado
     */
    public function asignadoA(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class, 'asignado_a');
    }

    /**
     * Relación con el usuario que asignó la tarea
     */
    public function asignadoPor(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class, 'asignado_por');
    }
}
