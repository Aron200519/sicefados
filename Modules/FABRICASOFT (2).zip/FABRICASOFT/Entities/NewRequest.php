<?php

namespace Modules\FABRICASOFT\Entities;

use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class NewRequest extends Model
{
    protected $table = 'new_request';
    
    // Constantes para estados de proyecto
    const STATUS_PENDIENTE = 'pendiente';
    const STATUS_EN_DESARROLLO = 'en_desarrollo';
    const STATUS_REVISION = 'revision';
    const STATUS_TESTING = 'testing';
    const STATUS_APROBADA = 'aprobada';
    const STATUS_COMPLETADO = 'completado';
    const STATUS_RECHAZADO = 'rechazado';
    const STATUS_PAUSADO = 'pausado';
    
    // Array de estados válidos
    public static $estadosValidos = [
        self::STATUS_PENDIENTE,
        self::STATUS_EN_DESARROLLO,
        self::STATUS_REVISION,
        self::STATUS_TESTING,
        self::STATUS_APROBADA,
        self::STATUS_COMPLETADO,
        self::STATUS_RECHAZADO,
        self::STATUS_PAUSADO
    ];
    
    // Array de estados para validación
    public static function getEstadosParaValidacion()
    {
        return implode(',', self::$estadosValidos);
    }
    
    // Método estático para obtener el nombre legible de un estado específico
    public static function getEstadoLegible($status)
    {
        $estados = [
            self::STATUS_PENDIENTE => 'Pendiente',
            self::STATUS_EN_DESARROLLO => 'En Desarrollo',
            self::STATUS_REVISION => 'Revisión',
            self::STATUS_TESTING => 'Testing',
            self::STATUS_APROBADA => 'Aprobada',
            self::STATUS_COMPLETADO => 'Completado',
            self::STATUS_RECHAZADO => 'Rechazado',
            self::STATUS_PAUSADO => 'Pausado'
        ];
        
        return $estados[$status] ?? ucfirst(str_replace('_', ' ', $status));
    }
    
    // Método para obtener el nombre legible del estado
    public function getEstadoLegibleAttribute()
    {
        return self::getEstadoLegible($this->status);
    }
    
    // Método para obtener la clase CSS del estado
    public function getEstadoClaseCssAttribute()
    {
        $clases = [
            self::STATUS_PENDIENTE => 'bg-yellow-100 text-yellow-800',
            self::STATUS_EN_DESARROLLO => 'bg-blue-100 text-blue-800',
            self::STATUS_REVISION => 'bg-purple-100 text-purple-800',
            self::STATUS_TESTING => 'bg-orange-100 text-orange-800',
            self::STATUS_APROBADA => 'bg-green-100 text-green-800',
            self::STATUS_COMPLETADO => 'bg-green-100 text-green-800',
            self::STATUS_RECHAZADO => 'bg-red-100 text-red-800',
            self::STATUS_PAUSADO => 'bg-gray-100 text-gray-800'
        ];
        
        return $clases[$this->status] ?? 'bg-gray-100 text-gray-800';
    }
    
    // Método para obtener el porcentaje de progreso basado en el estado
    public function getProgresoPorEstadoAttribute()
    {
        $progresos = [
            self::STATUS_PENDIENTE => 10,
            self::STATUS_EN_DESARROLLO => 40,
            self::STATUS_REVISION => 70,
            self::STATUS_TESTING => 85,
            self::STATUS_APROBADA => 95,
            self::STATUS_COMPLETADO => 100,
            self::STATUS_RECHAZADO => 0,
            self::STATUS_PAUSADO => 25
        ];
        
        return $progresos[$this->status] ?? 0;
    }
    
    protected $fillable = [
        'applicant_name',
        'applicant_role',
        'company_name',
        'department',
        'email',
        'phone',
        'country',
        'department_location',
        'municipality',
        'project_name',
        'project_code_exists',
        'project_code',
        'document_version',
        'version_number',
        'has_documents',
        'documents',
        'system_type',
        'system_type_other',
        'reference_system',
        'reference_system_details',
        'system_purpose',
        'general_objective',
        'specific_objectives',
        'system_goals',
        'system_goals_other',
        'functionalities',
        'functionalities_other',
        'user_type_1',
        'user_functions_1',
        'user_type_2',
        'user_functions_2',
        'user_type_other',
        'user_functions_other',
        'user_restrictions',
        'platform',
        'offline',
        'devices',
        'devices_other',
        'integration',
        'integration_details',
        'database',
        'backups',
        'security_level',
        'availability',
        'availability_other',
        'initial_users',
        'future_users',
        'load_time',
        'phased_delivery',
        'phase_1',
        'phase_2',
        'phase_3',
        'phase_other',
        'documentation',
        'documentation_other',
        'documentation_support',
        'training_needed',
        'training_details',
        'training_type',
        'training_type_other',
        'start_date',
        'end_date',
        'strict_deadlines',
        'deadlines_details',
        'budget_defined',
        'budget_details',
        'budget_includes_support',
        'current_process',
        'has_process_documents',
        'process_documents',
        'assigned_user_id',
        'status',
        'prioridad',
        'apprentice_comments',
    ];

    /**
     * Relación con el usuario asignado
     */
    public function assignedUser()
    {
        return $this->belongsTo(User::class, 'assigned_user_id');
    }

    /**
     * Obtener proyectos asignados a un usuario específico
     */
    public static function getProjectsByUser($userId)
    {
        return self::where('assigned_user_id', $userId)
                   ->whereNotIn('status', ['rechazado'])
                   ->orderBy('created_at', 'desc')
                   ->get();
    }

    /**
     * Obtener estadísticas de proyectos para un usuario
     */
    public static function getProjectStatsByUser($userId)
    {
        return [
            'activos' => self::where('assigned_user_id', $userId)
                ->whereIn('status', ['en_desarrollo', 'aprobada'])
                ->count(),
            'completados' => self::where('assigned_user_id', $userId)
                ->where('status', 'completado')
                ->count(),
            'pendientes' => self::where('assigned_user_id', $userId)
                ->where('status', 'pendiente')
                ->count(),
            'total' => self::where('assigned_user_id', $userId)
                ->count(),
        ];
    }

    /**
     * Calcular progreso avanzado basado en tareas, requerimientos y avances
     */
    public function calcularProgresoAvanzado()
    {
        // Obtener tareas del proyecto
        $tareas = DB::table('proyecto_tareas')
            ->where('proyecto_id', $this->id)
            ->get();
        
        // Obtener requerimientos del proyecto
        $requerimientos = DB::table('proyecto_requerimientos')
            ->where('proyecto_id', $this->id)
            ->get();
        
        // Obtener avances del proyecto
        $avances = DB::table('proyecto_avances')
            ->where('proyecto_id', $this->id)
            ->get();
        
        return $this->calcularProgresoCompleto($tareas, $requerimientos, $avances);
    }

    /**
     * Método unificado para calcular progreso completo
     */
    public function calcularProgresoCompleto($tareas = null, $requerimientos = null, $avances = null)
    {
        // Progreso base según el estado del proyecto (20% del total)
        $progresoBase = $this->progreso_por_estado * 0.2;
        
        // Si no hay tareas, usar progreso base más conservador
        if (!$tareas || $tareas->count() == 0) {
            // Para proyectos sin tareas, usar solo el progreso del estado pero más conservador
            return min(100, max(0, $this->progreso_por_estado * 0.8));
        }
        
        // Progreso por tareas completadas (40% del total)
        $tareasCompletadas = $tareas->where('estado', 'completada')->count();
        $totalTareas = $tareas->count();
        $progresoTareas = $totalTareas > 0 ? ($tareasCompletadas / $totalTareas) * 40 : 0;
        
        // Progreso por requerimientos aprobados (20% del total)
        $progresoRequerimientos = 0;
        if ($requerimientos && $requerimientos->count() > 0) {
            $requerimientosAprobados = $requerimientos->where('estado', 'aprobado')->count();
            $totalRequerimientos = $requerimientos->count();
            $progresoRequerimientos = ($requerimientosAprobados / $totalRequerimientos) * 20;
        }
        
        // Progreso por avances registrados (20% del total)
        $progresoAvances = 0;
        if ($avances && $avances->count() > 0) {
            $promedioAvances = $avances->avg('porcentaje_avance') ?? 0;
            $progresoAvances = ($promedioAvances / 100) * 20;
        }
        
        // Progreso total
        $progresoTotal = $progresoBase + $progresoTareas + $progresoRequerimientos + $progresoAvances;
        
        // Asegurar que esté entre 0 y 100
        return min(100, max(0, round($progresoTotal, 1)));
    }

    /**
     * Obtener progreso con datos precargados (para evitar múltiples consultas)
     */
    public static function calcularProgresosParaProyectos($proyectos)
    {
        $progresos = [];
        
        foreach ($proyectos as $proyecto) {
            // Obtener datos relacionados
            $tareas = DB::table('proyecto_tareas')
                ->where('proyecto_id', $proyecto->id)
                ->get();
            
            $requerimientos = DB::table('proyecto_requerimientos')
                ->where('proyecto_id', $proyecto->id)
                ->get();
            
            $avances = DB::table('proyecto_avances')
                ->where('proyecto_id', $proyecto->id)
                ->get();
            
            // Calcular progreso
            $progresos[$proyecto->id] = $proyecto->calcularProgresoCompleto($tareas, $requerimientos, $avances);
        }
        
        return $progresos;
    }

    /**
     * Accessor para obtener el progreso calculado dinámicamente
     */
    public function getProgresoCalculadoAttribute()
    {
        return $this->calcularProgresoAvanzado();
    }
} 