<?php

namespace Modules\FABRICASOFT\Entities;

use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class FormularioSeguimiento extends Model
{
    protected $table = 'formulario_seguimiento';
    
    protected $fillable = [
        'formulario_id',
        'servicio_id',
        'user_id',
        'assigned_user_id',
        'estado',
        'comentarios',
        'respuesta_admin',
        'respuesta_desarrollador',
        'fecha_envio',
        'fecha_revision',
        'fecha_desarrollo',
        'fecha_completado',
        'prioridad',
        'notificado_admin',
        'notificado_desarrollador',
        'notificado_usuario'
    ];

    protected $casts = [
        'fecha_envio' => 'datetime',
        'fecha_revision' => 'datetime',
        'fecha_desarrollo' => 'datetime',
        'fecha_completado' => 'datetime',
        'notificado_admin' => 'boolean',
        'notificado_desarrollador' => 'boolean',
        'notificado_usuario' => 'boolean'
    ];

    // Estados disponibles
    const ESTADO_PENDIENTE = 'pendiente';
    const ESTADO_EN_REVISION = 'en_revision';
    const ESTADO_EN_DESARROLLO = 'en_desarrollo';
    const ESTADO_TESTING = 'testing';
    const ESTADO_COMPLETADO = 'completado';
    const ESTADO_RECHAZADO = 'rechazado';
    const ESTADO_PAUSADO = 'pausado';

    // Prioridades
    const PRIORIDAD_BAJA = 1;
    const PRIORIDAD_MEDIA = 2;
    const PRIORIDAD_ALTA = 3;
    const PRIORIDAD_URGENTE = 4;

    /**
     * Relación con el formulario
     */
    public function formulario()
    {
        return $this->belongsTo(Formulario::class);
    }

    /**
     * Relación con el servicio (new_request)
     */
    public function servicio()
    {
        return $this->belongsTo(NewRequest::class, 'servicio_id');
    }

    /**
     * Relación con el usuario que envió el formulario
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Relación con el desarrollador asignado
     */
    public function assignedUser()
    {
        return $this->belongsTo(User::class, 'assigned_user_id');
    }

    /**
     * Obtener el nombre legible del estado
     */
    public function getEstadoLegibleAttribute()
    {
        $estados = [
            self::ESTADO_PENDIENTE => 'Pendiente',
            self::ESTADO_EN_REVISION => 'En Revisión',
            self::ESTADO_EN_DESARROLLO => 'En Desarrollo',
            self::ESTADO_TESTING => 'Testing',
            self::ESTADO_COMPLETADO => 'Completado',
            self::ESTADO_RECHAZADO => 'Rechazado',
            self::ESTADO_PAUSADO => 'Pausado'
        ];

        return $estados[$this->estado] ?? ucfirst(str_replace('_', ' ', $this->estado));
    }

    /**
     * Obtener la clase CSS del estado
     */
    public function getEstadoClassAttribute()
    {
        $classes = [
            self::ESTADO_PENDIENTE => 'badge-warning',
            self::ESTADO_EN_REVISION => 'badge-info',
            self::ESTADO_EN_DESARROLLO => 'badge-primary',
            self::ESTADO_TESTING => 'badge-secondary',
            self::ESTADO_COMPLETADO => 'badge-success',
            self::ESTADO_RECHAZADO => 'badge-danger',
            self::ESTADO_PAUSADO => 'badge-dark'
        ];

        return $classes[$this->estado] ?? 'badge-secondary';
    }

    /**
     * Obtener el nombre legible de la prioridad
     */
    public function getPrioridadLegibleAttribute()
    {
        $prioridades = [
            self::PRIORIDAD_BAJA => 'Baja',
            self::PRIORIDAD_MEDIA => 'Media',
            self::PRIORIDAD_ALTA => 'Alta',
            self::PRIORIDAD_URGENTE => 'Urgente'
        ];

        return $prioridades[$this->prioridad] ?? 'Baja';
    }

    /**
     * Obtener la clase CSS de la prioridad
     */
    public function getPrioridadClassAttribute()
    {
        $classes = [
            self::PRIORIDAD_BAJA => 'badge-success',
            self::PRIORIDAD_MEDIA => 'badge-info',
            self::PRIORIDAD_ALTA => 'badge-warning',
            self::PRIORIDAD_URGENTE => 'badge-danger'
        ];

        return $classes[$this->prioridad] ?? 'badge-secondary';
    }

    /**
     * Obtener estadísticas por usuario
     */
    public static function getStatsByUser($userId)
    {
        return self::where('user_id', $userId)
            ->selectRaw('
                COUNT(*) as total,
                SUM(CASE WHEN estado = "pendiente" THEN 1 ELSE 0 END) as pendientes,
                SUM(CASE WHEN estado = "en_revision" THEN 1 ELSE 0 END) as en_revision,
                SUM(CASE WHEN estado = "en_desarrollo" THEN 1 ELSE 0 END) as en_desarrollo,
                SUM(CASE WHEN estado = "testing" THEN 1 ELSE 0 END) as testing,
                SUM(CASE WHEN estado = "completado" THEN 1 ELSE 0 END) as completados,
                SUM(CASE WHEN estado = "rechazado" THEN 1 ELSE 0 END) as rechazados
            ')
            ->first();
    }

    /**
     * Obtener estadísticas por desarrollador
     */
    public static function getStatsByDeveloper($developerId)
    {
        return self::where('assigned_user_id', $developerId)
            ->selectRaw('
                COUNT(*) as total,
                SUM(CASE WHEN estado = "pendiente" THEN 1 ELSE 0 END) as pendientes,
                SUM(CASE WHEN estado = "en_revision" THEN 1 ELSE 0 END) as en_revision,
                SUM(CASE WHEN estado = "en_desarrollo" THEN 1 ELSE 0 END) as en_desarrollo,
                SUM(CASE WHEN estado = "testing" THEN 1 ELSE 0 END) as testing,
                SUM(CASE WHEN estado = "completado" THEN 1 ELSE 0 END) as completados,
                SUM(CASE WHEN estado = "rechazado" THEN 1 ELSE 0 END) as rechazados
            ')
            ->first();
    }

    /**
     * Obtener estadísticas generales para admin
     */
    public static function getGeneralStats()
    {
        return self::selectRaw('
            COUNT(*) as total,
            SUM(CASE WHEN estado = "pendiente" THEN 1 ELSE 0 END) as pendientes,
            SUM(CASE WHEN estado = "en_revision" THEN 1 ELSE 0 END) as en_revision,
            SUM(CASE WHEN estado = "en_desarrollo" THEN 1 ELSE 0 END) as en_desarrollo,
            SUM(CASE WHEN estado = "testing" THEN 1 ELSE 0 END) as testing,
            SUM(CASE WHEN estado = "completado" THEN 1 ELSE 0 END) as completados,
            SUM(CASE WHEN estado = "rechazado" THEN 1 ELSE 0 END) as rechazados,
            AVG(CASE WHEN estado = "completado" THEN DATEDIFF(fecha_completado, fecha_envio) END) as tiempo_promedio_dias
        ')
        ->first();
    }

    /**
     * Actualizar estado y fechas automáticamente
     */
    public function updateEstado($nuevoEstado)
    {
        $this->estado = $nuevoEstado;
        
        // Actualizar fechas según el estado
        switch ($nuevoEstado) {
            case self::ESTADO_EN_REVISION:
                $this->fecha_revision = now();
                break;
            case self::ESTADO_EN_DESARROLLO:
                $this->fecha_desarrollo = now();
                break;
            case self::ESTADO_COMPLETADO:
                $this->fecha_completado = now();
                break;
        }
        
        $this->save();
    }
}

