<?php

namespace Modules\FABRICASOFT\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProyectoRequerimiento extends Model
{
    protected $table = 'requerimientos';
    
    protected $fillable = [
        'titulo',
        'descripcion',
        'proyecto_id',
        'tipo',
        'prioridad',
        'estado',
        'criterios_aceptacion',
        'creado_por',
        'asignado_a',
        'fecha_limite',
        'tiempo_estimado_horas',
        'comentarios'
    ];

    protected $casts = [
        'fecha_limite' => 'date',
        'tiempo_estimado_horas' => 'integer'
    ];

    /**
     * Relación con el proyecto
     */
    public function proyecto(): BelongsTo
    {
        return $this->belongsTo(NewRequest::class, 'proyecto_id');
    }

    /**
     * Relación con el usuario que creó el requerimiento
     */
    public function creadoPor(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class, 'creado_por');
    }

    /**
     * Relación con el usuario asignado
     */
    public function asignadoA(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class, 'asignado_a');
    }
}
