<?php
namespace Modules\FABRICASOFT\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Formulario extends Model
{
    protected $table = 'formularios';
    protected $fillable = ['nombre', 'preguntas'];
    protected $casts = [
        'preguntas' => 'array',
    ];

    /**
     * Relación con las respuestas de este formulario
     */
    public function respuestas(): HasMany
    {
        return $this->hasMany(RespuestaFormulario::class, 'pregunta_id');
    }

    /**
     * Obtener todos los formularios disponibles
     */
    public static function getFormulariosDisponibles()
    {
        return self::orderBy('created_at', 'desc')->get();
    }

    /**
     * Crear un nuevo formulario
     */
    public static function crearFormulario($nombre, $preguntas)
    {
        return self::create([
            'nombre' => $nombre,
            'preguntas' => $preguntas
        ]);
    }
} 