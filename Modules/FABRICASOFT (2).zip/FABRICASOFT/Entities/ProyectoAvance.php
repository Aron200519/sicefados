<?php

namespace Modules\FABRICASOFT\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProyectoAvance extends Model
{
    protected $table = 'proyecto_avances';
    
    protected $fillable = [
        'proyecto_id',
        'usuario_id',
        'porcentaje_avance',
        'descripcion',
        'fecha_avance',
        'comentarios',
        'archivos_adjuntos'
    ];

    protected $casts = [
        'fecha_avance' => 'datetime',
        'porcentaje_avance' => 'integer',
        'archivos_adjuntos' => 'array'
    ];

    /**
     * Relación con el proyecto
     */
    public function proyecto(): BelongsTo
    {
        return $this->belongsTo(NewRequest::class, 'proyecto_id');
    }

    /**
     * Relación con el usuario que registró el avance
     */
    public function usuario(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class, 'usuario_id');
    }
}
