<?php

namespace Modules\FABRICASOFT\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class RespuestaFormulario extends Model
{
    protected $table = 'respuestas_formularios';
    
    protected $fillable = [
        'servicio_id',
        'pregunta_id',
        'respuesta'
    ];

    /**
     * Relación con el servicio (new_request)
     */
    public function servicio(): BelongsTo
    {
        return $this->belongsTo(NewRequest::class, 'servicio_id');
    }

    /**
     * Obtener todas las respuestas de un servicio específico
     */
    public static function getRespuestasByServicio($servicioId)
    {
        return self::where('servicio_id', $servicioId)->get();
    }

    /**
     * Obtener respuesta específica por servicio y pregunta
     */
    public static function getRespuestaByServicioYPregunta($servicioId, $preguntaId)
    {
        return self::where('servicio_id', $servicioId)
                   ->where('pregunta_id', $preguntaId)
                   ->first();
    }
}
