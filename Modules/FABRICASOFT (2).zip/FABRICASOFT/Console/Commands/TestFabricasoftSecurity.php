<?php

namespace Modules\FABRICASOFT\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Modules\SICA\Entities\Role;

class TestFabricasoftSecurity extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'fabricasoft:test-security {--user= : ID del usuario a probar} {--route= : Ruta específica a probar}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Prueba la seguridad del módulo FABRICASOFT';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->info('🔒 Probando seguridad del módulo FABRICASOFT...');
        $this->newLine();

        // Obtener rutas de FABRICASOFT
        $fabricasoftRoutes = $this->getFabricasoftRoutes();
        
        if (empty($fabricasoftRoutes)) {
            $this->error('❌ No se encontraron rutas de FABRICASOFT');
            return 1;
        }

        $this->info('📋 Rutas encontradas: ' . count($fabricasoftRoutes));
        $this->newLine();

        // Probar con usuario específico si se proporciona
        $userId = $this->option('user');
        $specificRoute = $this->option('route');

        if ($userId) {
            $this->testWithUser($userId, $specificRoute ? [$specificRoute] : $fabricasoftRoutes);
        } else {
            $this->testAllScenarios($fabricasoftRoutes);
        }

        $this->newLine();
        $this->info('✅ Pruebas de seguridad completadas');
        
        return 0;
    }

    /**
     * Obtener todas las rutas de FABRICASOFT
     */
    private function getFabricasoftRoutes()
    {
        $routes = Route::getRoutes();
        $fabricasoftRoutes = [];

        foreach ($routes as $route) {
            if (strpos($route->uri(), 'fabricasoft') === 0) {
                $fabricasoftRoutes[] = [
                    'uri' => $route->uri(),
                    'methods' => $route->methods(),
                    'middleware' => $route->middleware(),
                    'name' => $route->getName()
                ];
            }
        }

        return $fabricasoftRoutes;
    }

    /**
     * Probar con un usuario específico
     */
    private function testWithUser($userId, $routes)
    {
        $user = User::find($userId);
        
        if (!$user) {
            $this->error("❌ Usuario con ID {$userId} no encontrado");
            return;
        }

        $this->info("👤 Probando con usuario: {$user->nickname} ({$user->email})");
        $this->newLine();

        // Obtener roles del usuario
        $userRoles = $user->roles()->pluck('slug')->toArray();
        $this->info("🎭 Roles del usuario: " . implode(', ', $userRoles ?: ['Sin roles']));
        $this->newLine();

        foreach ($routes as $route) {
            $this->testRoute($route, $user);
        }
    }

    /**
     * Probar todos los escenarios
     */
    private function testAllScenarios($routes)
    {
        // Escenario 1: Usuario no autenticado
        $this->info('🔓 Escenario 1: Usuario no autenticado');
        $this->newLine();
        
        Auth::logout();
        
        foreach ($routes as $route) {
            if ($route['uri'] !== 'fabricasoft/index') { // Excluir ruta pública
                $this->testRoute($route, null);
            }
        }

        $this->newLine();
        $this->info('🔐 Escenario 2: Usuarios con diferentes roles');
        $this->newLine();

        // Obtener usuarios con diferentes roles
        $users = User::with('roles')->get();

        foreach ($users as $user) {
            $userRoles = $user->roles()->pluck('slug')->toArray();
            $hasFabricasoftRole = in_array('fabricasoft.admin', $userRoles) || 
                                 in_array('fabricasoft.apprentice', $userRoles) ||
                                 in_array('fabricasoft.user', $userRoles);

            if ($hasFabricasoftRole) {
                $this->info("👤 Probando con usuario: {$user->nickname} - Roles: " . implode(', ', $userRoles));
                
                Auth::login($user);
                
                // Probar algunas rutas clave
                $keyRoutes = array_filter($routes, function($route) {
                    return in_array($route['uri'], [
                        'fabricasoft/admin/welcome',
                        'fabricasoft/apprentices/aprendiz',
                        'fabricasoft/users/users'
                    ]);
                });

                foreach ($keyRoutes as $route) {
                    $this->testRoute($route, $user);
                }
                
                $this->newLine();
            }
        }
    }

    /**
     * Probar una ruta específica
     */
    private function testRoute($route, $user = null)
    {
        $uri = $route['uri'];
        $name = $route['name'] ?: 'Sin nombre';
        $middleware = implode(', ', $route['middleware']);

        $this->line("🔗 Probando: {$uri}");
        $this->line("   Nombre: {$name}");
        $this->line("   Middleware: {$middleware}");

        // Determinar el tipo de ruta
        $routeType = $this->getRouteType($route);
        $this->line("   Tipo: {$routeType}");

        // Verificar acceso
        $accessResult = $this->checkAccess($route, $user);
        
        if ($accessResult['allowed']) {
            $this->info("   ✅ Acceso permitido");
        } else {
            $this->error("   ❌ Acceso denegado: {$accessResult['reason']}");
        }

        $this->newLine();
    }

    /**
     * Determinar el tipo de ruta
     */
    private function getRouteType($route)
    {
        $uri = $route['uri'];
        
        if ($uri === 'fabricasoft/index') {
            return 'Pública';
        } elseif (strpos($uri, 'fabricasoft/admin') === 0) {
            return 'Administrativa';
        } else {
            return 'Protegida';
        }
    }

    /**
     * Verificar acceso a una ruta
     */
    private function checkAccess($route, $user = null)
    {
        $uri = $route['uri'];
        $middleware = $route['middleware'];

        // Ruta pública
        if ($uri === 'fabricasoft/index') {
            return ['allowed' => true, 'reason' => 'Ruta pública'];
        }

        // Usuario no autenticado
        if (!$user) {
            return ['allowed' => false, 'reason' => 'Usuario no autenticado'];
        }

        // Verificar roles
        $userRoles = $user->roles()->pluck('slug')->toArray();
        
        // Rutas administrativas
        if (strpos($uri, 'fabricasoft/admin') === 0) {
            if (in_array('fabricasoft.admin', $userRoles)) {
                return ['allowed' => true, 'reason' => 'Usuario con rol de administrador'];
            } else {
                return ['allowed' => false, 'reason' => 'Sin rol de administrador'];
            }
        }

        // Rutas protegidas
        $hasFabricasoftRole = in_array('fabricasoft.admin', $userRoles) || 
                             in_array('fabricasoft.apprentice', $userRoles) ||
                             in_array('fabricasoft.user', $userRoles);

        if ($hasFabricasoftRole) {
            return ['allowed' => true, 'reason' => 'Usuario con rol de FABRICASOFT'];
        } else {
            return ['allowed' => false, 'reason' => 'Sin roles de FABRICASOFT'];
        }
    }
} 