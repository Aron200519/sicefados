# Sistema de Seguimiento de Avance de Proyectos - FABRICASOFT

## Descripción General

Se ha implementado un sistema completo de seguimiento de avance de proyectos para el módulo FABRICASOFT, que permite tanto a administradores como a clientes monitorear el progreso de los proyectos de desarrollo de software.

## Funcionalidades Implementadas

### 1. Dashboard del Cliente (`/fabricasoft/cliente/dashboard`)

**Características principales:**
- **Métricas en tiempo real**: Total de proyectos, proyectos en desarrollo, completados y progreso promedio
- **Gráficos interactivos**: 
  - Gráfico de barras para progreso de proyectos
  - Gráfico de dona para distribución por estado
- **Tabla de proyectos con avance**: Muestra cada proyecto con su progreso visual
- **Modal de detalles**: Información detallada de cada proyecto incluyendo:
  - Información del desarrollador asignado
  - Progreso detallado por fases
  - Comentarios del desarrollador
  - Timeline de actividades

**Funcionalidades adicionales:**
- Exportación de reportes
- Filtros por estado y desarrollador
- Contacto directo con desarrolladores
- Actualización automática de datos

### 2. Panel de Avance para Administradores (`/fabricasoft/admin/avance-proyectos`)

**Características principales:**
- **Métricas generales**: Total de proyectos, en desarrollo, completados y progreso promedio
- **Gráficos de análisis**:
  - Distribución por estado (gráfico de dona)
  - Progreso mensual (gráfico de línea)
- **Filtros avanzados**:
  - Por estado del proyecto
  - Por desarrollador asignado
  - Por rango de progreso
- **Tabla detallada** con:
  - Información completa de cada proyecto
  - Progreso visual con barras de progreso
  - Tiempo estimado y transcurrido
  - Acciones para editar y generar reportes

**Funcionalidades administrativas:**
- Actualización manual del progreso
- Generación de reportes individuales
- Exportación de datos
- Gestión de comentarios y estados

## Estructura de Archivos

### Vistas Creadas
- `Modules/FABRICASOFT/Resources/views/cliente/dashboard.blade.php` - Dashboard del cliente
- `Modules/FABRICASOFT/Resources/views/admin/avance-proyectos.blade.php` - Panel de avance para admin

### Controlador Actualizado
- `Modules/FABRICASOFT/Http/Controllers/FABRICASOFTController.php` - Nuevos métodos agregados:
  - `clienteDashboard()` - Dashboard del cliente
  - `avanceProyectos()` - Panel de avance para admin
  - `getDetalleAvance($id)` - Detalles de avance de un proyecto
  - `actualizarProgreso(Request $request, $id)` - Actualizar progreso
  - `generarReporteAvance($id)` - Generar reporte

### Rutas Agregadas
- `GET /fabricasoft/cliente/dashboard` - Dashboard del cliente
- `GET /fabricasoft/admin/avance-proyectos` - Panel de avance para admin
- `GET /fabricasoft/admin/proyecto/{id}/detalle-avance` - Detalles de avance
- `PUT /fabricasoft/admin/proyecto/{id}/actualizar-progreso` - Actualizar progreso
- `GET /fabricasoft/admin/proyecto/{id}/generar-reporte` - Generar reporte

### Layouts Actualizados
- `Modules/FABRICASOFT/Resources/views/layouts/masteradmin.blade.php` - Enlaces agregados
- `Modules/FABRICASOFT/Resources/views/layouts/masterusers.blade.php` - Enlaces agregados

## Estados de Proyecto y Progreso

### Estados Disponibles
1. **Pendiente** - 10% de progreso
2. **En Desarrollo** - 40% de progreso
3. **Revisión** - 70% de progreso
4. **Testing** - 85% de progreso
5. **Completado** - 100% de progreso
6. **Rechazado** - 0% de progreso

### Cálculo de Progreso
El progreso se calcula automáticamente basado en el estado del proyecto, pero también permite actualización manual por parte de los administradores.

## Tecnologías Utilizadas

- **Frontend**: Tailwind CSS, Chart.js, Font Awesome
- **Backend**: Laravel, PHP
- **Base de Datos**: MySQL (tabla `new_request`)
- **JavaScript**: Vanilla JS para interactividad

## Instalación y Configuración

### Requisitos
- Laravel 8+
- PHP 7.4+
- MySQL 5.7+
- Módulo FABRICASOFT instalado

### Pasos de Instalación
1. Los archivos ya están incluidos en el módulo
2. Las rutas están configuradas automáticamente
3. Los enlaces en los layouts están actualizados
4. No se requieren migraciones adicionales

### Acceso
- **Clientes**: `/fabricasoft/cliente/dashboard`
- **Administradores**: `/fabricasoft/admin/avance-proyectos`

## Funcionalidades Futuras

### Planificadas para próximas versiones:
1. **Notificaciones en tiempo real** - WebSockets para actualizaciones automáticas
2. **Reportes PDF/Excel** - Exportación avanzada de reportes
3. **Timeline interactivo** - Vista de cronograma de proyectos
4. **Métricas avanzadas** - KPIs y análisis de rendimiento
5. **Integración con calendario** - Fechas de entrega y hitos
6. **Sistema de comentarios** - Comunicación entre cliente y desarrollador
7. **Alertas automáticas** - Notificaciones de retrasos o cambios de estado

## Mantenimiento

### Logs y Monitoreo
- Los cambios de estado se registran automáticamente
- Los comentarios se almacenan en el campo `apprentice_comments`
- El progreso manual se guarda en `progreso_manual` (si se implementa)

### Backup y Seguridad
- Los datos se respaldan con el sistema general de Laravel
- Las validaciones previenen datos incorrectos
- Los permisos se manejan a través de middleware existentes

## Soporte

Para soporte técnico o reportar problemas:
1. Revisar los logs de Laravel
2. Verificar la conectividad de la base de datos
3. Confirmar que los roles de usuario estén correctamente asignados
4. Contactar al equipo de desarrollo

---

**Versión**: 1.0.0  
**Fecha**: Enero 2025  
**Desarrollado por**: Equipo FABRICASOFT - SENA 