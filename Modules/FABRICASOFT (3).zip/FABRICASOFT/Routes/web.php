<?php

use Illuminate\Support\Facades\Route;
use Modules\FABRICASOFT\Http\Controllers\FABRICASOFTController;
use Modules\FABRICASOFT\Http\Controllers\PreregistroController;
use Modules\FABRICASOFT\Http\Controllers\AdminController;
use Modules\FABRICASOFT\Http\Controllers\AnalystController;
use Modules\FABRICASOFT\Http\Controllers\ScrumProjectController;
use Modules\FABRICASOFT\Http\Controllers\ClientAuthController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your module. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('fabricasoft')->group(function() {
    // Ruta principal del módulo
    Route::get('/', [FABRICASOFTController::class, 'index'])->name('fabricasoft.index');
    Route::get('/index', [FABRICASOFTController::class, 'index'])->name('fabricasoft.index.alternative');
    
    // Rutas de pre-registro
    Route::get('/preregistro', [PreregistroController::class, 'index'])->name('fabricasoft.preregistro');
    Route::post('/preregistro', [PreregistroController::class, 'store'])->name('fabricasoft.preregistro.store');
    Route::get('/preregistro/success', [PreregistroController::class, 'success'])->name('fabricasoft.preregistro.success');
    
    // Rutas de autenticación para clientes externos
    Route::get('/client/login', [ClientAuthController::class, 'showLoginForm'])->name('fabricasoft.client.login');
    Route::post('/client/login', [ClientAuthController::class, 'login'])->name('fabricasoft.client.login');
    Route::post('/client/logout', [ClientAuthController::class, 'logout'])->name('fabricasoft.client.logout');
    
    // Ruta de prueba para el modal
    Route::get('/test-modal', [AdminController::class, 'testModal'])->name('fabricasoft.admin.test.modal');
    
    // Ruta de debug para verificar autenticación
    Route::get('/debug-auth', function() {
        $user = auth()->user();
        if (!$user) {
            return response()->json([
                'authenticated' => false,
                'message' => 'No hay usuario autenticado'
            ]);
        }
        
        $hasAdminRole = $user->hasCustomRole('fabricasoft.admin');
        
        return response()->json([
            'authenticated' => true,
            'user_id' => $user->id,
            'email' => $user->email,
            'has_admin_role' => $hasAdminRole,
            'all_roles' => $user->roles ?? 'No disponible'
        ]);
    })->name('fabricasoft.debug.auth');
    
    // Rutas del admin (requieren autenticación y rol de admin)
    Route::prefix('admin')->middleware(['auth', 'custom.role:fabricasoft.admin'])->group(function() {
        // Página de inicio con gestión de usuarios
        Route::get('/inicio', [AdminController::class, 'inicio'])->name('fabricasoft.admin.inicio');
        
        // Dashboard del admin (redirige a inicio)
        Route::get('/', function() {
            return redirect()->route('fabricasoft.admin.inicio');
        })->name('fabricasoft.admin.dashboard');
        
        // Dashboard del admin (vista directa)
        Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('fabricasoft.admin.dashboard.view');
        
        // Gestión de solicitudes
        Route::get('/solicitudes', [AdminController::class, 'solicitudes'])->name('fabricasoft.admin.solicitudes');
        Route::get('/solicitud/{id}', [AdminController::class, 'showSolicitud'])->name('fabricasoft.admin.show.solicitud');
        
        // Asignación de analistas
        Route::post('/solicitud/{id}/asignar-analista', [AdminController::class, 'assignAnalyst'])->name('fabricasoft.admin.asignar.analista');
        Route::post('/solicitud/{id}/cambiar-analista', [AdminController::class, 'changeAnalyst'])->name('fabricasoft.admin.cambiar.analista');
        
        // Filtros y búsquedas
        Route::get('/solicitudes/filtrar', [AdminController::class, 'filtrarSolicitudes'])->name('fabricasoft.admin.filtrar.solicitudes');
        
        // Acciones sobre solicitudes
        Route::post('/solicitud/{id}/aprobar', [AdminController::class, 'aprobarSolicitud'])->name('fabricasoft.admin.aprobar.solicitud');
        Route::post('/solicitud/{id}/rechazar', [AdminController::class, 'rechazarSolicitud'])->name('fabricasoft.admin.rechazar.solicitud');
        
        // Creación de proyectos Scrum
        Route::post('/solicitud/{id}/crear-proyecto', [ScrumProjectController::class, 'createProject'])->name('fabricasoft.admin.crear.proyecto');
        
        // Descarga de SRS
        Route::get('/solicitud/{id}/descargar-srs', [AdminController::class, 'downloadSRS'])->name('fabricasoft.admin.descargar.srs');
        
        // Gestión de usuarios
        Route::post('/usuarios/crear', [AdminController::class, 'crearUsuario'])->name('fabricasoft.admin.usuarios.crear');
        Route::post('/usuarios/{userId}/cambiar-rol', [AdminController::class, 'cambiarRol'])->name('fabricasoft.admin.usuarios.cambiar.rol');
        Route::put('/usuarios/{userId}/editar', [AdminController::class, 'editarUsuario'])->name('fabricasoft.admin.usuarios.editar');
        Route::delete('/usuarios/{userId}/eliminar', [AdminController::class, 'eliminarUsuario'])->name('fabricasoft.admin.usuarios.eliminar');
        
        // Ruta temporal para debug de roles
        Route::get('/debug-roles', [AdminController::class, 'debugRoles'])->name('fabricasoft.admin.debug.roles');
        
        // Exportación
        Route::get('/exportar/csv', [AdminController::class, 'exportarCSV'])->name('fabricasoft.admin.exportar.csv');
        
                        // Gestión de proyectos Scrum
                Route::get('/proyectos', [ScrumProjectController::class, 'listProjects'])->name('fabricasoft.admin.projects.list');
                Route::get('/proyecto/{id}', [ScrumProjectController::class, 'showProject'])->name('fabricasoft.admin.projects.show');
                Route::post('/proyecto/{id}/agregar-miembro', [ScrumProjectController::class, 'addTeamMember'])->name('fabricasoft.admin.projects.add.member');
                Route::delete('/proyecto/{id}/remover-miembro/{memberId}', [ScrumProjectController::class, 'removeTeamMember'])->name('fabricasoft.admin.projects.remove.member');
                
                // Gestión de fases del proyecto
                Route::post('/proyecto/{id}/fase/{phaseId}/asignar', [ScrumProjectController::class, 'assignPhase'])->name('fabricasoft.admin.projects.phase.assign');
                Route::post('/proyecto/{id}/fase/{phaseId}/iniciar', [ScrumProjectController::class, 'startPhase'])->name('fabricasoft.admin.projects.phase.start');
                Route::post('/proyecto/{id}/fase/{phaseId}/completar', [ScrumProjectController::class, 'completePhase'])->name('fabricasoft.admin.projects.phase.complete');
                Route::post('/proyecto/{id}/fase/{phaseId}/completar-con-info', [ScrumProjectController::class, 'completePhaseWithInfo'])->name('fabricasoft.admin.projects.phase.complete.with.info');
                
                // Nuevas rutas para el sistema secuencial de fases
                Route::get('/proyecto/{id}/fase/guardar', [ScrumProjectController::class, 'savePhase'])->name('fabricasoft.admin.projects.phase.save');
                Route::post('/proyecto/{id}/fase/{phaseId}/habilitar-siguiente', [ScrumProjectController::class, 'enableNextPhase'])->name('fabricasoft.admin.projects.phase.enable.next');
                Route::post('/proyecto/{id}/fase/agregar-info', [ScrumProjectController::class, 'addPhaseInfo'])->name('fabricasoft.admin.projects.add.phase.info');
                Route::post('/proyecto/{id}/fase/informacion/agregar', [ScrumProjectController::class, 'addPhaseInfo'])->name('fabricasoft.admin.projects.phase.info.add');
                Route::put('/proyecto/{id}/fase/informacion/actualizar', [ScrumProjectController::class, 'updatePhaseInfoNew'])->name('fabricasoft.admin.projects.phase.info.update');
                Route::delete('/proyecto/{id}/fase/informacion/{historyId}/eliminar', [ScrumProjectController::class, 'deletePhaseInfoNew'])->name('fabricasoft.admin.projects.phase.info.delete');
                Route::get('/proyecto/{id}/fase/informacion/{historyId}/info', [ScrumProjectController::class, 'getPhaseInfo'])->name('fabricasoft.admin.projects.phase.info.get');
                Route::put('/proyecto/{id}/historial/actualizar', [ScrumProjectController::class, 'updatePhaseInfo'])->name('fabricasoft.admin.projects.historial.update');
                Route::delete('/proyecto/{id}/historial/{historyId}/eliminar', [ScrumProjectController::class, 'deletePhaseInfo'])->name('fabricasoft.admin.projects.historial.delete');
                Route::post('/proyecto/{id}/fase2/guardar', [ScrumProjectController::class, 'savePhase2'])->name('fabricasoft.admin.projects.phase2.save');
    });
    
    // Rutas del analista (requieren autenticación y rol de analista)
    Route::prefix('analyst')->middleware(['auth', 'custom.role:fabricasoft.analista'])->group(function() {
        // Dashboard del analista
        Route::get('/', [AnalystController::class, 'dashboard'])->name('fabricasoft.analyst.dashboard');
        
        // Gestión de solicitudes asignadas
        Route::get('/solicitudes', [AnalystController::class, 'assignedRequests'])->name('fabricasoft.analyst.solicitudes');
        Route::get('/solicitud/{id}', [AnalystController::class, 'showRequest'])->name('fabricasoft.analyst.show.request');
        
        // Análisis y SRS
        Route::post('/solicitud/{id}/iniciar-analisis', [AnalystController::class, 'startAnalysis'])->name('fabricasoft.analyst.iniciar.analisis');
        Route::post('/solicitud/{id}/subir-srs', [AnalystController::class, 'uploadSRS'])->name('fabricasoft.analyst.subir.srs');
        Route::post('/solicitud/{id}/actualizar-notas', [AnalystController::class, 'updateNotes'])->name('fabricasoft.analyst.actualizar.notas');
        
        // Descarga de SRS
        Route::get('/solicitud/{id}/descargar-srs', [AnalystController::class, 'downloadSRS'])->name('fabricasoft.analyst.descargar.srs');
        
        // Proyectos Scrum asignados al analista
        Route::get('/proyectos', [AnalystController::class, 'assignedProjects'])->name('fabricasoft.analyst.projects');
        Route::get('/proyecto/{id}', [AnalystController::class, 'showProject'])->name('fabricasoft.analyst.projects.show');
        Route::post('/proyecto/{projectId}/fase/info/agregar', [AnalystController::class, 'addPhaseInfo'])->name('fabricasoft.analyst.projects.phase.info.add');
        Route::get('/proyecto/{projectId}/fase/{phaseId}/info/{infoId}/editar', [AnalystController::class, 'getPhaseInfoForEdit'])->name('fabricasoft.analyst.projects.phase.info.get');
        Route::put('/proyecto/{projectId}/fase/{phaseId}/info/{historyId}/editar', [AnalystController::class, 'editPhaseInfo'])->name('fabricasoft.analyst.projects.phase.info.edit');
        Route::delete('/proyecto/{projectId}/fase/{phaseId}/info/{infoId}/eliminar', [AnalystController::class, 'deletePhaseInfo'])->name('fabricasoft.analyst.projects.phase.info.delete');
        
        // Rutas adicionales para funcionalidad completa
        Route::get('/proyectos/list', [AnalystController::class, 'assignedProjects'])->name('fabricasoft.analyst.projects.list');
        Route::post('/proyecto/{projectId}/agregar-miembro', [AnalystController::class, 'addTeamMember'])->name('fabricasoft.analyst.projects.add.member');
        Route::delete('/proyecto/{projectId}/remover-miembro/{memberId}', [AnalystController::class, 'removeTeamMember'])->name('fabricasoft.analyst.projects.remove.member');
        Route::post('/proyecto/{projectId}/fase/{phaseId}/completar-con-info', [AnalystController::class, 'completePhaseWithInfo'])->name('fabricasoft.analyst.projects.phase.complete.with.info');
        Route::post('/proyecto/{projectId}/fase/{phaseId}/iniciar', [AnalystController::class, 'startPhase'])->name('fabricasoft.analyst.projects.phase.start');
        Route::put('/proyecto/{projectId}/fase/informacion/actualizar', [AnalystController::class, 'updatePhaseInfo'])->name('fabricasoft.analyst.projects.phase.info.update');
        Route::put('/proyecto/{projectId}/fase/informacion/actualizar-nuevo', [AnalystController::class, 'updatePhaseInfoNew'])->name('fabricasoft.analyst.projects.phase.info.update.new');
        Route::delete('/proyecto/{projectId}/fase/informacion/{historyId}/eliminar', [AnalystController::class, 'deletePhaseInfoSimple'])->name('fabricasoft.analyst.projects.phase.info.delete');
        Route::get('/proyecto/{projectId}/fase/informacion/{historyId}/info', [AnalystController::class, 'getPhaseInfo'])->name('fabricasoft.analyst.projects.phase.info.get');
        
        // Ruta para guardar información general de fase
        Route::post('/proyecto/{projectId}/fase/guardar', [AnalystController::class, 'savePhase'])->name('fabricasoft.analyst.projects.phase.save');
        
        // Ruta para guardar fase 2 (Análisis y SRS)
        Route::post('/proyecto/{projectId}/fase2/guardar', [AnalystController::class, 'savePhase2'])->name('fabricasoft.analyst.projects.phase2.save');
    });
    
    // Rutas de dashboards por rol
    Route::middleware(['auth'])->group(function() {
        Route::get('/desarrollador/dashboard', [FABRICASOFTController::class, 'desarrolladorDashboard'])->name('fabricasoft.desarrollador.dashboard');
        Route::get('/desarrollador/proyectos', [FABRICASOFTController::class, 'desarrolladorProjects'])->name('fabricasoft.desarrollador.projects');
        Route::get('/cliente-interno/dashboard', [FABRICASOFTController::class, 'clienteInternoDashboard'])->name('fabricasoft.cliente_interno.dashboard');
        Route::get('/cliente-externo/dashboard', [FABRICASOFTController::class, 'clienteExternoDashboard'])->name('fabricasoft.cliente_externo.dashboard');
        
        // Ruta para que el cliente externo vea los detalles de sus proyectos
        Route::get('/cliente-externo/proyecto/{id}', [FABRICASOFTController::class, 'showProjectForClient'])->name('fabricasoft.cliente_externo.projects.show');
    });
    
    // Rutas específicas del desarrollador
Route::prefix('desarrollador')->middleware(['auth', 'custom.role:fabricasoft.desarrollador'])->group(function() {
    Route::get('/proyecto/{id}', [ScrumProjectController::class, 'showProjectForDeveloper'])->name('fabricasoft.desarrollador.projects.show');
    
    // Rutas para gestión de información de fases
    Route::post('/proyecto/{projectId}/fase/info/agregar', [ScrumProjectController::class, 'addPhaseInfoForDeveloper'])->name('fabricasoft.desarrollador.projects.phase.info.add');
    Route::put('/proyecto/{projectId}/fase/informacion/actualizar-nuevo', [ScrumProjectController::class, 'updatePhaseInfoForDeveloper'])->name('fabricasoft.desarrollador.projects.phase.info.update.new');
    Route::delete('/proyecto/{projectId}/fase/informacion/{historyId}/eliminar', [ScrumProjectController::class, 'deletePhaseInfoForDeveloper'])->name('fabricasoft.desarrollador.projects.phase.info.delete');
    Route::get('/proyecto/{projectId}/fase/informacion/{historyId}/info', [ScrumProjectController::class, 'getPhaseInfoForDeveloper'])->name('fabricasoft.desarrollador.projects.phase.info.get');
});
});
