<?php

namespace Modules\FABRICASOFT\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Modules\FABRICASOFT\Entities\Project;
use Modules\FABRICASOFT\Entities\ProjectPhase;

class UpdateProjectPhases extends Command
{
    protected $signature = 'fabricasoft:update-project-phases {project_id?}';
    protected $description = 'Actualizar las fases de un proyecto existente con el nuevo flujo de trabajo';

    public function handle()
    {
        $projectId = $this->argument('project_id');
        
        if (!$projectId) {
            $this->error('Debes especificar el ID del proyecto');
            return;
        }
        
        $project = Project::find($projectId);
        if (!$project) {
            $this->error("Proyecto con ID {$projectId} no encontrado");
            return;
        }
        
        $this->info("Actualizando fases del proyecto: {$project->project_name}");
        
        // Eliminar fases existentes
        ProjectPhase::where('project_id', $projectId)->delete();
        $this->info('✅ Fases existentes eliminadas');
        
        // Crear nuevas fases
        $phases = [
            [
                'phase_name' => 'Definición de Necesidades',
                'description' => 'Recepción y análisis inicial de la solicitud del cliente. El admin revisa y aprueba la solicitud.',
                'type' => 'milestone',
                'status' => 'completed', // Se completa cuando se crea el proyecto
                'duration_days' => 3,
                'order' => 1,
            ],
            [
                'phase_name' => 'Análisis y SRS',
                'description' => 'El analista revisa la solicitud, se comunica con el cliente y crea el documento de Especificación de Requisitos del Software (SRS).',
                'type' => 'milestone',
                'status' => 'planned',
                'duration_days' => 10,
                'order' => 2,
            ],
            [
                'phase_name' => 'Diseño del Sistema',
                'description' => 'Diseño de la arquitectura, base de datos, interfaces y componentes del sistema basado en el SRS.',
                'type' => 'milestone',
                'status' => 'planned',
                'duration_days' => 14,
                'order' => 3,
            ],
            [
                'phase_name' => 'Codificación',
                'description' => 'Desarrollo e implementación del código según el diseño establecido. Los desarrolladores trabajan en las funcionalidades.',
                'type' => 'milestone',
                'status' => 'planned',
                'duration_days' => 21,
                'order' => 4,
            ],
            [
                'phase_name' => 'Pruebas',
                'description' => 'Ejecución de pruebas unitarias, de integración y del sistema para validar la funcionalidad.',
                'type' => 'milestone',
                'status' => 'planned',
                'duration_days' => 10,
                'order' => 5,
            ],
            [
                'phase_name' => 'Validación',
                'description' => 'Validación final con el cliente, pruebas de aceptación y ajustes finales antes de la entrega.',
                'type' => 'milestone',
                'status' => 'planned',
                'duration_days' => 7,
                'order' => 6,
            ],
            [
                'phase_name' => 'Mantenimiento',
                'description' => 'Soporte post-entrega, corrección de errores y mejoras continuas del sistema.',
                'type' => 'milestone',
                'status' => 'planned',
                'duration_days' => 30,
                'order' => 7,
            ],
        ];
        
        foreach ($phases as $phaseData) {
            ProjectPhase::create(array_merge($phaseData, ['project_id' => $projectId]));
            $this->line("✅ Fase creada: {$phaseData['phase_name']}");
        }
        
        $this->info("🎉 Proyecto actualizado exitosamente con " . count($phases) . " fases");
    }
}
