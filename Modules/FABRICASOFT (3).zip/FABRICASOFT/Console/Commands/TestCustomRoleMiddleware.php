<?php

namespace Modules\FABRICASOFT\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class TestCustomRoleMiddleware extends Command
{
    protected $signature = 'fabricasoft:test-middleware {email} {role}';
    protected $description = 'Probar el middleware personalizado de roles';

    public function handle()
    {
        $email = $this->argument('email');
        $role = $this->argument('role');

        $this->info("Probando middleware para usuario: {$email} y rol: {$role}");

        // Buscar el usuario
        $user = DB::table('users')->where('email', $email)->first();
        if (!$user) {
            $this->error("Usuario no encontrado");
            return 1;
        }

        $this->line("Usuario encontrado: {$user->nickname} (ID: {$user->id})");

        // Verificar si tiene el rol
        $hasRole = DB::table('role_user')
            ->join('roles', 'role_user.role_id', '=', 'roles.id')
            ->where('role_user.user_id', $user->id)
            ->where('roles.slug', $role)
            ->exists();

        if ($hasRole) {
            $this->info("✅ El usuario SÍ tiene el rol {$role}");
        } else {
            $this->error("❌ El usuario NO tiene el rol {$role}");
        }

        // Mostrar todos los roles del usuario
        $this->line('');
        $this->info("Roles del usuario:");
        $userRoles = DB::table('role_user')
            ->join('roles', 'role_user.role_id', '=', 'roles.id')
            ->where('role_user.user_id', $user->id)
            ->select('roles.name', 'roles.slug')
            ->get();

        foreach ($userRoles as $userRole) {
            $this->line("  - {$userRole->name} ({$userRole->slug})");
        }

        return 0;
    }
}
