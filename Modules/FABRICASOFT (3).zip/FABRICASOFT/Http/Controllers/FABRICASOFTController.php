<?php

namespace Modules\FABRICASOFT\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB; // Added this import for DB facade

class FABRICASOFTController extends Controller
{
    /**
     * Vista principal del módulo (accesible sin autenticación)
     * Si el usuario está autenticado, lo redirige a su dashboard
     */
    public function index()
    {
        // Si el usuario está autenticado, redirigirlo a su dashboard
        if (Auth::check()) {
            $user = Auth::user();
            
            // Debug temporal - mostrar información del usuario
            if (request()->has('debug')) {
                dd([
                    'user_id' => $user->id,
                    'user_name' => $user->name,
                    'user_roles' => $user->roles->pluck('name', 'slug')->toArray(),
                    'has_role_fabricasoft_admin' => $user->hasCustomRole('fabricasoft.admin'),
                    'has_role_fabricasoft_desarrollador' => $user->hasCustomRole('fabricasoft.desarrollador'),
                    'has_role_fabricasoft_cliente_interno' => $user->hasCustomRole('fabricasoft.cliente_interno'),
                    'has_role_fabricasoft_cliente_externo' => $user->hasCustomRole('fabricasoft.cliente_externo'),
                ]);
            }
            
            // Verificar roles usando nuestro método personalizado
            $roles = [
                'has_role_fabricasoft_admin' => $user->hasCustomRole('fabricasoft.admin'),
                'has_role_fabricasoft_analista' => $user->hasCustomRole('fabricasoft.analista'),
                'has_role_fabricasoft_desarrollador' => $user->hasCustomRole('fabricasoft.desarrollador'),
                'has_role_fabricasoft_cliente_interno' => $user->hasCustomRole('fabricasoft.cliente_interno'),
                'has_role_fabricasoft_cliente_externo' => $user->hasCustomRole('fabricasoft.cliente_externo'),
            ];
            
            // Redirigir según el rol
            if ($user->hasCustomRole('fabricasoft.admin')) {
                return redirect()->route('fabricasoft.admin.dashboard');
            } elseif ($user->hasCustomRole('fabricasoft.analista')) {
                return redirect()->route('fabricasoft.analyst.dashboard');
            } elseif ($user->hasCustomRole('fabricasoft.desarrollador')) {
                return redirect()->route('fabricasoft.desarrollador.dashboard');
            } elseif ($user->hasCustomRole('fabricasoft.cliente_interno')) {
                return redirect()->route('fabricasoft.cliente_interno.dashboard');
            } elseif ($user->hasCustomRole('fabricasoft.cliente_externo')) {
                return redirect()->route('fabricasoft.cliente_externo.dashboard');
            }
            
            // Si no tiene ningún rol específico en FABRICASOFT, mostrar mensaje
            return view('fabricasoft::index')->with('no_role_message', 'No tienes un rol asignado en FABRICASOFT. Contacta al administrador.');
        }
        
        // Si no está autenticado, mostrar la página de bienvenida
        return view('fabricasoft::index');
    }

    /**
     * Dashboard del administrador
     */
    public function adminDashboard()
    {
        if (!Auth::user()->hasCustomRole('fabricasoft.admin')) {
            abort(403, 'Acceso denegado. Solo administradores pueden acceder a esta sección.');
        }
        
        return redirect()->route('fabricasoft.admin.dashboard');
    }
    
    /**
     * Dashboard del analista
     */
    public function analystDashboard()
    {
        return redirect()->route('fabricasoft.analyst.dashboard');
    }

    /**
     * Dashboard del desarrollador
     */
    public function desarrolladorDashboard()
    {
        if (!Auth::user()->hasCustomRole('fabricasoft.desarrollador')) {
            abort(403, 'Acceso denegado. Solo desarrolladores pueden acceder a esta sección.');
        }
        
        $developerId = Auth::id();
        
        // Obtener proyectos asignados al desarrollador
        $projects = \Modules\FABRICASOFT\Entities\Project::whereHas('teamMembers', function($query) use ($developerId) {
            $query->where('user_id', $developerId)
                  ->where('status', 'active');
        })->with(['phases', 'teamMembers', 'preregistration', 'scrumMaster'])
          ->orderBy('created_at', 'desc')
          ->get();
        
        // Calcular estadísticas generales
        $stats = [
            'total_projects' => $projects->count(),
            'active_projects' => $projects->where('status', 'active')->count(),
            'completed_projects' => $projects->where('status', 'completed')->count(),
            'total_phases' => $projects->sum(function($project) {
                return $project->phases->count();
            }),
            'completed_phases' => $projects->sum(function($project) {
                return $project->phases->where('status', 'completed')->count();
            }),
            'in_progress_phases' => $projects->sum(function($project) {
                return $project->phases->where('status', 'in_progress')->count();
            }),
            'planned_phases' => $projects->sum(function($project) {
                return $project->phases->where('status', 'planned')->count();
            })
        ];
        
        // Calcular progreso general
        $stats['overall_progress'] = $stats['total_phases'] > 0 
            ? round(($stats['completed_phases'] / $stats['total_phases']) * 100, 1)
            : 0;
        
        // Obtener actividad reciente (últimas 8 entradas)
        $recentActivity = \Modules\FABRICASOFT\Entities\PhaseInfoHistory::whereHas('project.teamMembers', function($query) use ($developerId) {
            $query->where('user_id', $developerId)
                  ->where('status', 'active');
        })->with(['project', 'phase'])
          ->orderBy('created_at', 'desc')
          ->limit(8)
          ->get();
        
        // Proyectos con mejor progreso (top 3)
        $topProjects = $projects->sortByDesc(function($project) {
            $totalPhases = $project->phases->count();
            $completedPhases = $project->phases->where('status', 'completed')->count();
            return $totalPhases > 0 ? ($completedPhases / $totalPhases) * 100 : 0;
        })->take(3);
        
        // Fases próximas a vencer (en los próximos 7 días)
        $upcomingDeadlines = collect();
        foreach ($projects as $project) {
            foreach ($project->phases as $phase) {
                if ($phase->end_date && $phase->status !== 'completed') {
                    $daysUntilDeadline = now()->diffInDays($phase->end_date, false);
                    if ($daysUntilDeadline >= 0 && $daysUntilDeadline <= 7) {
                        $upcomingDeadlines->push([
                            'phase' => $phase,
                            'project' => $project,
                            'days_until' => $daysUntilDeadline
                        ]);
                    }
                }
            }
        }
        $upcomingDeadlines = $upcomingDeadlines->sortBy('days_until')->take(5);
        
        // Fases asignadas al desarrollador
        $myAssignedPhases = collect();
        foreach ($projects as $project) {
            foreach ($project->phases as $phase) {
                if ($phase->assigned_to === $developerId && $phase->status !== 'completed') {
                    $myAssignedPhases->push([
                        'phase' => $phase,
                        'project' => $project
                    ]);
                }
            }
        }
        $myAssignedPhases = $myAssignedPhases->sortBy('phase.end_date')->take(6);
        
        return view('fabricasoft::desarrollador.dashboard', compact(
            'projects', 
            'stats', 
            'recentActivity', 
            'topProjects',
            'upcomingDeadlines',
            'myAssignedPhases'
        ));
    }
    
    /**
     * Dashboard del cliente interno
     */
    public function clienteInternoDashboard()
    {
        if (!Auth::user()->hasCustomRole('fabricasoft.cliente_interno')) {
            abort(403, 'Acceso denegado. Solo clientes internos pueden acceder a esta sección.');
        }
        
        return view('fabricasoft::cliente_interno.dashboard');
    }
    
    /**
     * Dashboard del cliente externo
     */
    public function clienteExternoDashboard()
    {
        if (!Auth::user()->hasCustomRole('fabricasoft.cliente_externo')) {
            abort(403, 'Acceso denegado. Solo clientes externos pueden acceder a esta sección.');
        }

        $user = Auth::user();
        
        // Obtener las solicitudes aprobadas del cliente externo
        $solicitudesAprobadas = \Modules\FABRICASOFT\Entities\Preregistration::where('email', $user->email)
            ->where('status', 'approved')
            ->orderBy('created_at', 'desc')
            ->get();

        // Obtener proyectos creados a partir de las solicitudes aprobadas
        $proyectos = \Modules\FABRICASOFT\Entities\Project::whereIn('preregistration_id', $solicitudesAprobadas->pluck('id'))
            ->with(['preregistration', 'phases', 'teamMembers'])
            ->orderBy('created_at', 'desc')
            ->get();

        // Calcular estadísticas
        $stats = [
            'total_proyectos' => $proyectos->count(),
            'proyectos_activos' => $proyectos->where('status', 'active')->count(),
            'proyectos_completados' => $proyectos->where('status', 'completed')->count(),
            'proyectos_pendientes' => $proyectos->where('status', 'pending')->count(),
        ];

        return view('fabricasoft::cliente_externo.dashboard', compact('proyectos', 'solicitudesAprobadas', 'stats'));
    }
    
    /**
     * Proyectos Scrum asignados al desarrollador
     */
    public function desarrolladorProjects()
    {
        if (!Auth::user()->hasCustomRole('fabricasoft.desarrollador')) {
            abort(403, 'Acceso denegado. Solo desarrolladores pueden acceder a esta sección.');
        }
        
        $developerId = Auth::id();
        
        // Buscar proyectos donde el desarrollador sea miembro del equipo
        $projects = \Modules\FABRICASOFT\Entities\Project::whereHas('teamMembers', function($query) use ($developerId) {
            $query->where('user_id', $developerId)
                  ->where('status', 'active');
        })->with(['preregistration', 'phases', 'teamMembers'])
          ->orderBy('created_at', 'desc')
          ->get();
        
        // Calcular estadísticas
        $stats = [
            'total_projects' => $projects->count(),
            'in_development' => $projects->where('status', 'in_progress')->count(),
            'completed' => $projects->where('status', 'completed')->count(),
            'completed_phases' => $projects->sum(function($project) {
                return $project->phases->where('status', 'completed')->count();
            })
        ];
        
        return view('fabricasoft::desarrollador.projects', compact('projects', 'stats'));
    }

    /**
     * Mostrar proyecto para cliente externo
     */
    public function showProjectForClient($id)
    {
        if (!Auth::user()->hasCustomRole('fabricasoft.cliente_externo')) {
            abort(403, 'Acceso denegado. Solo clientes externos pueden acceder a esta sección.');
        }

        $user = Auth::user();
        
        // Obtener el proyecto y verificar que pertenezca al cliente externo
        $proyecto = \Modules\FABRICASOFT\Entities\Project::where('id', $id)
            ->whereHas('preregistration', function($query) use ($user) {
                $query->where('email', $user->email);
            })
            ->with(['preregistration', 'phases', 'teamMembers'])
            ->firstOrFail();

        // Cargar información del historial de las fases
        foreach ($proyecto->phases as $phase) {
            $phase->phaseInfoHistory = DB::table('fabricasoft_phase_info_history')
                ->where('project_id', $id)
                ->where('phase_id', $phase->id)
                ->orderBy('created_at', 'desc')
                ->get();
        }

        return view('fabricasoft::cliente_externo.show_project', compact('proyecto'));
    }
}