@extends('fabricasoft::layouts.app')
@section('title', 'Dashboard Cliente Interno - FABRICASOFT')
@section('content')

<!-- Header del Dashboard -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="mb-1">
            <i class="fas fa-building me-2" style="color: var(--sena-green);"></i>
            Dashboard Cliente Interno
        </h2>
        <p class="text-muted mb-0">Panel de seguimiento de proyectos internos del SENA</p>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-sena-outline">
            <i class="fas fa-download me-2"></i>Descargar Reporte
        </button>
        <button class="btn btn-sena">
            <i class="fas fa-plus me-2"></i>Solicitar Proyecto
        </button>
    </div>
</div>

<!-- Tarjetas de Estadísticas -->
<div class="row mb-4">
    <div class="col-md-3 mb-3">
        <div class="stats-card">
            <div class="stats-icon">
                <i class="fas fa-project-diagram"></i>
            </div>
            <div class="stats-number">8</div>
            <div class="stats-label">Proyectos Activos</div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stats-card" style="background: linear-gradient(135deg, var(--sena-blue), #1976D2);">
            <div class="stats-icon">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stats-number">3</div>
            <div class="stats-label">En Espera</div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stats-card" style="background: linear-gradient(135deg, var(--sena-orange), #F57C00);">
            <div class="stats-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stats-number">15</div>
            <div class="stats-label">Completados</div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stats-card" style="background: linear-gradient(135deg, var(--sena-yellow), #FF8F00);">
            <div class="stats-icon">
                <i class="fas fa-percentage"></i>
            </div>
            <div class="stats-number">78%</div>
            <div class="stats-label">Satisfacción</div>
        </div>
    </div>
</div>

<!-- Contenido Principal -->
<div class="row">
    <!-- Proyectos Activos -->
    <div class="col-md-8 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-project-diagram me-2"></i>
                    Mis Proyectos Activos
                </h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Proyecto</th>
                                <th>Desarrollador</th>
                                <th>Estado</th>
                                <th>Progreso</th>
                                <th>Última Actualización</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                            <i class="fas fa-graduation-cap text-white"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0">Sistema de Gestión Académica</h6>
                                            <small class="text-muted">Centro Industrial</small>
                                        </div>
                                    </div>
                                </td>
                                <td>Carlos Rodríguez</td>
                                <td><span class="badge bg-success">En Desarrollo</span></td>
                                <td>
                                    <div class="progress" style="height: 8px;">
                                        <div class="progress-bar bg-success" style="width: 75%"></div>
                                    </div>
                                    <small class="text-muted">75%</small>
                                </td>
                                <td>Hace 2 horas</td>
                                <td>
                                    <button class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-info">
                                        <i class="fas fa-comment"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="bg-warning rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                            <i class="fas fa-chart-line text-white"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0">Dashboard de Métricas</h6>
                                            <small class="text-muted">Centro de Gestión</small>
                                        </div>
                                    </div>
                                </td>
                                <td>Ana Martínez</td>
                                <td><span class="badge bg-info">Análisis</span></td>
                                <td>
                                    <div class="progress" style="height: 8px;">
                                        <div class="progress-bar bg-info" style="width: 45%"></div>
                                    </div>
                                    <small class="text-muted">45%</small>
                                </td>
                                <td>Hace 1 día</td>
                                <td>
                                    <button class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-info">
                                        <i class="fas fa-comment"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="bg-success rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                            <i class="fas fa-database text-white"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0">Sistema de Inventarios</h6>
                                            <small class="text-muted">Centro Agroindustrial</small>
                                        </div>
                                    </div>
                                </td>
                                <td>Luis González</td>
                                <td><span class="badge bg-warning">Planificación</span></td>
                                <td>
                                    <div class="progress" style="height: 8px;">
                                        <div class="progress-bar bg-warning" style="width: 25%"></div>
                                    </div>
                                    <small class="text-muted">25%</small>
                                </td>
                                <td>Hace 3 días</td>
                                <td>
                                    <button class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-info">
                                        <i class="fas fa-comment"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Actividad y Acciones Rápidas -->
    <div class="col-md-4 mb-4">
        <!-- Actividad Reciente -->
        <div class="card mb-4">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-history me-2"></i>
                    Actividad Reciente
                </h6>
            </div>
            <div class="card-body">
                <div class="timeline">
                    <div class="d-flex mb-3">
                        <div class="bg-success rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 32px; height: 32px;">
                            <i class="fas fa-upload text-white" style="font-size: 12px;"></i>
                        </div>
                        <div>
                            <p class="mb-0 small"><strong>Documento subido</strong></p>
                            <small class="text-muted">Requerimientos actualizados - Hace 2 horas</small>
                        </div>
                    </div>
                    <div class="d-flex mb-3">
                        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 32px; height: 32px;">
                            <i class="fas fa-comment text-white" style="font-size: 12px;"></i>
                        </div>
                        <div>
                            <p class="mb-0 small"><strong>Comentario recibido</strong></p>
                            <small class="text-muted">Carlos Rodríguez - Hace 4 horas</small>
                        </div>
                    </div>
                    <div class="d-flex mb-3">
                        <div class="bg-info rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 32px; height: 32px;">
                            <i class="fas fa-calendar text-white" style="font-size: 12px;"></i>
                        </div>
                        <div>
                            <p class="mb-0 small"><strong>Reunión programada</strong></p>
                            <small class="text-muted">Revisión de proyecto - Mañana 10:00 AM</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Acciones Rápidas -->
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-bolt me-2"></i>
                    Acciones Rápidas
                </h6>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <button class="btn btn-sena-outline btn-sm">
                        <i class="fas fa-plus me-2"></i>Solicitar Proyecto
                    </button>
                    <button class="btn btn-sena-outline btn-sm">
                        <i class="fas fa-upload me-2"></i>Subir Documento
                    </button>
                    <button class="btn btn-sena-outline btn-sm">
                        <i class="fas fa-calendar me-2"></i>Programar Reunión
                    </button>
                    <button class="btn btn-sena-outline btn-sm">
                        <i class="fas fa-star me-2"></i>Evaluar Proyecto
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Proyectos Completados -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-check-circle me-2"></i>
                    Proyectos Completados Recientemente
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <div class="card border-success h-100">
                            <div class="card-body">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="bg-success rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                                        <i class="fas fa-check text-white"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0">Sistema de Reportes</h6>
                                        <small class="text-muted">Centro de Formación</small>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between mb-1">
                                        <small>Fecha de entrega:</small>
                                        <small class="text-success">15 Feb 2024</small>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <small class="text-muted">Evaluación:</small>
                                    <span class="badge bg-success">5.0 ⭐</span>
                                </div>
                                <div class="d-flex gap-2">
                                    <button class="btn btn-sena btn-sm flex-fill">
                                        <i class="fas fa-eye me-1"></i>Ver Proyecto
                                    </button>
                                    <button class="btn btn-sena-outline btn-sm">
                                        <i class="fas fa-download"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <div class="card border-success h-100">
                            <div class="card-body">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="bg-success rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                                        <i class="fas fa-check text-white"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0">Portal de Estudiantes</h6>
                                        <small class="text-muted">Centro Tecnológico</small>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between mb-1">
                                        <small>Fecha de entrega:</small>
                                        <small class="text-success">28 Ene 2024</small>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <small class="text-muted">Evaluación:</small>
                                    <span class="badge bg-success">4.8 ⭐</span>
                                </div>
                                <div class="d-flex gap-2">
                                    <button class="btn btn-sena btn-sm flex-fill">
                                        <i class="fas fa-eye me-1"></i>Ver Proyecto
                                    </button>
                                    <button class="btn btn-sena-outline btn-sm">
                                        <i class="fas fa-download"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <div class="card border-success h-100">
                            <div class="card-body">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="bg-success rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                                        <i class="fas fa-check text-white"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0">App de Notificaciones</h6>
                                        <small class="text-muted">Centro de Innovación</small>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between mb-1">
                                        <small>Fecha de entrega:</small>
                                        <small class="text-success">10 Ene 2024</small>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <small class="text-muted">Evaluación:</small>
                                    <span class="badge bg-success">4.9 ⭐</span>
                                </div>
                                <div class="d-flex gap-2">
                                    <button class="btn btn-sena btn-sm flex-fill">
                                        <i class="fas fa-eye me-1"></i>Ver Proyecto
                                    </button>
                                    <button class="btn btn-sena-outline btn-sm">
                                        <i class="fas fa-download"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Métricas y Reportes -->
<div class="row">
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-chart-pie me-2"></i>
                    Distribución por Estado
                </h6>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-center align-items-center" style="height: 200px;">
                    <div class="text-center">
                        <div class="mb-3">
                            <i class="fas fa-chart-pie fa-4x" style="color: var(--sena-green);"></i>
                        </div>
                        <p class="text-muted">Estado de proyectos</p>
                        <small class="text-muted">Activos: 8 | En Espera: 3 | Completados: 15</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-star me-2"></i>
                    Satisfacción del Cliente
                </h6>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-center align-items-center" style="height: 200px;">
                    <div class="text-center">
                        <div class="mb-3">
                            <i class="fas fa-star fa-4x" style="color: var(--sena-yellow);"></i>
                        </div>
                        <p class="text-muted">Promedio de evaluación</p>
                        <div class="h3 text-warning mb-2">4.8 ⭐</div>
                        <small class="text-muted">Basado en 15 proyectos completados</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
