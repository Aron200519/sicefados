@extends('fabricasoft::layouts.app')
@section('title', 'Detalles del Proyecto - FABRICASOFT')
@section('content')

<!-- Header del Proyecto -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="mb-1">
            <i class="fas fa-project-diagram me-2" style="color: var(--sena-green);"></i>
            Detalles del Proyecto
        </h2>
        <p class="text-muted mb-0">Seguimiento detallado del desarrollo de tu proyecto</p>
    </div>
    <div class="d-flex gap-2">
        <a href="{{ route('fabricasoft.cliente_externo.dashboard') }}" class="btn btn-sena-outline">
            <i class="fas fa-arrow-left me-2"></i>Volver al Dashboard
        </a>
    </div>
</div>

<!-- Información del Proyecto -->
<div class="row mb-4">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-info-circle me-2"></i>
                    Información del Proyecto
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Descripción del Proyecto</h6>
                        <p>{{ $proyecto->preregistration->project_description ?: 'Sin descripción' }}</p>
                        
                        <h6>Requisitos Adicionales</h6>
                        <p>{{ $proyecto->preregistration->additional_requirements ?: 'Sin requisitos adicionales' }}</p>
                    </div>
                    <div class="col-md-6">
                        <h6>Tipo de Software</h6>
                        <span class="badge bg-info fs-6">{{ $proyecto->preregistration->software_type }}</span>
                        
                        <h6 class="mt-3">Estado del Proyecto</h6>
                        @php
                            $statusClass = 'bg-secondary';
                            $statusText = 'Pendiente';
                            
                            switch($proyecto->status) {
                                case 'active':
                                    $statusClass = 'bg-success';
                                    $statusText = 'Activo';
                                    break;
                                case 'completed':
                                    $statusClass = 'bg-primary';
                                    $statusText = 'Completado';
                                    break;
                                case 'paused':
                                    $statusClass = 'bg-warning';
                                    $statusText = 'Pausado';
                                    break;
                                case 'cancelled':
                                    $statusClass = 'bg-danger';
                                    $statusText = 'Cancelado';
                                    break;
                            }
                        @endphp
                        <span class="badge {{ $statusClass }} fs-6">{{ $statusText }}</span>
                        
                        <h6 class="mt-3">Fecha de Creación</h6>
                        <p>{{ $proyecto->created_at->format('d/m/Y H:i:s') }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-users me-2"></i>
                    Equipo del Proyecto
                </h5>
            </div>
            <div class="card-body">
                @if($proyecto->teamMembers->count() > 0)
                    @foreach($proyecto->teamMembers as $member)
                        <div class="d-flex align-items-center mb-2">
                            <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 32px; height: 32px;">
                                <i class="fas fa-user text-white"></i>
                            </div>
                            <div>
                                <small class="fw-bold">{{ $member->user->nickname ?: $member->user->email }}</small><br>
                                <small class="text-muted">{{ $member->role }}</small>
                            </div>
                        </div>
                    @endforeach
                @else
                    <p class="text-muted text-center">No hay miembros asignados</p>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- Fases del Proyecto -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-tasks me-2"></i>
            Fases del Proyecto
        </h5>
    </div>
    <div class="card-body">
        @if($proyecto->phases->count() > 0)
            <div class="row">
                @foreach($proyecto->phases as $phase)
                    <div class="col-md-6 mb-3">
                        <div class="card border-{{ $phase->status === 'completed' ? 'success' : ($phase->status === 'active' ? 'primary' : 'secondary') }}">
                            <div class="card-header bg-{{ $phase->status === 'completed' ? 'success' : ($phase->status === 'active' ? 'primary' : 'secondary') }} text-white">
                                <h6 class="mb-0">
                                    <i class="fas fa-{{ $phase->status === 'completed' ? 'check-circle' : ($phase->status === 'active' ? 'play-circle' : 'clock') }} me-2"></i>
                                    {{ $phase->name }}
                                </h6>
                            </div>
                            <div class="card-body">
                                <p class="card-text">{{ $phase->description ?: 'Sin descripción' }}</p>
                                
                                <div class="mb-2">
                                    <small class="text-muted">Estado:</small>
                                    <span class="badge bg-{{ $phase->status === 'completed' ? 'success' : ($phase->status === 'active' ? 'primary' : 'secondary') }}">
                                        {{ ucfirst($phase->status) }}
                                    </span>
                                </div>
                                
                                @if($phase->start_date)
                                    <div class="mb-2">
                                        <small class="text-muted">Fecha de inicio:</small><br>
                                        <strong>{{ \Carbon\Carbon::parse($phase->start_date)->format('d/m/Y') }}</strong>
                                    </div>
                                @endif
                                
                                @if($phase->end_date)
                                    <div class="mb-2">
                                        <small class="text-muted">Fecha de finalización:</small><br>
                                        <strong>{{ \Carbon\Carbon::parse($phase->end_date)->format('d/m/Y') }}</strong>
                                    </div>
                                @endif
                                
                                <!-- Información del historial de la fase -->
                                @if($phase->phaseInfoHistory && $phase->phaseInfoHistory->count() > 0)
                                    <div class="mt-3">
                                        <h6 class="text-muted">Información de la Fase</h6>
                                        @foreach($phase->phaseInfoHistory->take(3) as $info)
                                            <div class="border-start border-2 border-primary ps-3 mb-2">
                                                <small class="text-muted">{{ $info->created_at ? \Carbon\Carbon::parse($info->created_at)->format('d/m/Y H:i') : 'Sin fecha' }}</small>
                                                <p class="mb-1">{{ $info->description ?: 'Sin descripción' }}</p>
                                                @if($info->notes)
                                                    <small class="text-muted">{{ $info->notes }}</small>
                                                @endif
                                            </div>
                                        @endforeach
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        @else
            <div class="text-center py-4">
                <i class="fas fa-tasks fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">No hay fases definidas</h5>
                <p class="text-muted">Las fases del proyecto se definirán durante el desarrollo.</p>
            </div>
        @endif
    </div>
</div>

@endsection
