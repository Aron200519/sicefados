@extends('fabricasoft::layouts.app')
@section('title', 'Dashboard Cliente Interno - FABRICASOFT')
@section('content')

<!-- Header del Dashboard -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="mb-1">
            <i class="fas fa-handshake me-2" style="color: var(--sena-green);"></i>
            Dashboard Cliente Interno
        </h2>
        <p class="text-muted mb-0">Panel de seguimiento de proyectos contratados internamente</p>
    </div>
    <div class="d-flex gap-2">
        <a href="{{ route('fabricasoft.cliente_interno.projects') }}" class="btn btn-sena-outline">
            <i class="fas fa-list me-2"></i>Ver Todos los Proyectos
        </a>
        @php
            $proyectoActivo = $proyectos->whereIn('status', ['planning', 'active'])->first();
        @endphp
        @if(!$proyectoActivo)
            <a href="{{ route('fabricasoft.cliente_interno.nueva-solicitud') }}" class="btn btn-sena">
                <i class="fas fa-plus me-2"></i>Nueva Solicitud
            </a>
        @else
            <button class="btn btn-secondary" disabled title="No puedes crear una nueva solicitud mientras tengas un proyecto activo">
                <i class="fas fa-plus me-2"></i>Nueva Solicitud
            </button>
        @endif
    </div>
</div>

<!-- Mensajes de Sesión -->
@if(session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fas fa-check-circle me-2"></i>
        {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
@endif

@if(session('error'))
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fas fa-exclamation-triangle me-2"></i>
        {{ session('error') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
@endif

<!-- Mensaje Informativo -->
@if($proyectos->count() == 0)
    <div class="alert alert-info" role="alert">
        <div class="d-flex align-items-center">
            <i class="fas fa-info-circle fa-2x me-3"></i>
            <div>
                <h5 class="alert-heading">¡Bienvenido a FABRICASOFT!</h5>
                <p class="mb-0">
                    Tu solicitud ha sido aprobada exitosamente. Una vez que se cree el proyecto y se asigne el equipo de desarrollo, 
                    podrás ver aquí el seguimiento completo de tu proyecto, incluyendo las fases, el progreso y el equipo asignado.
                </p>
            </div>
        </div>
    </div>
@endif

<!-- Tarjetas de Estadísticas -->
<div class="row mb-4">
    <div class="col-md-3 mb-3">
        <div class="stats-card">
            <div class="stats-icon">
                <i class="fas fa-project-diagram"></i>
            </div>
            <div class="stats-number">{{ $stats['total_proyectos'] }}</div>
            <div class="stats-label">Total de Proyectos</div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stats-card" style="background: linear-gradient(135deg, var(--sena-blue), #1976D2);">
            <div class="stats-icon">
                <i class="fas fa-play-circle"></i>
            </div>
            <div class="stats-number">{{ $stats['proyectos_activos'] }}</div>
            <div class="stats-label">Proyectos Activos</div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stats-card" style="background: linear-gradient(135deg, var(--sena-orange), #F57C00);">
            <div class="stats-icon">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stats-number">{{ $stats['proyectos_pendientes'] }}</div>
            <div class="stats-label">Proyectos Pendientes</div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stats-card" style="background: linear-gradient(135deg, var(--sena-yellow), #FF8F00);">
            <div class="stats-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stats-number">{{ $stats['proyectos_completados'] }}</div>
            <div class="stats-label">Proyectos Completados</div>
        </div>
    </div>
</div>

<!-- Contenido Principal -->
<div class="row">
    <!-- Proyectos Contratados -->
    <div class="col-md-8 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-project-diagram me-2"></i>
                    Mis Proyectos Contratados
                </h5>
            </div>
            <div class="card-body">
                @if($proyectos->count() > 0)
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Proyecto</th>
                                    <th>Estado</th>
                                    <th>Progreso</th>
                                    <th>Scrum Master</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($proyectos->take(5) as $proyecto)
                                    @php
                                        $totalPhases = $proyecto->phases->count();
                                        $completedPhases = $proyecto->phases->where('status', 'completed')->count();
                                        $progressPercentage = $totalPhases > 0 ? round(($completedPhases / $totalPhases) * 100) : 0;
                                    @endphp
                                    <tr>
                                        <td>
                                            <div>
                                                <strong>{{ Str::limit($proyecto->preregistration->project_description ?: 'Proyecto #' . $proyecto->id, 40) }}</strong>
                                                <br>
                                                <small class="text-muted">
                                                    {{ $proyecto->preregistration->software_type ?? 'Tipo no especificado' }}
                                                </small>
                                            </div>
                                        </td>
                                        <td>
                                            @if($proyecto->status == 'planning')
                                                <span class="badge bg-warning">En Planificación</span>
                                            @elseif($proyecto->status == 'active')
                                                <span class="badge bg-info">Activo</span>
                                            @elseif($proyecto->status == 'completed')
                                                <span class="badge bg-success">Completado</span>
                                            @else
                                                <span class="badge bg-secondary">{{ $proyecto->status_text }}</span>
                                            @endif
                                        </td>
                                        <td>
                                            @if($totalPhases > 0)
                                                <div class="d-flex align-items-center">
                                                    <div class="progress me-2" style="width: 60px; height: 6px;">
                                                        <div class="progress-bar bg-success" role="progressbar" 
                                                             style="width: {{ $progressPercentage }}%" 
                                                             aria-valuenow="{{ $progressPercentage }}" 
                                                             aria-valuemin="0" aria-valuemax="100">
                                                        </div>
                                                    </div>
                                                    <small class="text-muted">{{ $progressPercentage }}%</small>
                                                </div>
                                                <small class="text-muted">{{ $completedPhases }}/{{ $totalPhases }} fases</small>
                                            @else
                                                <span class="text-muted">Sin fases</span>
                                            @endif
                                        </td>
                                        <td>
                                            <div>
                                                <strong>{{ $proyecto->scrumMaster->nickname ?? $proyecto->scrumMaster->name ?? 'No asignado' }}</strong>
                                                <br>
                                                <small class="text-muted">{{ $proyecto->scrumMaster->email ?? '' }}</small>
                                            </div>
                                        </td>
                                        <td>
                                            <a href="{{ route('fabricasoft.cliente_interno.projects.show', $proyecto->id) }}" 
                                               class="btn btn-info btn-sm">
                                                <i class="fas fa-eye me-1"></i>Ver Avance
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    
                    @if($proyectos->count() > 5)
                        <div class="text-center mt-3">
                            <a href="{{ route('fabricasoft.cliente_interno.projects') }}" class="btn btn-sena-outline">
                                <i class="fas fa-list me-2"></i>Ver Todos los Proyectos ({{ $proyectos->count() }})
                            </a>
                        </div>
                    @endif
                @else
                    <div class="text-center py-4">
                        <i class="fas fa-folder-open fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No tienes proyectos contratados</h5>
                        <p class="text-muted">Una vez que se aprueben tus solicitudes y se creen los proyectos, aparecerán aquí.</p>
                        <a href="{{ route('fabricasoft.cliente_interno.nueva-solicitud') }}" class="btn btn-sena">
                            <i class="fas fa-plus me-2"></i>Crear Primera Solicitud
                        </a>
                    </div>
                @endif
            </div>
        </div>
    </div>

    <!-- Panel Derecho -->
    <div class="col-md-4 mb-4">
        <!-- Resumen Rápido -->
        <div class="card mb-4">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-chart-pie me-2"></i>
                    Resumen Rápido
                </h6>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <div class="d-flex justify-content-between">
                        <span>Proyectos Activos:</span>
                        <strong class="text-info">{{ $stats['proyectos_activos'] }}</strong>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="d-flex justify-content-between">
                        <span>En Planificación:</span>
                        <strong class="text-warning">{{ $stats['proyectos_pendientes'] }}</strong>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="d-flex justify-content-between">
                        <span>Completados:</span>
                        <strong class="text-success">{{ $stats['proyectos_completados'] }}</strong>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="d-flex justify-content-between">
                        <span>Total Fases:</span>
                        <strong class="text-primary">{{ $stats['total_fases'] }}</strong>
                    </div>
                </div>
            </div>
        </div>

        <!-- Acciones Rápidas -->
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-bolt me-2"></i>
                    Acciones Rápidas
                </h6>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="{{ route('fabricasoft.cliente_interno.projects') }}" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-list me-2"></i>Ver Todos los Proyectos
                    </a>
                    <a href="{{ route('fabricasoft.cliente_interno.nueva-solicitud') }}" class="btn btn-outline-success btn-sm">
                        <i class="fas fa-plus me-2"></i>Nueva Solicitud
                    </a>
                    <a href="{{ route('fabricasoft.cliente_interno.ajustes') }}" class="btn btn-outline-info btn-sm">
                        <i class="fas fa-cog me-2"></i>Configuración
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@push('styles')
<style>
.stats-card {
    background: linear-gradient(135deg, var(--sena-green), #2E7D32);
    color: white;
    padding: 1.5rem;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s ease-in-out;
}

.stats-card:hover {
    transform: translateY(-5px);
}

.stats-icon {
    font-size: 2rem;
    margin-bottom: 1rem;
    opacity: 0.9;
}

.stats-number {
    font-size: 2rem;
    font-weight: bold;
    margin-bottom: 0.5rem;
}

.stats-label {
    font-size: 0.9rem;
    opacity: 0.9;
}

.card {
    border: none;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
}

.card-header {
    background-color: #f8f9fa;
    border-bottom: 1px solid #e9ecef;
    border-radius: 10px 10px 0 0 !important;
}

.table th {
    border-top: none;
    font-weight: 600;
    color: #495057;
}

.progress {
    border-radius: 10px;
}

.badge {
    font-size: 0.75rem;
    padding: 0.5em 0.75em;
}
</style>
@endpush
