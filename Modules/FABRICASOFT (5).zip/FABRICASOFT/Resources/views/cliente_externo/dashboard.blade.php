@extends('fabricasoft::layouts.app')
@section('title', 'Dashboard Cliente Externo - FABRICASOFT')
@section('content')

<!-- Header del Dashboard -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="mb-1">
            <i class="fas fa-handshake me-2" style="color: var(--sena-green);"></i>
            Dashboard Cliente Externo
        </h2>
        <p class="text-muted mb-0">Panel de seguimiento de proyectos contratados externamente</p>
    </div>
    <div class="d-flex gap-2">
        <a href="{{ route('cliente_externo.projects') }}" class="btn btn-sena-outline">
            <i class="fas fa-list me-2"></i>Ver Todos los Proyectos
        </a>
        @php
            $proyectoActivo = $proyectos->whereIn('status', ['planning', 'active'])->first();
        @endphp
        @if(!$proyectoActivo)
            <a href="{{ route('cliente_externo.nueva-solicitud') }}" class="btn btn-sena">
                <i class="fas fa-plus me-2"></i>Nueva Solicitud
            </a>
        @else
            <button class="btn btn-secondary" disabled title="No puedes crear una nueva solicitud mientras tengas un proyecto activo">
                <i class="fas fa-plus me-2"></i>Nueva Solicitud
            </button>
        @endif
    </div>
</div>

<!-- Mensaje Informativo -->
@if($proyectos->count() == 0)
    <div class="alert alert-info" role="alert">
        <div class="d-flex align-items-center">
            <i class="fas fa-info-circle fa-2x me-3"></i>
            <div>
                <h5 class="alert-heading">¡Bienvenido a FABRICASOFT!</h5>
                <p class="mb-0">
                    Tu solicitud ha sido aprobada exitosamente. Una vez que se cree el proyecto y se asigne el equipo de desarrollo, 
                    podrás ver aquí el seguimiento completo de tu proyecto, incluyendo las fases, el progreso y el equipo asignado.
                </p>
            </div>
        </div>
    </div>
@endif

<!-- Tarjetas de Estadísticas -->
<div class="row mb-4">
    <div class="col-md-3 mb-3">
        <div class="stats-card">
            <div class="stats-icon">
                <i class="fas fa-project-diagram"></i>
            </div>
            <div class="stats-number">{{ $stats['total_proyectos'] }}</div>
            <div class="stats-label">Total de Proyectos</div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stats-card" style="background: linear-gradient(135deg, var(--sena-blue), #1976D2);">
            <div class="stats-icon">
                <i class="fas fa-play-circle"></i>
            </div>
            <div class="stats-number">{{ $stats['proyectos_activos'] }}</div>
            <div class="stats-label">Proyectos Activos</div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stats-card" style="background: linear-gradient(135deg, var(--sena-orange), #F57C00);">
            <div class="stats-icon">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stats-number">{{ $stats['proyectos_pendientes'] }}</div>
            <div class="stats-label">Proyectos Pendientes</div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="stats-card" style="background: linear-gradient(135deg, var(--sena-yellow), #FF8F00);">
            <div class="stats-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stats-number">{{ $stats['proyectos_completados'] }}</div>
            <div class="stats-label">Proyectos Completados</div>
        </div>
    </div>
</div>

<!-- Contenido Principal -->
<div class="row">
    <!-- Proyectos Contratados -->
    <div class="col-md-8 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-project-diagram me-2"></i>
                    Mis Proyectos Contratados
                </h5>
            </div>
            <div class="card-body">
                @if($proyectos->count() > 0)
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Proyecto</th>
                                    <th>Tipo de Software</th>
                                    <th>Estado</th>
                                    <th>Progreso</th>
                                    <th>Fecha Creación</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($proyectos as $proyecto)
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                                    <i class="fas fa-project-diagram text-white"></i>
                                                </div>
                                                <div>
                                                    <h6 class="mb-0">{{ $proyecto->preregistration->project_description ?: 'Proyecto #' . $proyecto->id }}</h6>
                                                    <small class="text-muted">{{ $proyecto->preregistration->organization ?: 'Sin organización' }}</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-info">{{ $proyecto->preregistration->software_type }}</span>
                                        </td>
                                        <td>
                                            @php
                                                $statusClass = 'bg-secondary';
                                                $statusText = 'Pendiente';
                                                
                                                switch($proyecto->status) {
                                                    case 'active':
                                                        $statusClass = 'bg-success';
                                                        $statusText = 'Activo';
                                                        break;
                                                    case 'completed':
                                                        $statusClass = 'bg-primary';
                                                        $statusText = 'Completado';
                                                        break;
                                                    case 'paused':
                                                        $statusClass = 'bg-warning';
                                                        $statusText = 'Pausado';
                                                        break;
                                                    case 'cancelled':
                                                        $statusClass = 'bg-danger';
                                                        $statusText = 'Cancelado';
                                                        break;
                                                }
                                            @endphp
                                            <span class="badge {{ $statusClass }}">{{ $statusText }}</span>
                                        </td>
                                        <td>
                                            @php
                                                $progress = 0;
                                                if($proyecto->phases->count() > 0) {
                                                    $completedPhases = $proyecto->phases->where('status', 'completed')->count();
                                                    $progress = round(($completedPhases / $proyecto->phases->count()) * 100);
                                                }
                                                
                                                $progressClass = 'bg-secondary';
                                                if($progress >= 80) $progressClass = 'bg-success';
                                                elseif($progress >= 50) $progressClass = 'bg-info';
                                                elseif($progress >= 20) $progressClass = 'bg-warning';
                                            @endphp
                                            <div class="progress" style="height: 8px;">
                                                <div class="progress-bar {{ $progressClass }}" style="width: {{ $progress }}%"></div>
                                            </div>
                                            <small class="text-muted">{{ $progress }}%</small>
                                        </td>
                                        <td>{{ $proyecto->created_at->format('d/m/Y') }}</td>
                                        <td>
                                            <a href="{{ route('cliente_externo.projects.show', $proyecto->id) }}" 
                                               class="btn btn-primary btn-sm">
                                                <i class="fas fa-eye me-2"></i>Ver Detalles
                                            </a>
                                            <button class="btn btn-sm btn-outline-info" title="Comentarios">
                                                <i class="fas fa-comment"></i>
                                            </button>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @else
                    <div class="text-center py-4">
                        <i class="fas fa-folder-open fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No tienes proyectos contratados</h5>
                        <p class="text-muted">Una vez que se aprueben tus solicitudes, aparecerán aquí.</p>
                    </div>
                @endif
            </div>
        </div>
    </div>
    
    <!-- Actividad y Acciones Rápidas -->
    <div class="col-md-4 mb-4">
        <!-- Actividad Reciente -->
        <div class="card mb-4">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-history me-2"></i>
                    Actividad Reciente
                </h6>
            </div>
            <div class="card-body">
                <div class="timeline">
                    <div class="d-flex mb-3">
                        <div class="bg-success rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 32px; height: 32px;">
                            <i class="fas fa-file-invoice text-white" style="font-size: 12px;"></i>
                        </div>
                        <div>
                            <p class="mb-0 small"><strong>Factura generada</strong></p>
                            <small class="text-muted">E-commerce - $3,500 - Hace 1 hora</small>
                        </div>
                    </div>
                    <div class="d-flex mb-3">
                        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 32px; height: 32px;">
                            <i class="fas fa-comment text-white" style="font-size: 12px;"></i>
                        </div>
                        <div>
                            <p class="mb-0 small"><strong>Comentario recibido</strong></p>
                            <small class="text-muted">Desarrollador - Hace 3 horas</small>
                        </div>
                    </div>
                    <div class="d-flex mb-3">
                        <div class="bg-info rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 32px; height: 32px;">
                            <i class="fas fa-calendar text-white" style="font-size: 12px;"></i>
                        </div>
                        <div>
                            <p class="mb-0 small"><strong>Reunión programada</strong></p>
                            <small class="text-muted">Revisión de avances - Mañana 2:00 PM</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Acciones Rápidas -->
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-bolt me-2"></i>
                    Acciones Rápidas
                </h6>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <button class="btn btn-sena-outline btn-sm">
                        <i class="fas fa-plus me-2"></i>Nuevo Proyecto
                    </button>
                    <button class="btn btn-sena-outline btn-sm">
                        <i class="fas fa-file-contract me-2"></i>Ver Contratos
                    </button>
                    <button class="btn btn-sena-outline btn-sm">
                        <i class="fas fa-calendar me-2"></i>Programar Reunión
                    </button>
                    <button class="btn btn-sena-outline btn-sm">
                        <i class="fas fa-download me-2"></i>Descargar Facturas
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Contratos y Facturación -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-file-contract me-2"></i>
                    Contratos y Facturación
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <div class="card border-primary h-100">
                            <div class="card-body">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                                        <i class="fas fa-file-contract text-white"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0">E-commerce Corporativo</h6>
                                        <small class="text-muted">Contrato #CTR-001</small>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between mb-1">
                                        <small>Valor Total:</small>
                                        <small class="text-primary fw-bold">$12,500</small>
                                    </div>
                                    <div class="d-flex justify-content-between mb-1">
                                        <small>Pagado:</small>
                                        <small class="text-success">$7,500</small>
                                    </div>
                                    <div class="d-flex justify-content-between mb-2">
                                        <small>Pendiente:</small>
                                        <small class="text-warning">$5,000</small>
                                    </div>
                                </div>
                                <div class="d-flex gap-2">
                                    <button class="btn btn-sena btn-sm flex-fill">
                                        <i class="fas fa-eye me-1"></i>Ver Contrato
                                    </button>
                                    <button class="btn btn-sena-outline btn-sm">
                                        <i class="fas fa-download"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <div class="card border-warning h-100">
                            <div class="card-body">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="bg-warning rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                                        <i class="fas fa-file-contract text-white"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0">Sistema de Facturación</h6>
                                        <small class="text-muted">Contrato #CTR-002</small>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between mb-1">
                                        <small>Valor Total:</small>
                                        <small class="text-primary fw-bold">$8,200</small>
                                    </div>
                                    <div class="d-flex justify-content-between mb-1">
                                        <small>Pagado:</small>
                                        <small class="text-success">$2,000</small>
                                    </div>
                                    <div class="d-flex justify-content-between mb-2">
                                        <small>Pendiente:</small>
                                        <small class="text-warning">$6,200</small>
                                    </div>
                                </div>
                                <div class="d-flex gap-2">
                                    <button class="btn btn-sena btn-sm flex-fill">
                                        <i class="fas fa-eye me-1"></i>Ver Contrato
                                    </button>
                                    <button class="btn btn-sena-outline btn-sm">
                                        <i class="fas fa-download"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <div class="card border-info h-100">
                            <div class="card-body">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="bg-info rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                                        <i class="fas fa-file-contract text-white"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0">App de Delivery</h6>
                                        <small class="text-muted">Contrato #CTR-003</small>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between mb-1">
                                        <small>Valor Total:</small>
                                        <small class="text-primary fw-bold">$15,800</small>
                                    </div>
                                    <div class="d-flex justify-content-between mb-1">
                                        <small>Pagado:</small>
                                        <small class="text-success">$5,000</small>
                                    </div>
                                    <div class="d-flex justify-content-between mb-2">
                                        <small>Pendiente:</small>
                                        <small class="text-warning">$10,800</small>
                                    </div>
                                </div>
                                <div class="d-flex gap-2">
                                    <button class="btn btn-sena btn-sm flex-fill">
                                        <i class="fas fa-eye me-1"></i>Ver Contrato
                                    </button>
                                    <button class="btn btn-sena-outline btn-sm">
                                        <i class="fas fa-download"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Métricas Financieras -->
<div class="row">
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-chart-pie me-2"></i>
                    Distribución de Inversión
                </h6>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-center align-items-center" style="height: 200px;">
                    <div class="text-center">
                        <div class="mb-3">
                            <i class="fas fa-chart-pie fa-4x" style="color: var(--sena-green);"></i>
                        </div>
                        <p class="text-muted">Inversión por proyecto</p>
                        <small class="text-muted">E-commerce: 27% | Facturación: 18% | Delivery: 35% | Otros: 20%</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-chart-line me-2"></i>
                    Flujo de Caja
                </h6>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-center align-items-center" style="height: 200px;">
                    <div class="text-center">
                        <div class="mb-3">
                            <i class="fas fa-chart-line fa-4x" style="color: var(--sena-blue);"></i>
                        </div>
                        <p class="text-muted">Tendencia de pagos</p>
                        <div class="h3 text-success mb-2">$14,500</div>
                        <small class="text-muted">Total recibido este mes</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
